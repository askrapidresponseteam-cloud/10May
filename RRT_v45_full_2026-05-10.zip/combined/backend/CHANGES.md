# RRT Backend v45 - patched

This is the v45 backend codebase (Cloud Functions + Storage rules) with
the fixes from the audit applied. Two files changed: `functions/index.js`
and `storage.rules`.

After unzipping, deploy with:

```bash
firebase deploy --only functions,storage
```

The `--only` flag matters - the patched `index.js` adds new scheduled
functions (`purgeSosMediaAtMidnightIST`, `purgeChatMediaAtMidnightIST`)
that won't deploy with `--only functions:api`.

---

## Files changed

### `functions/index.js`

Many distinct fixes; full list below grouped by area.

#### SOS lifecycle - the bug the user originally reported

The user's first report was: trigger SOS → add photo + voice → stop →
trigger again → second SOS shows the first SOS's photo/voice.

Root cause: `sos_alerts/{senderId}` is a single doc reused across
sessions. `set(..., {merge: true})` on stop only wrote `active: false`;
photo_urls and voice_url survived into the next trigger. Storage bytes
were also never cleaned up.

Fixes applied:
- `storeSOSAlert`: now resets `seen_by`, `photo_urls`, and `voice_url`
  on every trigger (active=true) AND clears them on stop (active=false).
  Belt-and-suspenders so a missed stop never poisons the next trigger.
- New shared helper `purgeSosMedia(sender_id)` walks both
  `sos_photos/{sender_id}/` and `sos_voice/{sender_id}/` and deletes
  every object. Best-effort, idempotent, swallows errors.
- Manual stop, 60-min Cloud Task auto-expire, and hourly fallback all
  now call `purgeSosMedia` before/around the active=false write.
- New `purgeSosMediaAtMidnightIST` scheduled function runs daily at
  00:00 IST as a safety net for orphan bytes (anything older than
  75min OR whose parent alert is inactive gets deleted).

#### SOS expire - other bugs

- `SCHEDULE_CONFIG.ALERT_EXPIRATION_CHECK_INTERVAL` was `'every 12 hours'`
  but the comment said "every hour". Set to `'every 1 hours'`. The
  hourly fallback is the safety net for stuck alerts the 60-min Cloud
  Task missed; running it 2x/day made stuck alerts visible to
  responders for up to 12 hours.
- SOS trigger order: `storeSOSAlert(true)` now runs BEFORE
  `admin.messaging().send()`. Previously the FCM push went out first,
  responder devices opened the app, queried `sos_alerts/{senderId}`,
  and either found it missing or read stale fields from a prior cycle.
- Auto-expire and hourly fallback (`expireOldAlerts`) now both call
  the new `sendSOSResolutionFcm` helper. Previously only manual stop
  sent the "Emergency Resolved" push, so a 60-min auto-expired alert
  left responder devices showing the red banner forever.
- `expireOldAlerts` previously only flipped `active: false` and didn't
  clean up media at all. Now it clears `photo_urls`/`voice_url` in the
  batch and calls `purgeSosMedia` per sender.

#### Photo/voice attach

- `/sos/attach-photo` had a TOCTOU race - read length, check `< 3`,
  arrayUnion. Two parallel calls could both pass the check and end
  up with 4+ photos. Now wrapped in `runTransaction` so the limit
  check and append are atomic.
- The single shared `mediaAttachRateLimiter` was applied to BOTH
  attach AND detach calls. A user adding a blurry photo and
  immediately tapping delete would silently 429. Split into separate
  `mediaAttachRateLimiter` (2s) and `mediaDetachRateLimiter` (0.5s).
- Auto-expire was clearing `photo_urls` but not `voice_url` - fixed.

#### Chat - send-message

The `messages` array was unbounded on a single Firestore document.
Firestore docs cap at 1MB. Without bounds, sends would silently start
failing once a conversation grew past that limit.

- Added 200-message cap (`CHAT_MAX_MESSAGES_PER_CONV`). When the cap
  is hit, oldest messages are dropped to make room.
- Wrapped append in `runTransaction` so the cap check and write are
  atomic. (Also drops `arrayUnion`'s deep-equality dedupe, which
  could silently swallow same-millisecond messages.)
- Strict input validation: `text` must be a string, capped at 1000
  chars AND 4000 UTF-8 bytes. Rejects objects/arrays that would
  crash the Flutter client on cast.
- Per-FID rate limit (`chatSendRateLimiter`, 0.5s). Already-defined
  but previously never wired in.
- Logged warning at 150 msgs (approaching cap) and on every drop.

#### Chat - mark-seen

- `/sos/mark-seen` used `batch.update` which fails the entire batch
  if any single doc is missing. A responder marking 50 alerts where
  one had auto-expired would have all 50 fail silently. Switched to
  `Promise.allSettled` per-doc; missing docs fail individually and
  successful ones still go through.
- Strict input validation + per-FID rate limit added alongside.

#### Chat - new media feature

Brand new feature: photos and voice notes can now be attached to chat
messages, with the same retention policy as SOS media (deleted when
the underlying SOS ends).

- Four new endpoints: `/chat/attach-photo`, `/chat/detach-photo`,
  `/chat/attach-voice`, `/chat/detach-voice`. All transactional.
- New helpers `purgeChatMedia(conv_id)` and
  `purgeChatMediaForSosOwner(sender_id)`.
- Wired into all three SOS termination paths (manual stop, auto-expire,
  hourly fallback) so chat media dies on the same lifecycle as SOS
  media.
- Daily 00:00 IST chat wipe now also purges `chat_photos/{conv_id}/`
  and `chat_voice/{conv_id}/` per-conversation before deleting the
  conversation document.
- New `purgeChatMediaAtMidnightIST` scheduled function as the
  daily safety-net sweep.
- Caps: max 20 photos and 5 voice notes per conversation.
- Sender-only delete: only the original poster can detach their
  own media, server-enforced.
- Note: there is no client UI for this yet. The backend is ready
  and waiting; the Flutter side needs work.

#### Admin endpoints - district scoping

The audit found that admin destructive endpoints (block-user,
unblock-user, delete-user) had no district scoping - a district admin
in Mangalore could block/unblock/delete a user in any other district.

- All three now call `assertAdminCanActOnDistrict(scope, target.district)`
  before performing the action. Super admins bypass; district admins
  must have the target's district in their `assignedDistricts`.

#### Admin/delete-user - media purge

- Previously left the user's photos/voice/chat-media on Storage. Now
  calls `purgeSosMedia` and `purgeChatMedia` for every conversation
  the user participated in. Same retention policy as
  `/delete-user-data`.

#### /delete-user-data - completeness

Previously only deleted from `sos_alerts` and `subscribed_users`,
leaving:
- `blocked_users` records (so a deleted user stayed blocked)
- `sos_conversations` (chat history persisted forever for the other party)
- Storage bytes under `sos_photos/{fid}/` and `sos_voice/{fid}/`

All four are now cleaned up. Each cleanup step has its own try/catch
so a single failure doesn't block the rest.

### `storage.rules`

Added two new prefix matches to support chat-attached media:

- `chat_photos/{convId}/{filename}` - same shape as SOS rules, JPEG
  only, 10MB cap.
- `chat_voice/{convId}/{filename}` - audio/mp4 (.m4a), 5MB cap.

Both are keyed on `convId` rather than FID because chat is two-way -
either participant can attach. The conversation owns the bytes.

The same App Check TODO carries forward: read is open, delete is open
to clients (matching SOS prefixes). Real auth/integrity hardening is
the App Check cluster (audit issues #19-#27, deliberately deferred).

---

## Audit issues addressed

| # | Issue | Status |
|---|---|---|
|  1 | Photos/voice from prior SOS leaked into new SOS | ✅ |
|  2 | Media not deleted from Storage on SOS end | ✅ |
|  3 | Daily 00:00 IST cleanup sweep | ✅ |
|  4 | Hourly fallback running every 12h instead of 1h | ✅ |
|  5 | SOS trigger order race (FCM before Firestore) | ✅ |
|  6 | Photo attach TOCTOU race | ✅ |
|  7 | Detach blocked by attach rate-limiter | ✅ |
|  8 | Chat messages array unbounded | ✅ |
|  9 | mark-seen batch fails on missing doc | ✅ |
| 10 | Auto-expire / hourly fallback don't send "Resolved" FCM | ✅ |
| 11 | delete-user-data incomplete | ✅ |
| 15 | Admin destructive endpoints not district-scoped | ✅ |
| 16 | admin/delete-user doesn't purge media | ✅ |

Frontend-only fixes (12-14, 17, 18) are in the matching client zip.

Issues 19-27 (App Check / auth architecture cluster) are deliberately
deferred. They need a coordinated mobile + backend + rules change
plus a multi-week soak window for old apps to update before
enforcement can flip on.

---

## Deploy

```bash
firebase deploy --only functions,storage
```

Verify the new schedules registered:

```bash
gcloud scheduler jobs list --location=asia-south1 \
  | grep -E "purgeSosMedia|purgeChatMedia|wipeChats|expireOldAlerts"
```

You should see four entries.

To manually trigger the daily sweeps for testing without waiting for
midnight:

```bash
gcloud scheduler jobs run \
  firebase-schedule-purgeSosMediaAtMidnightIST-asia-south1 \
  --location=asia-south1
```

(Job names may differ slightly; `gcloud scheduler jobs list` is
authoritative.)

---

## Test plan

1. **Original bug verification:**
   - Trigger SOS, add photo + voice, stop, trigger again. Strip
     should be empty, voice player should show no recording.
   - Check Firebase Storage console: `sos_photos/{your_fid}/` and
     `sos_voice/{your_fid}/` should be empty within seconds of stop.

2. **Auto-expire flow:**
   - Trigger SOS, add media, kill the app, wait 60 minutes.
   - Bytes in Storage should be gone.
   - Responders' active-alert push should clear (resolution FCM sent).

3. **Hourly fallback:**
   - Manually create a stuck alert in Firestore (active: true,
     timestamp older than 1h). Wait for the next hourly run or
     trigger via gcloud.
   - Alert flips to inactive, media purged, resolution FCM sent.

4. **Chat unbounded:**
   - Send 199 messages in a conversation - all kept.
   - Send #200, then #201 - oldest gets dropped, log shows the
     warning, conversation stays under 200.

5. **Admin scoping:**
   - As a district admin assigned to "udupi", call /admin/delete-user
     with a user from "mangalore". Should 403.
   - Same call as a super-admin should succeed.

6. **Daily sweeps:**
   - Manually upload a junk file to `sos_photos/test123/foo.jpg`.
   - Trigger `purgeSosMediaAtMidnightIST` via gcloud.
   - File should be gone.

If any of these fail, the per-step logs in Cloud Functions logs
make it possible to identify which assumption broke.

---

## Chat-media UI integration (2026-05-06, post-deploy)

After the audit fixes deployed and were tested, three additional changes
to support the chat photo and chat voice UI features in the client.

### `functions/index.js`

- `CHAT_MAX_PHOTOS_PER_CONV` lowered from 20 → 3. Matches the spec the
  client uses: capture-only photo, max 3 per active SOS session.
- `CHAT_MAX_VOICE_PER_CONV` lowered from 5 → 4. Same spec rationale.
- `/chat/attach-photo`: when caption is empty, the message's `text`
  field gets a `📷 Photo` fallback. Older client builds (still on
  2.1.13+48 in production until users update) don't recognise
  `kind=='photo'` and would render an empty bubble without this. New
  clients ignore the text field for kind==photo and render the photo.
- `/chat/attach-voice`: similar fallback, `🎙 Voice note (Xs)` (with
  duration if available, else just `🎙 Voice note`).
- `purgeChatMedia(conv_id)` extended: in addition to deleting Storage
  objects, it now also strips photo/voice messages from the conv
  doc's `messages` array. This implements the "per active SOS
  session" cap reset - a new SOS in the same conversation gets fresh
  slots (3 photos / 4 voice) rather than inheriting the previous
  session's references. Text and location messages are preserved so
  the chat-history download still produces a coherent transcript.

### Deploy

Same command as before; no new functions, just updated existing ones:

```bash
firebase deploy --only functions --project rrt-sos
```

Expected output: 5 functions updated (api, expireOldAlertsScheduled,
wipeChatsAtMidnightIST, purgeSosMediaAtMidnightIST,
purgeChatMediaAtMidnightIST). 2-3 minute deploy. No `npm install`
needed (no dep changes). Storage rules unchanged.
