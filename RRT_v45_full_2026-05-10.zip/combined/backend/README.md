# RRT Cloud Functions

Backend API for **Rapid Response Team** mobile app — a community-based
SOS alert system that sends emergency notifications to nearby users via
Firebase Cloud Messaging.

**Firebase Project**: `rrt-sos`

## What it does

- 🚨 Sends SOS alerts to users in specific districts via FCM
- 📷 Attaches user-uploaded photos and voice clips to active alerts
- 💬 Brokers 1:1 chat between SOS senders and responders
- 📍 Resolves district from GPS coordinates
- 🚫 Blocks/unblocks abusive users (shadow-blocked: backend returns 200 but no FCM)
- 🌙 Wipes chats nightly at 00:00 IST (data minimisation)
- ⏰ Auto-expires alerts 60 min after creation (Cloud Tasks)
- 📊 Stores alert snapshots for admin dashboard
- 👥 Manages admin accounts and permissions
- 📧 Sends welcome emails to new admins, plus app contact-form emails

## Deploy

**Read [DEPLOY_GUIDE.md](DEPLOY_GUIDE.md) before deploying.** This release
is paired with a client release; the order matters.

Quick reference for routine redeploys (after the v45 cutover):
```sh
cd functions && npm install && cd ..
firebase deploy --only firestore,storage,functions
```

### Prerequisites
- Node.js 24+
- Firebase CLI: `npm install -g firebase-tools`
- Logged into the `rrt-sos` project: `firebase use rrt-sos`

### Secrets

Set Gmail credentials for admin welcome emails and the contact form:
```bash
firebase functions:secrets:set GMAIL_USER     # askrapidresponseteam@gmail.com
firebase functions:secrets:set GMAIL_PASS     # Gmail app password
firebase functions:secrets:set OLA_MAPS_API_KEY  # for /geocode/district
```

## API Endpoints

### Public (mobile app)
- `GET /health` — Health check
- `GET /app-version` — Force-update version info from `app_config/version`
- `GET /geocode/district?lat=<lat>&lng=<lng>` — Reverse geocode → district name
- `POST /sos` — Send / stop SOS alert
- `POST /sos/attach-photo` — Attach uploaded photo URL to alert (NEW in v45)
- `POST /sos/detach-photo` — Detach photo (also deletes from Storage) (NEW in v45)
- `POST /sos/attach-voice` — Attach voice URL (NEW in v45)
- `POST /sos/detach-voice` — Detach voice (NEW in v45)
- `POST /sos/mark-seen` — Batch-mark alerts as seen by FID
- `POST /subscribe-user` — Upsert subscribed_users on district subscribe
- `POST /delete-user-data` — Self-delete (FID-rate-limited, no Firebase Auth)
- `POST /chat/initiate` — Create or update a 1:1 conversation
- `POST /chat/send-message` — Append a message and notify the other party
- `POST /feedback` — Help/contact form (sends email)

### Internal (Cloud Tasks only)
- `POST /sosAutoExpire` — Auto-expire handler, gated by Cloud Tasks header

### Admin (Firebase Auth required)
- `GET /admin/profile` — Current admin profile
- `GET /admin/users` — Paginated user list
- `POST /admin/block-user`, `POST /admin/unblock-user`, `GET /admin/blocked-users`
- `GET /admin/sos-alerts` — All alerts
- `POST /admin/delete-user` — Admin-initiated user deletion

### Super Admin (custom claim required)
- `GET /admin/admins`, `POST /admin/admins`, `PUT /admin/admins/:email`, `DELETE /admin/admins/:email`

### Test
- `POST /test-push` — Send a synthetic push notification (super admin only)

## Scheduled functions

- **`expireOldAlertsScheduled`** — Sweeps for orphaned active alerts hourly
- **`wipeChatsAtMidnightIST`** — Daily chat wipe at 00:00 IST (NEW in v45)

## Firestore Security Rules

The authoritative rules file is `functions/firestore-security-rules.rules`.
It's wired into `firebase.json` so `firebase deploy` picks it up.

Mobile clients are NOT Firebase Auth users — they're identified by Firebase
Installation ID. Reads are open on `sos_alerts`, `sos_conversations`,
`subscribed_users`. Writes to all of these go through Cloud Functions
(admin SDK). The only collection clients write to directly is
`sos_feedback` (post-SOS feedback), and the doc ID is composite
(`{senderId}_{activatedAtMillis}`) to prevent displacement.

## Storage rules

`storage.rules` allowlists:
- `sos_photos/{senderId}/*.jpg` — `image/jpeg`, ≤10 MB
- `sos_voice/{senderId}/*.m4a` — `audio/mp4`, ≤5 MB

Everything else is denied.

## Configuration

### Feature flags (`functions/index.js`)

```javascript
const FEATURES = {
  ENABLE_SOS_ALERT_SNAPSHOT: true,  // Store alerts in Firestore
  BLOCKED_USERS: true               // Always keep enabled
};
```

### Super admins (`functions/index.js`)

Edit the `SUPER_ADMINS` array to manage super admin emails:
```javascript
const SUPER_ADMINS = [
  'shamanthknr@gmail.com',
  'karthik.dhanya11@gmail.com',
  'gandhim@exmpls.sansad.in'
];
```

## Local development

```bash
cd functions
npm run serve
```

## Tech stack

- Node.js 24 + Express.js
- Firebase Cloud Functions (v2)
- Cloud Firestore + Cloud Storage
- Firebase Cloud Messaging
- Cloud Tasks (auto-expire)
- Cloud Scheduler (chat wipe, alert sweeper)
- Nodemailer (Gmail SMTP)
