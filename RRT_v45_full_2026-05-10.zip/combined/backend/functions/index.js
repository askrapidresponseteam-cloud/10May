const functions = require('firebase-functions');
const {onSchedule} = require('firebase-functions/v2/scheduler');
const {defineString} = require('firebase-functions/params');
const express = require('express');
const admin = require('firebase-admin');
const cors = require('cors');
const helmet = require('helmet');
const nodemailer = require('nodemailer');
const {CloudTasksClient} = require('@google-cloud/tasks');

// Define Firebase secrets for Gmail credentials
const gmailUser = defineString('GMAIL_USER');
const gmailPass = defineString('GMAIL_PASS');
const olaMapsApiKey = defineString('OLA_MAPS_API_KEY');

const app = express();

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// Initialize Firebase Admin SDK (no credentials needed in Cloud Functions)
admin.initializeApp();
console.log('✅ Firebase Admin SDK initialized successfully');

// ============================================================================
// RATE LIMITER - In-memory per sender_id
// Max 1 sos_alert per 60 seconds per sender. Stop requests are not rate limited.
// ============================================================================
const sosRateLimitMap = new Map(); // sender_id -> last sos_alert timestamp (ms)
const SOS_RATE_LIMIT_MS = 60 * 1000; // 60 seconds

function isSosRateLimited(senderId) {
  const now = Date.now();
  const lastAlert = sosRateLimitMap.get(senderId);
  if (lastAlert && (now - lastAlert) < SOS_RATE_LIMIT_MS) {
    return true;
  }
  sosRateLimitMap.set(senderId, now);
  // Clean up old entries every 100 requests to prevent memory leak
  if (sosRateLimitMap.size > 1000) {
    for (const [id, ts] of sosRateLimitMap.entries()) {
      if (now - ts > SOS_RATE_LIMIT_MS) sosRateLimitMap.delete(id);
    }
  }
  return false;
}

// ============================================================================
// GENERIC RATE LIMITER
// Used by endpoints that have no Firebase Auth and identify the caller
// only by a self-asserted FID. The pattern is: caller can do action X for
// FID Y at most once per windowMs. Per-FID, in-memory, single-instance.
// ============================================================================
function makeRateLimiter(windowMs, maxEntries = 5000) {
  const map = new Map(); // key -> last action timestamp (ms)
  return {
    isLimited(key) {
      const now = Date.now();
      const last = map.get(key);
      if (last && (now - last) < windowMs) return true;
      map.set(key, now);
      // Lazy GC when the map gets large
      if (map.size > maxEntries) {
        for (const [k, ts] of map.entries()) {
          if (now - ts > windowMs) map.delete(k);
        }
      }
      return false;
    },
    // For testing: forget a key (so we don't trigger limits in tests)
    forget(key) { map.delete(key); },
  };
}

// Per-FID delete cooldown. Mobile users aren't authenticated; we identify
// the caller by self-asserted FID. 1h is loose enough for legitimate
// retry, tight enough to make FID enumeration uneconomical.
const deleteRateLimiter = makeRateLimiter(60 * 60 * 1000); // 1 hour

// Per-FID media attach cooldown. Each photo/voice URL must be attached
// individually; bursts should be 4-5 (3 photos + 1 voice) within seconds,
// not hundreds. We allow 1 attach per FID per 2 seconds. For a normal
// user this never trips. For a malicious caller spraying URLs at random
// alerts, it caps damage to ~1800 attempts/hour.
const mediaAttachRateLimiter = makeRateLimiter(2 * 1000); // 2 seconds

// Per-FID media DETACH cooldown. Separate from attach because users
// commonly attach a photo and then immediately tap delete (e.g. they
// took a blurry shot and want to redo it). Sharing one limiter between
// attach and detach made that delete return 429 silently and leave the
// orphan photo on the alert. Detach is also cheap server-side, so we
// can afford a tighter window here.
const mediaDetachRateLimiter = makeRateLimiter(500); // 0.5 seconds

// Per-FID chat send cooldown. Real conversations don't exceed a few
// messages per second; this caps spam at 1 msg / 500ms per sender. Far
// below typing speed but blocks programmatic flood of the messages
// array (which lives inside a single 1MB-capped Firestore doc).
const chatSendRateLimiter = makeRateLimiter(500); // 0.5 seconds

// ============================================================================
// EMAIL CONFIGURATION - Nodemailer setup
// ============================================================================

/**
 * Send welcome email to newly created admin
 * @param {string} email - Admin email address
 * @param {string} password - Temporary password
 * @param {string[]} assignedDistricts - List of assigned districts (empty for super-admin)
 * @param {string} role - Admin role: 'admin' or 'super-admin'
 */
async function sendWelcomeEmail(email, password, assignedDistricts, role = 'admin') {
  // Create transporter at runtime to access secrets properly
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: gmailUser.value(),
      pass: gmailPass.value()
    }
  });

  const isSuperAdminRole = role === 'super-admin';
  const roleLabel = isSuperAdminRole ? 'Super Admin' : 'Admin';
  const districtsList = isSuperAdminRole
    ? 'All Districts'
    : (assignedDistricts.length > 0
        ? assignedDistricts.map(d => d.toUpperCase()).join(', ')
        : 'None assigned');
    
  const mailOptions = {
    from: 'RRT Admin <' + gmailUser.value() + '>',
    to: email,
    subject: '🔐 Your RRT Admin Account - Login Details',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to RRT Admin Dashboard</h2>
        
        <p>Your administrator account has been created successfully.</p>
        
        <div style="background: #f5f5f5; padding: 20px; border-radius: 5px; margin: 20px 0;">
          <h3 style="margin-top: 0;">Login Credentials</h3>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Temporary Password:</strong> <code style="background: white; padding: 5px 10px; border-radius: 3px;">${password}</code></p>
          <p><strong>Role:</strong> ${roleLabel}</p>
          <p><strong>Assigned Districts:</strong> ${districtsList}</p>
        </div>
        
        <p><strong>Next Steps:</strong></p>
        <ol>
          <li>Login to the Admin Dashboard</li>
          <li>Use the credentials above</li>
          <li>Change your password using "Reset Password" option on the login screen</li>
        </ol>
        
        <p style="color: #666; font-size: 12px; margin-top: 30px;">
          This is an automated email. If you did not request this account, please contact support.
        </p>
      </div>
    `,
    text: `
Welcome to RRT Admin Dashboard

Your administrator account has been created successfully.

LOGIN CREDENTIALS
Email: ${email}
Temporary Password: ${password}
Role: ${roleLabel}
Assigned Districts: ${districtsList}

NEXT STEPS
1. Login to the Admin Dashboard
2. Use the credentials above
3. Change your password using "Reset Password" option on the login screen

This is an automated email. If you did not request this account, please contact support.
    `
  };

  await transporter.sendMail(mailOptions);
}

// ============================================================================
// FEATURE FLAGS - Toggle features to control costs
// ============================================================================
const FEATURES = {
  ENABLE_SOS_ALERT_SNAPSHOT: true,  // Set to false to disable SOS alert snapshot storage for admin dashboard
  BLOCKED_USERS: true               // Always keep true - critical security feature
};

// ============================================================================
// CLOUD TASKS CONFIGURATION
// ============================================================================
const CLOUD_TASKS_CONFIG = {
  PROJECT: 'rrt-sos',
  LOCATION: 'us-central1',
  QUEUE: 'sos-alert-expiry',
  FUNCTION_URL: 'https://us-central1-rrt-sos.cloudfunctions.net/api/sosAutoExpire',
  SOS_EXPIRY_DELAY_SECONDS: 60 * 60  // 1 hour
};
// ============================================================================
// SCHEDULED FUNCTION CONFIGURATION
// ============================================================================
const SCHEDULE_CONFIG = {
  ALERT_EXPIRATION_CHECK_INTERVAL: 'every 1 hours',  // How often to check for expired alerts (cron syntax or 'every X hours/minutes'). Was 'every 12 hours' which made stuck alerts visible to responders for up to 12h between runs. The 60-min Cloud Task auto-expire is the primary path; this is the fallback when that fails, and needs to run frequently enough to catch the gap.
  ALERT_EXPIRATION_THRESHOLD_MS: 60 * 60 * 1000      // How old an alert must be to expire (default: 1 hour in milliseconds)
};

// ============================================================================
// FIRESTORE TTL CONFIGURATION
// ============================================================================
const FIRESTORE_TTL_CONFIG = {
  SOS_ALERT_HISTORY_DAYS: 180  // sos_alert_history documents older than this are auto-deleted by Firestore TTL policy
};

// ============================================================================
// DATABASE OPERATIONS - Centralized Firestore operations
// ============================================================================

/**
 * Check if a sender is blocked (CRITICAL - always enabled)
 */
async function isSenderBlocked(sender_id) {
  if (!FEATURES.BLOCKED_USERS) return false;
  
  try {
    const blockedDoc = await admin.firestore()
      .collection('blocked_users')
      .doc(sender_id)
      .get();
    
    return blockedDoc.exists && blockedDoc.data()?.blocked === true;
  } catch (error) {
    console.error('Error checking blocked status:', error);
    // Fail open or closed depending on your preference
    return false; // Fail open - allow request if check fails
  }
}

/**
 * Reverse geocode lat/lng using Ola Maps to extract the district name.
 * Returns a lowercase_underscore district key (e.g. "dakshina_kannada") on success,
 * or null if the district cannot be determined.
 *
 * @param {number} lat - Latitude
 * @param {number} lng - Longitude
 * @returns {Promise<string|null>} district key or null
 */
async function reverseGeocodeDistrict(lat, lng) {
  try {
    const apiKey = olaMapsApiKey.value();
    if (!apiKey) {
      console.warn('⚠️  OLA_MAPS_API_KEY not set, skipping reverse geocode');
      return null;
    }

    const url = `https://api.olamaps.io/places/v1/reverse-geocode?latlng=${lat},${lng}&api_key=${apiKey}`;
    const response = await fetch(url);

    if (!response.ok) {
      console.error(`❌ Ola Maps reverse geocode failed: ${response.status} ${response.statusText}`);
      return null;
    }

    const data = await response.json();

    // Ola Maps returns results[0].address_components similar to Google Maps format.
    const result = data?.results?.[0];
    if (!result) return null;

    const components = result.address_components || [];

    // Prefer level 2 (actual district/zone) over level 3 (sub-district/tehsil)
    const districtComp =
      components.find(c => c.types?.includes('administrative_area_level_2')) ||
      components.find(c => c.types?.includes('administrative_area_level_3'));

    if (!districtComp) {
      console.warn('⚠️  District component not found in Ola Maps response');
      return null;
    }

    // Normalise to lowercase with underscores: "Dakshina Kannada" -> "dakshina_kannada"
    const districtKey = districtComp.long_name
      .trim()
      .toLowerCase()
      .replace(/\s+/g, '_');

    console.log(`🗺️  Reverse geocoded district: ${districtComp.long_name} -> "${districtKey}"`);
    return districtKey;
  } catch (err) {
    console.error('❌ Ola Maps reverse geocode error:', err.message);
    return null;
  }
}

/**
 * Delete every Storage object under sos_photos/{sender_id}/ and
 * sos_voice/{sender_id}/. Called from every SOS termination path so
 * media never outlives the alert: manual stop via /sos, the 60-min
 * Cloud Task auto-expire, the hourly fallback sweep, and the daily
 * leftover purge.
 *
 * Idempotent: if the prefix is already empty, this is a no-op.
 * Best-effort: per-file errors are swallowed so one stuck object can't
 * block the rest, and the outer try/catch ensures a Storage outage
 * never crashes the calling endpoint.
 *
 * Returns { photos, voice } counts of files deleted (0 if anything
 * went wrong - we don't surface storage errors to the client).
 *
 * @param {string} sender_id - Firebase Installation ID
 */
async function purgeSosMedia(sender_id) {
  let photos = 0;
  let voice = 0;
  try {
    const bucket = admin.storage().bucket();
    try {
      const [files] = await bucket.getFiles({ prefix: `sos_photos/${sender_id}/` });
      await Promise.all(files.map(f => f.delete().catch(() => {})));
      photos = files.length;
    } catch (e) {
      console.error(`⚠️ purgeSosMedia: photo cleanup failed for ${sender_id}: ${e.message}`);
    }
    try {
      const [voiceFiles] = await bucket.getFiles({ prefix: `sos_voice/${sender_id}/` });
      await Promise.all(voiceFiles.map(f => f.delete().catch(() => {})));
      voice = voiceFiles.length;
    } catch (e) {
      console.error(`⚠️ purgeSosMedia: voice cleanup failed for ${sender_id}: ${e.message}`);
    }
    if (photos > 0 || voice > 0) {
      console.log(`🧹 purgeSosMedia(${sender_id}): photos=${photos} voice=${voice}`);
    }
  } catch (e) {
    console.error(`⚠️ purgeSosMedia outer error for ${sender_id}: ${e.message}`);
  }
  return { photos, voice };
}

/**
 * Delete every Storage object under chat_photos/{conv_id}/ and
 * chat_voice/{conv_id}/. Mirror of purgeSosMedia but keyed on conversation
 * ID instead of sender FID, because chat media is two-way (either
 * participant can attach) and is therefore owned by the conversation,
 * not by either FID individually.
 *
 * Called from every chat termination path:
 *   - SOS termination (manual stop, 60-min auto-expire, hourly fallback) -
 *     via purgeChatMediaForSosOwner(sender_id), which fans out to every
 *     conversation with active_alert_owner == sender_id.
 *   - Daily 00:00 IST chat wipe - explicitly purges before deleting the
 *     conversation document itself.
 *   - Daily 00:00 IST media sweep - safety net for any orphans.
 *
 * Idempotent and best-effort; swallows errors so it cannot block a
 * calling endpoint.
 *
 * @param {string} conv_id - sos_conversations document ID
 */
async function purgeChatMedia(conv_id) {
  let photos = 0;
  let voice = 0;
  try {
    const bucket = admin.storage().bucket();
    try {
      const [files] = await bucket.getFiles({ prefix: `chat_photos/${conv_id}/` });
      await Promise.all(files.map(f => f.delete().catch(() => {})));
      photos = files.length;
    } catch (e) {
      console.error(`⚠️ purgeChatMedia: photo cleanup failed for ${conv_id}: ${e.message}`);
    }
    try {
      const [voiceFiles] = await bucket.getFiles({ prefix: `chat_voice/${conv_id}/` });
      await Promise.all(voiceFiles.map(f => f.delete().catch(() => {})));
      voice = voiceFiles.length;
    } catch (e) {
      console.error(`⚠️ purgeChatMedia: voice cleanup failed for ${conv_id}: ${e.message}`);
    }
    if (photos > 0 || voice > 0) {
      console.log(`🧹 purgeChatMedia(${conv_id}): photos=${photos} voice=${voice}`);
    }

    // Also strip photo and voice messages from the conv doc's messages
    // array. This implements the "per active SOS session" cap reset
    // the spec calls for - a new SOS in the same conversation gets
    // fresh slots (3 photos / 4 voice) instead of inheriting whatever
    // was attached during the previous session.
    //
    // Text and location messages are preserved so the chat history
    // download (chat-screen menu → "Download chat as text") still
    // produces a coherent transcript that includes everything except
    // the now-deleted media references.
    //
    // Best-effort: a Firestore failure here is logged but doesn't roll
    // back the Storage cleanup above. The orphan text-with-broken-URL
    // entries would render as "📷 Photo" / "🎙 Voice note (Xs)" via
    // the fallback text - inconvenient but not catastrophic.
    try {
      const convRef = admin.firestore().collection('sos_conversations').doc(conv_id);
      await admin.firestore().runTransaction(async (tx) => {
        const snap = await tx.get(convRef);
        if (!snap.exists) return;
        const data = snap.data() || {};
        const existing = Array.isArray(data.messages) ? data.messages : [];
        const filtered = existing.filter(m => m && m.kind !== 'photo' && m.kind !== 'voice');
        if (filtered.length !== existing.length) {
          tx.update(convRef, { messages: filtered });
        }
      });
    } catch (e) {
      console.error(`⚠️ purgeChatMedia: messages strip failed for ${conv_id}: ${e.message}`);
    }
  } catch (e) {
    console.error(`⚠️ purgeChatMedia outer error for ${conv_id}: ${e.message}`);
  }
  return { photos, voice };
}

/**
 * Find every conversation whose alert is owned by this sender and purge
 * its chat media. Called from every SOS termination path so chat media
 * dies on the same lifecycle as SOS media.
 *
 * Uses a where('active_alert_owner', '==', sender_id) query instead of
 * scanning all conversations, so this stays cheap. Best-effort: a query
 * failure logs but doesn't throw - the daily media sweep is the safety
 * net.
 *
 * @param {string} sender_id - SOS alert owner FID
 */
async function purgeChatMediaForSosOwner(sender_id) {
  try {
    const snap = await admin.firestore()
      .collection('sos_conversations')
      .where('active_alert_owner', '==', sender_id)
      .get();
    if (snap.empty) return { conversations: 0, photos: 0, voice: 0 };
    let totalPhotos = 0;
    let totalVoice = 0;
    // Sequential to avoid overwhelming Storage with parallel listAll() ops.
    // Real-world fan-out is small (a sender's SOS typically has 0-5 chat
    // partners), so this is fine.
    for (const doc of snap.docs) {
      const r = await purgeChatMedia(doc.id);
      totalPhotos += r.photos;
      totalVoice += r.voice;
    }
    if (snap.size > 0 && (totalPhotos > 0 || totalVoice > 0)) {
      console.log(`🧹 purgeChatMediaForSosOwner(${sender_id}): convs=${snap.size} photos=${totalPhotos} voice=${totalVoice}`);
    }
    return { conversations: snap.size, photos: totalPhotos, voice: totalVoice };
  } catch (e) {
    console.error(`⚠️ purgeChatMediaForSosOwner error for ${sender_id}: ${e.message}`);
    return { conversations: 0, photos: 0, voice: 0 };
  }
}

/**
 * Send the "Emergency Resolved" FCM to the SOS sender's district topic.
 *
 * This used to live inline in the manual /sos stop branch. It has been
 * factored out so the same notification fires when an SOS ends through
 * any path:
 *   - Manual stop (sos_type === 'stop')
 *   - 60-minute Cloud Task auto-expire
 *   - Hourly fallback expireOldAlerts
 *
 * Without this, responder devices that received the original alert push
 * would keep showing the red banner in the notification tray indefinitely
 * even after the SOS ended on the server. The Firestore stream catches up
 * inside the app, but the OS-level push doesn't go away on its own.
 *
 * Best-effort: failures here log but never throw to the caller. The
 * caller has already done the authoritative state change (active=false),
 * so a missed notification is recoverable degradation, not a hard error.
 *
 * @param {object} args
 * @param {string} args.sender_id      - SOS sender FID
 * @param {string} args.district       - District topic key (e.g. "udupi")
 * @param {string} [args.userName]     - For body text. Falls back to "Someone"
 * @param {string} [args.userLocation] - For body text. Falls back to district
 * @param {string} [args.expiredBy]    - 'manual_stop' | 'cloud_task_ttl' |
 *                                       'scheduled_job'. Surfaces to clients
 *                                       in the data payload so they can
 *                                       distinguish (e.g. analytics).
 * @returns {Promise<{ok: boolean, messageId?: string, error?: string}>}
 */
async function sendSOSResolutionFcm({
  sender_id, district, userName, userLocation, expiredBy = 'unknown',
}) {
  if (!district) {
    console.warn(`⚠️ sendSOSResolutionFcm: no district for ${sender_id}, skipping`);
    return { ok: false, error: 'no_district' };
  }
  const safeName = (typeof userName === 'string' && userName.trim().length > 0)
    ? userName.trim()
    : 'Someone';
  const safeLocation = (typeof userLocation === 'string' && userLocation.trim().length > 0)
    ? userLocation.trim()
    : district.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

  const message = {
    topic: `district-${district}`,
    notification: {
      title: '✅ Emergency Resolved',
      body: `All good now. ${safeName} • ${safeLocation}`,
    },
    data: {
      type: 'sos_resolved',
      sender_id: sender_id,
      district: district,
      expired_by: expiredBy,
      timestamp: Date.now().toString(),
    },
    android: {
      priority: 'high',
      notification: {
        channelId: 'sos_alerts',
        icon: 'ic_notification',
        color: '#00FF00',
        sound: 'default',
        priority: 'high',
      },
    },
    apns: {
      headers: {
        'apns-priority': '10',
        'apns-push-type': 'alert',
      },
      payload: {
        aps: {
          alert: {
            title: '✅ Emergency Resolved',
            body: `All good now. ${safeName} • ${safeLocation}`,
          },
          sound: 'default',
        },
      },
    },
  };

  try {
    const messageId = await admin.messaging().send(message);
    console.log(`✅ Resolution FCM sent (${expiredBy}, district=${district}, sender=${sender_id}): ${messageId}`);
    return { ok: true, messageId };
  } catch (e) {
    console.error(`⚠️ sendSOSResolutionFcm failed (${expiredBy}, district=${district}, sender=${sender_id}): ${e.message}`);
    return { ok: false, error: e.message };
  }
}

/**
 * Store/Update SOS alert snapshot in Firestore for admin dashboard (OPTIONAL - can be disabled)
 * Uses sender_id as document ID for easy lookup and tabular display
 * 
 * @param {string} sender_id - Firebase Installation ID (used as document ID)
 * @param {boolean} active - true for SOS alert, false for stop
 * @param {object} location - GPS coordinates {latitude, longitude, accuracy}
 * @param {object} userInfo - User details {name, mobile_number, message}
 * @param {string} district - District name (e.g., "udupi", "mangalore")
 * @param {string} state - State extracted from user location (last component of location string)
 */
async function storeSOSAlert(sender_id, active, location = null, userInfo = null, district = null, state = null) {
  if (!FEATURES.ENABLE_SOS_ALERT_SNAPSHOT) {
    console.log('⏭️  SOS alert snapshot disabled');
    return false;
  }
  
  try {
    const alertData = {
      sender_id: sender_id,
      active: active,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    };
    
    // Only update location, userInfo, and district when creating/updating an active alert
    if (active && location) {
      alertData.location = location;
    }
    
    if (active && userInfo) {
      alertData.userInfo = {
        name: userInfo.name || 'Unknown',
        mobile_number: userInfo.phone || userInfo.mobile_number || 'N/A',
        message: userInfo.message || '',
        location: userInfo.location || ''
      };
      // Top-level approx_loc for mobile app display (from userInfo.location)
      alertData.approx_loc = userInfo.location || district || 'Unknown Location';
    }
    
    if (active && district) {
      alertData.district = district;
    }
    
    if (active && state) {
      alertData.state = state;
    }

    // Reset per-session fields so stale data from a previous SOS by the same
    // sender doesn't carry over. The sos_alerts doc is keyed by sender_id and
    // reused across SOS sessions, so set(..., { merge: true }) without
    // explicit resets here would leak photo_urls / voice_url / seen_by from
    // the prior session into the new one. Belt-and-suspenders: we also clear
    // these on stop below, but resetting here protects against the case where
    // a prior stop never ran (app crash, killed mid-flow, network failure).
    if (active) {
      alertData.seen_by = {};
      alertData.photo_urls = [];
      alertData.voice_url = admin.firestore.FieldValue.delete();
    } else {
      // On user-initiated stop, clear media URLs so the next SOS doesn't
      // surface them. Storage object cleanup happens via the auto-expire
      // task and the client-side purgeAll; this only clears the Firestore
      // pointers the responder UI reads from.
      alertData.photo_urls = [];
      alertData.voice_url = admin.firestore.FieldValue.delete();
    }

    // Use sender_id as document ID for easy updates
    await admin.firestore()
      .collection('sos_alerts')
      .doc(sender_id)
      .set(alertData, { merge: true });

    // Append an immutable event record to the history collection
    const historyData = {
      sender_id: sender_id,
      event: active ? 'triggered' : 'stopped',
      timestamp: admin.firestore.FieldValue.serverTimestamp(),
      ttl: new Date(Date.now() + FIRESTORE_TTL_CONFIG.SOS_ALERT_HISTORY_DAYS * 24 * 60 * 60 * 1000)
    };
    // district and userInfo are recorded for both triggered and stopped events
    if (district) historyData.district = district;
    if (userInfo) {
      historyData.userInfo = {
        name: userInfo.name || 'Unknown',
        mobile_number: userInfo.phone || userInfo.mobile_number || 'N/A',
        message: userInfo.message || '',
        location: userInfo.location || ''
      };
    }
    // location and state are only meaningful when the alert is triggered
    if (active) {
      if (state) historyData.state = state;
      if (location) historyData.location = location;
    }
    const historyRef = await admin.firestore()
      .collection('sos_alert_history')
      .add(historyData);

    if (active) {
      // Stamp the session ID so Cloud Tasks can validate ownership when the task fires
      await admin.firestore()
        .collection('sos_alerts')
        .doc(sender_id)
        .update({ active_session_id: historyRef.id });

      // Enqueue a Cloud Task to auto-expire this alert after 1 hour
      await enqueueSOSAutoExpire(sender_id, historyRef.id);
    }

    console.log(`📝 SOS alert ${active ? 'activated' : 'deactivated'} in Firestore for ${sender_id}`);
    return true;
  } catch (error) {
    console.error('⚠️  Failed to store SOS alert:', error);
    return false; // Don't fail the request if snapshot fails
  }
}

/**
 * Enqueue a Cloud Task to auto-expire an SOS alert after 1 hour.
 * The task carries a session_id so it can validate it still owns the current
 * alert when it fires — if the user stopped and re-triggered, the new task
 * owns a different session_id and this one will no-op.
 *
 * @param {string} sender_id - Firebase Installation ID (sos_alerts doc ID)
 * @param {string} session_id - The sos_alert_history doc ID stamped as active_session_id
 */
async function enqueueSOSAutoExpire(sender_id, session_id) {
  try {
    const client = new CloudTasksClient();
    const parent = client.queuePath(
      CLOUD_TASKS_CONFIG.PROJECT,
      CLOUD_TASKS_CONFIG.LOCATION,
      CLOUD_TASKS_CONFIG.QUEUE
    );

    const scheduleTime = new Date(Date.now() + CLOUD_TASKS_CONFIG.SOS_EXPIRY_DELAY_SECONDS * 1000);

    const task = {
      httpRequest: {
        httpMethod: 'POST',
        url: CLOUD_TASKS_CONFIG.FUNCTION_URL,
        headers: { 'Content-Type': 'application/json' },
        body: Buffer.from(JSON.stringify({ sender_id, session_id })).toString('base64')
      },
      scheduleTime: {
        seconds: Math.floor(scheduleTime.getTime() / 1000)
      }
    };

    const [response] = await client.createTask({ parent, task });
    console.log(`⏰ SOS auto-expire task enqueued for ${sender_id} (session: ${session_id}): ${response.name}`);
  } catch (error) {
    // Non-fatal: the scheduled job (expireOldAlerts) acts as a fallback
    console.error('⚠️ Failed to enqueue SOS auto-expire task:', error);
  }
}

/**
 * Block a user in Firestore (CRITICAL - always enabled)
 */
async function blockUser(sender_id, reason, blocked_by, district) {
  const blockData = {
    blocked: true,
    blockedAt: admin.firestore.FieldValue.serverTimestamp(),
    reason: reason || 'No reason provided',
    blockedBy: blocked_by || 'admin'
  };
  // Store district so unblock can verify admin scope even if the user's
  // subscribed_users record is later deleted (e.g. via /delete-user-data).
  // Without this, an unblock of a ghost record can't be scope-checked at
  // all, forcing us to either reject all such unblocks or allow them
  // unconditionally - both wrong.
  if (typeof district === 'string' && district.length > 0) {
    blockData.district = district.toLowerCase();
  }

  await admin.firestore()
    .collection('blocked_users')
    .doc(sender_id)
    .set(blockData);

  return blockData;
}

/**
 * Unblock a user in Firestore (CRITICAL - always enabled)
 */
async function unblockUser(sender_id) {
  await admin.firestore()
    .collection('blocked_users')
    .doc(sender_id)
    .delete();
}

/**
 * Get blocked user document (CRITICAL - always enabled)
 */
async function getBlockedUser(sender_id) {
  const doc = await admin.firestore()
    .collection('blocked_users')
    .doc(sender_id)
    .get();
  
  return doc.exists ? { id: doc.id, ...doc.data() } : null;
}

/**
 * List all blocked users (CRITICAL - always enabled)
 */
async function listBlockedUsers() {
  const snapshot = await admin.firestore()
    .collection('blocked_users')
    .where('blocked', '==', true)
    .orderBy('blockedAt', 'desc')
    .get();
  
  const blockedUsers = [];
  snapshot.forEach(doc => {
    blockedUsers.push({
      sender_id: doc.id,
      ...doc.data(),
      blockedAt: doc.data().blockedAt?.toDate().toISOString()
    });
  });
  
  return blockedUsers;
}

/**
 * Get all SOS alert snapshots for admin dashboard (OPTIONAL - can be disabled)
 * @param {boolean} activeOnly - If true, only return active alerts
 */
async function getSOSAlerts(activeOnly = false) {
  if (!FEATURES.ENABLE_SOS_ALERT_SNAPSHOT) {
    return [];
  }
  
  let query = admin.firestore().collection('sos_alerts');
  
  if (activeOnly) {
    query = query.where('active', '==', true);
  }
  
  const snapshot = await query.orderBy('timestamp', 'desc').get();
  
  const alerts = [];
  snapshot.forEach(doc => {
    const data = doc.data();
    alerts.push({
      sender_id: doc.id,
      active: data.active,
      district: data.district,
      location: data.location,
      userInfo: data.userInfo,
      timestamp: data.timestamp?.toDate().toISOString()
    });
  });
  
  return alerts;
}

/**
 * Expire old active SOS alerts (OPTIONAL - can be disabled)
 * Checks all active alerts and marks them as inactive if they exceed the threshold
 * @returns {object} Summary of expired alerts
 */
async function expireOldAlerts() {
  if (!FEATURES.ENABLE_SOS_ALERT_SNAPSHOT) {
    console.log('⏭️  Alert expiration disabled (SOS alert snapshot disabled)');
    return { expired: 0, checked: 0, enabled: false };
  }
  
  try {
    const now = Date.now();
    const thresholdTime = now - SCHEDULE_CONFIG.ALERT_EXPIRATION_THRESHOLD_MS;
    
    console.log(`🔍 Checking for alerts older than ${SCHEDULE_CONFIG.ALERT_EXPIRATION_THRESHOLD_MS / 1000 / 60} minutes`);
    
    // Query all active alerts
    const snapshot = await admin.firestore()
      .collection('sos_alerts')
      .where('active', '==', true)
      .get();
    
    const expiredAlerts = [];
    const batch = admin.firestore().batch();
    
    snapshot.forEach(doc => {
      const data = doc.data();
      const timestamp = data.timestamp?.toDate();
      
      if (timestamp && timestamp.getTime() < thresholdTime) {
        // Alert is older than threshold, mark for expiration AND clear
        // media URLs in the same write so the responder UI never sees a
        // stale photo/voice pointer. Storage purge happens after the
        // batch commits so we don't leak bytes when the doc claims they
        // were cleaned up.
        const alertRef = admin.firestore().collection('sos_alerts').doc(doc.id);
        batch.update(alertRef, {
          active: false,
          active_session_id: admin.firestore.FieldValue.delete(),
          photo_urls: [],
          voice_url: admin.firestore.FieldValue.delete(),
          expiredAt: admin.firestore.FieldValue.serverTimestamp(),
          expiredBy: 'scheduled_job'
        });
        
        // Capture userInfo + approx_loc here so we can build the
        // resolution FCM body after the batch commits without re-reading
        // the doc (which would now show active:false anyway).
        expiredAlerts.push({
          sender_id: doc.id,
          district: data.district,
          age_minutes: Math.floor((now - timestamp.getTime()) / 1000 / 60),
          user_name: data.userInfo?.name,
          user_location: data.userInfo?.location || data.approx_loc,
        });
      }
    });
    
    // Commit all updates in a single batch
    if (expiredAlerts.length > 0) {
      await batch.commit();
      console.log(`✅ Expired ${expiredAlerts.length} old alerts:`, expiredAlerts);

      // Purge Storage for each expired sender. Done after the batch
      // because purgeSosMedia is best-effort and we don't want a slow
      // bucket op to delay the Firestore state change. Sequential to
      // avoid overwhelming Storage with parallel listAll() calls when
      // the backlog is large; real-world expiry batches are tiny.
      // Also purge any chat media tied to conversations this sender
      // owned - chat media follows the same retention as SOS media.
      // Then send a resolution FCM so responder devices dismiss the
      // active-alert push from their notification tray (the in-app
      // stream catches up but the OS-level push doesn't go away on
      // its own).
      for (const a of expiredAlerts) {
        await purgeSosMedia(a.sender_id);
        await purgeChatMediaForSosOwner(a.sender_id);
        await sendSOSResolutionFcm({
          sender_id: a.sender_id,
          district: a.district,
          userName: a.user_name,
          userLocation: a.user_location,
          expiredBy: 'scheduled_job',
        });
      }
    } else {
      console.log(`✅ No alerts to expire (checked ${snapshot.size} active alerts)`);
    }
    
    return {
      expired: expiredAlerts.length,
      checked: snapshot.size,
      enabled: true,
      expiredAlerts: expiredAlerts
    };
  } catch (error) {
    console.error('⚠️  Failed to expire old alerts:', error);
    throw error;
  }
}

// ============================================================================
// AUTHENTICATION MIDDLEWARE
// ============================================================================

// ============================================================================
// SUPER ADMIN CACHE - Fetched from Firestore (admins collection, role: super-admin)
// with a 1-hour TTL so repeated requests don't hammer the database.
// ============================================================================

const superAdminCache = {
  emails: /** @type {string[]|null} */ (null),
  lastFetched: /** @type {number|null} */ (null),
  TTL_MS: 60 * 60 * 1000 // 1 hour
};

/**
 * Fetch super-admin emails from Firestore, using an in-memory cache (1-hour TTL).
 * Super admins are documents in the `admins` collection where role === 'super-admin'.
 * @returns {Promise<string[]>}
 */
async function getSuperAdminEmails() {
  const now = Date.now();
  if (
    superAdminCache.emails !== null &&
    superAdminCache.lastFetched !== null &&
    now - superAdminCache.lastFetched < superAdminCache.TTL_MS
  ) {
    return superAdminCache.emails;
  }

  console.log('🔄 Refreshing super admin cache from Firestore...');
  const snapshot = await admin.firestore()
    .collection('admins')
    .where('role', '==', 'super-admin')
    .get();

  const emails = snapshot.docs.map(doc => doc.id);
  superAdminCache.emails = emails;
  superAdminCache.lastFetched = now;
  console.log(`✅ Super admin cache updated: ${emails.length} super admin(s)`);
  return emails;
}

/**
 * Invalidate the super-admin cache so the next request re-fetches from Firestore.
 * Call this after creating or deleting a super-admin.
 */
function invalidateSuperAdminCache() {
  superAdminCache.emails = null;
  superAdminCache.lastFetched = null;
  console.log('♻️  Super admin cache invalidated');
}

/**
 * Middleware to verify Firebase ID token
 * Also sets custom claims for super admins if needed
 */
async function authenticateUser(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ 
        error: 'Unauthorized',
        message: 'Missing or invalid authorization header'
      });
    }
    
    const idToken = authHeader.split('Bearer ')[1];
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    
    // Set custom claim for super admins if not already set
    if (await isSuperAdmin(decodedToken.email) && !decodedToken.superadmin) {
      await admin.auth().setCustomUserClaims(decodedToken.uid, { superadmin: true });
      console.log(`✅ Set superadmin custom claim for ${decodedToken.email}`);
    }
    
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email
    };
    
    next();
  } catch (error) {
    console.error('Authentication error:', error);
    return res.status(401).json({ 
      error: 'Unauthorized',
      message: 'Invalid or expired token'
    });
  }
}

/**
 * Middleware to verify super admin access
 */
async function requireSuperAdmin(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ 
      error: 'Unauthorized',
      message: 'Authentication required'
    });
  }
  
  if (!await isSuperAdmin(req.user.email)) {
    return res.status(403).json({ 
      error: 'Forbidden',
      message: 'Super admin access required'
    });
  }
  
  next();
}

/**
 * Get admin document from Firestore
 */
async function getAdmin(email) {
  const doc = await admin.firestore()
    .collection('admins')
    .doc(email)
    .get();
  
  return doc.exists ? { email: doc.id, ...doc.data() } : null;
}

/**
 * Check if email belongs to a super admin (uses cached Firestore lookup).
 * @param {string} email
 * @returns {Promise<boolean>}
 */
async function isSuperAdmin(email) {
  const emails = await getSuperAdminEmails();
  return emails.includes(email);
}

// ============================================================================
// ADMIN SCOPE HELPERS
//
// District admins are scoped to their assignedDistricts. Super admins act
// system-wide. The /admin/users endpoint already enforces this on read;
// these helpers extend the same pattern to the destructive endpoints
// (block, unblock, delete) and to the previously-unscoped read endpoints
// (blocked-users, sos-alerts).
//
// Without these checks a district admin in (e.g.) Mangalore could block,
// unblock, or delete users in any other district by passing a foreign
// FID in the request body. authenticateUser only proves "you are an
// admin"; it does not constrain "which users you can act on".
// ============================================================================

/**
 * Resolve the district scope a request operates under.
 *
 * Returns one of:
 *   { ok: true, isSuperAdmin: true,  allowedDistricts: null }
 *      → super admin, no scope filter
 *   { ok: true, isSuperAdmin: false, allowedDistricts: [...lowercase] }
 *      → district admin, may only act on these districts
 *   { ok: false, status, error, message }
 *      → admin record missing or inactive; caller should res.status(...).json(...)
 *
 * Districts are normalized to lowercase here so callers can do
 * `allowedDistricts.includes(target.toLowerCase())` without thinking
 * about casing variations.
 */
async function getAdminScope(req) {
  if (!req.user || !req.user.email) {
    return { ok: false, status: 401, error: 'Unauthorized', message: 'Authentication required' };
  }
  if (await isSuperAdmin(req.user.email)) {
    return { ok: true, isSuperAdmin: true, allowedDistricts: null };
  }
  const adminDoc = await getAdmin(req.user.email);
  if (!adminDoc || !adminDoc.active) {
    return {
      ok: false,
      status: 403,
      error: 'Forbidden',
      message: 'Admin account is inactive or not found',
    };
  }
  const raw = Array.isArray(adminDoc.assignedDistricts) ? adminDoc.assignedDistricts : [];
  const allowedDistricts = raw
    .filter(d => typeof d === 'string' && d.length > 0)
    .map(d => d.toLowerCase());
  return { ok: true, isSuperAdmin: false, allowedDistricts };
}

/**
 * Resolve the district that owns this target FID. Used by destructive
 * admin endpoints to verify the caller has scope.
 *
 * Lookup order:
 *   1. subscribed_users/{fid}.district (the canonical source).
 *   2. blocked_users/{fid}.district (fallback: a user can be deleted
 *      from subscribed_users while still in the block list, especially
 *      after a /delete-user-data call - we still need to be able to
 *      unblock them via the proper district admin).
 *
 * Returns { district: string|null, source: 'subscribed_users'|'blocked_users'|null }.
 * district is null when neither doc exists; the caller decides whether
 * that's a 404 (block of unknown user) or a soft skip (unblock of a
 * ghost record).
 */
async function getTargetUserDistrict(fid) {
  const db = admin.firestore();
  try {
    const subDoc = await db.collection('subscribed_users').doc(fid).get();
    if (subDoc.exists) {
      const d = subDoc.data() && subDoc.data().district;
      if (typeof d === 'string' && d.length > 0) {
        return { district: d.toLowerCase(), source: 'subscribed_users' };
      }
    }
  } catch (e) {
    console.warn(`⚠️ getTargetUserDistrict subscribed_users lookup failed for ${fid}: ${e.message}`);
  }
  try {
    const blockedDoc = await db.collection('blocked_users').doc(fid).get();
    if (blockedDoc.exists) {
      const d = blockedDoc.data() && blockedDoc.data().district;
      if (typeof d === 'string' && d.length > 0) {
        return { district: d.toLowerCase(), source: 'blocked_users' };
      }
    }
  } catch (e) {
    console.warn(`⚠️ getTargetUserDistrict blocked_users lookup failed for ${fid}: ${e.message}`);
  }
  return { district: null, source: null };
}

/**
 * Returns null if the admin scope permits acting on `targetDistrict`,
 * or a { status, body } pair to send as the rejection.
 *
 * Super admin: always allowed.
 * District admin: allowed iff targetDistrict ∈ allowedDistricts.
 *
 * If targetDistrict is null/missing (i.e. we couldn't resolve the
 * target's district), super admin is still allowed; district admins
 * are rejected with 404 to avoid leaking "this FID exists in some
 * district you can't see".
 */
function assertAdminCanActOnDistrict(scope, targetDistrict) {
  if (scope.isSuperAdmin) return null;
  if (!targetDistrict) {
    // District admin acting on an unknown target. Returning 404 is the
    // safer choice: 403 would confirm the FID exists somewhere, which
    // a malicious district admin could use to enumerate other districts'
    // users. 404 is consistent with "you don't see this user".
    return { status: 404, body: { error: 'User not found in your assigned districts' } };
  }
  if (!scope.allowedDistricts.includes(targetDistrict.toLowerCase())) {
    return { status: 403, body: {
      error: 'Forbidden',
      message: 'You do not have permission to act on users in this district',
    }};
  }
  return null;
}

// ============================================================================
// API ENDPOINTS
// ============================================================================

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    firebase: 'connected', // Always connected in CF
    features: {
      sosAlertSnapshot: FEATURES.ENABLE_SOS_ALERT_SNAPSHOT,
      blockedUsers: FEATURES.BLOCKED_USERS
    },
    scheduledJobs: {
      alertExpiration: {
        enabled: FEATURES.ENABLE_SOS_ALERT_SNAPSHOT,
        interval: SCHEDULE_CONFIG.ALERT_EXPIRATION_CHECK_INTERVAL,
        thresholdMinutes: SCHEDULE_CONFIG.ALERT_EXPIRATION_THRESHOLD_MS / 1000 / 60
      }
    }
  });
});

// Admin endpoint: Block a user
app.post('/admin/block-user', authenticateUser, async (req, res) => {
  console.log('🔒 Block user request received:', req.body);

  try {
    const { sender_id, reason } = req.body;
    const blocked_by = req.user.email;

    // Validate required fields
    if (!sender_id) {
      return res.status(400).json({
        error: 'Missing required field',
        required: ['sender_id']
      });
    }

    // Resolve admin scope. Super admins skip the district check; district
    // admins must have the target user's district in their assignedDistricts.
    const scope = await getAdminScope(req);
    if (!scope.ok) {
      return res.status(scope.status).json({ error: scope.error, message: scope.message });
    }

    // Resolve the target's district. For block, we REQUIRE a known
    // district - blocking a user whose subscribed_users record is missing
    // is suspicious (we wouldn't have any way to scope-check the unblock
    // either, beyond the value we'd store in the block record).
    const target = await getTargetUserDistrict(sender_id);
    if (!target.district) {
      return res.status(404).json({
        error: 'User not found',
        message: 'Cannot block a user with no known district. The user may not have subscribed yet.',
      });
    }
    const denial = assertAdminCanActOnDistrict(scope, target.district);
    if (denial) {
      console.warn(`🚫 /admin/block-user: ${blocked_by} denied for ${sender_id} (district ${target.district})`);
      return res.status(denial.status).json(denial.body);
    }

    // Check if user is already blocked
    const existingUser = await getBlockedUser(sender_id);

    if (existingUser && existingUser.blocked === true) {
      return res.status(409).json({
        error: 'User already blocked',
        message: `User ${sender_id} is already in the blocked list`,
        blockedAt: existingUser.blockedAt,
        reason: existingUser.reason
      });
    }

    // Block the user (stores district so unblock can scope-check)
    await blockUser(sender_id, reason, blocked_by, target.district);

    console.log(`✅ User blocked successfully: ${sender_id} (district=${target.district}, by=${blocked_by})`);

    res.json({
      success: true,
      message: 'User blocked successfully',
      sender_id: sender_id,
      district: target.district,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Block user error:', error);
    res.status(500).json({
      error: 'Failed to block user',
      message: error.message
    });
  }
});

// Admin endpoint: Unblock a user
app.post('/admin/unblock-user', authenticateUser, async (req, res) => {
  console.log('🔓 Unblock user request received:', req.body);

  try {
    const { sender_id } = req.body;

    // Validate required fields
    if (!sender_id) {
      return res.status(400).json({
        error: 'Missing required field',
        required: ['sender_id']
      });
    }

    const scope = await getAdminScope(req);
    if (!scope.ok) {
      return res.status(scope.status).json({ error: scope.error, message: scope.message });
    }

    // Check if user exists in blocked list FIRST so we can return 404
    // before doing the district-scope check (and so we have block-record
    // district as fallback if subscribed_users is gone).
    const existingUser = await getBlockedUser(sender_id);
    if (!existingUser) {
      return res.status(404).json({
        error: 'User not found',
        message: `User ${sender_id} is not in the blocked list`
      });
    }

    // Resolve target district. For unblock, blocked_users.district is
    // the canonical fallback - a user can be deleted from subscribed_users
    // (via /delete-user-data) while still in the block list.
    const target = await getTargetUserDistrict(sender_id);
    const denial = assertAdminCanActOnDistrict(scope, target.district);
    if (denial) {
      console.warn(`🚫 /admin/unblock-user: ${req.user.email} denied for ${sender_id} (district ${target.district || 'unknown'})`);
      return res.status(denial.status).json(denial.body);
    }

    // Unblock the user
    await unblockUser(sender_id);

    console.log(`✅ User unblocked successfully: ${sender_id} (district=${target.district || 'unknown'}, by=${req.user.email})`);

    res.json({
      success: true,
      message: 'User unblocked successfully',
      sender_id: sender_id,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Unblock user error:', error);
    res.status(500).json({
      error: 'Failed to unblock user',
      message: error.message
    });
  }
});

// Admin endpoint: List all blocked users
app.get('/admin/blocked-users', authenticateUser, async (req, res) => {
  console.log('📋 List blocked users request received');

  try {
    const scope = await getAdminScope(req);
    if (!scope.ok) {
      return res.status(scope.status).json({ error: scope.error, message: scope.message });
    }

    let blockedUsers = await listBlockedUsers();

    // District-scope filter for non-super-admins. We rely on the district
    // recorded on each block document. For records created BEFORE the
    // block-time district was added (i.e. legacy blocks with no district
    // field), we conservatively cross-reference subscribed_users to figure
    // out the district. If neither source has a district, the record is
    // hidden from district admins (only super admin can see/act on it).
    if (!scope.isSuperAdmin) {
      const allowed = scope.allowedDistricts;
      // Pre-fetch any missing districts in parallel for legacy records.
      const recordsNeedingLookup = blockedUsers.filter(
        u => typeof u.district !== 'string' || u.district.length === 0
      );
      if (recordsNeedingLookup.length > 0) {
        const lookups = await Promise.all(
          recordsNeedingLookup.map(u => getTargetUserDistrict(u.sender_id))
        );
        recordsNeedingLookup.forEach((u, i) => { u.district = lookups[i].district; });
      }
      blockedUsers = blockedUsers.filter(
        u => typeof u.district === 'string' && allowed.includes(u.district.toLowerCase())
      );
    }

    console.log(`✅ Returning ${blockedUsers.length} blocked users (super=${scope.isSuperAdmin})`);

    res.json({
      success: true,
      count: blockedUsers.length,
      blockedUsers: blockedUsers,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ List blocked users error:', error);
    res.status(500).json({
      error: 'Failed to retrieve blocked users',
      message: error.message
    });
  }
});

// Admin endpoint: Get SOS alerts for dashboard
app.get('/admin/sos-alerts', authenticateUser, async (req, res) => {
  console.log('📊 Get SOS alerts request received');

  try {
    const scope = await getAdminScope(req);
    if (!scope.ok) {
      return res.status(scope.status).json({ error: scope.error, message: scope.message });
    }

    const activeOnly = req.query.active === 'true';
    let alerts = await getSOSAlerts(activeOnly);

    // District-scope filter for non-super-admins.
    if (!scope.isSuperAdmin) {
      const allowed = scope.allowedDistricts;
      alerts = alerts.filter(a =>
        typeof a.district === 'string' && allowed.includes(a.district.toLowerCase())
      );
    }

    console.log(`✅ Returning ${alerts.length} SOS alerts${activeOnly ? ' (active only)' : ''} (super=${scope.isSuperAdmin})`);

    res.json({
      success: true,
      count: alerts.length,
      activeOnly: activeOnly,
      alerts: alerts,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Get SOS alerts error:', error);
    res.status(500).json({
      error: 'Failed to retrieve SOS alerts',
      message: error.message
    });
  }
});

// Admin endpoint: Get paginated list of users with search (from subscribed_users collection)
app.get('/admin/users', authenticateUser, async (req, res) => {
  console.log('👥 Get users list request received');
  
  try {
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 50;
    const search = req.query.search || '';
    
    // Get admin profile to check permissions
    const isSuperAdminUser = await isSuperAdmin(req.user.email);
    let allowedDistricts = [];
    
    if (!isSuperAdminUser) {
      const adminDoc = await getAdmin(req.user.email);
      if (!adminDoc || !adminDoc.active) {
        return res.status(403).json({ 
          error: 'Forbidden',
          message: 'Admin account is inactive or not found'
        });
      }
      allowedDistricts = adminDoc.assignedDistricts || [];
    }
    
    // Query subscribed_users collection
    let query = admin.firestore().collection('subscribed_users');
    
    // Admins only see users from their assigned districts
    if (!isSuperAdminUser && allowedDistricts.length > 0) {
      query = query.where('district', 'in', allowedDistricts);
    }
    
    const snapshot = await query.get();
    
    // Build user list from subscribed_users documents
    const userList = snapshot.docs.map(doc => {
      const data = doc.data();
      const fid = doc.id;
      return {
        sender_id: fid,
        name: data.name || 'Unknown',
        mobile_number: data.number || 'N/A',
        state: data.state || 'Unknown',
        district: data.district || 'Unknown',
        last_subscribed_at: data.last_subscribed_at?.toDate().toISOString() ?? null,
        blocked: false,
      };
    });

    // Build a lookup map for quick access
    const userMap = new Map(userList.map(u => [u.sender_id, u]));
    
    // Get blocked users information and merge
    const blockedSnapshot = await admin.firestore()
      .collection('blocked_users')
      .where('blocked', '==', true)
      .get();
    
    blockedSnapshot.forEach(doc => {
      const data = doc.data();
      if (userMap.has(doc.id)) {
        const userData = userMap.get(doc.id);
        userMap.set(doc.id, {
          ...userData,
          blocked: true,
          blockedAt: data.blockedAt?.toDate().toISOString(),
          blockedBy: data.blockedBy,
          reason: data.reason,
        });
      }
    });
    
    let users = Array.from(userMap.values());
    
    // Apply search filter
    if (search) {
      const searchLower = search.toLowerCase();
      users = users.filter(user => 
        user.name.toLowerCase().includes(searchLower) ||
        user.mobile_number.toLowerCase().includes(searchLower) ||
        user.state.toLowerCase().includes(searchLower) ||
        user.district.toLowerCase().includes(searchLower)
      );
    }
    
    // Sort by name
    users.sort((a, b) => a.name.localeCompare(b.name));
    
    // Paginate
    const total = users.length;
    const totalPages = Math.ceil(total / pageSize);
    const startIndex = (page - 1) * pageSize;
    const paginatedUsers = users.slice(startIndex, startIndex + pageSize);
    
    console.log(`✅ Found ${total} subscribed users (showing ${paginatedUsers.length} on page ${page})`);
    
    res.json({ 
      success: true,
      users: paginatedUsers,
      total: total,
      page: page,
      pageSize: pageSize,
      totalPages: totalPages,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Get users list error:', error);
    res.status(500).json({ 
      error: 'Failed to retrieve users',
      message: error.message
    });
  }
});

// Admin endpoint: Delete a subscribed user
app.post('/admin/delete-user', authenticateUser, async (req, res) => {
  console.log('🗑️ Admin delete user request received:', req.body);

  try {
    const { fid } = req.body || {};

    if (typeof fid !== 'string' || fid.length === 0) {
      return res.status(400).json({
        error: 'Missing or invalid required field',
        required: ['fid (non-empty string)'],
      });
    }

    const scope = await getAdminScope(req);
    if (!scope.ok) {
      return res.status(scope.status).json({ error: scope.error, message: scope.message });
    }

    // Resolve target district BEFORE deleting anything. Once we delete
    // subscribed_users we can't look it up anymore - and the scope check
    // is the gate, so it has to happen first.
    const target = await getTargetUserDistrict(fid);
    const denial = assertAdminCanActOnDistrict(scope, target.district);
    if (denial) {
      console.warn(`🚫 /admin/delete-user: ${req.user.email} denied for ${fid} (district ${target.district || 'unknown'})`);
      return res.status(denial.status).json(denial.body);
    }

    const db = admin.firestore();
    const results = {};

    // ---- subscribed_users/{fid} -------------------------------------------
    try {
      const subRef = db.collection('subscribed_users').doc(fid);
      const subDoc = await subRef.get();
      if (subDoc.exists) {
        await subRef.delete();
        results.subscribed_users = 'deleted';
      } else {
        results.subscribed_users = 'not_found';
      }
    } catch (err) {
      console.warn(`⚠️ admin-delete subscribed_users/${fid}: ${err.message}`);
      results.subscribed_users = `error: ${err.message}`;
    }

    // ---- sos_alerts/{fid} -------------------------------------------------
    try {
      const alertRef = db.collection('sos_alerts').doc(fid);
      const alertDoc = await alertRef.get();
      if (alertDoc.exists) {
        await alertRef.delete();
        results.sos_alerts = 'deleted';
      } else {
        results.sos_alerts = 'not_found';
      }
    } catch (err) {
      console.warn(`⚠️ admin-delete sos_alerts/${fid}: ${err.message}`);
      results.sos_alerts = `error: ${err.message}`;
    }

    // ---- blocked_users/{fid} ----------------------------------------------
    try {
      const blockedRef = db.collection('blocked_users').doc(fid);
      const blockedDoc = await blockedRef.get();
      if (blockedDoc.exists) {
        await blockedRef.delete();
        results.blocked_users = 'deleted';
      } else {
        results.blocked_users = 'not_found';
      }
    } catch (err) {
      console.warn(`⚠️ admin-delete blocked_users/${fid}: ${err.message}`);
      results.blocked_users = `error: ${err.message}`;
    }

    // ---- sos_conversations the user participated in ------------------------
    // Same reasoning as /delete-user-data: deleting the conversation
    // entirely is cleaner than redacting in-array messages, and the
    // daily wipe normalizes lifetime anyway. Chat media is purged
    // inline so we don't leak Storage bytes.
    let convsDeleted = 0;
    let convsErrored = 0;
    try {
      const convSnap = await db.collection('sos_conversations')
        .where('participants', 'array-contains', fid)
        .get();
      for (const doc of convSnap.docs) {
        try {
          await purgeChatMedia(doc.id).catch(() => {});
          await doc.ref.delete();
          convsDeleted++;
        } catch (perDocErr) {
          console.warn(`⚠️ admin-delete sos_conversations/${doc.id}: ${perDocErr.message}`);
          convsErrored++;
        }
      }
      results.sos_conversations = `deleted: ${convsDeleted}, errors: ${convsErrored}`;
    } catch (err) {
      console.warn(`⚠️ admin-delete sos_conversations query: ${err.message}`);
      results.sos_conversations = `error: ${err.message}`;
    }

    // ---- Storage: sos_photos/{fid}/* and sos_voice/{fid}/* ----------------
    // Same retention guarantee as the SOS termination paths and
    // /delete-user-data: when the user is gone, their media is gone.
    try {
      const r = await purgeSosMedia(fid);
      results.sos_storage = `photos: ${r.photos}, voice: ${r.voice}`;
    } catch (err) {
      console.warn(`⚠️ admin-delete sos storage purge: ${err.message}`);
      results.sos_storage = `error: ${err.message}`;
    }

    console.log(`✅ Admin delete-user complete: ${fid} (district=${target.district || 'unknown'}, by=${req.user.email}):`, results);

    res.json({
      success: true,
      message: 'User deleted successfully',
      fid,
      district: target.district,
      results,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('❌ Admin delete user error:', error);
    res.status(500).json({
      error: 'Failed to delete user',
      message: error.message,
    });
  }
});

// ============================================================================
// ADMIN MANAGEMENT ENDPOINTS
// ============================================================================

// Get current user profile (authenticated user - super admin or admin)
app.get('/admin/profile', authenticateUser, async (req, res) => {
  console.log('👤 Get profile request received for:', req.user.email);
  
  try {
    const isSuperAdminUser = await isSuperAdmin(req.user.email);
    let adminDoc = null;
    
    if (!isSuperAdminUser) {
      adminDoc = await getAdmin(req.user.email);
      
      if (!adminDoc || !adminDoc.active) {
        return res.status(403).json({ 
          error: 'Forbidden',
          message: 'Admin account is inactive or not found'
        });
      }
    }
    
    res.json({ 
      success: true,
      user: {
        email: req.user.email,
        role: isSuperAdminUser ? 'superadmin' : 'admin',
        assignedDistricts: isSuperAdminUser ? [] : (adminDoc?.assignedDistricts || []),
        active: isSuperAdminUser ? true : (adminDoc?.active || false)
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Get profile error:', error);
    res.status(500).json({ 
      error: 'Failed to retrieve profile',
      message: error.message
    });
  }
});

// List all admins (super admin only)
app.get('/admin/admins', authenticateUser, requireSuperAdmin, async (req, res) => {
  console.log('📋 List admins request received');
  
  try {
    const snapshot = await admin.firestore()
      .collection('admins')
      .orderBy('createdAt', 'desc')
      .get();
    
    const admins = [];
    snapshot.forEach(doc => {
      const data = doc.data();
      admins.push({
        email: doc.id,
        role: data.role || 'admin',
        assignedDistricts: data.assignedDistricts || [],
        active: data.active !== false,
        createdAt: data.createdAt?.toDate().toISOString(),
        createdBy: data.createdBy || 'unknown'
      });
    });
    
    console.log(`✅ Found ${admins.length} admins`);
    
    res.json({ 
      success: true,
      count: admins.length,
      admins: admins,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ List admins error:', error);
    res.status(500).json({ 
      error: 'Failed to retrieve admins',
      message: error.message
    });
  }
});

// Create new admin (super admin only)
app.post('/admin/admins', authenticateUser, requireSuperAdmin, async (req, res) => {
  console.log('➕ Create admin request received:', req.body);
  
  try {
    const { email, password, assignedDistricts, role } = req.body;

    // Validate required fields
    if (!email || !password) {
      return res.status(400).json({ 
        error: 'Missing required fields',
        required: ['email', 'password']
      });
    }
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ 
        error: 'Invalid email format'
      });
    }

    // Resolve role: only 'super-admin' or 'admin' are valid
    const adminRole = role === 'super-admin' ? 'super-admin' : 'admin';

    // Super-admins see all districts — assigned districts are not applicable
    const districts = adminRole === 'super-admin' ? [] : (assignedDistricts || []);
    
    // Check if admin already exists in Firestore
    const existingAdmin = await getAdmin(email);
    if (existingAdmin) {
      return res.status(409).json({ 
        error: 'Admin already exists',
        message: `Admin with email ${email} already exists`
      });
    }
    
    // Create user in Firebase Auth
    let userRecord;
    try {
      userRecord = await admin.auth().createUser({
        email: email,
        password: password,
        emailVerified: true
      });
    } catch (authError) {
      console.error('Auth creation error:', authError);
      return res.status(400).json({ 
        error: 'Failed to create user account',
        message: authError.message
      });
    }

    // Set superadmin custom claim immediately for super-admin role
    if (adminRole === 'super-admin') {
      await admin.auth().setCustomUserClaims(userRecord.uid, { superadmin: true });
      console.log(`✅ Set superadmin custom claim for ${email}`);
    }
    
    // Create admin document in Firestore
    const adminData = {
      role: adminRole,
      assignedDistricts: districts,
      active: true,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      createdBy: req.user.email
    };
    
    await admin.firestore()
      .collection('admins')
      .doc(email)
      .set(adminData);

    // Invalidate cache so the new super-admin is recognised on next request
    if (adminRole === 'super-admin') {
      invalidateSuperAdminCache();
    }
    
    console.log(`✅ ${adminRole} created successfully: ${email}`);
    
    // Send welcome email (don't fail if email fails)
    try {
      await sendWelcomeEmail(email, password, districts, adminRole);
      console.log(`✅ Welcome email sent to ${email}`);
    } catch (emailError) {
      console.error('⚠️ Failed to send welcome email:', emailError);
      // Continue anyway - admin is created successfully
    }
    
    res.json({ 
      success: true,
      message: 'Admin created successfully',
      admin: {
        email: email,
        uid: userRecord.uid,
        ...adminData,
        createdAt: new Date().toISOString()
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Create admin error:', error);
    res.status(500).json({ 
      error: 'Failed to create admin',
      message: error.message
    });
  }
});

// Update admin (super admin only)
app.put('/admin/admins/:email', authenticateUser, requireSuperAdmin, async (req, res) => {
  console.log('✏️ Update admin request received:', req.params.email, req.body);
  
  try {
    const { email } = req.params;
    const { assignedDistricts, active } = req.body;
    
    // Super admin accounts cannot be modified via API
    if (await isSuperAdmin(email)) {
      return res.status(400).json({ 
        error: 'Cannot update super admin',
        message: 'Super admin accounts cannot be modified'
      });
    }
    
    // Check if admin exists
    const existingAdmin = await getAdmin(email);
    if (!existingAdmin) {
      return res.status(404).json({ 
        error: 'Admin not found',
        message: `Admin with email ${email} does not exist`
      });
    }
    
    // Build update data
    const updateData = {
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedBy: req.user.email
    };
    
    if (assignedDistricts !== undefined) {
      updateData.assignedDistricts = assignedDistricts;
    }
    
    if (active !== undefined) {
      updateData.active = active;
    }
    
    // Update admin document
    await admin.firestore()
      .collection('admins')
      .doc(email)
      .update(updateData);
    
    console.log(`✅ Admin updated successfully: ${email}`);
    
    res.json({ 
      success: true,
      message: 'Admin updated successfully',
      email: email,
      updates: updateData,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Update admin error:', error);
    res.status(500).json({ 
      error: 'Failed to update admin',
      message: error.message
    });
  }
});

// Delete admin (super admin only)
app.delete('/admin/admins/:email', authenticateUser, requireSuperAdmin, async (req, res) => {
  console.log('🗑️ Delete admin request received:', req.params.email);
  
  try {
    const { email } = req.params;
    
    // Super admin accounts cannot be deleted via API
    if (await isSuperAdmin(email)) {
      return res.status(400).json({ 
        error: 'Cannot delete super admin',
        message: 'Super admin accounts cannot be deleted'
      });
    }
    
    // Check if admin exists
    const existingAdmin = await getAdmin(email);
    if (!existingAdmin) {
      return res.status(404).json({ 
        error: 'Admin not found',
        message: `Admin with email ${email} does not exist`
      });
    }

    const wasSuper = existingAdmin.role === 'super-admin';
    
    // Get user by email to delete from Auth
    let userRecord;
    try {
      userRecord = await admin.auth().getUserByEmail(email);
      await admin.auth().deleteUser(userRecord.uid);
    } catch (authError) {
      console.error('Auth deletion error:', authError);
      // Continue to delete from Firestore even if Auth deletion fails
    }
    
    // Delete admin document from Firestore
    await admin.firestore()
      .collection('admins')
      .doc(email)
      .delete();

    // Invalidate cache if we just removed a super-admin
    if (wasSuper) {
      invalidateSuperAdminCache();
    }
    
    console.log(`✅ Admin deleted successfully: ${email}`);
    
    res.json({ 
      success: true,
      message: 'Admin deleted successfully',
      email: email,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ Delete admin error:', error);
    res.status(500).json({ 
      error: 'Failed to delete admin',
      message: error.message
    });
  }
});

// Feedback / Contact Us endpoint
app.post('/feedback', async (req, res) => {
  console.log('📬 Feedback request received:', req.body);

  try {
    const { name, email, subject, message } = req.body;

    if (!message || message.trim().length === 0) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: gmailUser.value(),
        pass: gmailPass.value()
      }
    });

    const senderName = (name && name.trim()) ? name.trim() : 'Anonymous';
    const senderEmail = (email && email.trim()) ? email.trim() : null;
    const emailSubject = (subject && subject.trim()) ? subject.trim() : 'General';

    await transporter.sendMail({
      from: `RRT App <${gmailUser.value()}>`,
      to: 'ask@rapid-response.in',
      subject: `[App Feedback] ${emailSubject} - from ${senderName}`,
      text: `Name: ${senderName}\nEmail: ${senderEmail ?? 'Not provided'}\nSubject: ${emailSubject}\n\n${message.trim()}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #EF4444;">New Feedback from RRT App</h2>
          <table style="width: 100%; border-collapse: collapse;">
            <tr><td style="padding: 8px; color: #666;"><strong>From:</strong></td><td style="padding: 8px;">${senderName}</td></tr>
            <tr><td style="padding: 8px; color: #666;"><strong>Email:</strong></td><td style="padding: 8px;">${senderEmail ? `<a href="mailto:${senderEmail}">${senderEmail}</a>` : '<em style="color:#999">Not provided</em>'}</td></tr>
            <tr><td style="padding: 8px; color: #666;"><strong>Subject:</strong></td><td style="padding: 8px;">${emailSubject}</td></tr>
          </table>
          <div style="background: #f5f5f5; padding: 16px; border-radius: 8px; margin-top: 16px;">
            <p style="margin: 0; white-space: pre-wrap;">${message.trim()}</p>
          </div>
          <p style="color: #999; font-size: 12px; margin-top: 24px;">Sent via RRT App feedback form</p>
        </div>
      `
    });

    console.log(`✅ Feedback email sent from ${senderName}`);
    res.json({ success: true, message: 'Feedback sent successfully' });
  } catch (error) {
    console.error('❌ Failed to send feedback email:', error);
    res.status(500).json({ error: 'Failed to send feedback', details: error.message });
  }
});

// SOS Alert endpoint
app.post('/sos', async (req, res) => {
  console.log('📡 SOS request received:', req.body);
  
  try {
    const { sender_id, sos_type, location, userInfo, timestamp } = req.body;
    
    // Validate required fields
    if (!sender_id || !sos_type || !location) {
      return res.status(400).json({ 
        error: 'Missing required fields',
        required: ['sender_id', 'sos_type', 'location']
      });
    }

    // Check if sender is blocked (shadow block - return success but don't process)
    if (await isSenderBlocked(sender_id)) {
      console.log(`🚫 Blocked sender attempted SOS: ${sender_id} (shadow blocked)`);
      return res.status(200).json({ 
        success: true,
        message: 'SOS alert sent successfully',
        messageId: `blocked-${Date.now()}`,
        senderId: sender_id,
        timestamp: new Date().toISOString()
      });
    }

    // Rate limit: only apply to sos_alert, not stop
    if (sos_type === 'sos_alert' && isSosRateLimited(sender_id)) {
      console.warn(`⚠️ Rate limited SOS from sender: ${sender_id}`);
      return res.status(429).json({
        error: 'Too many requests',
        message: 'Please wait before sending another SOS alert',
        retryAfter: SOS_RATE_LIMIT_MS / 1000
      });
    }

    // Validate sos_type
    if (!['sos_alert', 'stop'].includes(sos_type)) {
      return res.status(400).json({ 
        error: 'Invalid sos_type',
        message: 'sos_type must be either "sos_alert" or "stop"'
      });
    }

    if (sos_type === 'stop') {
      console.log(`🛑 Stopping SOS alert from sender: ${sender_id}`);
      
      // Extract district and user info for stop notification
      const district = userInfo?.district;
      if (!district) {
        return res.status(400).json({ 
          error: 'Missing district in userInfo',
          message: 'district is required for stop notification'
        });
      }
      
      const userName = userInfo?.name || 'Someone';
      const userLocation = userInfo?.location || district.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
      const state = userInfo?.state?.toUpperCase() || userLocation.split(',').pop().trim().toUpperCase();

      // Send resolution FCM via the shared helper. This is the same payload
      // shape as before, just factored out so auto-expire and the hourly
      // fallback can fire it too.
      const fcmResult = await sendSOSResolutionFcm({
        sender_id,
        district,
        userName,
        userLocation,
        expiredBy: 'manual_stop',
      });
      const stopResponse = fcmResult.messageId || null;
      
      // Update SOS alert status to inactive in Firestore (optional)
      await storeSOSAlert(sender_id, false, null, userInfo, district, state);

      // Purge media from Storage. Photos and voice notes (both SOS and
      // chat) are scoped to the lifetime of the alert per our retention
      // policy - manual stop means delete now, not on the next 60-min
      // Cloud Task. Best-effort and non-blocking: a Storage failure here
      // doesn't fail the stop request because the daily 00:00 IST sweep
      // is the safety net for any leftovers.
      try {
        await purgeSosMedia(sender_id);
      } catch (e) {
        console.error(`⚠️ Manual stop: SOS media purge failed for ${sender_id}: ${e.message}`);
      }
      try {
        await purgeChatMediaForSosOwner(sender_id);
      } catch (e) {
        console.error(`⚠️ Manual stop: chat media purge failed for ${sender_id}: ${e.message}`);
      }

      return res.json({ 
        success: true, 
        message: 'SOS alert stopped successfully',
        messageId: stopResponse,
        senderId: sender_id,
        district: district,
        timestamp: new Date().toISOString()
      });
    }
    else if (sos_type === 'sos_alert') {
      // Extract district from userInfo
      const district = userInfo?.district;
      if (!district) {
        return res.status(400).json({ 
          error: 'Missing district in userInfo',
          message: 'district is required for SOS alert'
        });
      }
      
      console.log(`🚨 Sending SOS alert to district: ${district} (Sender: ${sender_id})`);
      
      // Extract user info for notification
      const userName = userInfo?.name || 'Someone';
      const userLocation = userInfo?.location || district.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
      const state = userInfo?.state?.toUpperCase() || userLocation.split(',').pop().trim().toUpperCase();
      
      // Prepare FCM message
      const message = {
        topic: `district-${district}`,
        notification: {
          title: '🚨 Emergency Alert',
          body: `Help needed. ${userName} • ${userLocation}`
        },
        data: {
          type: 'sos_alert',
          sender_id: sender_id,
          district: district,
          location: JSON.stringify(location),
          timestamp: timestamp || Date.now().toString(),
          userInfo: userInfo ? JSON.stringify(userInfo) : '{}'
        },
        android: {
          priority: 'high',  // Critical: Forces immediate delivery bypassing Doze mode
          notification: {
            channelId: 'sos_alerts',  // Use high-importance channel
            icon: 'ic_notification',
            color: '#FF0000',
            sound: 'default',
            priority: 'high',
            defaultSound: true
          }
        },
        apns: {
          headers: {
            'apns-priority': '10'  // High priority for iOS
          },
          payload: {
            aps: {
              contentAvailable: true, 
              alert: {
                title: '🚨 Emergency Alert',
                body: `Help needed. ${userName} • ${userLocation}`
              },
              sound: 'default',
              badge: 1
            }
          }
        }
      };

      // Store SOS alert snapshot in Firestore BEFORE sending FCM. Responders'
      // apps receive the push, then immediately query sos_alerts/{senderId} to
      // render the alert card. Sending the push first creates a race where the
      // doc may not exist yet, or worse, contains stale fields from a previous
      // SOS by the same sender that haven't been overwritten by the new write.
      // Doing the write first guarantees the doc is current when responders
      // query it.
      await storeSOSAlert(sender_id, true, location, userInfo, district, state);

      // Send FCM message
      const response = await admin.messaging().send(message);

      console.log('✅ SOS alert sent successfully:', response);
      
      res.json({ 
        success: true, 
        message: 'SOS alert sent successfully',
        messageId: response,
        topic: `district-${district}`,
        senderId: sender_id,
        district: district,
        timestamp: new Date().toISOString()
      });
    }
    else {
      return res.status(400).json({ 
        error: 'Invalid sos_type',
        message: 'sos_type must be either "sos_alert" or "stop"'
      });
    }
  } catch (error) {
    console.error('❌ SOS send error:', error);
    
    res.status(500).json({ 
      error: 'Failed to send SOS alert',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// Test push notification endpoint
//
// Accepts (all optional, sensible defaults provided):
//   type        - "sos_alert" (default) | "stop"
//   district    - e.g. "udupi" (default)
//   sender_id   - document ID used in Firestore (default: "test-sender-fid")
//   name        - display name in notification body
//   phone       - phone number stored in userInfo
//   message     - optional message stored in userInfo
//   approx_loc  - human-readable location string
//   latitude    - GPS latitude  (sos_alert only)
//   longitude   - GPS longitude (sos_alert only)
//   accuracy    - GPS accuracy  (sos_alert only)
app.post('/test-push', authenticateUser, requireSuperAdmin, async (req, res) => {
  console.log('📡 Test push notification request received:', req.body);

  try {
    const {
      type       = 'sos_alert',
      district   = 'udupi',
      sender_id  = 'test-sender-fid',
      name       = 'Test User',
      phone      = '+91-XXXX-XXXX',
      message    = '',
      approx_loc,
      latitude   = 13.3409,
      longitude  = 74.7421,
      accuracy   = 10
    } = req.body;

    if (!['sos_alert', 'stop'].includes(type)) {
      return res.status(400).json({
        error: 'Invalid type',
        message: 'type must be either "sos_alert" or "stop"'
      });
    }

    const districtLabel = district.charAt(0).toUpperCase() + district.slice(1);
    const locationLabel = approx_loc || `${districtLabel} Test Location`;

    const testUserInfo = {
      name,
      district,
      location: locationLabel,
      phone,
      message
    };

    // ── STOP ────────────────────────────────────────────────────────────────
    if (type === 'stop') {
      console.log(`🧪 Sending test STOP notification to district: ${district}`);

      const stopMessage = {
        topic: `district-${district}`,
        notification: {
          title: '✅ Emergency Resolved',
          body: `All good now. ${name} • ${locationLabel}`
        },
        data: {
          type: 'sos_resolved',
          sender_id,
          district,
          timestamp: Date.now().toString()
        },
        android: {
          priority: 'high',
          notification: {
            channelId: 'sos_alerts',
            icon: 'ic_notification',
            color: '#00FF00',
            sound: 'default',
            priority: 'high'
          }
        },
        apns: {
          headers: {
            'apns-priority': '10',
            'apns-push-type': 'alert'
          },
          payload: {
            aps: {
              alert: {
                title: '✅ Emergency Resolved',
                body: `All good now. ${name} • ${locationLabel}`
              },
              sound: 'default'
            }
          }
        }
      };

      const stopResponse = await admin.messaging().send(stopMessage);
      console.log('✅ Test STOP notification sent:', stopResponse);

      await storeSOSAlert(sender_id, false, null, testUserInfo, district);

      return res.json({
        success: true,
        message: 'Test STOP notification sent successfully',
        type: 'stop',
        messageId: stopResponse,
        topic: `district-${district}`,
        district,
        senderId: sender_id,
        timestamp: new Date().toISOString()
      });
    }

    // ── SOS ALERT ───────────────────────────────────────────────────────────
    console.log(`🧪 Sending test SOS alert to district: ${district}`);

    const testLocation = { latitude, longitude, accuracy };
    const state = locationLabel.split(',').pop().trim().toUpperCase();

    const sosMessage = {
      topic: `district-${district}`,
      notification: {
        title: '🚨 Emergency Alert',
        body: `Help needed. ${name} • ${locationLabel}`
      },
      data: {
        type: 'sos_alert',
        sender_id,
        district,
        location: JSON.stringify(testLocation),
        timestamp: Date.now().toString(),
        userInfo: JSON.stringify(testUserInfo)
      },
      android: {
        priority: 'high',
        notification: {
          channelId: 'sos_alerts',
          icon: 'ic_notification',
          color: '#FF0000',
          sound: 'default',
          priority: 'high',
          defaultSound: true
        }
      },
      apns: {
        headers: {
          'apns-priority': '10'
        },
        payload: {
          aps: {
            contentAvailable: true,
            alert: {
              title: '🚨 Emergency Alert',
              body: `Help needed. ${name} • ${locationLabel}`
            },
            sound: 'default',
            badge: 1
          }
        }
      }
    };

    const sosResponse = await admin.messaging().send(sosMessage);
    console.log('✅ Test SOS alert sent:', sosResponse);

    await storeSOSAlert(sender_id, true, testLocation, testUserInfo, district, state);

    return res.json({
      success: true,
      message: 'Test SOS alert sent successfully',
      type: 'sos_alert',
      messageId: sosResponse,
      topic: `district-${district}`,
      district,
      senderId: sender_id,
      testData: {
        location: testLocation,
        userInfo: testUserInfo
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('❌ Test notification error:', error);

    res.status(500).json({
      error: 'Failed to send test notification',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// 404 handler
// Reverse geocode a lat/lng to a district key usable as an FCM topic segment.
// Called by the mobile app on first launch / location update to resolve district.
// GET /geocode/district?lat=13.3409&lng=74.7421
app.get('/geocode/district', async (req, res) => {
  const { lat, lng } = req.query;

  if (!lat || !lng) {
    return res.status(400).json({
      error: 'Missing parameters',
      message: 'lat and lng query parameters are required'
    });
  }

  const latitude  = parseFloat(lat);
  const longitude = parseFloat(lng);

  if (isNaN(latitude) || isNaN(longitude)) {
    return res.status(400).json({
      error: 'Invalid parameters',
      message: 'lat and lng must be valid numbers'
    });
  }

  if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
    return res.status(400).json({
      error: 'Invalid parameters',
      message: 'lat must be in [-90, 90] and lng in [-180, 180]'
    });
  }

  console.log(`📍 /geocode/district request — lat: ${latitude}, lng: ${longitude}`);

  const district = await reverseGeocodeDistrict(latitude, longitude);

  if (!district) {
    return res.status(404).json({
      error: 'District not found',
      message: 'Could not determine district from the provided coordinates'
    });
  }

  return res.json({
    district,
    fcmTopic: `district-${district}`,
    lat: latitude,
    lng: longitude
  });
});

// ============================================================================
// MARK ALERTS SEEN
// Records that a user (identified by FID) has viewed one or more SOS alerts.
// seen_by is stored as a map { [fid]: true } for O(1) lookup with no duplicates.
// POST /sos/mark-seen
// Body: { fid: string, alert_ids: string[] }
//
// Marks each given alert as seen by the calling responder. Used to clear
// the "unseen" red dot on the responder's alerts tab.
//
// History: this used to do a Firestore batch.update across all alert_ids.
// batch.update throws if ANY referenced doc is missing - which would
// happen any time even one alert in the list had auto-expired between
// the responder's last list-fetch and this call. The whole batch failed,
// none of the legitimately-still-active alerts got marked, and the red
// dot stayed on the responder's tab. Now each alert is updated
// independently via Promise.allSettled, so missing docs (or any other
// per-doc failure) only skip themselves.
// ============================================================================

// Per-FID rate limiter for mark-seen. The endpoint is cheap server-side,
// but a buggy or hostile client could call it in a tight loop. 1s is
// well below the natural cadence (mark-seen is triggered by the
// responder opening the tab or scrolling).
const markSeenRateLimiter = makeRateLimiter(1000);

// Cap on alert_ids per call. Real responders see at most a few dozen
// alerts in their district at once; this defends against a malicious
// caller passing thousands of IDs to fan out reads/writes.
const MARK_SEEN_MAX_ALERT_IDS = 100;

app.post('/sos/mark-seen', async (req, res) => {
  console.log('👁️  /sos/mark-seen request received');

  try {
    const { fid, alert_ids } = req.body || {};

    // Strict input validation. fid must be a non-empty string; alert_ids
    // must be a non-empty array of non-empty strings; each id must look
    // like a Firestore doc ID (no path separators / quotes / control chars
    // - those would break dot-notation construction or worse).
    if (typeof fid !== 'string' || fid.length === 0 ||
        !Array.isArray(alert_ids) || alert_ids.length === 0) {
      return res.status(400).json({
        error: 'Missing or invalid required fields',
        required: ['fid (string)', 'alert_ids (non-empty string array)'],
      });
    }
    if (alert_ids.length > MARK_SEEN_MAX_ALERT_IDS) {
      return res.status(400).json({
        error: `Too many alert_ids (max ${MARK_SEEN_MAX_ALERT_IDS} per call)`,
      });
    }
    // Filter to only valid string IDs. Empty/invalid entries are dropped
    // silently rather than failing the whole call - the client may have
    // a stale view that includes garbage. Firestore IDs cannot contain
    // /, but we allow other characters since FIDs use a wide alphabet.
    const validIds = alert_ids.filter(
      id => typeof id === 'string' && id.length > 0 && !id.includes('/'),
    );
    if (validIds.length === 0) {
      return res.status(400).json({ error: 'No valid alert_ids supplied' });
    }

    if (markSeenRateLimiter.isLimited(fid)) {
      return res.status(429).json({ error: 'Too many requests' });
    }

    const db = admin.firestore();

    // Per-doc update via Promise.allSettled. Each update is independent;
    // a 'NOT_FOUND' on one alert (because it auto-expired) leaves the
    // rest untouched. We use update (not set+merge) so we never
    // accidentally create a stub alert doc with only seen_by populated.
    const results = await Promise.allSettled(
      validIds.map(id =>
        db.collection('sos_alerts').doc(id).update({
          [`seen_by.${fid}`]: true,
        }),
      ),
    );

    let marked = 0;
    let skipped = 0;
    for (const r of results) {
      if (r.status === 'fulfilled') marked++;
      else skipped++;
    }

    if (skipped > 0) {
      console.log(`👁️  mark-seen: FID ${fid} marked ${marked}, ${skipped} skipped (likely expired)`);
    } else {
      console.log(`✅ mark-seen: FID ${fid} saw ${marked} alert(s)`);
    }

    return res.json({
      success: true,
      fid,
      marked,
      skipped,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    // Reaches here only on truly unexpected errors (e.g. Firestore
    // unavailable). Per-doc errors are absorbed by allSettled above.
    console.error('❌ /sos/mark-seen unexpected error:', error);
    return res.status(500).json({
      error: 'Failed to mark alerts as seen',
      message: error.message,
    });
  }
});

// ============================================================================
// USER SUBSCRIPTION REGISTRATION
// Upserts a subscribed_users document when a device subscribes to a district.
// Called by the mobile app on district subscription (init + district change).
// POST /subscribe-user
// Body: { fid, name, number, district, state, fcm_token }
// ============================================================================
app.post('/subscribe-user', async (req, res) => {
  console.log('📋 /subscribe-user request received');

  try {
    const { fid, name, number, district, state, fcm_token } = req.body;

    if (!fid || !district) {
      return res.status(400).json({
        error: 'Missing required fields',
        required: ['fid', 'district'],
        optional: ['name', 'number', 'state', 'fcm_token']
      });
    }

    const userData = {
      fid,
      district,
      last_subscribed_at: admin.firestore.FieldValue.serverTimestamp(),
    };

    if (name)      userData.name      = name;
    if (number)    userData.number    = number;
    if (state)     userData.state     = state;
    if (fcm_token) userData.fcm_token = fcm_token;

    await admin.firestore()
      .collection('subscribed_users')
      .doc(fid)
      .set(userData, { merge: true });

    console.log(`✅ subscribed_users upserted for FID: ${fid} (district: ${district})`);

    return res.json({
      success: true,
      message: 'User subscription registered',
      fid,
      district,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ /subscribe-user error:', error);
    return res.status(500).json({
      error: 'Failed to register user subscription',
      message: error.message
    });
  }
});

// ============================================================================
// CHAT - Initiate a 1:1 conversation between a volunteer and an SOS sender
// POST /chat/initiate
// Body: { responder_fid, responder_name, sender_fid, sender_name, district }
// The conversation document ID is derived by sorting both FIDs so the same
// two users always land on the same document regardless of who initiates.
// ============================================================================
app.post('/chat/initiate', async (req, res) => {
  console.log('💬 /chat/initiate request received');

  const { responder_fid, responder_name, sender_fid, sender_name, district } = req.body;

  if (!responder_fid || !sender_fid || !district) {
    return res.status(400).json({
      error: 'Missing required fields',
      required: ['responder_fid', 'sender_fid', 'district'],
      optional: ['responder_name', 'sender_name'],
    });
  }

  if (responder_fid === sender_fid) {
    return res.status(400).json({ error: 'responder_fid and sender_fid must be different' });
  }

  // Deterministic conversation ID — sorted so order never matters
  const conv_id = [responder_fid, sender_fid].sort().join('_');

  try {
    const db = admin.firestore();
    const convRef = db.collection('sos_conversations').doc(conv_id);

    // Read the current SOS alert to capture the active_session_id.
    // This token is written by storeSOSAlert on every new SOS trigger, so if
    // the SOS re-triggers later the session IDs will diverge and the chat will
    // appear archived — without touching any expiry code path.
    const alertDoc = await db.collection('sos_alerts').doc(sender_fid).get();
    const chatSosSessionId = alertDoc.exists
      ? (alertDoc.data().active_session_id || '')
      : '';

    const convDoc = await convRef.get();
    const now = Date.now();

    if (!convDoc.exists) {
      await convRef.set({
        participants: [responder_fid, sender_fid],
        participant_names: {
          [responder_fid]: responder_name || 'Unknown',
          [sender_fid]: sender_name || 'Unknown',
        },
        active_alert_owner: sender_fid,
        chat_sos_session_id: chatSosSessionId,
        alert_district: district,
        created_at: now,
        last_message_at: now,
        messages: [],
      });
      console.log(`✅ sos_conversations created: ${conv_id}`);
    } else {
      // Roles may have flipped — update active_alert_owner and refresh names.
      // Always refresh chat_sos_session_id so it matches the current SOS cycle.
      const nameUpdate = {
        active_alert_owner: sender_fid,
        chat_sos_session_id: chatSosSessionId,
        alert_district: district,
      };
      // Only overwrite a name if the caller provided one
      if (responder_name) nameUpdate[`participant_names.${responder_fid}`] = responder_name;
      if (sender_name)    nameUpdate[`participant_names.${sender_fid}`]    = sender_name;
      await convRef.update(nameUpdate);
      console.log(`✅ sos_conversations updated: ${conv_id} (existing, roles may have flipped)`);
    }

    // Record the responder on the SOS alert so the sender knows who is responding
    try {
      await db.collection('sos_alerts').doc(sender_fid).update({
        responder_ids: admin.firestore.FieldValue.arrayUnion(responder_fid),
      });
    } catch (alertErr) {
      // Non-fatal — alert doc may have already expired
      console.warn(`⚠️ Could not update responder_ids on sos_alerts/${sender_fid}: ${alertErr.message}`);
    }

    return res.json({ success: true, conv_id });
  } catch (error) {
    console.error('❌ /chat/initiate error:', error);
    return res.status(500).json({ error: 'Failed to initiate conversation', message: error.message });
  }
});

// ============================================================================
// CHAT - Send a message in an existing conversation
// POST /chat/send-message
// Body: { conv_id, from_fid, text }
// Appends the message to the conversation document and sends an FCM push
// notification to the other participant if their FCM token is available.
//
// Storage shape: messages live as an array on a single sos_conversations/{conv_id}
// document. Firestore docs are capped at 1 MB. Without bounds this will silently
// start failing arrayUnion writes once a conversation grows past that limit.
//
// Defenses (in order):
//   1. Per-FID rate limit (chatSendRateLimiter, 0.5s) - real users can't type
//      faster than this; programmatic floods get 429.
//   2. Strict input validation - text must be a string, capped at 1000 chars
//      AND 4000 UTF-8 bytes (so 1000 4-byte emoji can't blow past the budget).
//   3. Transactional append with a 200-message cap. When the cap is hit, the
//      oldest messages are dropped to make room. This trades some chat history
//      for guaranteed deliverability. In practice the daily 00:00 IST wipe
//      means conversations rarely live longer than ~16 hours, so 200 messages
//      worth of headroom is more than enough for any real conversation.
//
// 200 msgs * 4 KB worst-case = 800 KB, comfortably under the 1 MB document
// limit even with the surrounding doc fields (participants, names, etc).
// ============================================================================

// Hard cap on messages retained per conversation. Once exceeded, the oldest
// messages are dropped on each new send.
const CHAT_MAX_MESSAGES_PER_CONV = 200;
// Soft warning threshold. We log loudly when a conversation crosses this so
// we notice if real users are bumping into the cap (which would suggest the
// cap should rise, the daily wipe is broken, or a client is looping).
const CHAT_MESSAGE_WARN_THRESHOLD = 150;
// Per-message size limits. Both apply; the stricter one wins. Chars-only
// would let a 1000-emoji message (each up to 4 UTF-8 bytes) blow the
// per-conversation byte budget, hence the byte cap.
const CHAT_TEXT_MAX_CHARS = 1000;
const CHAT_TEXT_MAX_BYTES = 4000;

app.post('/chat/send-message', async (req, res) => {
  console.log('📨 /chat/send-message request received');

  const { conv_id, from_fid, text } = req.body || {};

  // Strict input validation. text MUST be a string; rejecting non-string
  // payloads here prevents a malicious client from sneaking objects/arrays
  // into the messages array which the Flutter client would then crash on
  // when casting to Map<String, dynamic>.
  if (typeof conv_id !== 'string' || conv_id.length === 0 ||
      typeof from_fid !== 'string' || from_fid.length === 0 ||
      typeof text !== 'string') {
    return res.status(400).json({
      error: 'Missing or invalid required fields',
      required: ['conv_id (string)', 'from_fid (string)', 'text (string)'],
    });
  }

  const trimmedText = text.trim();
  if (trimmedText.length === 0) {
    return res.status(400).json({ error: 'Message text is empty' });
  }
  if (trimmedText.length > CHAT_TEXT_MAX_CHARS) {
    return res.status(400).json({
      error: `Message too long (max ${CHAT_TEXT_MAX_CHARS} characters)`,
    });
  }
  // UTF-8 byte cap. Buffer.byteLength is the actual on-disk Firestore cost.
  if (Buffer.byteLength(trimmedText, 'utf8') > CHAT_TEXT_MAX_BYTES) {
    return res.status(400).json({
      error: `Message too large (max ${CHAT_TEXT_MAX_BYTES} bytes UTF-8)`,
    });
  }

  // Per-FID rate limit. 1 msg / 0.5s. A real user typing can't approach this;
  // programmatic flooders get 429.
  if (chatSendRateLimiter.isLimited(from_fid)) {
    return res.status(429).json({
      error: 'Too many messages',
      message: 'Please slow down before sending another message.',
    });
  }

  try {
    const db = admin.firestore();
    const convRef = db.collection('sos_conversations').doc(conv_id);

    // Transactional append. We use a transaction (rather than arrayUnion)
    // for three reasons:
    //   a) Need to read the existing array length to enforce the cap.
    //   b) Two parallel sends near the cap could otherwise both pass the
    //      "still under cap" check and both append, exceeding the cap.
    //   c) arrayUnion deduplicates by deep value equality. With ms-precision
    //      timestamps this almost never matters, but if two messages from
    //      the same sender arrive in the same millisecond with identical
    //      text, one would be silently dropped. Replacing the array
    //      outright via tx.update avoids this.
    const now = Date.now();
    const newMessage = { from: from_fid, text: trimmedText, timestamp: now };

    const result = await db.runTransaction(async (tx) => {
      const snap = await tx.get(convRef);
      if (!snap.exists) {
        return { status: 404 };
      }
      const data = snap.data() || {};

      // Verify sender is a participant. Inside the tx so a parallel
      // /chat/initiate that flips roles can't open an impersonation
      // window between read and write.
      const participants = Array.isArray(data.participants) ? data.participants : [];
      if (!participants.includes(from_fid)) {
        return { status: 403 };
      }

      // Read current messages. Tolerate a missing or wrong-shape field -
      // if a future schema change leaves it absent, treat as empty.
      const existing = Array.isArray(data.messages) ? data.messages.slice() : [];

      // Cap enforcement. If we're at or over the cap, drop oldest messages
      // so the new one fits. We compare against the cap directly (not cap-1)
      // and shift until under cap, then append.
      let droppedCount = 0;
      while (existing.length >= CHAT_MAX_MESSAGES_PER_CONV) {
        existing.shift();
        droppedCount++;
      }
      existing.push(newMessage);

      tx.update(convRef, {
        messages: existing,
        last_message_at: now,
      });

      return {
        status: 200,
        recipientFid: participants.find(p => p !== from_fid) || null,
        senderName: (data.participant_names && data.participant_names[from_fid]) || 'Someone',
        messageCount: existing.length,
        droppedCount,
      };
    });

    if (result.status === 404) {
      return res.status(404).json({ error: 'Conversation not found' });
    }
    if (result.status === 403) {
      return res.status(403).json({ error: 'Sender is not a participant of this conversation' });
    }

    if (result.droppedCount > 0) {
      // Loud-but-not-fatal: real users shouldn't ever hit this. If we see
      // it in production logs it means either a chat survived past the
      // daily wipe or a client is looping. Either way, worth investigating.
      console.warn(`⚠️ /chat/send-message: dropped ${result.droppedCount} oldest message(s) ` +
                   `from conv ${conv_id} to keep within cap of ${CHAT_MAX_MESSAGES_PER_CONV}`);
    } else if (result.messageCount >= CHAT_MESSAGE_WARN_THRESHOLD) {
      // Approaching the cap. Soft warning so we have a heads-up before
      // the cap actually starts dropping messages.
      console.warn(`⚠️ /chat/send-message: conv ${conv_id} now has ${result.messageCount} ` +
                   `messages (warn threshold ${CHAT_MESSAGE_WARN_THRESHOLD}, cap ${CHAT_MAX_MESSAGES_PER_CONV})`);
    }

    // Send FCM push to the other participant. Anything that fails here is
    // strictly non-fatal: the message is already persisted, and the
    // recipient's app will surface it on the next snapshot. We don't want
    // notification failure to surface as "message not sent" to the sender.
    if (result.recipientFid) {
      try {
        const recipientDoc = await db.collection('subscribed_users').doc(result.recipientFid).get();
        const fcmToken = recipientDoc.data()?.fcm_token;

        if (fcmToken) {
          const notifBody = trimmedText.length > 100
            ? `${trimmedText.substring(0, 97)}...`
            : trimmedText;

          await admin.messaging().send({
            token: fcmToken,
            notification: {
              title: `Message from ${result.senderName}`,
              body: notifBody,
            },
            data: {
              type: 'chat_message',
              conv_id: conv_id,
              from_fid: from_fid,
              sender_name: result.senderName,
            },
            android: {
              priority: 'high',
              notification: { channelId: 'chat_messages' },
            },
            apns: {
              payload: { aps: { sound: 'default' } },
            },
          });
          console.log(`✅ Chat FCM sent to ${result.recipientFid}`);
        } else {
          console.warn(`⚠️ No FCM token for recipient ${result.recipientFid}`);
        }
      } catch (fcmError) {
        // Non-fatal — message was written; only notification failed
        console.warn(`⚠️ Chat FCM send failed: ${fcmError.message}`);
      }
    }

    return res.json({ success: true });
  } catch (error) {
    console.error('❌ /chat/send-message error:', error);
    return res.status(500).json({ error: 'Failed to send message', message: error.message });
  }
});

// ============================================================================
// MEDIA ATTACH / DETACH - photo and voice URLs on sos_alerts
//
// History: the mobile client used to write photo_urls and voice_url
// directly to sos_alerts via Firestore set(merge:true). That meant the
// Firestore Security Rules had to either (a) leave sos_alerts wide open
// to writes - bad - or (b) accept field-level updates with an unauth'd
// caller who self-asserts their senderId - also bad.
//
// These endpoints fix both: the client uploads bytes to Firebase Storage
// (Storage rules enforce path == sos_photos/{senderId}/* using App
// Check), gets the URL, and then asks the backend to attach it. The
// backend validates that the URL actually points at the sender's own
// Storage path before merging onto the alert doc. This means even if a
// caller forges a senderId on the wire, they can only attach a URL that
// they themselves uploaded, and only to their own alert.
//
// Per-FID rate-limit (2s) caps abuse. App Check (added later) will
// authenticate the device.
// ============================================================================

// Strict allowlist for photo storage paths. The URL must be a Firebase
// Storage download URL whose object path is sos_photos/{senderId}/...
// We don't try to be clever about URL parsing - just two cheap checks:
//   - URL starts with the Firebase Storage host
//   - the object path encoded in the URL matches the expected prefix
// If a future SDK version changes URL shapes, we update this.
function urlMatchesStoragePrefix(url, expectedPrefix) {
  if (typeof url !== 'string' || !url.startsWith('https://')) return false;
  // Firebase Storage download URLs encode the object path after `/o/`,
  // URL-encoded. Example:
  //   https://firebasestorage.googleapis.com/v0/b/<bucket>/o/sos_photos%2F<fid>%2F<file>?alt=media&token=...
  const m = url.match(/\/o\/([^?]+)/);
  if (!m) return false;
  let decoded;
  try { decoded = decodeURIComponent(m[1]); } catch { return false; }
  return decoded.startsWith(expectedPrefix);
}

// POST /sos/attach-photo  body: { sender_id, url }
// Appends url to sos_alerts/{sender_id}.photo_urls.
app.post('/sos/attach-photo', async (req, res) => {
  const { sender_id, url } = req.body || {};
  if (!sender_id || !url) {
    return res.status(400).json({ error: 'Missing sender_id or url' });
  }
  if (mediaAttachRateLimiter.isLimited(sender_id)) {
    return res.status(429).json({ error: 'Too many requests' });
  }
  if (!urlMatchesStoragePrefix(url, `sos_photos/${sender_id}/`)) {
    console.warn(`⚠️ /sos/attach-photo: url does not match sender's storage path`);
    return res.status(400).json({ error: 'URL does not match sender storage path' });
  }
  try {
    const ref = admin.firestore().collection('sos_alerts').doc(sender_id);

    // Use a transaction so the photo-limit check and arrayUnion are atomic.
    // Without it, two parallel attach calls could both read length < 3 and
    // both append, ending with 4 (or more) photos on the alert. The
    // transaction also guarantees we never attach to an inactive alert
    // even if the active flag flipped between the read and the write.
    const result = await admin.firestore().runTransaction(async (tx) => {
      const doc = await tx.get(ref);
      if (!doc.exists) return { status: 404 };
      const data = doc.data() || {};
      if (data.active !== true) return { status: 409, error: 'Alert is not active' };
      const current = Array.isArray(data.photo_urls) ? data.photo_urls : [];
      if (current.includes(url)) {
        // Idempotent re-attach (client retried) - return success.
        return { status: 200, photo_urls: current, idempotent: true };
      }
      if (current.length >= 3) return { status: 409, error: 'Photo limit reached' };
      tx.update(ref, {
        photo_urls: admin.firestore.FieldValue.arrayUnion(url),
      });
      return { status: 200, photo_urls: [...current, url] };
    });

    if (result.status === 404) {
      return res.status(404).json({ error: 'Alert not found for this sender_id' });
    }
    if (result.status === 409) {
      return res.status(409).json({ error: result.error });
    }
    if (result.idempotent) {
      return res.json({ success: true, photo_urls: result.photo_urls });
    }
    console.log(`📷 attached photo to sos_alerts/${sender_id}`);
    return res.json({ success: true });
  } catch (e) {
    console.error('❌ /sos/attach-photo error:', e);
    return res.status(500).json({ error: 'Internal error', message: e.message });
  }
});

// POST /sos/detach-photo  body: { sender_id, url }
// Removes url from sos_alerts/{sender_id}.photo_urls AND deletes the
// underlying Storage object (best-effort).
app.post('/sos/detach-photo', async (req, res) => {
  const { sender_id, url } = req.body || {};
  if (!sender_id || !url) {
    return res.status(400).json({ error: 'Missing sender_id or url' });
  }
  if (mediaDetachRateLimiter.isLimited(sender_id)) {
    return res.status(429).json({ error: 'Too many requests' });
  }
  if (!urlMatchesStoragePrefix(url, `sos_photos/${sender_id}/`)) {
    return res.status(400).json({ error: 'URL does not match sender storage path' });
  }
  try {
    await admin.firestore().collection('sos_alerts').doc(sender_id).update({
      photo_urls: admin.firestore.FieldValue.arrayRemove(url),
    });
    // Best-effort Storage delete - don't fail the request if the object
    // is already gone (e.g. concurrent auto-expire cleanup).
    try {
      const m = url.match(/\/o\/([^?]+)/);
      if (m) {
        const objectPath = decodeURIComponent(m[1]);
        await admin.storage().bucket().file(objectPath).delete();
      }
    } catch (storageErr) {
      console.warn(`⚠️ detach-photo: storage delete non-fatal: ${storageErr.message}`);
    }
    return res.json({ success: true });
  } catch (e) {
    console.error('❌ /sos/detach-photo error:', e);
    return res.status(500).json({ error: 'Internal error', message: e.message });
  }
});

// POST /sos/attach-voice  body: { sender_id, url }
// Sets sos_alerts/{sender_id}.voice_url = url. Replaces any prior voice.
app.post('/sos/attach-voice', async (req, res) => {
  const { sender_id, url } = req.body || {};
  if (!sender_id || !url) {
    return res.status(400).json({ error: 'Missing sender_id or url' });
  }
  if (mediaAttachRateLimiter.isLimited(sender_id)) {
    return res.status(429).json({ error: 'Too many requests' });
  }
  if (!urlMatchesStoragePrefix(url, `sos_voice/${sender_id}/`)) {
    console.warn(`⚠️ /sos/attach-voice: url does not match sender's storage path`);
    return res.status(400).json({ error: 'URL does not match sender storage path' });
  }
  try {
    const ref = admin.firestore().collection('sos_alerts').doc(sender_id);
    const doc = await ref.get();
    if (!doc.exists) {
      return res.status(404).json({ error: 'Alert not found for this sender_id' });
    }
    const data = doc.data() || {};
    if (data.active !== true) {
      return res.status(409).json({ error: 'Alert is not active' });
    }
    // If a previous voice exists, delete its Storage object before
    // replacing the URL - otherwise we'd orphan the old recording.
    const previousUrl = data.voice_url;
    if (previousUrl && previousUrl !== url) {
      try {
        const m = previousUrl.match(/\/o\/([^?]+)/);
        if (m) {
          const objectPath = decodeURIComponent(m[1]);
          await admin.storage().bucket().file(objectPath).delete();
        }
      } catch (e) {
        console.warn(`⚠️ attach-voice: previous voice delete non-fatal: ${e.message}`);
      }
    }
    await ref.update({ voice_url: url });
    console.log(`🎙 attached voice to sos_alerts/${sender_id}`);
    return res.json({ success: true });
  } catch (e) {
    console.error('❌ /sos/attach-voice error:', e);
    return res.status(500).json({ error: 'Internal error', message: e.message });
  }
});

// POST /sos/detach-voice  body: { sender_id }
// Clears voice_url and deletes the underlying object.
app.post('/sos/detach-voice', async (req, res) => {
  const { sender_id } = req.body || {};
  if (!sender_id) {
    return res.status(400).json({ error: 'Missing sender_id' });
  }
  if (mediaDetachRateLimiter.isLimited(sender_id)) {
    return res.status(429).json({ error: 'Too many requests' });
  }
  try {
    const ref = admin.firestore().collection('sos_alerts').doc(sender_id);
    const doc = await ref.get();
    if (doc.exists) {
      const previousUrl = doc.data()?.voice_url;
      if (previousUrl) {
        try {
          const m = previousUrl.match(/\/o\/([^?]+)/);
          if (m) {
            const objectPath = decodeURIComponent(m[1]);
            await admin.storage().bucket().file(objectPath).delete();
          }
        } catch (e) {
          console.warn(`⚠️ detach-voice: storage delete non-fatal: ${e.message}`);
        }
      }
      await ref.update({ voice_url: admin.firestore.FieldValue.delete() });
    }
    return res.json({ success: true });
  } catch (e) {
    console.error('❌ /sos/detach-voice error:', e);
    return res.status(500).json({ error: 'Internal error', message: e.message });
  }
});

// ============================================================================
// CHAT MEDIA ATTACH / DETACH
//
// Mirrors the SOS media endpoints but for messages inside a chat
// conversation. Each chat-media URL is appended as a distinct message in
// the conversation's messages[] array, with kind='photo' or kind='voice'.
//
// Storage layout:
//   chat_photos/{conv_id}/{filename}.jpg
//   chat_voice/{conv_id}/{filename}.m4a
// Keyed on conv_id (not FID) because chat is two-way - either
// participant can attach. The conversation owns the bytes.
//
// Lifecycle: chat media is purged when the underlying SOS ends. See
// purgeChatMediaForSosOwner. The daily 00:00 IST chat wipe and the
// daily chat-media sweep are the safety nets.
//
// Authorization model (same gaps as SOS endpoints):
//   - sender_fid is self-asserted (no App Check yet).
//   - URL prefix MUST match chat_(photos|voice)/{conv_id}/* so a caller
//     can't paste a foreign URL onto someone's chat.
//   - sender must be in the conversation's participants array.
//   - The conversation's underlying SOS must be currently active (this
//     check is stricter than text /chat/send-message, which doesn't
//     verify session - acceptable because attaching to a dead chat
//     creates orphan storage objects, not just a stale text message).
//
// Per-FID rate limits: separate from SOS media so the two don't compete
// for budget.
// ============================================================================

// Per-FID rate limiters for chat media. Same shape as SOS media limits.
// Attach is the slower op (round-trip to Firestore + transaction); 2s
// keeps real users unaffected and caps abuse. Detach is fast; 0.5s.
const chatMediaAttachRateLimiter = makeRateLimiter(2 * 1000);
const chatMediaDetachRateLimiter = makeRateLimiter(500);

// Per-conversation media counts. Keep both tight since chat lives inside
// a 1MB doc - URLs are small but every attached message is a slot in the
// 200-message cap.
const CHAT_MAX_PHOTOS_PER_CONV = 3;
const CHAT_MAX_VOICE_PER_CONV = 4;

/**
 * Validates an attach request and (if valid) returns the conv data needed
 * for the rest of the endpoint. Centralized so the four endpoints don't
 * duplicate the same 30 lines.
 *
 * Returns { ok: false, status, error } on failure or
 * { ok: true, convData, recipientFid, senderName } on success.
 *
 * @param {object} args
 * @param {string} args.conv_id
 * @param {string} args.from_fid
 * @param {boolean} args.requireActiveSession - true for attach (don't
 *   want to add bytes to a dead chat); false for detach (always allow
 *   cleanup).
 */
async function validateChatMediaCaller({ conv_id, from_fid, requireActiveSession }) {
  if (typeof conv_id !== 'string' || conv_id.length === 0 ||
      typeof from_fid !== 'string' || from_fid.length === 0) {
    return { ok: false, status: 400, error: 'Missing or invalid conv_id / from_fid' };
  }

  const db = admin.firestore();
  const convRef = db.collection('sos_conversations').doc(conv_id);
  const convSnap = await convRef.get();
  if (!convSnap.exists) {
    return { ok: false, status: 404, error: 'Conversation not found' };
  }
  const data = convSnap.data() || {};
  const participants = Array.isArray(data.participants) ? data.participants : [];
  if (!participants.includes(from_fid)) {
    return { ok: false, status: 403, error: 'Sender is not a participant of this conversation' };
  }

  if (requireActiveSession) {
    const owner = data.active_alert_owner;
    const sessionId = data.chat_sos_session_id;
    if (!owner) {
      return { ok: false, status: 409, error: 'Conversation has no active alert owner' };
    }
    const alertSnap = await db.collection('sos_alerts').doc(owner).get();
    const alertData = alertSnap.exists ? (alertSnap.data() || {}) : {};
    const live = alertData.active === true && alertData.active_session_id === sessionId;
    if (!live) {
      return { ok: false, status: 409, error: 'Conversation is archived (underlying SOS is no longer active)' };
    }
  }

  const recipientFid = participants.find(p => p !== from_fid) || null;
  const senderName = (data.participant_names && data.participant_names[from_fid]) || 'Someone';
  return { ok: true, convRef, convData: data, recipientFid, senderName };
}

// Helper: extract the storage object path from a Firebase Storage download URL.
// Format: https://firebasestorage.googleapis.com/v0/b/<bucket>/o/<urlencoded-path>?...
// Returns null if the URL doesn't match the expected shape.
function extractStorageObjectPath(url) {
  if (typeof url !== 'string') return null;
  const m = url.match(/\/o\/([^?]+)/);
  if (!m) return null;
  try { return decodeURIComponent(m[1]); } catch { return null; }
}

// POST /chat/attach-photo  body: { conv_id, from_fid, url, caption? }
// Appends a photo message to the conversation. Caption optional, max
// 200 chars (shorter than text-message cap because it's secondary to
// the image).
app.post('/chat/attach-photo', async (req, res) => {
  const { conv_id, from_fid, url, caption } = req.body || {};
  if (typeof url !== 'string' || url.length === 0) {
    return res.status(400).json({ error: 'Missing or invalid url' });
  }
  if (caption !== undefined && caption !== null && typeof caption !== 'string') {
    return res.status(400).json({ error: 'caption must be a string if provided' });
  }
  if (typeof caption === 'string' && caption.length > 200) {
    return res.status(400).json({ error: 'caption too long (max 200 chars)' });
  }
  if (!urlMatchesStoragePrefix(url, `chat_photos/${conv_id}/`)) {
    return res.status(400).json({ error: 'URL does not match conversation storage path' });
  }
  if (chatMediaAttachRateLimiter.isLimited(from_fid)) {
    return res.status(429).json({ error: 'Too many requests' });
  }

  try {
    const v = await validateChatMediaCaller({ conv_id, from_fid, requireActiveSession: true });
    if (!v.ok) return res.status(v.status).json({ error: v.error });

    const trimmedCaption = typeof caption === 'string' ? caption.trim() : '';
    const now = Date.now();
    // Fallback text: rendered as plain message body by older client
    // builds that don't recognize kind=='photo'. Newer clients render
    // the photo_url and ignore this text field. Without a fallback,
    // a caption-less photo would show as an empty bubble on old
    // clients. Show "📷 Photo" or the caption text.
    const fallbackText = trimmedCaption.length > 0
      ? trimmedCaption
      : '📷 Photo';
    const newMessage = {
      from: from_fid,
      kind: 'photo',
      photo_url: url,
      text: fallbackText,
      timestamp: now,
    };

    // Transactional append - same pattern as text send-message:
    //  - Re-verify participant inside tx (closes role-flip race).
    //  - Enforce 200-message cap (drop oldest if at cap).
    //  - Enforce per-conv photo count cap (max 20).
    //  - Idempotent re-attach: if the same URL is already attached,
    //    return 200 instead of attaching twice. Client retries on
    //    network glitch are common.
    const db = admin.firestore();
    const result = await db.runTransaction(async (tx) => {
      const snap = await tx.get(v.convRef);
      if (!snap.exists) return { status: 404 };
      const data = snap.data() || {};
      const parts = Array.isArray(data.participants) ? data.participants : [];
      if (!parts.includes(from_fid)) return { status: 403 };
      const existing = Array.isArray(data.messages) ? data.messages.slice() : [];

      // Idempotency check: same URL already attached?
      if (existing.some(m => m && m.kind === 'photo' && m.photo_url === url)) {
        return { status: 200, idempotent: true };
      }

      // Per-conv photo count cap. Counts only photo messages.
      const photoCount = existing.filter(m => m && m.kind === 'photo').length;
      if (photoCount >= CHAT_MAX_PHOTOS_PER_CONV) {
        return { status: 409, error: `Photo limit reached (max ${CHAT_MAX_PHOTOS_PER_CONV} per conversation)` };
      }

      // Drop oldest until under message cap.
      let droppedCount = 0;
      while (existing.length >= CHAT_MAX_MESSAGES_PER_CONV) {
        existing.shift();
        droppedCount++;
      }
      existing.push(newMessage);
      tx.update(v.convRef, { messages: existing, last_message_at: now });
      return { status: 200, droppedCount };
    });

    if (result.status === 404) return res.status(404).json({ error: 'Conversation not found' });
    if (result.status === 403) return res.status(403).json({ error: 'Sender is not a participant' });
    if (result.status === 409) return res.status(409).json({ error: result.error });
    if (result.idempotent) {
      console.log(`📷 /chat/attach-photo: idempotent re-attach to conv ${conv_id}`);
      return res.json({ success: true, idempotent: true });
    }
    if (result.droppedCount > 0) {
      console.warn(`⚠️ /chat/attach-photo: dropped ${result.droppedCount} oldest message(s) from conv ${conv_id}`);
    }
    console.log(`📷 attached photo to chat ${conv_id}`);

    // FCM push to recipient. Same non-fatal pattern as text send-message.
    if (v.recipientFid) {
      try {
        const recipientDoc = await admin.firestore().collection('subscribed_users').doc(v.recipientFid).get();
        const fcmToken = recipientDoc.data()?.fcm_token;
        if (fcmToken) {
          const body = trimmedCaption.length > 0
            ? (trimmedCaption.length > 80 ? `📷 ${trimmedCaption.substring(0, 77)}...` : `📷 ${trimmedCaption}`)
            : '📷 Sent a photo';
          await admin.messaging().send({
            token: fcmToken,
            notification: { title: `Message from ${v.senderName}`, body },
            data: {
              type: 'chat_message',
              conv_id, from_fid,
              sender_name: v.senderName,
              message_kind: 'photo',
            },
            android: { priority: 'high', notification: { channelId: 'chat_messages' } },
            apns: { payload: { aps: { sound: 'default' } } },
          });
        }
      } catch (fcmErr) {
        console.warn(`⚠️ chat photo FCM send failed: ${fcmErr.message}`);
      }
    }
    return res.json({ success: true });
  } catch (e) {
    console.error('❌ /chat/attach-photo error:', e);
    return res.status(500).json({ error: 'Internal error', message: e.message });
  }
});

// POST /chat/detach-photo  body: { conv_id, from_fid, url }
// Removes a photo message from the conversation AND deletes the
// underlying Storage object. Only the original sender of the photo
// can detach it (so a participant can't delete the other party's
// media unilaterally).
app.post('/chat/detach-photo', async (req, res) => {
  const { conv_id, from_fid, url } = req.body || {};
  if (typeof url !== 'string' || url.length === 0) {
    return res.status(400).json({ error: 'Missing or invalid url' });
  }
  if (!urlMatchesStoragePrefix(url, `chat_photos/${conv_id}/`)) {
    return res.status(400).json({ error: 'URL does not match conversation storage path' });
  }
  if (chatMediaDetachRateLimiter.isLimited(from_fid)) {
    return res.status(429).json({ error: 'Too many requests' });
  }

  try {
    // For detach we don't require active session - cleanup must always
    // be allowed, even on archived chats.
    const v = await validateChatMediaCaller({ conv_id, from_fid, requireActiveSession: false });
    if (!v.ok) return res.status(v.status).json({ error: v.error });

    const db = admin.firestore();
    const result = await db.runTransaction(async (tx) => {
      const snap = await tx.get(v.convRef);
      if (!snap.exists) return { status: 404 };
      const data = snap.data() || {};
      const parts = Array.isArray(data.participants) ? data.participants : [];
      if (!parts.includes(from_fid)) return { status: 403 };

      const existing = Array.isArray(data.messages) ? data.messages.slice() : [];
      const idx = existing.findIndex(m => m && m.kind === 'photo' && m.photo_url === url);
      if (idx < 0) return { status: 404, error: 'Photo not found in conversation' };
      // Only the original sender may detach. Prevents responder-deletes-
      // sender-evidence and vice versa. Server-enforced; clients should
      // hide the delete affordance for foreign messages anyway.
      if (existing[idx].from !== from_fid) {
        return { status: 403, error: 'Only the sender can delete their own photo' };
      }
      existing.splice(idx, 1);
      tx.update(v.convRef, { messages: existing });
      return { status: 200 };
    });

    if (result.status === 404) return res.status(404).json({ error: result.error || 'Conversation not found' });
    if (result.status === 403) return res.status(403).json({ error: result.error || 'Forbidden' });

    // Best-effort Storage delete - don't fail the request if the object
    // is already gone (concurrent purge from SOS termination).
    try {
      const objectPath = extractStorageObjectPath(url);
      if (objectPath) {
        await admin.storage().bucket().file(objectPath).delete();
      }
    } catch (storageErr) {
      console.warn(`⚠️ /chat/detach-photo: storage delete non-fatal: ${storageErr.message}`);
    }
    return res.json({ success: true });
  } catch (e) {
    console.error('❌ /chat/detach-photo error:', e);
    return res.status(500).json({ error: 'Internal error', message: e.message });
  }
});

// POST /chat/attach-voice  body: { conv_id, from_fid, url, duration_ms? }
// Appends a voice-note message to the conversation. duration_ms is
// optional but lets the UI render a scrub bar without loading the audio.
app.post('/chat/attach-voice', async (req, res) => {
  const { conv_id, from_fid, url, duration_ms } = req.body || {};
  if (typeof url !== 'string' || url.length === 0) {
    return res.status(400).json({ error: 'Missing or invalid url' });
  }
  if (duration_ms !== undefined && duration_ms !== null) {
    if (typeof duration_ms !== 'number' || !Number.isFinite(duration_ms) || duration_ms < 0 || duration_ms > 120000) {
      return res.status(400).json({ error: 'duration_ms must be a finite number between 0 and 120000' });
    }
  }
  if (!urlMatchesStoragePrefix(url, `chat_voice/${conv_id}/`)) {
    return res.status(400).json({ error: 'URL does not match conversation storage path' });
  }
  if (chatMediaAttachRateLimiter.isLimited(from_fid)) {
    return res.status(429).json({ error: 'Too many requests' });
  }

  try {
    const v = await validateChatMediaCaller({ conv_id, from_fid, requireActiveSession: true });
    if (!v.ok) return res.status(v.status).json({ error: v.error });

    const now = Date.now();
    // Fallback text: rendered as plain message body by older client
    // builds that don't recognize kind=='voice'. Newer clients render
    // the voice bubble UI and ignore this text field. Without a
    // fallback, voice notes would show as empty bubbles on old clients.
    const durationLabel = (typeof duration_ms === 'number' && duration_ms > 0)
      ? ` (${Math.round(duration_ms / 1000)}s)`
      : '';
    const newMessage = {
      from: from_fid,
      kind: 'voice',
      voice_url: url,
      text: `🎙 Voice note${durationLabel}`,
      timestamp: now,
    };
    if (typeof duration_ms === 'number') newMessage.voice_duration_ms = Math.round(duration_ms);

    const db = admin.firestore();
    const result = await db.runTransaction(async (tx) => {
      const snap = await tx.get(v.convRef);
      if (!snap.exists) return { status: 404 };
      const data = snap.data() || {};
      const parts = Array.isArray(data.participants) ? data.participants : [];
      if (!parts.includes(from_fid)) return { status: 403 };
      const existing = Array.isArray(data.messages) ? data.messages.slice() : [];

      if (existing.some(m => m && m.kind === 'voice' && m.voice_url === url)) {
        return { status: 200, idempotent: true };
      }

      const voiceCount = existing.filter(m => m && m.kind === 'voice').length;
      if (voiceCount >= CHAT_MAX_VOICE_PER_CONV) {
        return { status: 409, error: `Voice note limit reached (max ${CHAT_MAX_VOICE_PER_CONV} per conversation)` };
      }

      let droppedCount = 0;
      while (existing.length >= CHAT_MAX_MESSAGES_PER_CONV) {
        existing.shift();
        droppedCount++;
      }
      existing.push(newMessage);
      tx.update(v.convRef, { messages: existing, last_message_at: now });
      return { status: 200, droppedCount };
    });

    if (result.status === 404) return res.status(404).json({ error: 'Conversation not found' });
    if (result.status === 403) return res.status(403).json({ error: 'Sender is not a participant' });
    if (result.status === 409) return res.status(409).json({ error: result.error });
    if (result.idempotent) {
      console.log(`🎙 /chat/attach-voice: idempotent re-attach to conv ${conv_id}`);
      return res.json({ success: true, idempotent: true });
    }
    if (result.droppedCount > 0) {
      console.warn(`⚠️ /chat/attach-voice: dropped ${result.droppedCount} oldest message(s) from conv ${conv_id}`);
    }
    console.log(`🎙 attached voice to chat ${conv_id}`);

    if (v.recipientFid) {
      try {
        const recipientDoc = await admin.firestore().collection('subscribed_users').doc(v.recipientFid).get();
        const fcmToken = recipientDoc.data()?.fcm_token;
        if (fcmToken) {
          await admin.messaging().send({
            token: fcmToken,
            notification: { title: `Message from ${v.senderName}`, body: '🎙 Sent a voice note' },
            data: {
              type: 'chat_message',
              conv_id, from_fid,
              sender_name: v.senderName,
              message_kind: 'voice',
            },
            android: { priority: 'high', notification: { channelId: 'chat_messages' } },
            apns: { payload: { aps: { sound: 'default' } } },
          });
        }
      } catch (fcmErr) {
        console.warn(`⚠️ chat voice FCM send failed: ${fcmErr.message}`);
      }
    }
    return res.json({ success: true });
  } catch (e) {
    console.error('❌ /chat/attach-voice error:', e);
    return res.status(500).json({ error: 'Internal error', message: e.message });
  }
});

// POST /chat/detach-voice  body: { conv_id, from_fid, url }
// Removes a voice-note message and its Storage object. Same sender-only
// rule as detach-photo.
app.post('/chat/detach-voice', async (req, res) => {
  const { conv_id, from_fid, url } = req.body || {};
  if (typeof url !== 'string' || url.length === 0) {
    return res.status(400).json({ error: 'Missing or invalid url' });
  }
  if (!urlMatchesStoragePrefix(url, `chat_voice/${conv_id}/`)) {
    return res.status(400).json({ error: 'URL does not match conversation storage path' });
  }
  if (chatMediaDetachRateLimiter.isLimited(from_fid)) {
    return res.status(429).json({ error: 'Too many requests' });
  }

  try {
    const v = await validateChatMediaCaller({ conv_id, from_fid, requireActiveSession: false });
    if (!v.ok) return res.status(v.status).json({ error: v.error });

    const db = admin.firestore();
    const result = await db.runTransaction(async (tx) => {
      const snap = await tx.get(v.convRef);
      if (!snap.exists) return { status: 404 };
      const data = snap.data() || {};
      const parts = Array.isArray(data.participants) ? data.participants : [];
      if (!parts.includes(from_fid)) return { status: 403 };

      const existing = Array.isArray(data.messages) ? data.messages.slice() : [];
      const idx = existing.findIndex(m => m && m.kind === 'voice' && m.voice_url === url);
      if (idx < 0) return { status: 404, error: 'Voice note not found in conversation' };
      if (existing[idx].from !== from_fid) {
        return { status: 403, error: 'Only the sender can delete their own voice note' };
      }
      existing.splice(idx, 1);
      tx.update(v.convRef, { messages: existing });
      return { status: 200 };
    });

    if (result.status === 404) return res.status(404).json({ error: result.error || 'Conversation not found' });
    if (result.status === 403) return res.status(403).json({ error: result.error || 'Forbidden' });

    try {
      const objectPath = extractStorageObjectPath(url);
      if (objectPath) {
        await admin.storage().bucket().file(objectPath).delete();
      }
    } catch (storageErr) {
      console.warn(`⚠️ /chat/detach-voice: storage delete non-fatal: ${storageErr.message}`);
    }
    return res.json({ success: true });
  } catch (e) {
    console.error('❌ /chat/detach-voice error:', e);
    return res.status(500).json({ error: 'Internal error', message: e.message });
  }
});

// ============================================================================
// CLOUD TASKS HANDLER - SOS alert auto-expiry
// ============================================================================

/**
 * Internal endpoint called by Cloud Tasks to auto-expire an SOS alert.
 * Only acts if the session_id still matches the alert's active_session_id,
 * which means no new alert has been triggered since this task was enqueued.
 */
app.post('/sosAutoExpire', async (req, res) => {
  // Verify the request originates from Cloud Tasks
  const queueName = req.headers['x-cloudtasks-queuename'];
  if (queueName !== CLOUD_TASKS_CONFIG.QUEUE) {
    console.warn('⚠️ /sosAutoExpire: rejected request without valid Cloud Tasks header');
    return res.status(403).json({ error: 'Forbidden' });
  }

  const { sender_id, session_id } = req.body;
  if (!sender_id || !session_id) {
    return res.status(400).json({ error: 'Missing sender_id or session_id' });
  }

  try {
    const alertRef = admin.firestore().collection('sos_alerts').doc(sender_id);
    const alertDoc = await alertRef.get();

    if (!alertDoc.exists) {
      console.log(`ℹ️ SOS auto-expire: no alert doc for ${sender_id}, skipping`);
      return res.json({ success: true, action: 'skipped', reason: 'no_document' });
    }

    const data = alertDoc.data();

    if (!data.active || data.active_session_id !== session_id) {
      console.log(`ℹ️ SOS auto-expire: session mismatch or already inactive for ${sender_id}, skipping`);
      return res.json({ success: true, action: 'skipped', reason: 'session_mismatch_or_inactive' });
    }

    // Clean up media (photos + voice) from Storage before expiring.
    // Shared helpers - same paths used by manual stop, hourly fallback,
    // and daily leftover sweep. Both SOS-direct media and chat media
    // tied to this sender's conversations are scoped to the alert.
    await purgeSosMedia(sender_id);
    await purgeChatMediaForSosOwner(sender_id);

    await alertRef.update({
      active: false,
      active_session_id: admin.firestore.FieldValue.delete(),
      photo_urls: [],
      voice_url: admin.firestore.FieldValue.delete(),
      expiredAt: admin.firestore.FieldValue.serverTimestamp(),
      expiredBy: 'cloud_task_ttl'
    });

    // Send resolution FCM to the district topic so responder devices
    // dismiss the active-alert push from their notification tray.
    // Without this, responders who got the original alert push keep
    // seeing it indefinitely - the in-app stream catches up but the
    // OS-level push doesn't go away on its own. Best-effort; alert
    // state is already authoritatively inactive in Firestore above.
    await sendSOSResolutionFcm({
      sender_id,
      district: data.district,
      userName: data.userInfo?.name,
      userLocation: data.userInfo?.location || data.approx_loc,
      expiredBy: 'cloud_task_ttl',
    });

    console.log(`✅ SOS alert auto-expired via Cloud Task for ${sender_id} (session: ${session_id})`);
    return res.json({ success: true, action: 'expired', sender_id });
  } catch (error) {
    console.error('❌ SOS auto-expire error:', error);
    // Return 200 to prevent Cloud Tasks from endlessly retrying on server errors
    return res.status(200).json({ success: false, error: error.message });
  }
});

// ============================================================================
// DELETE USER DATA
// Removes the device's documents from sos_alerts and subscribed_users.
// Called by the mobile app when the user taps "Delete My Data".
// POST /delete-user-data
// Body: { fid }
// ============================================================================
// Mobile users are not Firebase Auth users - they identify themselves via
// their Firebase Installation ID, which the device owns. The endpoint is
// therefore intentionally unauthenticated, and we rate-limit by FID
// (1 delete per FID per hour) to prevent a malicious caller from
// enumerating FIDs and deleting other users' data.
//
// Removes:
//   - sos_alerts/{fid}                       (active alert state)
//   - subscribed_users/{fid}                 (FCM token, district subscription)
//   - blocked_users/{fid}                    (block record if present)
//   - sos_conversations/* containing fid     (chat history both parties saw)
//   - chat_photos/{conv_id}/* and chat_voice/{conv_id}/* for each
//     conversation the user was in (best-effort, also caught by daily sweep)
//   - sos_photos/{fid}/* and sos_voice/{fid}/* from Storage
//
// Intentionally NOT removed:
//   - sos_alert_history/*                    (immutable operational audit
//                                             trail; preserved by daily
//                                             chat wipe too. Privacy-policy
//                                             question whether this should
//                                             be redacted/deleted - separate
//                                             decision from this endpoint.)
app.post('/delete-user-data', async (req, res) => {
  console.log('🗑️ /delete-user-data request received');

  try {
    const { fid } = req.body || {};

    if (typeof fid !== 'string' || fid.length === 0) {
      return res.status(400).json({ error: 'Missing or invalid fid (must be a non-empty string)' });
    }

    if (deleteRateLimiter.isLimited(fid)) {
      console.warn(`⚠️ Rate limited delete from FID: ${fid}`);
      return res.status(429).json({
        error: 'Too many requests',
        message: 'A delete request for this FID was processed recently. Please try again later.',
      });
    }

    const db = admin.firestore();
    const results = {};

    // ---- sos_alerts/{fid} -------------------------------------------------
    try {
      const alertRef = db.collection('sos_alerts').doc(fid);
      const alertDoc = await alertRef.get();
      if (alertDoc.exists) {
        await alertRef.delete();
        results.sos_alerts = 'deleted';
        console.log(`✅ sos_alerts/${fid} deleted`);
      } else {
        results.sos_alerts = 'not_found';
      }
    } catch (err) {
      console.warn(`⚠️ Could not delete sos_alerts/${fid}: ${err.message}`);
      results.sos_alerts = `error: ${err.message}`;
    }

    // ---- subscribed_users/{fid} -------------------------------------------
    try {
      const subRef = db.collection('subscribed_users').doc(fid);
      const subDoc = await subRef.get();
      if (subDoc.exists) {
        await subRef.delete();
        results.subscribed_users = 'deleted';
        console.log(`✅ subscribed_users/${fid} deleted`);
      } else {
        results.subscribed_users = 'not_found';
      }
    } catch (err) {
      console.warn(`⚠️ Could not delete subscribed_users/${fid}: ${err.message}`);
      results.subscribed_users = `error: ${err.message}`;
    }

    // ---- blocked_users/{fid} ----------------------------------------------
    // Without this, a user who was blocked and then deletes their data
    // leaves a tombstone record forever. The next FID they get on
    // reinstall is fine (different doc), but the old one rots in
    // blocked_users with no owner. This wasn't deleting before.
    try {
      const blockedRef = db.collection('blocked_users').doc(fid);
      const blockedDoc = await blockedRef.get();
      if (blockedDoc.exists) {
        await blockedRef.delete();
        results.blocked_users = 'deleted';
        console.log(`✅ blocked_users/${fid} deleted`);
      } else {
        results.blocked_users = 'not_found';
      }
    } catch (err) {
      console.warn(`⚠️ Could not delete blocked_users/${fid}: ${err.message}`);
      results.blocked_users = `error: ${err.message}`;
    }

    // ---- sos_conversations/* containing fid -------------------------------
    // Every conversation the user participated in gets nuked. Both
    // parties' chat history goes with it - acceptable because (a)
    // conversations are wiped nightly anyway, so the data lifetime is
    // short, (b) keeping the conv but removing this user's messages
    // would leave the other party with a half-broken thread, and
    // selectively redacting in-array messages is fragile. Chat media
    // (chat_photos/{conv_id}/, chat_voice/{conv_id}/) is purged inline
    // before each doc deletion so we don't leave orphan bytes.
    let convsDeleted = 0;
    let convsErrored = 0;
    try {
      const convSnap = await db.collection('sos_conversations')
        .where('participants', 'array-contains', fid)
        .get();
      for (const doc of convSnap.docs) {
        try {
          // Best-effort media purge; daily sweep is the safety net.
          await purgeChatMedia(doc.id).catch(() => {});
          await doc.ref.delete();
          convsDeleted++;
        } catch (perDocErr) {
          console.warn(`⚠️ Could not delete sos_conversations/${doc.id}: ${perDocErr.message}`);
          convsErrored++;
        }
      }
      results.sos_conversations = `deleted: ${convsDeleted}, errors: ${convsErrored}`;
      if (convsDeleted > 0) {
        console.log(`✅ sos_conversations cleared for ${fid}: ${convsDeleted} conv(s) deleted`);
      }
    } catch (err) {
      console.warn(`⚠️ Could not query sos_conversations for ${fid}: ${err.message}`);
      results.sos_conversations = `error: ${err.message}`;
    }

    // ---- Storage: sos_photos/{fid}/* and sos_voice/{fid}/* ----------------
    // Reuses the same purge helper as the SOS termination paths.
    try {
      const r = await purgeSosMedia(fid);
      results.sos_storage = `photos: ${r.photos}, voice: ${r.voice}`;
    } catch (err) {
      console.warn(`⚠️ Storage purge failed for ${fid}: ${err.message}`);
      results.sos_storage = `error: ${err.message}`;
    }

    return res.json({
      success: true,
      message: 'User data deleted',
      fid,
      results,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('❌ /delete-user-data error:', error);
    return res.status(500).json({
      error: 'Failed to delete user data',
      message: error.message
    });
  }
});

// GET /app-version — force update check
app.get(`/app-version`, async (req, res) => {
  try {
    const doc = await admin.firestore().collection(`app_config`).doc(`version`).get();
    if (!doc.exists) {
      return res.json({
        min_version: `1.0.0`,
        current_version: `2.0.0`,
        play_store_url: `https://play.google.com/store/apps/details?id=com.rrt.sos`,
        force_update_message: ``,
      });
    }
    return res.json(doc.data());
  } catch (e) {
    return res.status(500).json({ error: `Failed to fetch version config` });
  }
});

app.use((req, res) => {  // No path specified here—it's implied as catch-all
  res.status(404).json({ 
    error: 'Endpoint not found',
    availableEndpoints: [
      'GET /health',
      'GET /app-version',
      'GET /geocode/district?lat=<lat>&lng=<lng>',
      'POST /sos',
      'POST /sosAutoExpire (internal - Cloud Tasks only)',
      'POST /sos/attach-photo',
      'POST /sos/detach-photo',
      'POST /sos/attach-voice',
      'POST /sos/detach-voice',
      'POST /sos/mark-seen',
      'POST /subscribe-user',
      'POST /delete-user-data',
      'POST /feedback',
      'POST /chat/initiate',
      'POST /chat/send-message',
      'POST /chat/attach-photo',
      'POST /chat/detach-photo',
      'POST /chat/attach-voice',
      'POST /chat/detach-voice',
      'POST /test-push',
      'POST /admin/block-user',
      'POST /admin/unblock-user',
      'GET /admin/blocked-users',
      'GET /admin/sos-alerts?active=true',
      'GET /admin/profile (auth required)',
      'GET /admin/users (auth required)',
      'GET /admin/admins (super admin only)',
      'POST /admin/admins (super admin only)',
      'PUT /admin/admins/:email (super admin only)',
      'DELETE /admin/admins/:email (super admin only)'
    ]
  });
});

// Error handler (unchanged)
app.use((error, req, res, next) => { // eslint-disable-line no-unused-vars
  console.error('Server error:', error);
  res.status(500).json({ 
    error: 'Internal server error',
    message: error.message 
  });
});

// Export as Cloud Function (unchanged)
exports.api = functions.https.onRequest(app);

// ============================================================================
// SCHEDULED FUNCTIONS
// ============================================================================

/**
 * Scheduled function to automatically expire old active alerts
 * Runs every hour (configurable via SCHEDULE_CONFIG.ALERT_EXPIRATION_CHECK_INTERVAL)
 * Can be enabled/disabled via FEATURES.ENABLE_SOS_ALERT_SNAPSHOT
 * 
 * Configuration:
 * - ALERT_EXPIRATION_CHECK_INTERVAL: How often to run (default: every 1 hours)
 * - ALERT_EXPIRATION_THRESHOLD_MS: How old alerts must be to expire (default: 1 hour)
 */
exports.expireOldAlertsScheduled = onSchedule({
  schedule: SCHEDULE_CONFIG.ALERT_EXPIRATION_CHECK_INTERVAL,
  timeZone: 'Asia/Kolkata',  // IST timezone
}, async (event) => {
  console.log('⏰ Running scheduled alert expiration check');
  
  try {
    const result = await expireOldAlerts();
    
    console.log('✅ Scheduled alert expiration completed:', result);
    
    return result;
  } catch (error) {
    console.error('❌ Scheduled alert expiration failed:', error);
    throw error;
  }
});

/**
 * Daily chat wipe at midnight IST.
 *
 * Policy: emergency conversations are scoped to the day of the alert.
 * Every night at 00:00 Asia/Kolkata, delete every sos_conversations
 * document whose last_message_at is older than the start of the
 * current day, EXCEPT conversations whose linked SOS is still active.
 * Those are deferred to the next nightly run, by which point the
 * alert's 60-minute auto-expire will have fired.
 *
 * The "spare active" rule exists because of this edge case: an SOS
 * triggered at 11:30pm IST is still within its 60-minute auto-expire
 * window at 12:30am IST. Without the exclusion, the 00:00 wipe would
 * delete the conversation 30 minutes BEFORE the alert expires, and
 * two responders mid-rescue would lose their coordination chat. With
 * the exclusion, those conversations live until the next nightly
 * wipe (24 hours later), giving the alert plenty of time to finish
 * its lifecycle naturally.
 *
 * Cost of the exclusion: one extra Firestore read per candidate
 * conversation per night (to check if its linked alert is still
 * active). At expected service volume this is negligible — well
 * under 1,000 reads per night, against a free-tier 50K/day quota.
 *
 * Storage paths touched:
 *   - sos_conversations (delete the document)
 *   - chat_photos/{conv_id}/* (delete chat photos)
 *   - chat_voice/{conv_id}/* (delete chat voice notes)
 * sos_alert_history is preserved (it's the immutable audit trail).
 *
 * Robustness:
 *  - Paginated (500 docs per batch) to avoid hitting Firestore's 500-
 *    write-per-batch limit.
 *  - Idempotent: re-running the job in the same window simply finds
 *    no further docs to delete.
 *  - Per-batch try/catch so a single problematic doc doesn't kill the
 *    whole sweep.
 *  - Per-conv try/catch on the active-check so a single read failure
 *    doesn't poison the whole batch — we conservatively SKIP a conv
 *    if we can't determine its alert state, deferring the decision
 *    to the next nightly run. Skipping is the safer error mode (we
 *    might keep a conv one day longer than intended) vs deleting
 *    (which could interrupt a rescue).
 *  - Pagination cursor advances on skipped docs too, so we don't
 *    infinitely re-evaluate the same active conversations every batch.
 *  - Chat media purge is best-effort per-conv. The daily 00:00 IST
 *    media sweep (purgeSosMediaAtMidnightIST) is the safety net for
 *    any chat media we miss here.
 */
exports.wipeChatsAtMidnightIST = onSchedule({
  schedule: '0 0 * * *',           // 00:00 every day
  timeZone: 'Asia/Kolkata',
}, async (event) => {
  console.log('🌙 Running daily chat wipe (IST midnight)');
  const db = admin.firestore();

  // Cutoff = start of *today* in IST. Anything older than this is
  // wiped. We compute the cutoff in the function itself so a redeploy
  // in a different timezone doesn't change the policy.
  const nowIst = new Date();
  // toLocaleString in en-CA gives YYYY-MM-DD HH:mm:ss
  const istDateOnly = nowIst.toLocaleString('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric', month: '2-digit', day: '2-digit',
  });
  // Start-of-today in IST = istDateOnly + 00:00:00 IST in millis.
  // IST is UTC+5:30, no DST.
  const [y, mo, d] = istDateOnly.split('-').map(Number);
  const startOfTodayIstMs = Date.UTC(y, mo - 1, d, 0, 0, 0) - (5.5 * 60 * 60 * 1000);

  console.log(`Cutoff: deleting conversations with last_message_at < ${new Date(startOfTodayIstMs).toISOString()} (sparing those with an active SOS)`);

  let totalDeleted = 0;
  let totalSparedActive = 0;
  let totalChatPhotos = 0;
  let totalChatVoice = 0;
  const BATCH_SIZE = 500;

  // Pagination cursor: orderBy + startAfter on last_message_at lets us
  // advance past skipped (still-active) docs each iteration. Without
  // ordering, the same active conversations would re-appear in every
  // batch and we'd loop forever skipping them. With ordering, each
  // iteration sees a strictly later slice.
  let cursorMs = null;

  while (true) {
    let snap;
    try {
      // last_message_at is stored as millis (Date.now()) by /chat/send-message
      // and /chat/initiate. Range query without a separate index works
      // because there's no second filter or order constraint.
      let q = db.collection('sos_conversations')
        .where('last_message_at', '<', startOfTodayIstMs)
        .orderBy('last_message_at', 'asc')
        .limit(BATCH_SIZE);
      if (cursorMs !== null) q = q.startAfter(cursorMs);
      snap = await q.get();
    } catch (e) {
      console.error('❌ chat wipe: query failed:', e);
      break;
    }
    if (snap.empty) break;

    // Advance cursor to the last doc's last_message_at so the next
    // iteration starts strictly after it. This must happen regardless
    // of whether docs are deleted or skipped, otherwise we'd loop on
    // active convs forever.
    cursorMs = snap.docs[snap.docs.length - 1].data().last_message_at || cursorMs;

    // Partition this batch into (deletable, spared). A conv is spared
    // if its linked SOS alert is still active.
    const deletable = [];
    for (const doc of snap.docs) {
      const data = doc.data() || {};
      const owner = data.active_alert_owner;
      const sessionId = data.chat_sos_session_id;

      // No linked owner -> nothing to spare against -> safe to delete.
      // This handles legacy/orphan conversations that lack the link
      // fields, same as before this change.
      if (!owner) {
        deletable.push(doc);
        continue;
      }

      let live = false;
      try {
        const alertSnap = await db.collection('sos_alerts').doc(owner).get();
        if (alertSnap.exists) {
          const alertData = alertSnap.data() || {};
          // Match the existing helper's definition of "live" used in
          // the chat send path (around line 3260): active flag set AND
          // the conversation's session_id matches the alert's current
          // active_session_id. The session match prevents us from
          // sparing a conv linked to a STALE session of an alert that
          // has since been re-triggered.
          live = alertData.active === true &&
                 alertData.active_session_id === sessionId;
        }
      } catch (e) {
        // If we can't determine state, err on the side of NOT deleting.
        // Better to keep one extra conv overnight than to nuke a live
        // rescue chat.
        console.warn(`⚠️ chat wipe: alert read failed for ${doc.id}: ${e.message} — skipping (will retry next run)`);
        live = true;
      }

      if (live) {
        totalSparedActive++;
        // Don't add to deletable. The conv stays. Next nightly run
        // will re-evaluate; by then the alert's 60-minute auto-expire
        // will have fired.
      } else {
        deletable.push(doc);
      }
    }

    if (deletable.length === 0) {
      // Whole batch was spared. Continue to next cursor slice.
      if (snap.size < BATCH_SIZE) break;
      continue;
    }

    // Purge chat media for each deletable conv BEFORE deleting the doc.
    // We do this sequentially per-doc so a slow Storage op doesn't fan
    // out to 500 parallel listAll() calls. This is best-effort:
    // failures here log but don't stop the doc deletion - the daily
    // media sweep is the safety net.
    for (const doc of deletable) {
      try {
        const r = await purgeChatMedia(doc.id);
        totalChatPhotos += r.photos;
        totalChatVoice += r.voice;
      } catch (e) {
        console.warn(`⚠️ chat wipe: purgeChatMedia(${doc.id}) failed: ${e.message}`);
      }
    }

    const batch = db.batch();
    for (const doc of deletable) batch.delete(doc.ref);
    try {
      await batch.commit();
      totalDeleted += deletable.length;
      console.log(`🧹 deleted ${deletable.length} conversation(s); spared ${snap.size - deletable.length} active; total=${totalDeleted}`);
    } catch (e) {
      console.error(`❌ chat wipe batch commit failed: ${e.message}`);
      // Don't keep looping on the same batch - bail out and let the
      // next nightly run try again.
      break;
    }

    // If we got fewer than BATCH_SIZE results, we're done.
    if (snap.size < BATCH_SIZE) break;
  }

  console.log(`✅ chat wipe complete: ${totalDeleted} conversation(s) deleted, ${totalSparedActive} spared (active SOS), chat_photos=${totalChatPhotos}, chat_voice=${totalChatVoice}`);
  return {
    deleted: totalDeleted,
    spared_active: totalSparedActive,
    chat_photos: totalChatPhotos,
    chat_voice: totalChatVoice,
  };
});
/**
 * Daily SOS media leftover sweep at 00:00 IST.
 *
 * Policy: photos and voice notes attached to an SOS are scoped to the
 * lifetime of that SOS. They MUST be removed when the SOS ends - either
 * via manual stop, the 60-minute Cloud Task auto-expire, or the hourly
 * fallback (expireOldAlerts). Each of those paths now calls
 * purgeSosMedia, so under normal operation this nightly sweep finds
 * nothing.
 *
 * This job exists as the safety net for true leftovers: storage objects
 * orphaned because Storage was unreachable during cleanup, the alert
 * document was deleted out from under us, the Cloud Task never fired,
 * Firestore writes during cleanup raced and dropped the field, etc.
 *
 * Strategy:
 *   1. Walk every object under sos_photos/ and sos_voice/.
 *   2. Delete any object older than the active-window cutoff (75 min,
 *      slightly above the 60-min auto-expire so we never race with a
 *      legitimately active alert).
 *   3. For each remaining (younger) object, look up its parent
 *      sos_alerts doc. If the alert is inactive or missing, delete.
 *      If active, leave it alone - it's a live SOS in progress.
 *
 * The age-based cutoff is the primary defense; the active-flag check
 * is a belt-and-suspenders pass that catches recently-orphaned bytes.
 *
 * Robustness:
 *   - Per-file try/catch so one stuck object can't kill the sweep.
 *   - Idempotent: if everything is already cleaned up it's a no-op.
 *   - Logs counts for ops visibility - alerting on non-zero leftover
 *     counts in production tells us a cleanup path regressed.
 */
exports.purgeSosMediaAtMidnightIST = onSchedule({
  schedule: '0 0 * * *',           // 00:00 every day
  timeZone: 'Asia/Kolkata',
}, async (event) => {
  console.log('🌙 Running daily SOS media leftover sweep (IST midnight)');
  const bucket = admin.storage().bucket();
  const db = admin.firestore();

  // Anything older than this is unconditionally safe to delete - the
  // 60-min Cloud Task auto-expire would have run by now under any
  // healthy operation. 15-min cushion above 60 absorbs Cloud Tasks
  // delivery jitter.
  const ACTIVE_WINDOW_MS = 75 * 60 * 1000;
  const cutoffMs = Date.now() - ACTIVE_WINDOW_MS;

  // Cache sos_alerts lookups within this run so we don't read the same
  // doc once per object when a sender has multiple files.
  const alertActiveCache = new Map(); // sender_id -> boolean

  async function isAlertStillActive(sender_id) {
    if (alertActiveCache.has(sender_id)) {
      return alertActiveCache.get(sender_id);
    }
    let active = false;
    try {
      const snap = await db.collection('sos_alerts').doc(sender_id).get();
      active = !!(snap.exists && snap.data() && snap.data().active === true);
    } catch (e) {
      // On read failure, assume inactive so we err toward cleanup.
      // Worst case: a transient error wipes one in-flight alert's media.
      // Better case (and the real case 99.9% of the time): we delete an
      // actual leftover.
      console.warn(`⚠️ purge sweep: alert lookup failed for ${sender_id}: ${e.message}; treating as inactive`);
      active = false;
    }
    alertActiveCache.set(sender_id, active);
    return active;
  }

  // Extract sender_id from object name. Path is sos_photos/{fid}/file or
  // sos_voice/{fid}/file. Anything else is malformed and gets deleted.
  function extractSenderId(objectName) {
    const parts = objectName.split('/');
    if (parts.length < 3) return null;
    return parts[1] || null;
  }

  let scanned = 0;
  let deletedAged = 0;
  let deletedInactive = 0;
  let skippedActive = 0;
  let errors = 0;

  for (const prefix of ['sos_photos/', 'sos_voice/']) {
    let pageToken;
    do {
      let res;
      try {
        // getFiles is paginated; autoPaginate:false + pageToken keeps
        // memory bounded for large buckets.
        res = await bucket.getFiles({
          prefix,
          autoPaginate: false,
          maxResults: 1000,
          pageToken,
        });
      } catch (e) {
        console.error(`❌ purge sweep: getFiles(${prefix}) failed: ${e.message}`);
        errors++;
        break;
      }
      const files = res[0] || [];
      const nextQuery = res[1];
      pageToken = nextQuery && nextQuery.pageToken;

      for (const file of files) {
        scanned++;
        try {
          const meta = file.metadata || {};
          const updatedMs = meta.updated ? Date.parse(meta.updated) : 0;
          const senderId = extractSenderId(file.name);

          // Path 1: object older than the active window. Delete unconditionally.
          if (updatedMs && updatedMs < cutoffMs) {
            await file.delete().catch(() => {});
            deletedAged++;
            continue;
          }

          // Path 2: malformed path (no sender_id segment). Delete -
          // there's no alert for it to be attached to.
          if (!senderId) {
            await file.delete().catch(() => {});
            deletedInactive++;
            continue;
          }

          // Path 3: younger than cutoff - check whether the alert is
          // still live. If not (stopped, expired, or doc missing),
          // delete. If yes, this is an in-flight SOS and we leave it.
          const stillActive = await isAlertStillActive(senderId);
          if (!stillActive) {
            await file.delete().catch(() => {});
            deletedInactive++;
          } else {
            skippedActive++;
          }
        } catch (e) {
          console.error(`⚠️ purge sweep: error on ${file.name}: ${e.message}`);
          errors++;
        }
      }
    } while (pageToken);
  }

  const summary = { scanned, deletedAged, deletedInactive, skippedActive, errors };
  console.log(`✅ SOS media sweep complete:`, summary);
  // Non-zero deletedAged or deletedInactive in production means a
  // real-time cleanup path regressed - worth alerting on.
  return summary;
});

/**
 * Daily chat media leftover sweep at 00:00 IST.
 *
 * Mirror of purgeSosMediaAtMidnightIST but for chat-attached media. Chat
 * photos and voice notes live under chat_photos/{conv_id}/* and
 * chat_voice/{conv_id}/*, so cleanup is keyed on the conversation rather
 * than a single FID.
 *
 * Policy: chat media is scoped to the lifetime of the underlying SOS.
 * Real-time cleanup paths (manual stop, 60-min auto-expire, hourly
 * fallback) all call purgeChatMediaForSosOwner. The daily 00:00 IST
 * chat wipe also calls purgeChatMedia inline before deleting the conv
 * doc. This sweep is the safety net for everything they miss.
 *
 * Strategy mirrors the SOS sweep:
 *   1. Walk every object under chat_photos/ and chat_voice/.
 *   2. Delete any object older than the active-window cutoff (75 min,
 *      same as SOS sweep - chat media can't outlive its SOS, which itself
 *      auto-expires at 60 min).
 *   3. For each remaining (younger) object, look up its parent
 *      conversation. If the conversation is missing, or its
 *      active_alert_owner's SOS is inactive, delete. If active, leave
 *      it alone - this is a live conversation in an in-flight SOS.
 */
exports.purgeChatMediaAtMidnightIST = onSchedule({
  schedule: '0 0 * * *',           // 00:00 every day
  timeZone: 'Asia/Kolkata',
}, async (event) => {
  console.log('🌙 Running daily chat media leftover sweep (IST midnight)');
  const bucket = admin.storage().bucket();
  const db = admin.firestore();

  // Same active-window cutoff as the SOS sweep. Chat media can't outlive
  // its underlying SOS, and SOS auto-expires at 60 min, so 75 min is
  // a safe "definitely stale" boundary.
  const ACTIVE_WINDOW_MS = 75 * 60 * 1000;
  const cutoffMs = Date.now() - ACTIVE_WINDOW_MS;

  // Cache: conv_id -> bool (is the conversation's underlying SOS active).
  // A conv with no doc, or whose alert_owner has no active SOS, returns
  // false. We cache because a single conv often has multiple media files.
  const convActiveCache = new Map();

  async function isConversationLive(conv_id) {
    if (convActiveCache.has(conv_id)) return convActiveCache.get(conv_id);
    let live = false;
    try {
      const convSnap = await db.collection('sos_conversations').doc(conv_id).get();
      if (convSnap.exists) {
        const data = convSnap.data() || {};
        const owner = data.active_alert_owner;
        const sessionId = data.chat_sos_session_id;
        if (owner) {
          const alertSnap = await db.collection('sos_alerts').doc(owner).get();
          if (alertSnap.exists) {
            const a = alertSnap.data() || {};
            // Live iff the alert is currently active AND its session token
            // matches the one this conversation was created against. A
            // re-triggered SOS gets a new session_id, which means an old
            // chat from the previous SOS cycle is correctly treated as
            // archived - and its media as deletable.
            live = a.active === true && a.active_session_id === sessionId;
          }
        }
      }
    } catch (e) {
      // On lookup failure, err toward cleanup. Same reasoning as the
      // SOS sweep: a transient error wiping one in-flight conv's media
      // is a worse-case rare event vs. correctly deleting an actual
      // leftover, which is the common case.
      console.warn(`⚠️ chat media sweep: lookup failed for conv ${conv_id}: ${e.message}; treating as inactive`);
      live = false;
    }
    convActiveCache.set(conv_id, live);
    return live;
  }

  // Extract conv_id from object name. Path is chat_photos/{conv_id}/file
  // or chat_voice/{conv_id}/file. Anything else is malformed.
  function extractConvId(objectName) {
    const parts = objectName.split('/');
    if (parts.length < 3) return null;
    return parts[1] || null;
  }

  let scanned = 0;
  let deletedAged = 0;
  let deletedInactive = 0;
  let skippedActive = 0;
  let errors = 0;

  for (const prefix of ['chat_photos/', 'chat_voice/']) {
    let pageToken;
    do {
      let res;
      try {
        res = await bucket.getFiles({
          prefix,
          autoPaginate: false,
          maxResults: 1000,
          pageToken,
        });
      } catch (e) {
        console.error(`❌ chat media sweep: getFiles(${prefix}) failed: ${e.message}`);
        errors++;
        break;
      }
      const files = res[0] || [];
      const nextQuery = res[1];
      pageToken = nextQuery && nextQuery.pageToken;

      for (const file of files) {
        scanned++;
        try {
          const meta = file.metadata || {};
          const updatedMs = meta.updated ? Date.parse(meta.updated) : 0;
          const convId = extractConvId(file.name);

          // Path 1: object older than the active window. Delete unconditionally.
          if (updatedMs && updatedMs < cutoffMs) {
            await file.delete().catch(() => {});
            deletedAged++;
            continue;
          }

          // Path 2: malformed path (no conv_id segment). Delete - there's
          // no parent conversation for it to be attached to.
          if (!convId) {
            await file.delete().catch(() => {});
            deletedInactive++;
            continue;
          }

          // Path 3: younger than cutoff - check whether the conversation
          // (and its underlying SOS) is still live.
          const live = await isConversationLive(convId);
          if (!live) {
            await file.delete().catch(() => {});
            deletedInactive++;
          } else {
            skippedActive++;
          }
        } catch (e) {
          console.error(`⚠️ chat media sweep: error on ${file.name}: ${e.message}`);
          errors++;
        }
      }
    } while (pageToken);
  }

  const summary = { scanned, deletedAged, deletedInactive, skippedActive, errors };
  console.log(`✅ chat media sweep complete:`, summary);
  return summary;
});
