# RRT — full snapshot (client + backend)

Two folders. Apply each independently — they don't depend on each other.

## client/ — the Flutter app

`rrt_sos` v2.1.17+52 with all client-side patches applied. Comes with
nine-commit git history so you can review or revert any patch.

```bash
cd client
flutter pub get
flutter analyze 2>&1 | grep -E "^\s*error" | head -5    # expect: nothing
flutter build apk --release --dart-define=OLA_MAPS_API_KEY=YOUR_KEY
open build/app/outputs/flutter-apk/
```

Then install the APK on your phone (clear app data first if you have a
previous test build installed).

Read `client/SNAPSHOT_NOTES.md` and `client/PRESHIP_CHECKLIST.md` before
shipping to production. The checklist is what "tested" actually means
in practice.

## backend/ — the Firebase Cloud Functions

The `rrt-cloud-function-v45` project with one function changed:
`wipeChatsAtMidnightIST` now spares conversations whose linked SOS is
still active. They get deleted on the next nightly run instead.

```bash
cd backend
firebase deploy --only functions:wipeChatsAtMidnightIST
```

Only re-deploys the changed function. Everything else untouched.

Why: the previous wipe could delete a conversation while two responders
were mid-rescue if the SOS was triggered just before midnight IST.

## What's in each

### Client patches (nine commits)

```
dd5f1d4 fix(chat): no silent fail when conversation is wiped mid-session
3fcd429 feat(chats): retention disclaimer below conversation list
759166e feat(find_vet): hydrate coordinates via Place Details + clip TopBar overlap
ec687b8 docs: snapshot notes and pre-ship checklist
52bc907 fix(find_vet): match Help-mode chrome, fix footer clipping, better disclaimer
7d77b29 fix(share): Android queries declaration + iPad anchor
6aa3add fix(alerts): remove misleading hardcoded '0-8 km away' label
2e208ed feat: vet search via Ola Maps Nearby Search
0c0433c baseline: rrt_sos v2.1.17+52 (FINAL2 2026-05-07)
```

### Backend patches

One function rewritten: `wipeChatsAtMidnightIST` in
`functions/index.js`. Adds an active-SOS check before deleting any
conversation. New log line `spared M active` reports how many were
saved each night. Pagination cursor switched to `orderBy + startAfter`
to handle skipped (still-active) docs correctly across batches.

## What's NOT in this zip

- **API key rotation** — Krutrim console. Between you and them, no code involved.
- **Privacy policy update** — `client/docs/PRIVACY_POLICY.md` doesn't currently mention chat retention or Ola Maps. Worth adding when you next touch the policy. Sample text in `client/VET_SEARCH_INTEGRATION.md`.
- **Real-device verification** — has to happen on your phone, not in this zip.
