# RRT Client — full snapshot with vet-search + alerts-fix + share-fix

This is a snapshot of `rrt_sos` v2.1.17+52 with three patch sets applied
on top of the May 7 baseline. It comes with a clean four-commit git
history so you can review or revert any patch independently.

## Git history

```
7d77b29 fix(share): Android queries declaration + iPad anchor
6aa3add fix(alerts): remove misleading hardcoded '0-8 km away' label
2e208ed feat: vet search via Ola Maps Nearby Search
0c0433c baseline: rrt_sos v2.1.17+52 (FINAL2 2026-05-07)
```

To inspect any change: `git show <hash>`. To revert any patch:
`git revert <hash>` (creates a revert commit) or `git reset --hard <hash>`
(rewinds to that commit, destructive).

## What was statically verified before bundling

Static checks that ran clean:

- All relative imports (`import '../...'`) resolve to files that exist
- All package imports (`import 'package:...'`) are declared in pubspec.yaml
- All cross-file class references (`FindVetScreen`, `VetSearchService`,
  `_LookUpVetSection`) resolve in both directions
- The two known bugs from earlier iteration (the `latCell_lng` syntax
  error, the empty-results parsing bug) are NOT present
- Zero `km away` strings remain in UI code (only in a doc comment that
  documents the fix)
- Bracket balance ({}, (), []) is correct across all modified files
- Dart file count went from 53 -> 55 as expected (two new files)
- pubspec.yaml is unchanged (no new dependencies)

## What was NOT verified

Be honest with yourself about this list. None of these were possible from
the side that produced this zip:

- `flutter analyze` was not run
- `flutter test` was not run
- The code was not compiled to APK or IPA
- The app was not launched on emulator or device
- The vet-search HTTP integration was not tested end-to-end
- The Android share queries change was not verified on a real Android 11+ device
- The iPad share-anchor change was not verified on an iPad

You will need to run the steps in `PRESHIP_CHECKLIST.md` (in this same
folder) to actually verify the build works on real devices. Static checks
catch many bugs but not all - the parsing bug we hit during the first vet
test would have passed every static check above.

## Build

```bash
flutter pub get
flutter analyze              # expect: same pre-existing infos as before, no new errors
flutter build apk --release \
    --dart-define=OLA_MAPS_API_KEY=YOUR_OLA_KEY
```

If `OLA_MAPS_API_KEY` is omitted, the vet feature degrades gracefully to
"Open in Google Maps" only, which is a useful intermediate ship state.

## Files added

- `lib/screens/find_vet_screen.dart` (new, 670 lines)
- `lib/core/services/vet_search_service.dart` (new, 540 lines)
- `VET_SEARCH_INTEGRATION.md` (new, integration notes)

## Files modified

- `lib/core/config/api_config.dart` — Ola endpoint + key getter
- `lib/screens/active_sos_screen.dart` — Look up a vet row
- `lib/screens/help_screen.dart` — Help index entry + iPad share anchor
- `lib/screens/alerts_screen.dart` — removed false "0-8 km away" string
- `lib/screens/chat_screen.dart` — iPad share anchor
- `android/app/src/main/AndroidManifest.xml` — ACTION_SEND queries

## Known limitations of the vet feature (by design)

- No phone numbers in vet rows (Ola Nearby Search doesn't return them;
  fetching via Place Details would multiply API calls). Tap-to-call
  falls back to opening the vet's page in Google Maps.
- No coordinates for vets (same reason). Directions opens a Google Maps
  search by name+address, not a coordinate pin.
- "Search wider area" only goes 15 km -> 50 km; no further expansion.
- Empty results are cached for 24 hours to avoid hammering the API in
  vet deserts; new vets in your area appear within a day.
- Populated results are cached for 7 days. A vet that closes down may
  remain in the cache that long.

These are conscious tradeoffs documented in
`VET_SEARCH_INTEGRATION.md`. Worth revisiting if you start seeing user
complaints about staleness or missing details.
