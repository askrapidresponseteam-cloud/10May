# Pre-ship checklist

Work through these in order. Each step has a way to know whether it
passed or failed. Don't skip steps - the value of the checklist is its
completeness, not its speed.

## A. Code-level checks (5 minutes)

Run from the project root.

### A1. Dependencies resolve
```bash
flutter pub get
```
Pass: ends with "Got dependencies!". No "version solving failed".

### A2. Static analysis
```bash
flutter analyze
```
Pass: same set of pre-existing `info` and `warning` lines as before.
Specifically: 0 lines starting with `error`. The new code should
contribute nothing or at most one `info` (non-blocking style nit).

If you see any `error` lines, paste them and stop. Do not proceed.

### A3. Existing tests still pass
```bash
flutter test
```
Pass: all tests green. If any were already failing in the baseline,
they should fail in the same way (no NEW failures).

If you've never run `flutter test` on this project, this might surface
pre-existing breakage unrelated to the patches. Treat that as a
separate issue, not a blocker for this ship.

## B. Build (10-20 minutes first time, faster after)

### B1. Degraded-mode APK (no API key)
```bash
flutter build apk --release
```
Pass: ends with `✓ Built build/app/outputs/flutter-apk/app-release.apk`.

This APK will have the vet button visible but the in-app list will
show "We can't show vets in this build, but Google Maps works fine
for this." That's intentional - it's the safe fallback when the key
is absent.

### B2. Full-feature APK (with API key)
```bash
flutter build apk --release \
    --dart-define=OLA_MAPS_API_KEY=YOUR_OLA_KEY
```
Pass: same `✓ Built` line, similar size as B1 (within ~50 KB).

### B3. iOS build (only if you ship to App Store)
```bash
flutter build ios --release \
    --dart-define=OLA_MAPS_API_KEY=YOUR_OLA_KEY
```
Pass: build succeeds, no signing errors. If signing fails, that's
unrelated to these patches - it's your provisioning profile.

## C. Manual QA on Android (15-30 minutes)

Install the B2 APK on a real Android phone. **Clear app data first**
if you've previously installed any version with the vet feature:

> Settings -> Apps -> Rapid Response Team -> Storage -> Clear Data

This wipes the local cache so cached "no results" from older bad
builds don't poison the test.

### C1. Sanity: app still launches and existing features work
- [ ] App opens, gets past splash without crash
- [ ] Home screen renders with SOS button
- [ ] Bottom nav (Home / Alerts / Chats / Profile / Help) all reachable
- [ ] Profile shows the current user
- [ ] Alerts screen loads (may be empty if no active alerts in district)

### C2. Vet search via Active SOS
- [ ] Trigger an SOS (long-press SOS button, run through any prompts)
- [ ] On Active SOS screen, scroll down inside the content area
- [ ] Section "NEED A VET?" with bordered button "Look up a vet near you"
      is visible between Voice section and STOP SOS button
- [ ] Tap the button. New screen opens within ~300ms
- [ ] Red breadcrumb at top reads "SOS STILL ACTIVE · MM:SS" with a live
      timer counting down
- [ ] Headline reads "Vets / near you" (black + red split)
- [ ] Briefly shows "Looking nearby..." then a list of real vets
- [ ] Each vet row shows: number (01, 02, ...), distance (e.g. "0.7 KM"),
      vet name, address, and Call/Directions buttons
- [ ] List is sorted with closest first
- [ ] Tap "DIRECTIONS" on top vet -> Google Maps opens with that vet
- [ ] Press back -> return to Active SOS, timer still ticking
- [ ] Stop the SOS

### C3. Vet search via Help
- [ ] Help screen, second numbered row reads "Look up a vet"
- [ ] Tap it - same FindVetScreen opens BUT no red breadcrumb (because
      no active SOS)
- [ ] Vet list populates the same way
- [ ] "OPEN IN GOOGLE MAPS" footer button works
- [ ] Press back returns to Help index

### C4. Vet search empty state (only testable if you can simulate a remote
       location with no vets, OR you've never used the feature in a vet desert)
- [ ] If your area has zero Ola vets within 15km, the screen shows
      "No vets found within 15 km" and a "SEARCH WIDER AREA" button
- [ ] Tapping it triggers a new search at 50km
- [ ] If still empty, shows the "Try Google Maps or raise an SOS" message

### C5. Alerts screen (the distance fix)
- [ ] Open Alerts screen
- [ ] Each alert card now shows ONLY the relative time (e.g. "Just now",
      "5 min ago") on the right
- [ ] No "0-8 km away" or any distance text appears
- [ ] The alert's location (e.g. "Akshi, Maharashtra") still appears
      below the "Emergency: <name>" line

### C6. Share the app (the manifest + iPad fix)
- [ ] Help screen, last numbered row "Share the app"
- [ ] Tap it - system share sheet opens
- [ ] All your installed apps that accept text appear as share targets
      (WhatsApp, Telegram, Gmail, Messages, Slack if installed, etc.)
- [ ] Pick WhatsApp -> the share text is pre-filled correctly
- [ ] If the share sheet looks suspiciously short (only 2-3 options
      when you have 10+ messaging apps), the manifest queries change
      didn't take. Re-check `android/app/src/main/AndroidManifest.xml`.

### C7. Cache behaviour (advanced sanity check)
- [ ] After the first vet search, immediately close the screen and
      reopen it. The list should appear nearly instantly (cache hit).
- [ ] Force-quit the app, reopen, navigate back to vet search.
      Should still be near-instant (shared_preferences cache hit).

## D. Manual QA on iOS (if shipping to App Store)

Install on a real iPhone via Xcode or TestFlight.

### D1-D7
Same checklist as C1-C7 above. The behaviour should be identical;
the platform-specific code paths are limited to the share-sheet
anchor, which works on both.

### D8. iPad popover anchor (only if you have an iPad)
- [ ] On iPad, tap "Share the app" or the chat-export Download
- [ ] The share popover should appear near the bottom-centre of the
      screen, with the popover arrow pointing roughly upward
- [ ] If it appears in the top-left corner with the arrow pointing
      into the corner, the iPad anchor change didn't take

## E. Pre-release sanity (5 minutes)

### E1. Privacy policy
- [ ] Your existing privacy policy is live and reachable from the
      stored URL (`https://askrapidresponseteam-cloud.github.io/rrt-privacy-policy`)
- [ ] (Optional, do at your next major edit) Add a paragraph
      mentioning that "Find a Vet" sends approximate user location
      to Ola Maps. Not a release blocker - your app is already on
      both stores - but worth doing on the next privacy-policy
      revision for transparency.

### E2. API key restrictions
- [ ] In Krutrim Cloud console, the `rapid-response-vet-search`
      credential has restrictions applied:
      - Bundle/package allowlist: `com.rrt.app.rrtFlutterApp` and
        `com.rrt.app.rrt_flutter_app`
      - Daily quota cap (e.g. 5,000 calls/day)
- [ ] If you can't see those options on the Freemium Plan, at minimum
      set the daily quota cap

### E3. Firestore rules
- [ ] Add the rule for `vet_cache/{cellId}` from
      `VET_SEARCH_INTEGRATION.md`:
      ```
      match /vet_cache/{cellId} {
        allow read: if request.auth != null;
        allow write: if request.auth != null
          && request.resource.data.keys().hasAll(['vets', 'radius_m', 'fetched_at_ms'])
          && request.resource.data.fetched_at_ms is number
          && request.resource.data.fetched_at_ms <= request.time.toMillis() + 60000
          && request.resource.data.vets is list
          && request.resource.data.vets.size() <= 50;
      }
      ```
- [ ] Deploy the rules to Firebase: `firebase deploy --only firestore:rules`

### E4. Build version bump (if shipping to stores)
- [ ] Increment `version:` in `pubspec.yaml` (e.g. `2.1.17+52` -> `2.1.18+53`)
- [ ] Rebuild AAB: `flutter build appbundle --release \
        --dart-define=OLA_MAPS_API_KEY=YOUR_KEY`
- [ ] Upload to Play Console internal track first (not production)
- [ ] Run through C-checklist on a Play-Store-installed copy from the
      internal track - signing certificate is different than your local
      build, occasionally surfaces issues that only happen there.

## F. If anything fails

For each test that fails, capture:
- What you did (steps to reproduce)
- What you expected
- What you saw
- A screenshot if relevant
- The Android adb logcat output OR iOS console output if there was a crash

That's enough information to actually fix the bug. Don't ship a build
where any of section C tests are failing.

## Summary

If A through E are all green: you have done due diligence on the
patches. There may still be bugs that only show up at production
scale or in conditions you didn't test - that's life with software
shipping. But you're shipping with eyes open, which is the goal.
