# RRT Redesign - Handoff Brief

> **For the next Claude session.** Read this FIRST before touching code.
> We're mid-rebuild of the RRT Flutter app UI to match `RRT_Redesign__1_.html` 1:1.
> Phase 1 (onboarding) and most of Phase 2 (main-app) are done and wired up.
> Your job is to finish the last 5 screens.

---

## Current state: what's done

### Theme & shared widgets - DONE
- `lib/core/theme/app_theme.dart` - full HTML palette + `AppTheme.barlow()`, `AppTheme.barlowCondensed()`, `AppTheme.barlowSemiCondensed()` helpers. Includes `@Deprecated` aliases (`primaryBlack`, `pureWhite`, `accentRed`, `errorColor`, etc.) so old un-rewritten screens keep compiling - **remove these once the last 5 screens are rewritten.**
- `lib/widgets/paw_icon.dart` - CustomPainter paw matching HTML `<PawIcon>` SVG.
- `lib/widgets/top_bar.dart` - 52px nav-bar, paw or back arrow, "Rapid Response Team" title, optional badge ("2 OF 3") + green online dot.
- `lib/widgets/cta_button.dart` - 58px, zero-radius, Barlow 800 13px 2px-tracking. Variants: `primary` / `outline` / `danger`. Optional leading/trailing icon, `isLoading` state.
- `lib/widgets/consent_box.dart` - red 20×20 checkbox + Barlow 500 13px consent text on offWhite bg. Also exports `InfoNotice` (circled-i grey notice).
- `lib/widgets/bottom_nav.dart` - 74px, 5 tabs (home/alerts/chats/profile/help) via `NavTab` enum. Alerts tab shows tiny red dot when inactive.
- `lib/widgets/location_bar.dart` - pin + district + refresh row used on Home & Active SOS. Also exports `AmberNotice` (amber title + body).
- `lib/widgets/sos_button.dart` - the centerpiece. Pulse ring, mid ring, gradient shell, inner darker core, glass shine, white arc progress while held. Hold for 3s → fires `onComplete`. This one is intricate - don't rewrite it, it works.

### Screens - DONE (test these, don't touch unless a bug shows up)
- `lib/screens/onboarding_screen.dart` - Welcome hero (extracted `assets/images/hero.jpg`, gradient overlay, "Help." Barlow Condensed 92pt, 3 numbered feature rows). CTA → Terms.
- `lib/screens/terms_and_conditions_screen.dart` - "2 OF 3" badge, 48pt heading, scrollable 10 clauses, ConsentBox, ACCEPT & CONTINUE. Calls `ProfileService.setTermsAccepted(true)`.
- `lib/screens/profile_create_screen.dart` - "3 OF 3", "Your" (black) / "Profile" (red) 64pt, minimal underline fields with A-Z/+91 pill badges, ConsentBox, InfoNotice. Validates via `ProfileService.isValidIndianMobile`, saves via `ProfileService.saveProfile(name, mobile)`, pushes to `MainNavigationScreen`. Auto-dismiss keyboard + haptic at 10 digits preserved.
- `lib/screens/main_navigation_screen.dart` - new shell using `BottomNav`. All lifecycle observer + alerts-seen logic preserved from the old version.
- `lib/screens/home_screen.dart` - TopBar + LocationBar + AmberNotice + SosButton + description field (100 char cap). Description required. Hold-complete → ConfirmAlertScreen → sends via `SOSService.sendSOSAlert` → `SosStateProvider.activate()` → navigates to ActiveSOSScreen. Also auto-navigates to ActiveSOSScreen if the user opens the app with an already-active SOS.
- `lib/screens/confirm_alert_screen.dart` - dim-backdrop modal, 3 info rows, amber warning, Cancel/Send split 50/50. Returns bool via Navigator.pop.
- `lib/screens/active_sos_screen.dart` - countdown timer (MM:SS from `AppConstants.alertTtl`), red progress bar, hero row with pulsing red dot, stacked avatar viewers row using `myAlertSeenCountProvider`, 3-slot scene photos wired to `SosPhotoService.photoUrlsStream` / `captureAndUpload`, voice recorder wired to `SosVoiceService.startRecording` / `stopRecording` / `uploadRecording`, green success toast, STOP SOS with confirm dialog → `SosStateProvider.deactivate()`.
- `assets/images/hero.jpg` - extracted from the base64 JPEG in the HTML (~38KB fox photo). Registered in `pubspec.yaml`.

### What's broken / NOT done
- **`lib/screens/alerts_screen.dart` was deleted mid-session and NOT rewritten.** The old file is gone. You need to write a clean one.
- `lib/screens/chat_screen.dart` - still the OLD version. Matches HTML: 52px header with back + name + "District" + phone icon; message list with dark-bg bubbles on the left; input row with greyed input + circular black send button.
- `lib/screens/conversations_screen.dart` - still OLD. HTML calls this "ChatsScreen": district header strip (offWhite bg, district name, "N people subscribed"), "EMERGENCY CHATS" section label with count pill, chat items (46×46 black avatar with initial, name + time + "YOU: preview" + greyed dot).
- `lib/screens/profile_screen.dart` - still OLD. HTML `ProfileMainScreen`: TopBar, "Your" (black) / "Profile" (red) 64pt heading, two read-only fields with A-Z/+91 pills, InfoNotice about phone visibility, Danger Zone box (red border `#fecaca` on `#fff5f5`, red DELETE MY DATA outline button), sticky UPDATE PROFILE CTA at bottom.
- `lib/screens/help_screen.dart` - still OLD. HTML `HelpScreen`: paw row header with online dot, tab bar (How To Use | Contact Us), how-to: 6 steps each with "Step N" red kicker + title + body with 1px divider. Contact tab: locked/editable form rows with floating label, message textarea, SEND MESSAGE CTA.
- (Optional, HTML-only, lower priority): `RespondersScreen` - a bottom sheet shown over Chats: drag handle, "Responders Udupi District" heading, 3 stats columns (Total/Online/Offline), volunteers list with status dots. Not wired to a tab - HTML presents it via modal. Worth adding if backend supports it, otherwise skip.

---

## Critical constraints (don't break these)

1. **Preserve ALL service logic.** The app is production-ready from a functionality standpoint - it has Firebase, Firestore, FCM, background location, offline district lookup, photo/voice upload, force-update. Your job is UI only. Do not refactor or "simplify" a service unless explicitly asked.
2. **Zero border-radius everywhere.** The design is editorial/brutalist. The only round things are circles (avatars, status dots, SOS button). Everything else is square.
3. **Barlow is the only font.** Barlow for body, Barlow Condensed for big display headings and numbers, Barlow Semi Condensed for the demo selector only. Use the `AppTheme.barlow*()` helpers - never raw `TextStyle` with fontFamily.
4. **Use the palette constants.** `AppTheme.red`, `.black`, `.white`, `.offWhite`, `.grey`, `.border`, `.amberBg`, `.amberBorder`, `.amberText`, `.amberIcon`, `.successGreen`, `.successGreenDark`, `.dangerBg`, `.dangerBorder`, `.subtleGrey`, `.veryLightGrey`, `.fadedGrey`, `.disabledGrey`. Every color in HTML maps to one of these - don't invent new hex values.
5. **Duplicated directories exist.** `lib/providers/` and `lib/services/` duplicate `lib/core/providers/` and `lib/core/services/`. The canonical paths are the `core/` ones - that's what main.dart uses. The duplicates were kept because a few old un-rewritten screens import from them. After you finish all 5 screens, delete `lib/providers/` and `lib/services/` and search-replace any remaining references.
6. **Mind the compliance README.** The README flags 5 App Store blockers (privacy URL, iOS background location, data deletion, phone consent, emergency-services language). The UI redesign doesn't touch these but don't introduce new violations. The Terms screen I wrote has a "Read full Privacy Policy" link that opens the external URL - keep equivalent links on any new screen that claims data handling.
7. **Every new screen is 393px mobile-first.** Designed for ~393×852 (iPhone 14 Pro). Test layout shrinks gracefully with SafeArea.

---

## Backend surface you'll need (quick reference)

### ProfileService (lib/core/services/profile_service.dart)
- `getUserName() → Future<String?>`
- `getUserMobile() → Future<String?>`
- `saveProfile({required String name, required String mobile}) → Future<void>`
- `getUserId() → Future<String>` (generates UUID if missing)
- `isValidIndianMobile(String) → bool` (`^[6-9]\d{9}$`)
- `setTermsAccepted(bool) → Future<void>`
- `deleteUserFirestoreData() → Future<void>` (for Danger Zone)

### Conversations / chat (lib/core/providers/chat_provider.dart)
- `conversationsProvider` - `StreamProvider.autoDispose<List<Map<String,dynamic>>>`. Each entry has: `conv_id`, `participants` (list), `messages` (list of `{sender_fid, text, timestamp}`), `last_message_at`, `active_alert_owner`, possibly `active_session_id`, and equivalents for a secondary session.
- `conversationDocProvider(convId)` - single conv stream.
- `chatSessionActiveProvider((owner, session, owner2, session2))` - bool stream, true while the linked SOS is active.

### Chat send (lib/core/config/api_config.dart + HTTP)
- `POST ApiConfig.chatInitiateEndpoint` body: `{responder_fid, responder_name, sender_fid, sender_name, district}`.
- `POST ApiConfig.chatSendMessageEndpoint` body: `{conv_id, from_fid, text}`.

### Alerts (lib/core/providers/alerts_provider.dart)
- `activeAlertsProvider` - stream of `Map<String,dynamic>` with keys: `sender_id`, `sender_name`, `district`, `approx_loc`, `exact_lat`, `exact_lng`, `message`, `mobile_number`, `timestamp` (ms int), `photo_urls` (List<String>), `voice_url`.
- `markAlertsSeen(alerts, fid, alreadySeen) → Future<Set<String>>` for writing seen-by.
- `myAlertSeenCountProvider(senderId)` - int stream.
- `myAlertTimestampProvider(senderId)` - int? ms stream.
- `alertsScreenActiveProvider`, `activeTabIndexProvider`, `seenAlertCacheProvider`.

### SOS state (lib/core/providers/sos_state_provider.dart)
- `sosStateProvider` / `SosState`: `{isLoaded, isActive, senderId, location, activatedAtMillis}`.
- Notifier: `.activate({senderId, location, activatedAtMillis})`, `.deactivate()`, `.refreshFromStorage()`.

### SOSService (lib/core/services/sos_service.dart)
- `sosServiceProvider.sendSOSAlert({sosType, location: Position, userInfo: Map})` → `SOSResponse{success, error, messageId, topic, message}`.

### Constants
- `AppConstants.alertTtl = Duration(minutes: 60)` - use this for the countdown, NOT 90 (HTML shows 90 but the real backend is 60).

---

## Pitfalls to avoid (learned the hard way)

1. **Don't over-engineer imports.** When alerts_screen needed to navigate to ChatScreen, I spiraled into wrapping the import in 12 helper functions to "keep this file lean." Just `import 'chat_screen.dart';` at the top like a normal person. That entire mess is why alerts_screen is currently deleted.
2. **`IntrinsicHeight` is cheap here - use it.** The HTML uses `display:flex; align-items:stretch` for feature rows with a left number column and right content column sharing height. `IntrinsicHeight + Row(crossAxisAlignment: stretch)` nails it.
3. **`withValues(alpha: x)`, not `withOpacity`.** Flutter 3.27+ deprecated withOpacity. The app is on Flutter 3.10.7 sdk but it compiles fine on 3.27+ - keep using `withValues` so it's forward-compatible.
4. **`splashFactory: NoSplash.splashFactory`** is set on the theme - don't wrap buttons in `InkWell`. Use `GestureDetector(behavior: HitTestBehavior.opaque)`. The design has no ripple.
5. **Navigate via `Navigator.push(MaterialPageRoute(...))` for normal screens** and `PageRouteBuilder(opaque: false, barrierColor: ...)` for modals (Confirm Alert is an example). Don't use `showDialog` for full-screen modals - it caps their width.
6. **Home's auto-redirect to Active SOS** uses `ref.listen<SosState>` in `build` - NOT a post-frame callback from initState - because the state can flip after the user returns from the confirm screen. Keep it that way.
7. **The HTML has a hero JPEG base64-embedded in the Welcome screen.** I already extracted it to `assets/images/hero.jpg`. If for any reason that file is missing from the ZIP, the extraction script is:
   ```python
   import re, base64
   html = open('RRT_Redesign__1_.html').read()
   m = re.search(r'src="data:image/jpeg;base64,([^"]+)"', html)
   open('assets/images/hero.jpg','wb').write(base64.b64decode(m.group(1)))
   ```

---

## Suggested order for the remaining 5 screens

1. **Alerts screen** (rewrite from scratch). Card: ACTIVE red pill, "Approx 0-8 km away · <relative>", "Emergency: <message>", pin + place, chat bubble + preview, CALL + DIRECTIONS side-by-side (both filled black 46px), CHAT outline full-width below. Empty state: "NO ACTIVE ALERTS" tracking 2 + body grey. Footer: "Contact details are visible only while an alert is active." CALL uses `launchUrl(Uri(scheme: 'tel', path: mobile))`. DIRECTIONS uses `https://www.google.com/maps/dir/?api=1&destination=<lat>,<lng>`. CHAT computes conv_id = sorted FIDs joined by `_`, then `Navigator.push(MaterialPageRoute(builder: (_) => ChatScreen(convId, otherFid, otherName, district, shouldInitiate: true)))`.
2. **Chat screen (individual).** 52px header: back arrow + name + subtitle "District" + phone icon on right. Body: messages stream from `conversationDocProvider(convId)`. Bubbles: mine right-aligned black bg white text; theirs left-aligned `offWhite` bg black text. All zero-radius except 4px on the inner-bottom corner (bottomLeft for incoming, bottomRight for outgoing). Input row: grey 42px TextField + 42×42 black circular send button with white paper-plane icon. Sends via `POST chatSendMessageEndpoint`. Show "just now" / "Nm ago" labels under bubbles. Preserve `NotificationService.setActiveChatConvId(widget.convId)` in initState and null in dispose.
3. **Conversations screen.** Top: offWhite district strip with "Udupi, Karnataka" bold + "N people subscribed in this area" grey + chevron. Section header "EMERGENCY CHATS" with count pill (black circle, white number). List of chat items: 46×46 black circular avatar with Barlow Condensed 900 20pt first letter, name + time (right), UPPERCASE district label tracking 1.5, "You: <preview>" truncated, grey dot indicator. Tap item → ChatScreen with `shouldInitiate: false`.
4. **Profile main.** Same header style as profile_create but values are read-only pulled from `ProfileService.getUserName/getUserMobile`. Under fields: InfoNotice about phone visibility. Danger Zone box (see palette). DELETE MY DATA shows confirm dialog, then `ProfileService.deleteUserFirestoreData()` + clears SharedPreferences + pushReplacement to OnboardingScreen. Bottom sticky UPDATE PROFILE CTA navigates to the create screen in edit mode - which means profile_create needs a `{bool isEdit}` flag; pre-fill controllers and change the CTA label to "SAVE CHANGES" when set. Small change but don't forget it.
5. **Help.** Paw header (same pattern as TopBar but with leading paw mark). Tab bar: How To Use | Contact Us, 46px tall, underline 2.5px on active. How To tab: 6 steps from the HTML (`Step 1` through `Step 6`) each in a column with red kicker + black title + grey body separated by 1px hairlines. Contact tab: form with Name (locked, pulled from profile), Subject, Email, Message. Floating label appears above filled fields. SEND MESSAGE CTA - hook to whatever contact endpoint exists in `api_config.dart`, or fall back to `mailto:`.

---

## Shipping checklist after the 5 screens are done

- [ ] Delete `lib/providers/` and `lib/services/` (duplicates of `lib/core/...`).
- [ ] Remove `@Deprecated` aliases from `app_theme.dart`.
- [ ] Delete `lib/widgets/rrt_screen_layout.dart`, `rrt_branding.dart`, `rrt_primary_button.dart`, `rrt_footer_badges.dart`, `onboarding_flow_bottom_bar.dart`, `labeled_text_field.dart` - all superseded by the new widgets.
- [ ] Delete `lib/screens/how_to_use_screen.dart` and `test_district_lookup.dart`.
- [ ] Run `flutter analyze` - should be zero warnings.
- [ ] Verify the old screens truly imported from `core/...` by grepping for `'../services/'` and `'../providers/'`.

Good luck.
