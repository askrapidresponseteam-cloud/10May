# 🚨 COMPLIANCE FIXES CHECKLIST - PRIORITY ORDER

**Status:** ✅ **ALL CRITICAL BLOCKERS COMPLETE** - Ready for Store Listing Setup

**Progress:** ✅ 5/5 Complete (100%) 🎉

---

## ✅ PHASE 1: CRITICAL BLOCKERS (ALL COMPLETE!)

### 1. Privacy Policy (✅ BLOCKER #1 - COMPLETE)
**Impact:** 100% rejection without this  
**Effort:** 4-8 hours + legal review  
**Status:** ✅ **FIXED** - Committed in 14c830a, 8a52598  
**Privacy Policy URL:** https://askrapidresponseteam-cloud.github.io/rrt-privacy-policy

**Tasks:**
- [x] Draft privacy policy document covering:
  - [x] What data: name, phone, location, device ID, FCM token
  - [x] Why: emergency alerts, location-based routing, push notifications
  - [x] How used: stored locally, sent to backend on SOS, shared with volunteers
  - [x] Third parties: Firebase (Google), alert recipients
  - [x] Retention: profile until deletion, alerts 60 minutes, logs 90 days
  - [x] User rights: deletion, access, correction
  - [x] Security measures: HTTPS, encrypted storage
  - [x] Children: app is 18+
  - [x] Changes: notify users of policy updates
  - [x] Contact: support email (placeholder for user to update)
- [x] Host on public URL (GitHub Pages)
- [x] Add URL to `AndroidManifest.xml` (privacy_policy_url metadata)
- [x] Link from Terms screen: clickable "📄 Read our Privacy Policy" link
- [x] Link from Profile screen: centered "📄 Privacy Policy" footer link
- [ ] **TODO:** User must add URL to App Store Connect listing
- [ ] **TODO:** User must add URL to Google Play Console listing

**Files created:**
- ✅ `privacy-policy.html` (hosted version - professional styling)
- ✅ `PRIVACY_POLICY.md` (markdown reference version)
- ✅ `GITHUB_PAGES_SETUP.md` (hosting instructions)

**Files modified:**
- ✅ `android/app/src/main/AndroidManifest.xml` (added privacy_policy_url)
- ✅ `lib/screens/terms_and_conditions_screen.dart` (added link + launch method)
- ✅ `lib/screens/profile_screen.dart` (added link + launch method)

**Manual Steps Required:**
- [ ] Update `[YOUR_CONTACT_EMAIL]` in hosted privacy-policy.html
- [ ] Add privacy policy URL to App Store Connect (App Information section)
- [ ] Add privacy policy URL to Google Play Console (Store Listing section)
- [ ] Fill App Privacy details in App Store Connect
- [ ] Fill Data Safety section in Google Play Console

---

### 2. Remove iOS Background Location Permission (✅ BLOCKER #2 - COMPLETE)
**Impact:** 100% rejection - Apple flags unnecessary permissions  
**Effort:** 15 minutes  
**Status:** ✅ **FIXED** - Committed in 200362b

**Tasks:**
- [x] Delete from `ios/Runner/Info.plist`:
  ```xml
  <!-- DELETED THESE TWO LINES -->
  <key>NSLocationAlwaysAndWhenInUseUsageDescription</key>
  <string>This app needs location access to identify your district for emergency alerts and to help responders find you during an SOS situation.</string>
  ```
- [x] Update `lib/core/services/geolocator_location_service.dart`:
  ```dart
  // OLD:
  return permission == LocationPermission.always || LocationPermission.whileInUse;
  
  // NEW:
  return permission == LocationPermission.whileInUse;
  ```
- [x] Updated permission string to remove emergency responder implication
- [x] Removed all references to LocationPermission.always from codebase

**Files modified:**
- ✅ `ios/Runner/Info.plist`
- ✅ `lib/core/services/geolocator_location_service.dart`

**Note:** Manual iOS device testing recommended to verify location still works correctly.

---

### 3. Implement Data Deletion (✅ BLOCKER #3 - COMPLETE)
**Impact:** 95% rejection - GDPR/DPDPA requirement  
**Effort:** 2-3 hours  
**Status:** ✅ **FIXED** - Committed in 59356ee

**Tasks:**
- [x] Add deletion method to `ProfileService`:
  ```dart
  static Future<void> deleteAllData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
  ```
- [x] Add "Delete My Data" button to Profile screen in DANGER ZONE section
- [x] Show comprehensive confirmation dialog:
  - [x] Title: "Delete All Data?" with warning icon
  - [x] Message: Lists all data to be deleted (profile, alerts, settings)
  - [x] Explains action cannot be undone
  - [x] Buttons: [CANCEL] [DELETE] with red styling
- [x] On confirmation:
  - [x] Show loading indicator
  - [x] Call `ProfileService.deleteAllData()`
  - [x] Navigate to Onboarding screen (removes all routes)
  - [x] Show success message
- [x] Added hasProfile() helper method for convenience

**Files modified:**
- ✅ `lib/core/services/profile_service.dart` (added deleteAllData + hasProfile)
- ✅ `lib/screens/profile_screen.dart` (added DANGER ZONE section + dialogs)

**Testing Required:**
- [ ] Test deletion flow on physical device
- [ ] Verify all SharedPreferences data cleared
- [ ] Verify navigation to onboarding works
- [ ] Verify can create new profile after deletion
- [ ] Test cancel button works (no deletion occurs)

---

### 4. Add Phone Number Exposure Consent (✅ BLOCKER #4 - COMPLETE)
**Impact:** 85% rejection - data sharing requires explicit consent  
**Effort:** 2-3 hours  
**Status:** ✅ **FIXED** - Committed in f0d57f3

**Tasks:**

**A. Profile Creation Consent:**
- [x] Add boolean state variable: `bool _phoneExposureConsent = false;`
- [x] Add consent checkbox in orange-highlighted box BEFORE "SAVE & PROCEED" button
- [x] Checkbox text: 'I understand and agree that my phone number will be visible to other community members when I activate an emergency alert.'
- [x] Disable button if not checked: `onTap: _phoneExposureConsent ? _saveProfile : null`

**B. SOS Activation Confirmation:**
- [x] Add comprehensive confirmation dialog BEFORE sending SOS
- [x] Dialog shows exactly what will be shared:
  - Name (with icon)
  - Phone number (with icon)
  - Location/address (with icon)
- [x] Orange info box: "Your phone number will be visible to volunteers"
- [x] Clear CANCEL / SEND ALERT buttons
- [x] Returns without sending if user cancels
- [x] Added _buildInfoRow() helper method for dialog formatting

**C. Increase Font Size:**
- [x] Changed privacy notice font size from 8pt to 12pt (Apple minimum)
- [x] Applied to both profile_create_screen.dart and profile_screen.dart

**Files modified:**
- ✅ `lib/screens/profile_create_screen.dart` (consent checkbox + font size)
- ✅ `lib/screens/profile_screen.dart` (font size update)
- ✅ `lib/screens/home_screen.dart` (confirmation dialog + helper method)

**Testing Required:**
- [ ] Test profile creation with checkbox unchecked (button should be disabled)
- [ ] Test profile creation with checkbox checked (button should work)
- [ ] Test SOS flow with confirmation dialog
- [ ] Verify Cancel button works (no SOS sent)
- [ ] Verify Send Alert button sends SOS after confirmation
- [ ] Verify all shared data displays correctly in dialog

---

### 5. Add Emergency Services Disclaimer (✅ BLOCKER #5 - COMPLETE)
**Impact:** 90% rejection - misleading emergency claims  
**Effort:** 3-4 hours  
**Status:** ✅ **FIXED** - Committed in a45ec23

**Tasks:**

**A. Add Disclaimer to Home Screen:**
- [x] Added prominent orange warning banner BEFORE SOS button
- [x] Banner displays:
  - Warning icon
  - "IMPORTANT NOTICE" header
  - "This app connects you with volunteer community members, NOT official emergency services."
  - "For life-threatening emergencies, call 112." (in red)
- [x] Always visible when SOS button is available (impossible to miss)

**B. Add First-Time Acknowledgment Dialog:**
- [x] Added _checkEmergencyDisclaimerAcknowledgment() method
- [x] Checks SharedPreferences for 'emergency_disclaimer_acknowledged' flag
- [x] Shows comprehensive dialog on first SOS button press:
  - Warning icon in title
  - "This alert notifies volunteer community members only."
  - Red box: "This is NOT a connection to police, ambulance, or emergency services."
  - Green box: "For life-threatening emergencies, call 112."
  - "Do you understand and wish to proceed?"
- [x] Requires explicit "I UNDERSTAND" button click
- [x] User can CANCEL (returns to home without starting SOS)
- [x] Saves acknowledgment to SharedPreferences after confirmation
- [x] Only shown once per installation

**C. Update Location Permission String:**
- [x] Already completed in Blocker #2 (commit 200362b)
- [x] Verified: No longer mentions "help responders find you"
- [x] Now says: "send community alerts to volunteers in your area"

**D. Additional Implementation:**
- [x] Added SharedPreferences import
- [x] Modified _startHoldTimer() to async to check acknowledgment first
- [x] Won't start hold timer if user cancels acknowledgment

**Files modified:**
- ✅ `lib/screens/home_screen.dart` (warning banner + acknowledgment dialog)
- ✅ `ios/Runner/Info.plist` (verified - already fixed in Blocker #2)

**Testing Required:**
- [ ] Test first-time SOS press shows acknowledgment dialog
- [ ] Test CANCEL button works (no SOS sent, no acknowledgment saved)
- [ ] Test I UNDERSTAND button saves acknowledgment
- [ ] Test subsequent SOS presses don't show dialog again
- [ ] Verify warning banner always visible on home screen
- [ ] Test on fresh install (delete app data)

---

## ⚠️ PHASE 2: HIGH-RISK ISSUES (SHOULD FIX)

### 6. Add SOS Rate Limiting
**Impact:** 55% rejection - abuse prevention  
**Effort:** 1 hour

**Tasks:**
- [ ] Add static variables to track last SOS time:
  ```dart
  static DateTime? _lastSOSTime;
  static const _sosMinInterval = Duration(minutes: 5);
  ```
- [ ] Check interval before sending SOS:
  ```dart
  if (_lastSOSTime != null) {
    final elapsed = DateTime.now().difference(_lastSOSTime!);
    if (elapsed < _sosMinInterval) {
      final remaining = (_sosMinInterval - elapsed).inMinutes;
      // Show error message
      return;
    }
  }
  _lastSOSTime = DateTime.now();
  ```
- [ ] Test rate limiting: try sending 2 alerts within 5 minutes

**Files to modify:**
- `lib/screens/home_screen.dart`

---

### 7. Add Age Verification
**Impact:** 40% rejection - Terms state 18+ but no enforcement  
**Effort:** 30 minutes

**Tasks:**
- [ ] Add checkbox to Terms screen:
  ```dart
  bool _ageConfirmed = false;
  
  CheckboxListTile(
    value: _ageConfirmed,
    onChanged: (value) => setState(() => _ageConfirmed = value!),
    title: Text(
      'I confirm that I am 18 years of age or older',
      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
    ),
  )
  ```
- [ ] Disable ACCEPT button if not checked: `onTap: _ageConfirmed ? _acceptTerms : null`

**Files to modify:**
- `lib/screens/terms_and_conditions_screen.dart`

---

### 8. Move to Encrypted Storage
**Impact:** 45% rejection - sensitive data security  
**Effort:** 2-3 hours

**Tasks:**
- [ ] Add dependency: `flutter_secure_storage: ^9.0.0`
- [ ] Replace SharedPreferences with FlutterSecureStorage for:
  - [ ] User mobile number
  - [ ] User name (optional, but good practice)
  - [ ] User ID (UUID)
- [ ] Update ProfileService:
  ```dart
  import 'package:flutter_secure_storage/flutter_secure_storage.dart';
  
  static const _storage = FlutterSecureStorage();
  
  static Future<void> saveProfile({required String name, required String mobile}) async {
    await _storage.write(key: 'user_name', value: name);
    await _storage.write(key: 'user_mobile', value: mobile);
  }
  
  static Future<String?> getUserMobile() async {
    return await _storage.read(key: 'user_mobile');
  }
  ```
- [ ] Test on both iOS and Android
- [ ] Handle migration for existing users (read from SharedPreferences, write to secure storage, delete old)

**Files to modify:**
- `pubspec.yaml`
- `lib/core/services/profile_service.dart`

---

## ℹ️ PHASE 3: MEDIUM-PRIORITY IMPROVEMENTS

### 9. Remove Debug Hardcoded District
**Effort:** 10 minutes

- [ ] Remove or guard debug district override:
  ```dart
  // DELETE or wrap in assert():
  if (kDebugMode) {
    const testDistrict = 'udupi';  // ❌ Remove this
  }
  ```

**Files to modify:**
- `lib/screens/home_screen.dart`

---

### 10. Add Data Retention Policy to Terms
**Effort:** 15 minutes

- [ ] Add section to Terms:
  ```
  14. Data Retention
  - Profile data is retained until you delete your account
  - Active SOS alerts are stored for 60 minutes
  - Server logs are retained for 90 days for security purposes
  - You may delete your data at any time via Profile → Delete My Data
  ```

**Files to modify:**
- `lib/screens/terms_and_conditions_screen.dart`

---

### 11. Add Firebase Disclosure to Terms
**Effort:** 10 minutes

- [ ] Update Section 3 (User Data & Permissions):
  ```
  Technical Services:
  - We use Firebase (Google) for push notifications and backend services
  - Firebase may collect device information and usage analytics
  - See Firebase Privacy Policy: https://firebase.google.com/support/privacy
  ```

**Files to modify:**
- `lib/screens/terms_and_conditions_screen.dart`

---

### 12. Add Network Security Config (Android)
**Effort:** 20 minutes

- [ ] Create `android/app/src/main/res/xml/network_security_config.xml`:
  ```xml
  <?xml version="1.0" encoding="utf-8"?>
  <network-security-config>
      <base-config cleartextTrafficPermitted="false">
          <trust-anchors>
              <certificates src="system" />
          </trust-anchors>
      </base-config>
  </network-security-config>
  ```
- [ ] Reference in AndroidManifest.xml:
  ```xml
  <application
      android:networkSecurityConfig="@xml/network_security_config">
  ```

**Files to modify:**
- Create: `android/app/src/main/res/xml/network_security_config.xml`
- Modify: `android/app/src/main/AndroidManifest.xml`

---

## 📋 PRE-SUBMISSION VERIFICATION

### Before Committing to Stores:
- [ ] All Phase 1 tasks complete (5/5)
- [ ] All Phase 2 tasks complete (4/4)
- [ ] Privacy policy live and accessible
- [ ] Test on physical iOS device (iOS 16+)
- [ ] Test on physical Android device (Android 13+)
- [ ] Test all permission flows (grant, deny, ask again)
- [ ] Test SOS flow with all confirmations
- [ ] Test data deletion completely
- [ ] Review all user-facing text
- [ ] Screenshots show disclaimers clearly
- [ ] App Store Connect: Privacy details filled
- [ ] Google Play Console: Data Safety filled
- [ ] Both stores: Privacy policy URL added

---

## ⏱️ ESTIMATED TIMELINE

| Phase | Tasks | Effort | Priority |
|-------|-------|--------|----------|
| Phase 1 | 5 blockers | 12-18 hours | 🔴 CRITICAL |
| Phase 2 | 4 high-risk | 4-6 hours | 🟡 HIGH |
| Phase 3 | 4 improvements | 1-2 hours | 🟢 MEDIUM |
| Testing | Full QA | 4-6 hours | 🟡 HIGH |
| **Total** | **13 tasks** | **21-32 hours** | **3-5 days** |

---

## 📞 SUPPORT RESOURCES

**Privacy Policy Templates:**
- https://app-privacy-policy-generator.firebaseapp.com/
- https://termly.io/products/privacy-policy-generator/

**Compliance Guides:**
- Apple: https://developer.apple.com/app-store/review/guidelines/
- Google: https://play.google.com/about/developer-content-policy/

**Questions?**
- Refer to: `COMPLIANCE_AUDIT_REPORT.md` (full 100-page detailed report)
- Search for specific policy references in audit report

---

**Last Updated:** February 1, 2026  
**Next Review:** After Phase 1 completion
