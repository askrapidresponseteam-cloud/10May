# Privacy Policy for RRT (Rapid Response Team)

**Effective Date:** February 1, 2026  
**Last Updated:** February 1, 2026

---

## 1. Introduction

Welcome to RRT (Rapid Response Team), a community-based emergency alert mobile application. This Privacy Policy explains how we collect, use, store, and protect your personal information when you use our mobile application ("App").

By using the RRT App, you agree to the collection and use of information in accordance with this policy. If you do not agree with this policy, please do not use the App.

**RRT is designed for animal welfare workers, volunteers, and feeders to coordinate emergency response within their communities.**

---

## 2. Information We Collect

### 2.1 Information You Provide Directly

When you create a profile in the App, you provide:

- **Name:** Used to identify you when you send emergency alerts
- **Mobile Number:** Used as emergency contact information visible to other users when you activate an SOS alert
- **Emergency Messages (optional):** Text messages you may include with emergency alerts

### 2.2 Location Information

The App collects and uses location data for the following purposes:

- **District Identification:** To determine which district you are located in for routing emergency alerts to the correct community members
- **Emergency Location Sharing:** Your precise location (latitude/longitude) and approximate address are shared with other users when you activate an SOS alert

**How Location Data is Used:**
- Location is accessed only when the App is actively in use (foreground access only)
- Location data is used to determine your district using offline boundary mapping
- Your location is shared with volunteers in your district only when you actively send an SOS alert
- We do NOT track your location in the background
- We do NOT store historical location data beyond active emergency alerts

### 2.3 Automatically Collected Information

The App automatically collects:

- **Device Information:** Device type, operating system version, app version
- **Unique User ID:** A randomly generated UUID stored locally on your device to prevent duplicate notifications
- **Firebase Cloud Messaging (FCM) Token:** Used to send push notifications to your device
- **Alert History:** Active emergency alerts you send or receive (stored temporarily)

### 2.4 Information We Do NOT Collect

We do NOT collect:
- Precise location history or tracking data
- Contacts list
- Payment or financial information
- Social media accounts or credentials
- Browsing history or app usage analytics (beyond basic Firebase functionality)

(Note: Scene photos and voice messages are collected only during an active SOS,
with your explicit consent on first use, and are governed by the retention rules
in Section 4.2.)

---

## 3. How We Use Your Information

### 3.1 Primary Uses

Your information is used for the following purposes:

**Emergency Alert Functionality:**
- Send your name, phone number, and location to volunteers in your district when you activate an SOS alert
- Receive emergency alerts from other users in your district
- Route alerts to the appropriate geographic area

**App Functionality:**
- Create and maintain your user profile
- Subscribe you to relevant district-based notification topics
- Display active emergency alerts in your area
- Enable communication between alert senders and potential responders

**Legal Compliance:**
- Comply with applicable laws and regulations
- Respond to legal requests or prevent fraud/abuse

### 3.2 Data Sharing

**Your information is shared in the following circumstances:**

**During Active SOS Alerts (With Your Explicit Consent):**
- Your name, mobile number, and location are shared with all users subscribed to your district's notification topic
- This occurs ONLY when you actively send an SOS alert
- You explicitly consent to this sharing during profile creation and confirm before each alert

**Third-Party Services:**
- **Firebase (Google LLC):** We use Firebase Cloud Messaging for push notifications and Firebase Core for app infrastructure. Firebase may collect device information and usage data according to their privacy policy: https://firebase.google.com/support/privacy
- **Geocoding Services:** We use platform-native geocoding services (Apple/Google) to convert coordinates to readable addresses

**We DO NOT:**
- Sell your personal information to third parties
- Share your information for advertising or marketing purposes
- Share your location data except during active emergency alerts you initiate

---

## 4. Data Storage and Security

### 4.1 Where Your Data is Stored

- **Locally on Your Device:** Your profile (name, mobile number, user ID) is stored locally using encrypted storage on your device
- **Cloud Backend:** During active SOS alerts, your information is temporarily stored on our backend servers to facilitate alert distribution
- **Firebase:** Push notification tokens and subscriptions are managed by Firebase (Google)

### 4.2 Data Retention

- **Profile Data:** Stored on your device until you delete it via "Delete My Data" in the Profile screen
- **Active SOS Alerts:** Stored for 60 minutes after activation, then automatically removed
- **Scene Photos & Voice Messages:** Removed when the SOS ends (whether stopped manually or auto-expired) or after 60 minutes from activation, whichever is sooner. Not retained beyond the lifetime of the alert.
- **Server Logs:** Retained for 90 days for security and troubleshooting purposes
- **User ID:** Persists on your device until you delete the app or clear app data

### 4.3 Security Measures

We implement reasonable security measures to protect your information:

- **Encrypted Local Storage:** Sensitive data stored using platform-secure storage mechanisms
- **HTTPS:** All network communications use encrypted HTTPS connections
- **No Plaintext Passwords:** The App does not use password authentication
- **Limited Access:** Only necessary volunteers in your district receive your information during alerts

**However, please note:** No method of electronic storage or transmission is 100% secure. While we strive to protect your information, we cannot guarantee absolute security.

---

## 5. Your Rights and Choices

### 5.1 Access and Update

You can access and update your profile information at any time:
- Open the App → Navigate to Profile screen
- Edit your name or mobile number
- Click "UPDATE PROFILE" to save changes

### 5.2 Data Deletion (Right to Erasure)

You have the right to delete all your personal data from the App:

**How to Delete Your Data:**
1. Open the App → Navigate to Profile screen
2. Scroll to the "DANGER ZONE" section
3. Click "DELETE MY DATA"
4. Confirm deletion

**What Gets Deleted:**
- Your profile (name and mobile number)
- User ID and preferences
- Alert history and district subscriptions
- All app settings and data

**Note:** This action is permanent and cannot be undone. You will need to create a new profile to use the App again.

### 5.3 Location Permissions

You can manage location permissions through your device settings:

**iOS:** Settings → RRT → Location → Select "Never" or "While Using the App"  
**Android:** Settings → Apps → RRT → Permissions → Location → Deny or Allow

**Note:** Denying location access will prevent the App from functioning correctly, as location is essential for district-based emergency routing.

### 5.4 Notification Permissions

You can disable push notifications through your device settings:

**iOS:** Settings → RRT → Notifications → Toggle off  
**Android:** Settings → Apps → RRT → Notifications → Toggle off

**Note:** Disabling notifications means you will not receive emergency alerts from your community.

### 5.5 Withdraw Consent

You may withdraw consent for phone number sharing by:
- Deleting your data (see section 5.2)
- Uninstalling the App

Once consent is withdrawn, your information will no longer be shared during emergency alerts.

---

## 6. Children's Privacy

The RRT App is NOT intended for use by individuals under 18 years of age. We do not knowingly collect personal information from children under 18.

If you believe a child under 18 has provided personal information to the App, please contact us immediately at [YOUR_CONTACT_EMAIL] and we will take steps to delete such information.

By using the App, you confirm that you are 18 years of age or older.

---

## 7. Emergency Services Disclaimer

**IMPORTANT:** The RRT App is a technology platform that connects community volunteers. It is NOT a substitute for official emergency services.

**The App does NOT:**
- Connect you to police, ambulance, or fire services
- Provide professional emergency response
- Guarantee response times or outcomes
- Replace calling 112 (emergency services in India)

**For life-threatening emergencies, always call 112 or your local emergency number.**

Your use of the App for emergency alerts is voluntary and at your own risk. We are not liable for response times, outcomes, or lack of response from community volunteers.

---

## 8. Data Processing Legal Basis (GDPR & DPDPA)

If you are located in the European Union or India, we process your personal data under the following legal bases:

**Consent (GDPR Article 6(1)(a), DPDPA Section 6):**
- You explicitly consent to phone number sharing during profile creation
- You confirm sharing before each emergency alert

**Legitimate Interests (GDPR Article 6(1)(f)):**
- Operating the emergency alert service for community safety
- Preventing abuse and ensuring service integrity

**You have the right to:**
- Access your personal data
- Rectify inaccurate data
- Erase your data (right to be forgotten)
- Restrict or object to processing
- Data portability (where applicable)
- Withdraw consent at any time

---

## 9. International Data Transfers

The App operates primarily in India. Your data may be transferred to and processed in:

- **India:** Our backend servers (if applicable)
- **United States:** Firebase services operated by Google LLC

We ensure appropriate safeguards are in place for international transfers in accordance with GDPR and DPDPA requirements.

---

## 10. Third-Party Services

The App uses the following third-party services:

### 10.1 Firebase (Google LLC)

**Services Used:**
- Firebase Cloud Messaging (push notifications)
- Firebase Core (app infrastructure)

**Data Shared with Firebase:**
- Device tokens for push notifications
- District subscription topics
- Device information (OS, app version)

**Firebase Privacy Policy:** https://firebase.google.com/support/privacy

### 10.2 Platform Services

**Apple Location Services (iOS):**
- Used to access device GPS for district determination
- Subject to Apple's Privacy Policy

**Google Location Services (Android):**
- Used to access device GPS and geocoding
- Subject to Google's Privacy Policy

---

## 11. Push Notifications

The App uses Firebase Cloud Messaging to send emergency alerts:

**How It Works:**
- You are automatically subscribed to your district's notification topic (e.g., "district-bangalore")
- When any user in your district sends an SOS, you receive a push notification
- Notifications include the sender's name, location, and optional message

**Privacy Protection:**
- You only receive alerts from users in your district (geographic privacy boundary)
- You do NOT receive your own alerts (self-filtering)
- You can disable notifications via device settings (though this reduces App functionality)

---

## 12. Cookies and Tracking

The RRT App does NOT use:
- Cookies
- Web tracking pixels
- Advertising identifiers
- Analytics tracking (beyond basic Firebase functionality)
- Third-party advertising networks

---

## 13. Data Breach Notification

In the event of a data breach that affects your personal information, we will:
- Notify affected users within 72 hours (as required by GDPR/DPDPA)
- Provide details about the breach and steps taken to mitigate harm
- Notify relevant authorities if required by law

---

## 14. Changes to This Privacy Policy

We may update this Privacy Policy from time to time. When we make changes:

- We will update the "Last Updated" date at the top of this policy
- For material changes, we will notify you via:
  - In-app notification when you next open the App
  - Push notification (if enabled)
- Continued use of the App after changes constitutes acceptance of the updated policy

We encourage you to review this policy periodically.

---

## 15. Your California Privacy Rights (CCPA)

If you are a California resident, you have additional rights under the California Consumer Privacy Act (CCPA):

**Right to Know:** You can request information about the personal data we collect and how we use it.

**Right to Delete:** You can request deletion of your personal data (via "Delete My Data" in the App).

**Right to Opt-Out:** We do not sell personal information, so opt-out does not apply.

**Non-Discrimination:** We will not discriminate against you for exercising your privacy rights.

To exercise these rights, use the in-app deletion feature or contact us at [YOUR_CONTACT_EMAIL].

---

## 16. European Union Rights (GDPR)

If you are located in the European Union, you have rights under the General Data Protection Regulation (GDPR):

- **Right of Access:** Request a copy of your personal data
- **Right to Rectification:** Correct inaccurate personal data
- **Right to Erasure:** Request deletion of your personal data
- **Right to Restrict Processing:** Limit how we use your data
- **Right to Data Portability:** Receive your data in a structured format
- **Right to Object:** Object to processing based on legitimate interests
- **Right to Withdraw Consent:** Withdraw consent at any time

To exercise these rights, contact us at [YOUR_CONTACT_EMAIL] or use the in-app deletion feature.

You also have the right to lodge a complaint with your local data protection authority.

---

## 17. India Data Protection (DPDPA 2023)

For users in India, we comply with the Digital Personal Data Protection Act, 2023 (DPDPA):

- We process your data with explicit consent
- You have the right to access, correct, and erase your data
- You have the right to nominate a representative
- We maintain reasonable security safeguards
- You can file complaints with the Data Protection Board of India

---

## 18. Abuse Prevention and Misuse

We reserve the right to:
- Monitor SOS alerts for patterns of abuse or misuse
- Block or suspend users who violate our Terms of Service
- Report illegal activity to authorities when required by law
- Retain logs for security and fraud prevention (90 days)

**Prohibited Uses:**
- Sending false or prank emergency alerts
- Harassing other users
- Using the App for unlawful purposes

Violations may result in permanent suspension and reporting to authorities.

---

## 19. Disclaimer of Liability

**IMPORTANT:** The RRT App is a volunteer coordination tool and does NOT provide professional emergency services.

- We are not responsible for response times or outcomes of emergency alerts
- We do not guarantee that volunteers will respond to your alerts
- We are not liable for injuries, losses, or damages arising from App use
- You use the App at your own risk

**For life-threatening emergencies, always call 112 (India emergency services) or your local emergency number.**

---

## 20. Contact Us

If you have questions, concerns, or requests regarding this Privacy Policy or your personal data, please contact us:

**Email:** [YOUR_CONTACT_EMAIL - Replace with actual email]  
**Address:** [YOUR_COMPANY_ADDRESS - Optional]  
**Response Time:** We aim to respond to privacy requests within 30 days

For data deletion, you can also use the in-app "Delete My Data" feature in the Profile screen.

---

## 21. Governing Law

This Privacy Policy is governed by the laws of India. Any disputes arising from this policy shall be subject to the exclusive jurisdiction of courts in [YOUR_JURISDICTION - e.g., Bangalore, Karnataka, India].

---

## 22. Data Controller Information

The data controller responsible for your personal information is:

**App Name:** RRT (Rapid Response Team)  
**Developer:** [YOUR_COMPANY_NAME]  
**Contact:** [YOUR_CONTACT_EMAIL]

---

## 23. Summary of Data Practices

For your convenience, here's a quick summary:

| Data Type | Purpose | Sharing | Retention |
|-----------|---------|---------|-----------|
| Name | Emergency identification | Volunteers during SOS | Until you delete |
| Mobile Number | Emergency contact | Volunteers during SOS | Until you delete |
| Location (District) | Alert routing | Determines notification recipients | Not stored |
| Location (Precise) | Emergency response | Volunteers during active SOS | 60 minutes |
| User ID (UUID) | Duplicate prevention | Not shared | Until app deletion |
| FCM Token | Push notifications | Firebase (Google) | Until app deletion |
| Device Info | App functionality | Firebase (Google) | Not stored |
| Alert History | App display | Not shared | 60 minutes |

**Key Privacy Features:**
- ✅ Phone number shared ONLY during active emergency alerts
- ✅ Location used ONLY for district determination and emergency alerts
- ✅ No background tracking or location history
- ✅ No advertising or data selling
- ✅ Easy data deletion via in-app feature
- ✅ Geographic privacy (only your district, not citywide or nationwide)

---

## 24. Important Notes for Emergency App Users

**Before Using This App for Emergencies:**

1. **Understand What This App Does:** This is a community volunteer coordination tool, NOT a connection to official emergency services
2. **Call 112 First:** For life-threatening emergencies, call official emergency services before or instead of using this App
3. **No Guaranteed Response:** Volunteers may or may not be available to respond
4. **Your Safety First:** Do not rely solely on this App in dangerous situations
5. **Information Sharing:** Your phone number WILL BE visible to community members when you send alerts

---

## 25. Age Verification

By using this App, you confirm that you are at least 18 years of age. If you are under 18, you may not use this App.

---

## 26. Consent Mechanisms

This App uses the following consent mechanisms:

**Profile Creation:**
- You must explicitly check a consent box agreeing that your phone number will be visible to community members during emergency alerts

**SOS Activation:**
- Before each emergency alert, you must confirm in a dialog showing exactly what information will be shared (name, phone, location)

**First-Time Use:**
- You must acknowledge that this App does NOT connect to official emergency services

These consent mechanisms ensure you are fully informed before your data is shared.

---

## 27. Accessibility of This Policy

This Privacy Policy is:
- Available at: [YOUR_GITHUB_PAGES_URL - Will be added after hosting]
- Linked from the App's Terms & Conditions screen
- Linked from the App's Profile screen
- Accessible on Apple App Store Connect listing
- Accessible on Google Play Console listing

---

## 28. Questions and Concerns

If you have any questions about this Privacy Policy or how we handle your data:

1. Review this policy carefully
2. Contact us at [YOUR_CONTACT_EMAIL]
3. For GDPR concerns (EU users): Contact your local Data Protection Authority
4. For DPDPA concerns (India users): Contact the Data Protection Board of India

---

## 29. Acknowledgment

By using the RRT App, you acknowledge that:

- You have read and understood this Privacy Policy
- You consent to the collection, use, and sharing of your information as described
- You understand the App does NOT connect to official emergency services
- You are 18 years of age or older
- You accept the risks associated with using a volunteer-based emergency alert system

---

**Last Updated:** February 1, 2026

---

## Version History

- **v1.0 (February 1, 2026):** Initial privacy policy created for RRT App v0.1.0

---

*This privacy policy was created to comply with:*
- *Apple App Store Review Guidelines (Section 5.1)*
- *Google Play User Data Policy*
- *General Data Protection Regulation (GDPR) - EU*
- *Digital Personal Data Protection Act (DPDPA) 2023 - India*
- *California Consumer Privacy Act (CCPA) - USA*
