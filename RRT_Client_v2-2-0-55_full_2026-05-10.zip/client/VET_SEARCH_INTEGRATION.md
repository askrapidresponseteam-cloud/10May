# Vet Search Feature — Integration Notes

Added in this changeset:
- `lib/core/services/vet_search_service.dart` — cache-first vet lookup
- `lib/screens/find_vet_screen.dart` — list / empty / error UI
- New `_LookUpVetSection` widget in `lib/screens/active_sos_screen.dart`
- New "Look up a vet" entry in `lib/screens/help_screen.dart`
- Ola Maps endpoint + key getter in `lib/core/config/api_config.dart`

## How it's wired

Two entry points push the same screen:

1. **Active SOS screen** — outline button between Voice and STOP SOS. Pushes
   `FindVetScreen(fromActiveSos: true)`, which adds a "SOS still active · MM:SS"
   strip under the TopBar so the user knows the alert is still ticking.
2. **Help index** — second numbered row, "Look up a vet". Pushes
   `FindVetScreen(fromActiveSos: false)`. Same screen, no breadcrumb.

The screen reads location via the existing `locationServiceProvider`, hands
coordinates to `VetSearchService.findNearby()`, and renders one of:
- LOADING (cache miss + Ola call in flight)
- RESULTS (vets sorted by distance, Call + Directions per row)
- EMPTY at 15km (offers "Search wider area" → 50km)
- EMPTY at 50km (suggests Google Maps + raise SOS)
- ERROR / UNAVAILABLE (Google Maps button is the path forward)

The "Open in Google Maps" footer button is **always present**, in every state.
Zero API cost on our side. Means the screen is never a dead-end.

## Cache layering

`VetSearchService.findNearby()` reads through:
1. **In-memory** map (lost on app restart, ~µs)
2. **shared_preferences** (per-device persistence, ~ms)
3. **Firestore** `vet_cache/{cellId}` (shared across all users, ~50ms)
4. **Ola Maps** Nearby Search HTTP (counts against 500K monthly free tier)

On a network success (4), all three cache layers are written. Cell IDs are
1km grid squares + radius prefix, e.g. `r15_lat1334_lng7474`. A 15km search
and a 50km search at the same coords cache separately.

**TTLs:** populated results 7 days, empty results 24 hours.

Real API call rate ≈ "number of unique 1km cells with active users per week"
not "number of searches." Should comfortably stay under the Freemium 500K/mo.

## Build setup — REQUIRED before shipping

### 1. Provide the Ola Maps API key at build time

The key is read via `String.fromEnvironment('OLA_MAPS_API_KEY')`. Pass it as
a `--dart-define` flag on every build:

```bash
flutter run --dart-define=OLA_MAPS_API_KEY=your_key_here
flutter build apk --dart-define=OLA_MAPS_API_KEY=$OLA_MAPS_API_KEY
flutter build ios --dart-define=OLA_MAPS_API_KEY=$OLA_MAPS_API_KEY
```

For CI/CD: store the key as a secret env var, pass to the build command.
**Never commit the key to git.** A leaked key = someone else burning your
free tier.

If the key is missing at build time, `ApiConfig.olaMapsApiKey` is empty and
`olaMapsEnabled` returns false. The service throws `VetSearchUnavailable`
on cold-cache reads, which the screen handles by showing the "Open in
Google Maps" button only. **The feature still works in degraded mode** —
useful for early testing, or as a kill-switch if Ola goes down.

### 2. Restrict the API key in the Krutrim console

In the credential settings page for `rapid-response-vet-search`:

- **Restrict by app bundle / package**: add `com.rrt.app.rrtFlutterApp` (iOS)
  and `com.rrt.app.rrt_flutter_app` (Android). For Android you may also
  need to add the SHA-1 fingerprints of your debug and release signing
  certificates.
- **Restrict by API**: if Krutrim's UI exposes per-API toggles, restrict
  this key to **Places APIs > Nearby Search** only. Belt-and-braces with
  the code-side restriction.
- **Set a daily quota**: even a generous 5,000 calls/day acts as a circuit
  breaker against runaway bugs or abuse.

### 3. Firestore security rules

Add to your existing rules to allow the cache reads/writes the service does:

```
match /vet_cache/{cellId} {
  // Anyone authenticated can read - the cache is shared across all users
  // by design; that's how we get the network-effect cost savings.
  allow read: if request.auth != null;

  // Anyone authenticated can write a fresh cache entry. Server-side
  // validation: the doc must have the expected shape, and the entry
  // can't claim to be from the future.
  allow write: if request.auth != null
    && request.resource.data.keys().hasAll(['vets', 'radius_m', 'fetched_at_ms'])
    && request.resource.data.fetched_at_ms is number
    && request.resource.data.fetched_at_ms <= request.time.toMillis() + 60000
    && request.resource.data.vets is list
    && request.resource.data.vets.size() <= 50;
}
```

This lets any signed-in user (which is everyone, since the app uses Firebase
Anonymous auth) read and refresh the cache. The size cap on `vets` prevents
malicious oversized writes.

## Ship sequence — RECOMMENDED

This is built as a complete Phase 1 + 2, but the README's compliance audit
flagged "missing privacy policy URL" as a 100% rejection blocker. The Ola
integration adds a third-party data flow (sending GPS coordinates to Ola)
that needs disclosure in that policy.

**Recommendation: don't ship the Ola integration before the privacy policy
is live.** Two ways to do that:

### Option A — ship the screen now WITHOUT the key (degraded mode)

Build without `OLA_MAPS_API_KEY`. The button appears, the screen opens, the
list section is replaced with "We can't show vets in this build, but Google
Maps works fine for this." The "Open in Google Maps" button is the only
action. Zero new third-party data flow. Privacy policy unchanged.

When the policy is live, add the build flag and ship a new version. The
in-app list lights up automatically.

### Option B — ship the whole thing with the key

Update the privacy policy first to disclose:
- "When you use Find a Vet, your approximate GPS coordinates are sent to
  Ola Maps (Krutrim Cloud Services Pvt Ltd, India) so we can return a
  list of nearby veterinary clinics. We cache the result for up to 7 days
  on your device and on our servers, indexed by approximate area, not by
  user."

Then build with the key.

## Things to verify before going live

- **Ola's `types` parameter for vets.** The service uses `veterinary_care`.
  If the live supported-types list uses a different value (e.g. `vet`,
  `veterinarian`), update `_fetchFromOla` in `vet_search_service.dart`.
  Symptom: Ola returns zero results for cells that have known vets.
  Fallback: switch to Text Search endpoint with `query=veterinary clinic`.
- **Auth header vs query param.** The service passes `api_key=...` as a
  query parameter. If Ola requires `Authorization: Bearer ...` instead,
  update the URI construction in `_fetchFromOla`. Check the Authentication
  page in the docs for the canonical answer.
- **Result coordinate shape.** The parser tries `geometry.location.lat/lng`
  first, then top-level `lat/lng`. Spot-check actual responses against
  this — if Ola uses a third shape, distances will all be null and the
  list will sort wrong.

## Things NOT done that you might want later

- **No `place_id` based directory** — `vet_cache/{cellId}` is a pure
  TTL'd snapshot. The recommended Phase 3 (a curated `vets/{vetId}`
  collection that improves over time with user contributions) is not in
  this changeset. Add when you have moderation capacity.
- **No phone numbers in v1** — would require a Place Details API call per
  vet, multiplying API count. Tap-to-call falls back to opening the vet
  in Google Maps where Google's Place card has the number.
- **No "open now" status** — same reason. Place Details would carry hours
  but at significant API cost. Worth adding only if you find users
  consistently calling vets that turn out to be closed.
- **No Remote Config kill-switch for the feature itself** — the existing
  `String.fromEnvironment` flag is a build-time switch, not a remote one.
  If you want to disable Ola live without shipping a new build, add a
  `vet_search_enabled` boolean to `RemoteConfigService` and check it in
  `VetSearchService.findNearby` before the network call.
