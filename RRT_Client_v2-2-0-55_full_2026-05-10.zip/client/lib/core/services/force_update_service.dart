import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:in_app_update/in_app_update.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

/// Detects when a newer build of this app is live on the App Store (iOS) or
/// Play Store (Android), so the UI can show the blocking ForceUpdateDialog.
///
/// History: this used to be implemented on top of the `upgrader` package.
/// That implementation was failing 100% in production on both platforms.
/// Three problems:
///   1. `upgrader` exposed `currentInstalledVersion`/`currentAppStoreVersion`
///      as public methods on its main class, but the package's own
///      changelog (9.0.0) noted these were renamed/restructured because
///      callers were misusing them outside the official `UpgradeAlert`
///      widget. Calling them directly bypassed the lifecycle hooks the
///      package depended on, so they often returned null.
///   2. iTunes Lookup requires the right `country` parameter. `upgrader`
///      defaulted to the device's system locale, which for a globally-
///      distributed user base often resolved to US/etc. — and our app is
///      only published in the IN store, so the lookup returned no
///      matching record. That looked indistinguishable from "no update
///      available" and silently failed open.
///   3. The Android path scraped the Play Store HTML. Google has
///      changed that page structure multiple times; scrapers break
///      silently when they do. Failed open the same way.
///
/// Replacement strategy:
///   • iOS  -> direct http.get to the documented iTunes Lookup endpoint.
///            country=IN is explicit; bundle ID is hardcoded. Stable,
///            documented, observable.
///   • Android -> in_app_update package (Google's official Play Core
///            wrapper). This is the API Google recommends for
///            force-update flows. It can also run an immediate update
///            in-app (download + install in a Google-rendered full-
///            screen flow) so we don't have to bounce the user to the
///            Play Store.
///
/// Debug logging at every step. Future "this is broken" reports should
/// be greppable from the logs.
///
/// Failing open: any network/parse error returns null and the user is
/// let through. We never block on a transient store check failure.
class ForceUpdateService {
  /// iOS App Store ID for the published app.
  static const String _iosAppId = '6758672498';

  /// iOS bundle identifier (CFBundleIdentifier in Info.plist). iTunes
  /// Lookup queries by this. Currently identical to [_androidPackage]
  /// but kept as a separate constant so the two can diverge without
  /// silently breaking iOS update detection.
  static const String _iosBundleId = 'com.rrt.sos';

  /// Android Play Store package name (mirrors the app's applicationId).
  static const String _androidPackage = 'com.rrt.sos';

  /// App Store country to query. Hardcoded to IN because that's the
  /// only store the app is published in. If a user's iOS region is
  /// (say) US and we query without country, iTunes Lookup returns no
  /// match and we incorrectly conclude "no update".
  static const String _itunesCountry = 'IN';

  /// One-shot guard so a parallel check (cold start + immediate
  /// resume on some Android phones) doesn't fire two requests in flight.
  static bool _checkInFlight = false;

  /// Hits the relevant store and returns update info iff a newer
  /// version is available than what's currently installed. Returns null
  /// otherwise (including all error cases — fail open).
  static Future<ForceUpdateInfo?> checkForUpdate() async {
    if (_checkInFlight) {
      debugPrint('ForceUpdateService: check already in flight, skipping');
      return null;
    }
    _checkInFlight = true;
    try {
      if (Platform.isIOS) {
        return await _checkIos();
      } else if (Platform.isAndroid) {
        return await _checkAndroid();
      }
      debugPrint('ForceUpdateService: unsupported platform');
      return null;
    } catch (e, st) {
      // Catch-all: nothing here should ever propagate, since this is
      // called from app startup where an unhandled future would crash.
      debugPrint('ForceUpdateService: unexpected error (failing open): $e\n$st');
      return null;
    } finally {
      _checkInFlight = false;
    }
  }

  // ---------- iOS ------------------------------------------------------------

  static Future<ForceUpdateInfo?> _checkIos() async {
    debugPrint('ForceUpdateService: iOS check starting (bundleId=$_iosBundleId, country=$_itunesCountry)');
    final installed = await _getInstalledVersion();
    if (installed == null) {
      debugPrint('ForceUpdateService: could not read installed version');
      return null;
    }
    debugPrint('ForceUpdateService: installed=$installed');

    // iTunes Lookup endpoint. Public, no auth, JSON response.
    // bundleId param identifies the app; country pins it to the IN
    // storefront (where the app is actually published).
    final uri = Uri.parse(
      'https://itunes.apple.com/lookup'
      '?bundleId=$_iosBundleId&country=$_itunesCountry',
    );

    final http.Response res;
    try {
      res = await http.get(uri).timeout(const Duration(seconds: 8));
    } catch (e) {
      debugPrint('ForceUpdateService: iTunes Lookup network error: $e');
      return null;
    }

    if (res.statusCode != 200) {
      debugPrint('ForceUpdateService: iTunes Lookup non-200: ${res.statusCode}');
      return null;
    }

    Map<String, dynamic> json;
    try {
      json = jsonDecode(res.body) as Map<String, dynamic>;
    } catch (e) {
      debugPrint('ForceUpdateService: iTunes Lookup JSON parse error: $e');
      return null;
    }

    final results = json['results'];
    if (results is! List || results.isEmpty) {
      // Two reasons this could be empty: (a) brand-new release not yet
      // indexed by iTunes (CDN can take 6-24h), (b) wrong country code
      // for the user's region. Either way, fail open.
      debugPrint('ForceUpdateService: iTunes Lookup returned no results');
      return null;
    }

    final first = results.first;
    if (first is! Map<String, dynamic>) {
      debugPrint('ForceUpdateService: iTunes Lookup result not a map');
      return null;
    }

    final latest = first['version'];
    if (latest is! String || latest.isEmpty) {
      debugPrint('ForceUpdateService: iTunes Lookup missing version field');
      return null;
    }
    debugPrint('ForceUpdateService: latest=$latest');

    if (!_isVersionBelow(installed, latest)) {
      debugPrint('ForceUpdateService: installed >= latest, no update');
      return null;
    }

    return ForceUpdateInfo(
      installedVersion: installed,
      latestVersion: latest,
      // iOS has no in-app update flow — the dialog will deep-link to
      // the App Store and the user installs there.
      canUpdateInApp: false,
    );
  }

  // ---------- Android --------------------------------------------------------

  static Future<ForceUpdateInfo?> _checkAndroid() async {
    debugPrint('ForceUpdateService: Android check starting');
    AppUpdateInfo info;
    try {
      info = await InAppUpdate.checkForUpdate();
    } catch (e) {
      // checkForUpdate throws if the app wasn't installed via Play
      // Store ("ERROR_APP_NOT_OWNED"), if Play Services is missing,
      // or if there's a transient Play Core failure. All fail open.
      debugPrint('ForceUpdateService: InAppUpdate.checkForUpdate threw: $e');
      return null;
    }
    debugPrint(
      'ForceUpdateService: Android info '
      'availability=${info.updateAvailability} '
      'available=${info.availableVersionCode} '
      'immediateAllowed=${info.immediateUpdateAllowed} '
      'flexibleAllowed=${info.flexibleUpdateAllowed}',
    );

    if (info.updateAvailability != UpdateAvailability.updateAvailable) {
      return null;
    }

    // We only treat this as a "force" update if Google says immediate
    // update is allowed. If only flexible is allowed, the OS won't let
    // us run the blocking flow, so showing a non-dismissible dialog
    // would just trap the user. In that case fail open and let the
    // store auto-update catch them.
    if (!info.immediateUpdateAllowed) {
      debugPrint('ForceUpdateService: update available but immediate not allowed; failing open');
      return null;
    }

    final installedName = await _getInstalledVersion();

    return ForceUpdateInfo(
      installedVersion: installedName ?? '?',
      latestVersion: '${info.availableVersionCode ?? '?'}',
      canUpdateInApp: true,
    );
  }

  /// Triggers Google Play's native immediate-update flow. Available on
  /// Android only and only when [ForceUpdateInfo.canUpdateInApp] is true.
  ///
  /// On success the OS takes over: full-screen download + install,
  /// then relaunches the app on the new version. On failure (user
  /// cancels, network drops, Play Services error) returns false and
  /// the dialog stays up.
  static Future<bool> performImmediateAndroidUpdate() async {
    if (!Platform.isAndroid) return false;
    try {
      final result = await InAppUpdate.performImmediateUpdate();
      debugPrint('ForceUpdateService: performImmediateUpdate result=$result');
      return result == AppUpdateResult.success;
    } catch (e) {
      debugPrint('ForceUpdateService: performImmediateUpdate threw: $e');
      return false;
    }
  }

  // ---------- Common --------------------------------------------------------

  /// Opens the platform-appropriate store page as a fallback when the
  /// in-app flow isn't possible (iOS, or Android failures). Tries native
  /// `itms-apps://` / `market://` schemes first, then https.
  static Future<bool> openStorePage() async {
    final urls = _storeUrls();
    for (final url in urls) {
      try {
        final uri = Uri.parse(url);
        if (await canLaunchUrl(uri)) {
          final ok = await launchUrl(
            uri,
            mode: LaunchMode.externalApplication,
          );
          if (ok) return true;
        }
      } catch (e) {
        debugPrint('ForceUpdateService: launch failed for $url: $e');
      }
    }
    return false;
  }

  static List<String> _storeUrls() {
    if (Platform.isIOS) {
      return [
        'itms-apps://itunes.apple.com/app/id$_iosAppId',
        'https://apps.apple.com/$_itunesCountry/app/rapid-response/id$_iosAppId',
      ];
    }
    if (Platform.isAndroid) {
      return [
        'market://details?id=$_androidPackage',
        'https://play.google.com/store/apps/details?id=$_androidPackage',
      ];
    }
    return const [];
  }

  /// Read the running app's version (e.g. "2.1.10"). Returns null on
  /// failure - we'd rather skip the check than show garbage in the
  /// dialog's "INSTALLED: ..." line.
  static Future<String?> _getInstalledVersion() async {
    try {
      final pi = await PackageInfo.fromPlatform();
      final v = pi.version;
      return v.isEmpty ? null : v;
    } catch (e) {
      debugPrint('ForceUpdateService: PackageInfo.fromPlatform failed: $e');
      return null;
    }
  }

  /// Robust semver-ish comparison. Splits on `.` and compares numeric
  /// parts. Tolerates extra parts (`2.1.10.4`), missing parts (`2.1`),
  /// build suffixes (`2.1.10+45`, `2.1.10-beta`), and non-numeric
  /// components (treated as 0).
  static bool _isVersionBelow(String installed, String latest) {
    final a = _parseParts(installed);
    final b = _parseParts(latest);
    final len = a.length > b.length ? a.length : b.length;
    for (var i = 0; i < len; i++) {
      final ai = i < a.length ? a[i] : 0;
      final bi = i < b.length ? b[i] : 0;
      if (ai < bi) return true;
      if (ai > bi) return false;
    }
    return false;
  }

  static List<int> _parseParts(String v) {
    // Strip any build suffix (`+45`, `-beta`, etc.) before splitting.
    final clean = v.split(RegExp(r'[-+]')).first;
    return clean.split('.').map((p) => int.tryParse(p) ?? 0).toList();
  }
}

/// Plain-data result of a successful store check. Held by the
/// ForceUpdateDialog and used to render the version comparison line.
class ForceUpdateInfo {
  final String installedVersion;
  final String latestVersion;

  /// True iff the OS supports running the update entirely in-app
  /// (Android with Play Core's immediate-update flow). When true, the
  /// dialog's "Update Now" button calls
  /// [ForceUpdateService.performImmediateAndroidUpdate]. When false
  /// (always on iOS), the button deep-links to the store via
  /// [ForceUpdateService.openStorePage].
  final bool canUpdateInApp;

  const ForceUpdateInfo({
    required this.installedVersion,
    required this.latestVersion,
    required this.canUpdateInApp,
  });
}
