import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_app_installations/firebase_app_installations.dart';
import '../providers/alerts_provider.dart';

/// Service for handling FCM notifications.
/// Alerts are loaded from Firestore (single source of truth); FCM signals new alerts.
/// Chat messages are suppressed when the user is already viewing that conversation.
class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  static bool _initialized = false;
  static final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();

  /// WidgetRef stored so notification handlers can switch tabs without a BuildContext.
  /// Stored as dynamic to avoid a circular import between the service and providers.
  static dynamic _ref;

  /// The conv_id of the conversation currently open on screen, or null.
  /// Set by ChatScreen.initState / dispose.
  static String? _activeChatConvId;

  /// Called by ChatScreen to register/unregister the active conversation.
  /// While a conv_id is set, foreground FCM messages for that conversation
  /// will be silently dropped (user is already reading them).
  static void setActiveChatConvId(String? convId) {
    _activeChatConvId = convId;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Initialization
  // ─────────────────────────────────────────────────────────────────────────

  static Future<void> initialize(
      GlobalKey<NavigatorState> navigatorKey, dynamic ref) async {
    _ref = ref;

    if (!_initialized) {
      await _initializeLocalNotifications();
      await _requestFCMPermissions();
      _setupMessageHandlers();
      await _verifyInitialization();
      _initialized = true;
    }
  }

  static Future<void> _verifyInitialization() async {
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) {
        debugPrint('✅ Notification service initialized successfully');
      } else {
        debugPrint('⚠️ FCM token is null - notifications may not work');
      }
    } catch (e) {
      debugPrint('⚠️ Notification service verification failed: $e');
    }
  }

  static Future<void> _requestFCMPermissions() async {
    try {
      final messaging = FirebaseMessaging.instance;
      await messaging.requestPermission(
        alert: true,
        badge: true,
        sound: true,
        provisional: false,
      );
      final settings = await messaging.getNotificationSettings();
      debugPrint('FCM Permission status: ${settings.authorizationStatus}');
      if (kDebugMode) {
        final token = await messaging.getToken();
        debugPrint('FCM Token: $token');
      }
    } catch (e) {
      debugPrint('FCM permission request failed: $e');
    }
  }

  static Future<void> _initializeLocalNotifications() async {
    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );
    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );
    await _localNotifications.initialize(initSettings);

    // SOS alert channel - critical priority, max interruption
    const AndroidNotificationChannel sosChannel = AndroidNotificationChannel(
      'sos_alerts',
      'SOS Alerts',
      description: 'Critical emergency SOS notifications',
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
      enableLights: true,
      ledColor: Color(0xFFFF0000),
      showBadge: true,
    );

    // Chat message channel - high priority, standard interruption
    const AndroidNotificationChannel chatChannel = AndroidNotificationChannel(
      'chat_messages',
      'Chat Messages',
      description: 'Emergency coordination chat messages',
      importance: Importance.high,
      playSound: true,
      enableVibration: true,
      showBadge: true,
    );

    final androidPlugin = _localNotifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(sosChannel);
    await androidPlugin?.createNotificationChannel(chatChannel);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Message handlers
  // ─────────────────────────────────────────────────────────────────────────

  static void _setupMessageHandlers() {
    try {
      FirebaseMessaging.onMessage.listen(
        (RemoteMessage message) async {
          try {
            await _handleForegroundMessage(message);
          } catch (e) {
            debugPrint('❌ Foreground message handling failed: $e');
          }
        },
        onError: (error) {
          debugPrint('❌ Foreground message stream error: $error');
        },
      );

      FirebaseMessaging.onMessageOpenedApp.listen(
        (RemoteMessage message) async {
          try {
            await _handleNotificationTap(message);
          } catch (e) {
            debugPrint('❌ Message opened app handling failed: $e');
          }
        },
        onError: (error) {
          debugPrint('❌ Message opened app stream error: $error');
        },
      );

      handleTerminatedMessage();
      debugPrint('✅ Message handlers registered successfully');
    } catch (e) {
      debugPrint('❌ Notification handler setup failed: $e');
    }
  }

  /// Handle a message that arrives while the app is in the foreground.
  static Future<void> _handleForegroundMessage(RemoteMessage message) async {
    final type = message.data['type'] as String?;

    if (type == 'chat_message') {
      // Suppress notification if the user is already viewing this conversation
      final incomingConvId = message.data['conv_id'] as String?;
      if (incomingConvId != null && incomingConvId == _activeChatConvId) {
        debugPrint(
            '🔕 Chat notification suppressed - user is in the active conversation');
        return;
      }
      await _showLocalNotification(message, isChatMessage: true);
      return;
    }

    // SOS alert - filter out self-sent alerts
    final messageSenderId = message.data['sender_id'];
    if (messageSenderId != null) {
      try {
        final currentSenderId = await FirebaseInstallations.instance.getId();
        if (messageSenderId == currentSenderId) return;
      } catch (_) {}
    }
    await _showLocalNotification(message, isChatMessage: false);
  }

  /// Handle a notification tap when the app was in the background.
  static Future<void> _handleNotificationTap(RemoteMessage message) async {
    final type = message.data['type'] as String?;
    if (type == 'chat_message') {
      _switchToChatsTab();
    } else {
      _switchToAlertsTab();
    }
  }

  static void _switchToChatsTab() {
    try {
      // index 2 = Chats tab in MainNavigationScreen
      (_ref as dynamic).read(activeTabIndexProvider.notifier).state = 2;
    } catch (e) {
      debugPrint('Could not switch to Chats tab: $e');
    }
  }

  static void _switchToAlertsTab() {
    try {
      (_ref as dynamic).read(activeTabIndexProvider.notifier).state = 1;
      (_ref as dynamic).read(alertsScreenActiveProvider.notifier).state = true;
    } catch (e) {
      debugPrint('Could not switch to Alerts tab: $e');
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Local notification display
  // ─────────────────────────────────────────────────────────────────────────

  static Future<void> _showLocalNotification(
    RemoteMessage message, {
    required bool isChatMessage,
  }) async {
    final AndroidNotificationDetails androidDetails;
    final DarwinNotificationDetails iosDetails;

    if (isChatMessage) {
      androidDetails = const AndroidNotificationDetails(
        'chat_messages',
        'Chat Messages',
        channelDescription: 'Emergency coordination chat messages',
        importance: Importance.high,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
        playSound: true,
        enableVibration: true,
        channelShowBadge: true,
        autoCancel: true,
        visibility: NotificationVisibility.private,
      );
      iosDetails = const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
        interruptionLevel: InterruptionLevel.active,
      );
    } else {
      androidDetails = const AndroidNotificationDetails(
        'sos_alerts',
        'SOS Alerts',
        channelDescription: 'Critical emergency SOS notifications',
        importance: Importance.max,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
        playSound: true,
        enableVibration: true,
        enableLights: true,
        color: Color(0xFFFF0000),
        ledColor: Color(0xFFFF0000),
        ledOnMs: 1000,
        ledOffMs: 500,
        channelShowBadge: true,
        autoCancel: true,
        visibility: NotificationVisibility.public,
      );
      iosDetails = const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
        interruptionLevel: InterruptionLevel.critical,
      );
    }

    final notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    try {
      final title = message.notification?.title ??
          (isChatMessage ? 'New message' : 'SOS Alert');
      final body = message.notification?.body ??
          message.data['message'] ??
          (isChatMessage
              ? 'You have a new message'
              : 'Emergency alert in your area');

      await _localNotifications.show(
        message.hashCode,
        title,
        body,
        notificationDetails,
        payload: message.data.toString(),
      );
    } catch (e) {
      debugPrint('Local notification failed: $e');
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Background & terminated handlers
  // ─────────────────────────────────────────────────────────────────────────

  /// Called from the top-level background handler in main.dart.
  static Future<void> handleBackgroundMessage(RemoteMessage message) async {
    final messageSenderId = message.data['sender_id'];
    if (messageSenderId != null) {
      try {
        final currentSenderId = await FirebaseInstallations.instance.getId();
        if (messageSenderId == currentSenderId) return;
      } catch (_) {}
    }
    debugPrint(
        'Background FCM received (alerts loaded from Firestore on app open)');
  }

  /// Called once on app start to handle the notification that launched the app
  /// from a terminated state.
  static Future<void> handleTerminatedMessage() async {
    try {
      final message = await FirebaseMessaging.instance.getInitialMessage();
      if (message == null) return;

      final type = message.data['type'] as String?;

      // For SOS alerts, filter self-sent
      if (type != 'chat_message') {
        final messageSenderId = message.data['sender_id'];
        if (messageSenderId != null) {
          try {
            final currentSenderId =
                await FirebaseInstallations.instance.getId();
            if (messageSenderId == currentSenderId) return;
          } catch (_) {}
        }
      }

      // Route to the correct tab after a short delay so MainNavigationScreen
      // has time to mount and register its ref.listen.
      await Future.delayed(const Duration(milliseconds: 500));
      if (type == 'chat_message') {
        _switchToChatsTab();
      } else {
        _switchToAlertsTab();
      }
    } catch (e) {
      debugPrint('Terminated message handling failed: $e');
    }
  }
}
