import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:record/record.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'package:just_audio/just_audio.dart';
import '../config/api_config.dart';

/// Maximum number of voice notes per chat conversation, matching
/// CHAT_MAX_VOICE_PER_CONV in index.js.
const int kMaxChatVoiceNotes = 4;

/// Hard cap on a single recording. The recorder UI auto-stops at this
/// duration; the user gets a confirm/cancel choice after. 30 seconds
/// covers "describe what you're seeing" in an emergency context
/// without producing files large enough to choke a 3G upload.
const Duration kMaxChatVoiceDuration = Duration(seconds: 30);

/// Outcome of a recording attempt. The UI uses this to decide whether
/// to show the recording strip, what to put in error snackbars, etc.
enum ChatVoiceCaptureStatus {
  success,
  cancelled,
  atLimit,
  permissionDenied,
  recordFailed,
  uploadFailed,
  /// Bytes uploaded but /chat/attach-voice failed. Same orphan-in-storage
  /// pattern as ChatPhotoService.linkFailed - daily safety-net sweep
  /// will clean up if the conversation is gone.
  linkFailed,
}

class ChatVoiceCaptureResult {
  const ChatVoiceCaptureResult.success(this.url, this.durationMs)
      : status = ChatVoiceCaptureStatus.success;
  const ChatVoiceCaptureResult.cancelled()
      : status = ChatVoiceCaptureStatus.cancelled,
        url = null,
        durationMs = null;
  const ChatVoiceCaptureResult.atLimit()
      : status = ChatVoiceCaptureStatus.atLimit,
        url = null,
        durationMs = null;
  const ChatVoiceCaptureResult.permissionDenied()
      : status = ChatVoiceCaptureStatus.permissionDenied,
        url = null,
        durationMs = null;
  const ChatVoiceCaptureResult.recordFailed()
      : status = ChatVoiceCaptureStatus.recordFailed,
        url = null,
        durationMs = null;
  const ChatVoiceCaptureResult.uploadFailed()
      : status = ChatVoiceCaptureStatus.uploadFailed,
        url = null,
        durationMs = null;
  const ChatVoiceCaptureResult.linkFailed()
      : status = ChatVoiceCaptureStatus.linkFailed,
        url = null,
        durationMs = null;

  final ChatVoiceCaptureStatus status;
  final String? url;
  final int? durationMs;

  bool get isSuccess => status == ChatVoiceCaptureStatus.success;
}

/// Records voice notes from the mic, uploads them, and attaches to chat
/// messages via /chat/attach-voice. Owned by the chat screen for the
/// lifetime of the chat (one instance per ChatScreen state). Calls
/// dispose() on screen tear-down.
///
/// Threading: AudioRecorder + AudioPlayer are stateful and not thread-safe.
/// All methods on this service should be called from the UI thread, which
/// is the default in Flutter.
class ChatVoiceService {
  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _player = AudioPlayer();

  String? _currentRecordingPath;
  DateTime? _recordingStartedAt;
  bool _isRecording = false;
  bool get isRecording => _isRecording;

  /// Begin a recording. Returns true if started successfully, false on
  /// permission denied, already-recording guard, or platform error.
  ///
  /// Apply the same hardening as SosVoiceService:
  ///   - Refuse overlapping starts (double-tap, re-entry from a stream
  ///     listener)
  ///   - Unique filename per recording so a record-cancel-record cycle
  ///     can't overwrite a file that an in-flight upload is still
  ///     reading
  ///   - Time-based stale-file sweep on every start so disk usage stays
  ///     bounded across long-running app sessions
  Future<bool> startRecording(String convId) async {
    try {
      if (_isRecording) {
        debugPrint('ChatVoiceService: start ignored - already recording');
        return false;
      }

      final bool hasPermission = await _recorder.hasPermission();
      if (!hasPermission) {
        debugPrint('ChatVoiceService: microphone permission denied');
        return false;
      }

      final Directory tmp = await getTemporaryDirectory();

      // Stale-file sweep. Same logic as SosVoiceService - delete any
      // chat_voice_*.m4a older than 5 minutes. The 5-min cushion is
      // well past any legitimate upload of a 30s voice note (worst
      // case ~10s upload on 3G), so we never kill a file in use.
      try {
        final DateTime staleCutoff =
            DateTime.now().subtract(const Duration(minutes: 5));
        final List<FileSystemEntity> entries = tmp.listSync(followLinks: false);
        for (final FileSystemEntity ent in entries) {
          if (ent is! File) continue;
          final String base = path.basename(ent.path);
          if (!base.startsWith('chat_voice_') || !base.endsWith('.m4a')) continue;
          try {
            final FileStat stat = ent.statSync();
            if (stat.modified.isBefore(staleCutoff)) {
              ent.deleteSync();
            }
          } catch (_) { /* in use, race, fine */ }
        }
      } catch (e) {
        debugPrint('ChatVoiceService: temp cleanup warning (non-fatal): $e');
      }

      // Unique filename per recording. Without the timestamp suffix two
      // recordings for the same conversation share a path, and an
      // upload reading bytes while a fresh recording is being written
      // produces a corrupted upload.
      final int nowMs = DateTime.now().millisecondsSinceEpoch;
      _currentRecordingPath = path.join(
        tmp.path,
        'chat_voice_${convId}_$nowMs.m4a',
      );

      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          // 64 kbps mono is intelligible voice and produces ~250 KB
          // for a full 30s recording. Small enough to upload reliably
          // even on 2G.
          bitRate: 64000,
          sampleRate: 22050,
          numChannels: 1,
          noiseSuppress: true,
          echoCancel: true,
        ),
        path: _currentRecordingPath!,
      );

      _isRecording = true;
      _recordingStartedAt = DateTime.now();
      debugPrint('ChatVoiceService: recording started → $_currentRecordingPath');
      return true;
    } catch (e) {
      debugPrint('ChatVoiceService: start error: $e');
      _isRecording = false;
      _currentRecordingPath = null;
      _recordingStartedAt = null;
      return false;
    }
  }

  /// Stop the current recording and return the file. Caller is then
  /// expected to either call [uploadAndAttach] (confirm) or
  /// [discardRecording] (cancel).
  ///
  /// Returns null if the recorder failed or no recording was active.
  Future<File?> stopRecording() async {
    try {
      final String? filePath = await _recorder.stop();
      _isRecording = false;
      if (filePath == null) {
        _recordingStartedAt = null;
        return null;
      }
      final File file = File(filePath);
      final int size = await file.length();
      debugPrint('ChatVoiceService: recorded ${(size / 1024).toStringAsFixed(1)} KB');
      return file;
    } catch (e) {
      debugPrint('ChatVoiceService: stop error: $e');
      _isRecording = false;
      _recordingStartedAt = null;
      return null;
    }
  }

  /// Returns the elapsed recording time, or null if not recording.
  /// Used by the UI to render the live duration counter.
  Duration? get currentRecordingElapsed {
    final start = _recordingStartedAt;
    if (!_isRecording || start == null) return null;
    return DateTime.now().difference(start);
  }

  /// Path to the most-recently-started recording, or null if none.
  /// Stays set after stopRecording() returns (so the UI can recover
  /// the file to upload after auto-stop) and is cleared only by
  /// discardRecording() or a successful uploadAndAttach().
  String? get currentRecordingPath => _currentRecordingPath;

  /// Discard a recording without uploading. Deletes the local file.
  /// Safe to call multiple times - second call is a no-op.
  Future<void> discardRecording() async {
    final p = _currentRecordingPath;
    _currentRecordingPath = null;
    _recordingStartedAt = null;
    if (p == null) return;
    try {
      final f = File(p);
      if (await f.exists()) await f.delete();
    } catch (e) {
      debugPrint('ChatVoiceService: discard delete error (non-fatal): $e');
    }
  }

  /// Upload the recording and attach it to the chat. Returns a result
  /// describing success / specific failure. On success, includes the
  /// public URL and duration so the UI can render the bubble
  /// optimistically.
  Future<ChatVoiceCaptureResult> uploadAndAttach({
    required File file,
    required String convId,
    required String fromFid,
    required Duration duration,
  }) async {
    final int durationMs = duration.inMilliseconds;

    final String? url = await _uploadToFirebaseStorage(
      file: file,
      convId: convId,
    );
    if (url == null) {
      return const ChatVoiceCaptureResult.uploadFailed();
    }

    final bool linked = await _attachOnBackend(
      convId: convId,
      fromFid: fromFid,
      url: url,
      durationMs: durationMs,
    );
    if (!linked) {
      debugPrint(
          'ChatVoiceService: upload OK but /chat/attach-voice failed - '
          'voice orphaned in Storage');
      return const ChatVoiceCaptureResult.linkFailed();
    }

    // Local file no longer needed.
    try {
      if (await file.exists()) await file.delete();
    } catch (_) { /* non-fatal */ }
    _currentRecordingPath = null;
    _recordingStartedAt = null;

    return ChatVoiceCaptureResult.success(url, durationMs);
  }

  Future<String?> _uploadToFirebaseStorage({
    required File file,
    required String convId,
  }) async {
    try {
      final String fileName =
          'chat_voice_${convId}_${DateTime.now().millisecondsSinceEpoch}.m4a';
      final Reference ref = FirebaseStorage.instance
          .ref()
          .child('chat_voice')
          .child(convId)
          .child(fileName);

      final UploadTask task = ref.putFile(
        file,
        // audio/mp4 is the IANA registered type for M4A. Storage rules
        // allowlist that exact value.
        SettableMetadata(contentType: 'audio/mp4'),
      );

      final TaskSnapshot snapshot =
          await task.timeout(const Duration(seconds: 60));
      final String url = await snapshot.ref.getDownloadURL();
      debugPrint('ChatVoiceService: uploaded -> $url');
      return url;
    } catch (e, st) {
      debugPrint('ChatVoiceService: upload error: $e');
      debugPrint('$st');
      return null;
    }
  }

  /// POST /chat/attach-voice. Returns true on 200.
  Future<bool> _attachOnBackend({
    required String convId,
    required String fromFid,
    required String url,
    required int durationMs,
  }) async {
    try {
      final res = await http
          .post(
            Uri.parse(ApiConfig.chatAttachVoiceEndpoint),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({
              'conv_id': convId,
              'from_fid': fromFid,
              'url': url,
              'duration_ms': durationMs,
            }),
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return true;
      debugPrint(
          'ChatVoiceService: attach-voice failed status=${res.statusCode} body=${res.body}');
      return false;
    } catch (e) {
      debugPrint('ChatVoiceService: attach-voice error: $e');
      return false;
    }
  }

  /// Delete a previously attached voice note. Server-side enforces
  /// "only the original sender can detach" so this is safe to expose
  /// to anyone (the backend will 403 if the caller isn't the owner).
  Future<bool> deleteVoice({
    required String convId,
    required String fromFid,
    required String url,
  }) async {
    try {
      final res = await http
          .post(
            Uri.parse(ApiConfig.chatDetachVoiceEndpoint),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({
              'conv_id': convId,
              'from_fid': fromFid,
              'url': url,
            }),
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return true;
      debugPrint(
          'ChatVoiceService: detach-voice failed status=${res.statusCode} body=${res.body}');
      return false;
    } catch (e) {
      debugPrint('ChatVoiceService: detach-voice error: $e');
      return false;
    }
  }

  // ---- Playback (used by voice bubbles in the chat) ----------------

  /// Play a voice note from its URL. Single active player at a time -
  /// calling this while another voice is playing stops the previous.
  Future<void> playFromUrl(String url) async {
    try {
      await _player.setUrl(url);
      await _player.play();
    } catch (e) {
      debugPrint('ChatVoiceService: play error: $e');
    }
  }

  Future<void> pausePlayback() async {
    try {
      await _player.pause();
    } catch (e) {
      debugPrint('ChatVoiceService: pause error: $e');
    }
  }

  Future<void> resumePlayback() async {
    try {
      await _player.play();
    } catch (e) {
      debugPrint('ChatVoiceService: resume error: $e');
    }
  }

  Future<void> stopPlayback() async {
    try {
      await _player.stop();
    } catch (e) {
      debugPrint('ChatVoiceService: stop playback error: $e');
    }
  }

  /// Currently-loaded URL, or null if nothing is loaded. Used by voice
  /// bubbles to know which one is active when there are multiple in
  /// the conversation.
  String? get currentlyLoadedUrl => _player.audioSource is UriAudioSource
      ? (_player.audioSource as UriAudioSource).uri.toString()
      : null;

  Stream<PlayerState> get playerStateStream => _player.playerStateStream;
  Stream<Duration> get positionStream => _player.positionStream;
  Duration? get duration => _player.duration;

  /// Free the recorder + player. Safe to call multiple times.
  void dispose() {
    try {
      _recorder.dispose();
    } catch (_) { /* already disposed */ }
    try {
      _player.dispose();
    } catch (_) { /* already disposed */ }
  }
}
