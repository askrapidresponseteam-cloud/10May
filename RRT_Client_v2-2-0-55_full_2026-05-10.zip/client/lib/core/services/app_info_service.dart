import 'package:flutter/foundation.dart';
import 'package:package_info_plus/package_info_plus.dart';

/// Single source of truth for the running build's version string.
///
/// Replaces the previous pattern of hardcoding `'1.0.0'` in three call
/// sites that built the SOS userInfo payload, which made server-side
/// telemetry useless for distinguishing between actual app builds.
///
/// Usage:
///
///   1. Call [AppInfoService.initialize] once during app startup
///      (in main(), after WidgetsFlutterBinding.ensureInitialized()).
///   2. Read [AppInfoService.versionString] synchronously from anywhere.
///
/// If [initialize] hasn't completed yet, or if the underlying platform
/// channel call ever throws, [versionString] returns `'unknown'` rather
/// than crashing the caller. Reporting "unknown" loses one forensic
/// signal but never blocks an SOS send - that trade-off matches the
/// rest of this codebase's "fail open on non-critical init" pattern
/// (see main.dart's Firebase block).
class AppInfoService {
  static String _cached = 'unknown';
  static bool _initialized = false;

  /// Async one-time priming. Call from main() before runApp().
  ///
  /// Composes the canonical version string as `version+buildNumber`
  /// (matching pubspec.yaml semantics: e.g. `2.1.10+45`). If the build
  /// number is empty (some debug builds), just `version` is used.
  ///
  /// Idempotent - safe to call more than once but only the first call
  /// does work. Subsequent calls are no-ops.
  static Future<void> initialize() async {
    if (_initialized) return;
    try {
      final info = await PackageInfo.fromPlatform();
      final v = info.version;       // e.g. "2.1.10"
      final b = info.buildNumber;   // e.g. "45"
      if (v.isEmpty) {
        // PackageInfo returned an empty version - leave _cached as
        // 'unknown' but mark initialized so we don't re-attempt every
        // SOS send. _initialized=true means "we tried".
        debugPrint('AppInfoService: PackageInfo returned empty version, keeping "unknown"');
      } else if (b.isEmpty) {
        _cached = v;
      } else {
        _cached = '$v+$b';
      }
    } catch (e) {
      // PackageInfo can fail on platforms where the plugin isn't
      // wired up (rare - it covers iOS/Android/macOS/web/Linux/Windows
      // all out of the box) or in unit tests with no platform channel.
      // We log and proceed; callers see 'unknown'.
      debugPrint('AppInfoService: PackageInfo.fromPlatform failed: $e');
    } finally {
      _initialized = true;
    }
  }

  /// Synchronous accessor. Returns the cached version string after
  /// [initialize] has run, or `'unknown'` before that. Never throws.
  ///
  /// Use this in any build-time payload (SOS userInfo, feedback emails,
  /// analytics events, etc.) instead of a hardcoded literal.
  static String get versionString => _cached;

  /// True iff [initialize] has run AND successfully resolved a non-empty
  /// version. Useful for diagnostics; most callers should just read
  /// [versionString] and tolerate 'unknown'.
  static bool get isResolved => _initialized && _cached != 'unknown';
}
