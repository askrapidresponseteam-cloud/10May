import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_app_installations/firebase_app_installations.dart';

/// Centralized storage manager for alerts with proper synchronization
/// Prevents race conditions between background and foreground isolates
class AlertStorageManager {
  static final AlertStorageManager _instance = AlertStorageManager._internal();
  factory AlertStorageManager() => _instance;
  AlertStorageManager._internal() {
    // Start periodic cleanup of stale locks
    _startStaleLockCleanup();
  }

  static const String _alertsKey = 'active_alerts';
  static const String _lockKey = 'alerts_lock';
  static const int _maxLockWaitMs = 5000; // 5 seconds max wait for lock
  static const int _lockCheckIntervalMs = 50; // Check lock every 50ms
  static const Duration _staleLockAge = Duration(seconds: 10); // Locks older than this are stale
  static const Duration _cleanupInterval = Duration(minutes: 1); // Cleanup every minute
  
  // In-memory mutex for same-isolate synchronization
  final _mutex = _Mutex();
  Timer? _cleanupTimer;
  
  /// Start periodic cleanup of stale locks
  void _startStaleLockCleanup() {
    _cleanupTimer?.cancel();
    _cleanupTimer = Timer.periodic(_cleanupInterval, (timer) async {
      await _cleanupStaleLock();
    });
  }
  
  /// Cleanup stale lock if it exists
  Future<void> _cleanupStaleLock() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.reload();
      
      final lockTimestamp = prefs.getInt(_lockKey);
      if (lockTimestamp != null) {
        final now = DateTime.now().millisecondsSinceEpoch;
        final lockAge = now - lockTimestamp;
        
        if (lockAge > _staleLockAge.inMilliseconds) {
          await prefs.remove(_lockKey);
          debugPrint('🧹 Cleaned up stale lock (age: ${lockAge}ms)');
        }
      }
    } catch (e) {
      debugPrint('Error cleaning up stale lock: $e');
    }
  }
  
  /// Dispose cleanup timer
  void dispose() {
    _cleanupTimer?.cancel();
  }
  
  /// Add alert to storage with proper locking and deduplication
  Future<bool> addAlert(Map<String, dynamic> alert) async {
    return await _mutex.synchronized(() async {
      try {
        // Acquire storage lock
        final acquired = await _acquireStorageLock();
        if (!acquired) {
          debugPrint('Failed to acquire storage lock for addAlert');
          return false;
        }

        try {
          final prefs = await SharedPreferences.getInstance();
          
          // Critical: Reload from disk before reading
          await prefs.reload();
          
          // Read current alerts
          final alertsJson = prefs.getStringList(_alertsKey) ?? [];
          
          // Check for duplicate by sender ID
          final senderId = alert['sender_id'] as String?;
          if (senderId != null) {
            // Check if alert already exists
            for (final existingAlertJson in alertsJson) {
              try {
                final existingAlert = jsonDecode(existingAlertJson) as Map<String, dynamic>;
                if (existingAlert['sender_id'] == senderId) {
                  debugPrint('Alert already exists, skipping: $senderId');
                  return false; // Already exists
                }
              } catch (e) {
                // Skip malformed alerts
              }
            }
            
            // Filter out user's own alerts
            final currentSenderId = await FirebaseInstallations.instance.getId();
            if (senderId == currentSenderId) {
              debugPrint('Skipping own alert: $senderId');
              return false;
            }
          }
          
          // Add timestamp if not present
          if (!alert.containsKey('timestamp')) {
            alert['timestamp'] = DateTime.now().millisecondsSinceEpoch;
          }
          
          // Add new alert to the beginning
          alertsJson.insert(0, jsonEncode(alert));
          
          // Atomic write
          final success = await prefs.setStringList(_alertsKey, alertsJson);
          
          if (success) {
            debugPrint('✅ Alert added successfully: $senderId');
          } else {
            debugPrint('❌ Failed to save alert: $senderId');
          }
          
          return success;
        } finally {
          // Always release lock
          await _releaseStorageLock();
        }
      } catch (e) {
        debugPrint('Error in addAlert: $e');
        return false;
      }
    });
  }
  
  /// Remove alert from storage with proper locking
  Future<bool> removeAlert(String senderId) async {
    return await _mutex.synchronized(() async {
      try {
        final acquired = await _acquireStorageLock();
        if (!acquired) {
          debugPrint('Failed to acquire storage lock for removeAlert');
          return false;
        }

        try {
          final prefs = await SharedPreferences.getInstance();
          await prefs.reload();
          
          final alertsJson = prefs.getStringList(_alertsKey) ?? [];
          final initialCount = alertsJson.length;
          
          // Remove alert with matching sender ID
          alertsJson.removeWhere((alertString) {
            try {
              final alert = jsonDecode(alertString);
              return alert['sender_id'] == senderId;
            } catch (e) {
              return false;
            }
          });
          
          // Only write if something changed
          if (alertsJson.length != initialCount) {
            final success = await prefs.setStringList(_alertsKey, alertsJson);
            if (success) {
              debugPrint('✅ Alert removed successfully: $senderId');
            }
            return success;
          }
          
          return true;
        } finally {
          await _releaseStorageLock();
        }
      } catch (e) {
        debugPrint('Error in removeAlert: $e');
        return false;
      }
    });
  }
  
  /// Update alert in storage with proper locking
  Future<bool> updateAlert(String senderId, Map<String, dynamic> updates) async {
    return await _mutex.synchronized(() async {
      try {
        final acquired = await _acquireStorageLock();
        if (!acquired) {
          debugPrint('Failed to acquire storage lock for updateAlert');
          return false;
        }

        try {
          final prefs = await SharedPreferences.getInstance();
          await prefs.reload();
          
          final alertsJson = prefs.getStringList(_alertsKey) ?? [];
          bool found = false;
          
          // Update matching alert
          for (int i = 0; i < alertsJson.length; i++) {
            try {
              final alert = jsonDecode(alertsJson[i]) as Map<String, dynamic>;
              if (alert['sender_id'] == senderId) {
                // Merge updates
                final updatedAlert = {...alert, ...updates};
                alertsJson[i] = jsonEncode(updatedAlert);
                found = true;
                break;
              }
            } catch (e) {
              // Skip malformed alerts
            }
          }
          
          if (found) {
            final success = await prefs.setStringList(_alertsKey, alertsJson);
            if (success) {
              debugPrint('✅ Alert updated successfully: $senderId');
            }
            return success;
          }
          
          return false;
        } finally {
          await _releaseStorageLock();
        }
      } catch (e) {
        debugPrint('Error in updateAlert: $e');
        return false;
      }
    });
  }
  
  /// Load all alerts from storage with proper locking
  Future<List<Map<String, dynamic>>> loadAlerts({Duration? ttl}) async {
    return await _mutex.synchronized(() async {
      try {
        final acquired = await _acquireStorageLock();
        if (!acquired) {
          debugPrint('Failed to acquire storage lock for loadAlerts');
          return [];
        }

        try {
          final prefs = await SharedPreferences.getInstance();
          
          // Critical: Always reload from disk to get background updates
          await prefs.reload();
          
          final alertsJson = prefs.getStringList(_alertsKey) ?? [];
          final alerts = <Map<String, dynamic>>[];
          
          final currentTime = DateTime.now().millisecondsSinceEpoch;
          final currentSenderId = await FirebaseInstallations.instance.getId();
          
          for (final alertJson in alertsJson) {
            try {
              final alert = jsonDecode(alertJson) as Map<String, dynamic>;
              final alertSenderId = alert['sender_id'] as String?;
              
              // Skip user's own alerts
              if (alertSenderId == currentSenderId) {
                continue;
              }
              
              // Check TTL if provided
              if (ttl != null) {
                final alertTimestamp = _parseTimestampMillis(alert['timestamp']);
                final alertAge = Duration(milliseconds: currentTime - alertTimestamp);
                
                if (alertAge >= ttl) {
                  continue; // Skip expired alerts
                }
              }
              
              alerts.add(alert);
            } catch (e) {
              debugPrint('Skipping malformed alert: $e');
            }
          }
          
          debugPrint('📥 Loaded ${alerts.length} alerts from storage');
          return alerts;
        } finally {
          await _releaseStorageLock();
        }
      } catch (e) {
        debugPrint('Error in loadAlerts: $e');
        return [];
      }
    });
  }
  
  /// Clear all alerts from storage
  Future<bool> clearAllAlerts() async {
    return await _mutex.synchronized(() async {
      try {
        final acquired = await _acquireStorageLock();
        if (!acquired) {
          return false;
        }

        try {
          final prefs = await SharedPreferences.getInstance();
          final success = await prefs.setStringList(_alertsKey, []);
          if (success) {
            debugPrint('✅ All alerts cleared');
          }
          return success;
        } finally {
          await _releaseStorageLock();
        }
      } catch (e) {
        debugPrint('Error in clearAllAlerts: $e');
        return false;
      }
    });
  }
  
  /// Acquire inter-isolate storage lock
  Future<bool> _acquireStorageLock() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final startTime = DateTime.now().millisecondsSinceEpoch;
      
      while (true) {
        await prefs.reload();
        final lockTimestamp = prefs.getInt(_lockKey);
        final now = DateTime.now().millisecondsSinceEpoch;
        
        // Check if lock is available or stale (older than 5 seconds)
        if (lockTimestamp == null || (now - lockTimestamp) > _maxLockWaitMs) {
          // Try to acquire lock
          await prefs.setInt(_lockKey, now);
          // Verify we got the lock
          await prefs.reload();
          final verifyLock = prefs.getInt(_lockKey);
          if (verifyLock == now) {
            return true; // Successfully acquired
          }
        }
        
        // Check if we've waited too long
        if ((now - startTime) > _maxLockWaitMs) {
          debugPrint('Lock acquisition timeout');
          return false;
        }
        
        // Wait before retrying
        await Future.delayed(Duration(milliseconds: _lockCheckIntervalMs));
      }
    } catch (e) {
      debugPrint('Error acquiring lock: $e');
      return false;
    }
  }
  
  /// Release inter-isolate storage lock
  Future<void> _releaseStorageLock() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_lockKey);
    } catch (e) {
      debugPrint('Error releasing lock: $e');
    }
  }
  
  /// Parse timestamp to milliseconds
  int _parseTimestampMillis(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is num) return value.toInt();
    if (value is String) {
      final parsedInt = int.tryParse(value);
      if (parsedInt != null) return parsedInt;
      final parsedDouble = double.tryParse(value);
      if (parsedDouble != null) return parsedDouble.toInt();
    }
    return 0;
  }
}

/// Simple mutex implementation for in-isolate synchronization
class _Mutex {
  final _queue = <Completer<void>>[];
  bool _locked = false;
  
  Future<T> synchronized<T>(Future<T> Function() criticalSection) async {
    final completer = Completer<void>();
    _queue.add(completer);
    
    // Wait for our turn
    if (_locked) {
      await completer.future;
    } else {
      _locked = true;
      completer.complete();
    }
    
    try {
      return await criticalSection();
    } finally {
      _queue.remove(completer);
      if (_queue.isNotEmpty) {
        _locked = true;
        _queue.first.complete();
      } else {
        _locked = false;
      }
    }
  }
}
