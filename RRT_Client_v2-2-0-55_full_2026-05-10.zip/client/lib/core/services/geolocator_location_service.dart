import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:http/http.dart' as http;
import 'location_service.dart';
import 'offline_district_service.dart';
import '../config/api_config.dart';

/// Normalizes GeoJSON district names to match Ola API naming convention.
/// Handles known spelling differences between Census 2011 and Ola.
/// Normalizes any district name to the canonical underscore format
/// used by both GeoJSON and the Ola backend.
/// e.g. "Dakshina Kannada" → "dakshina_kannada"
///      "dakshina-kannada" → "dakshina_kannada"
///      "Koteshwara Proper, Karnataka" → "koteshwara_proper" (then validated)
String _normalizeDistrictName(String raw) {
  // Step 0: drop comma-suffixed state ("Foo, Karnataka" → "Foo")
  var name = raw.split(',').first;
  // Step 1: lowercase + trim
  name = name.trim().toLowerCase();
  // Step 2: replace hyphens AND spaces with underscores (unify formats)
  name = name.replaceAll('-', '_').replaceAll(RegExp(r'\s+'), '_');
  // Step 3: remove any characters that are not alphanumeric or underscore
  name = name.replaceAll(RegExp(r'[^a-z0-9_]'), '');
  // Step 4: drop trailing _district / _dist suffix
  name = name.replaceAll(RegExp(r'_district$|_dist$'), '');

  // Step 5: known canonical corrections (GeoJSON Census 2011 → common name)
  const Map<String, String> corrections = {
    'bangalore': 'bengaluru',
    'bangalore_urban': 'bengaluru_urban',
    'bangalore_rural': 'bengaluru_rural',
    'mysuru': 'mysore',
    'belagavi': 'belgaum',
    'kalaburagi': 'gulbarga',
    'ballari': 'bellary',
    'shivamogga': 'shimoga',
    'tumakuru': 'tumkur',
    'vijayapura': 'bijapur',
    'ahmadabad': 'ahmedabad',
    'anantpur': 'anantapur',
    'kanniyakumari': 'kanyakumari',
    'bid': 'beed',
    'dakshina_kannada': 'dakshina_kannada', // already correct
    'uttara_kannada': 'uttara_kannada',     // already correct
    'chamarajanagara': 'chamarajanagar',
    'kodagu': 'kodagu',
  };

  return corrections[name] ?? name;
}

/// Set of known district names (corrections-map values + a few common
/// aliases). Used to validate Ola responses are real districts and not
/// sub-localities like "Koteshwara Proper".
const Set<String> _knownDistrictAliases = {
  'bengaluru', 'bengaluru_urban', 'bengaluru_rural',
  'mysore', 'belgaum', 'gulbarga', 'bellary', 'shimoga',
  'tumkur', 'bijapur', 'ahmedabad', 'anantapur', 'kanyakumari',
  'beed', 'dakshina_kannada', 'uttara_kannada', 'chamarajanagar',
  'kodagu',
};

/// Returns true if the point is within [thresholdKm] km of any district boundary.
/// Used to decide whether to confirm with Ola API.
bool _isNearBoundary(double latitude, double longitude, {double thresholdKm = 2.0}) {
  final service = OfflineDistrictService.instance;
  if (!service.isInitialized) return false;

  // Check all districts - if point is inside bounding box but NOT in polygon,
  // it means we're near a boundary. We use a simple proximity heuristic:
  // if the closest polygon edge is within thresholdKm, return true.
  // For simplicity, we check if the point is within an expanded bounding box
  // of any district that doesn't contain the point itself.
  const double degreePerKm = 1.0 / 111.0; // ~111km per degree
  final double delta = thresholdKm * degreePerKm;

  // Get the district for this point
  final myDistrict = service.getDistrictFromCoordinates(latitude, longitude);
  if (myDistrict == null) return true; // If not found, near boundary by definition

  // Check if a slightly shifted point gives a different district
  final List<List<double>> testPoints = [
    [latitude + delta, longitude],
    [latitude - delta, longitude],
    [latitude, longitude + delta],
    [latitude, longitude - delta],
  ];

  for (final pt in testPoints) {
    final neighbor = service.getDistrictFromCoordinates(pt[0], pt[1]);
    if (neighbor != null && neighbor != myDistrict) {
      return true; // Near a boundary
    }
  }

  return false;
}

/// Geolocator-based implementation of LocationService
class GeolocatorLocationService implements LocationService {
  
  @override
  Future<LocationData?> getCurrentLocation({bool forceFresh = false}) async {
    try {
      // Check permissions first - DO NOT automatically request
      if (!await hasLocationPermission()) {
        debugPrint('Location permission not granted');
        return null;
      }

      if (!await isLocationServiceEnabled()) {
        debugPrint('Location services not enabled');
        return null;
      }

      // If not forcing fresh, try to get last known position first (faster, no GPS wait)
      if (!forceFresh) {
        try {
          final lastPosition = await Geolocator.getLastKnownPosition();
          if (lastPosition != null) {
            // Check if last known position is recent (within 5 minutes)
            final age = DateTime.now().difference(lastPosition.timestamp);
            if (age.inMinutes < 5) {
              debugPrint('Using recent cached location (${age.inSeconds}s old)');
              return LocationData(
                latitude: lastPosition.latitude,
                longitude: lastPosition.longitude,
                timestamp: lastPosition.timestamp,
              );
            } else {
              debugPrint('Cached location too old (${age.inMinutes}m), fetching fresh...');
            }
          }
        } catch (e) {
          debugPrint('No last known location available: $e');
        }
      } else {
        debugPrint('Forcing fresh GPS location fetch...');
      }

      // Fetch fresh GPS position
      try {
        final position = await Geolocator.getCurrentPosition(
          locationSettings: LocationSettings(
            accuracy: forceFresh ? LocationAccuracy.high : LocationAccuracy.medium,
            timeLimit: Duration(seconds: forceFresh ? 20 : 15),
          ),
        );
        debugPrint('Fresh GPS location obtained');
        return LocationData(
          latitude: position.latitude,
          longitude: position.longitude,
          timestamp: position.timestamp,
        );
      } catch (gpsError) {
        debugPrint('GPS fetch failed: $gpsError - trying last known position...');
        // Fallback: use last known position even if stale rather than returning null
        try {
          final last = await Geolocator.getLastKnownPosition();
          if (last != null) {
            debugPrint('Using stale last-known position as fallback');
            return LocationData(
              latitude: last.latitude,
              longitude: last.longitude,
              timestamp: last.timestamp,
            );
          }
        } catch (_) {}
        debugPrint('No location available at all');
        return null;
      }
    } catch (e) {
      debugPrint('Failed to get current location: $e');
      return null;
    }
  }

  @override
  Future<String?> getDistrictFromCoordinates(double latitude, double longitude) async {
    // ─── PRIMARY: Offline GeoJSON lookup ─────────────────────────────
    // Census 2011 polygons cover every district in India with authoritative
    // boundaries. When GeoJSON returns a name, it IS the district - full stop.
    // Free, instant, no network, no API quota, no surprises.
    final offlineService = OfflineDistrictService.instance;
    String? geoJsonDistrict;
    if (offlineService.isInitialized) {
      final raw = offlineService.getDistrictFromCoordinates(latitude, longitude);
      if (raw != null) {
        geoJsonDistrict = _normalizeDistrictName(raw);
      }
    }

    // ─── BORDER VALIDATION ───────────────────────────────────────────
    // If GeoJSON returned a result AND the point is < 2km from a district
    // boundary, ask Ola to confirm. We only TRUST Ola's answer if it
    // matches another valid GeoJSON neighbour district - this protects
    // against Ola returning a town/sub-locality (e.g., "Koteshwara Proper")
    // when level_2 data is missing in their response.
    if (geoJsonDistrict != null) {
      final nearBoundary = _isNearBoundary(latitude, longitude);
      if (nearBoundary) {
        final olaResult = await _getDistrictFromOla(latitude, longitude);
        if (olaResult != null && _isKnownDistrict(olaResult)) {
          // Ola named a real district that exists in our GeoJSON catalogue
          // - accept it as the boundary correction.
          debugPrint('Boundary correction: GeoJSON=$geoJsonDistrict → Ola=$olaResult');
          return olaResult;
        }
        // Ola unavailable, returned a sub-locality, or returned a
        // non-district name we don't recognise - keep the GeoJSON answer.
        debugPrint('Keeping GeoJSON district: $geoJsonDistrict (Ola gave: $olaResult)');
      }
      return geoJsonDistrict;
    }

    // ─── FALLBACK: Ola only when GeoJSON has no answer ────────────────
    // GeoJSON returned null - typically a post-2011 district (Shahdara,
    // Gurugram, Telangana, etc.) whose polygon isn't in our 2011-era
    // catalogue, or an edge/water-body coordinate. In this case we trust
    // whatever Ola returns as long as it looks like a plausible district
    // name (basic sanity: not empty, not a postcode, not a single token).
    //
    // Why we DON'T require _isKnownDistrict here (we used to):
    //   The strict catalogue check was rejecting valid Ola answers for
    //   any district created after 2011, which silently blocked SOS
    //   sends in those areas. The whole point of having Ola as fallback
    //   is to cover what GeoJSON misses - validating Ola's answer
    //   against the same incomplete catalogue defeats the purpose.
    //
    // Sender/receiver consistency: both clients run identical code
    // against identical coordinates and Ola is deterministic for the
    // same lat/lng, so both will arrive at the same district key.
    // The _normalizeDistrictName corrections map (above) is what
    // actually enforces canonical naming across Ola/GeoJSON variants.
    final olaResult = await _getDistrictFromOla(latitude, longitude);
    if (olaResult != null && _looksLikeDistrictName(olaResult)) {
      debugPrint('Using Ola fallback district: $olaResult');
      return olaResult;
    }
    debugPrint('No valid district found at $latitude,$longitude');
    return null;
  }

  /// Loose sanity check used only on the Ola fallback path. Rejects
  /// obviously-not-a-district strings (empty, too short, numeric like
  /// a postcode or house number) but accepts anything else - because
  /// at this point GeoJSON has already failed and Ola's answer, even
  /// if it's a sub-locality, is better than blocking the SOS entirely.
  ///
  /// Deliberately permissive. The strict catalogue match
  /// (_isKnownDistrict) is still used for boundary-correction above,
  /// where being wrong overwrites a correct GeoJSON answer.
  bool _looksLikeDistrictName(String name) {
    final trimmed = name.trim();
    if (trimmed.length < 3) return false;
    // Pure-numeric or starting with a digit (postcode, house number).
    if (RegExp(r'^\d').hasMatch(trimmed)) return false;
    // Long digit runs anywhere - postcodes embedded in addresses.
    if (RegExp(r'\d{3,}').hasMatch(trimmed)) return false;
    return true;
  }

  /// True if [name] is a recognised district present in our GeoJSON catalogue
  /// or in the canonical-corrections map. Guards against Ola returning a
  /// town, sub-district, or tehsil instead of a real administrative district.
  bool _isKnownDistrict(String name) {
    final offlineService = OfflineDistrictService.instance;
    if (offlineService.isInitialized && offlineService.hasDistrict(name)) {
      return true;
    }
    // Some districts have alias names (mysuru ↔ mysore). The corrections
    // map's right-hand-side values are also valid.
    return _knownDistrictAliases.contains(name);
  }

  Future<String?> _getDistrictFromOla(double latitude, double longitude) async {
    try {
      final uri = Uri.parse('${ApiConfig.baseUrl}/geocode/district')
          .replace(queryParameters: {
        'lat': latitude.toString(),
        'lng': longitude.toString(),
      });
      final response = await http.get(uri).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final raw = data['district'] as String?;
        if (raw == null) return null;
        return _normalizeDistrictName(raw);
      }
      debugPrint('Ola district lookup failed: ${response.statusCode}');
      return null;
    } catch (e) {
      debugPrint('Ola district lookup error: $e');
      return null;
    }
  }

  @override
  Future<String?> getCurrentDistrict() async {
    try {
      final location = await getCurrentLocation();
      if (location == null) {
        return null;
      }
      
      return await getDistrictFromCoordinates(location.latitude, location.longitude);
    } catch (e) {
      debugPrint('Failed to get current district: $e');
      return null;
    }
  }

  @override
  Future<String?> getStateFromCoordinates(double latitude, double longitude) async {
    try {
      final placemarks = await placemarkFromCoordinates(latitude, longitude);
      if (placemarks.isNotEmpty) {
        final area = placemarks.first.administrativeArea;
        return (area != null && area.isNotEmpty) ? area : null;
      }
      return null;
    } catch (e) {
      debugPrint('Failed to get state from coordinates: $e');
      return null;
    }
  }

  @override
  Future<String?> getCurrentState() async {
    try {
      final location = await getCurrentLocation();
      if (location == null) {
        return null;
      }

      return await getStateFromCoordinates(location.latitude, location.longitude);
    } catch (e) {
      debugPrint('Failed to get current state: $e');
      return null;
    }
  }

  @override
  Future<String?> getCurrentAddress() async {
    try {
      final location = await getCurrentLocation();
      if (location == null) {
        return null;
      }
      
      return await getAddressFromCoordinates(location.latitude, location.longitude);
    } catch (e) {
      debugPrint('Failed to get current address: $e');
      return null;
    }
  }

  @override
  Future<String?> getAddressFromCoordinates(double latitude, double longitude) async {
    try {
      final placemarks = await placemarkFromCoordinates(latitude, longitude);
      
      if (placemarks.isNotEmpty) {
        final place = placemarks.first;
        
        // Build a readable address
        final addressComponents = <String>[];
        
        // if (place.name != null && place.name!.isNotEmpty) {
        //   addressComponents.add(place.name!);
        // }
        // if (place.subLocality != null && place.subLocality!.isNotEmpty) {
        //   addressComponents.add(place.subLocality!);
        // }
        if (place.locality != null && place.locality!.isNotEmpty) {
          addressComponents.add(place.locality!);
        }
        if (place.administrativeArea != null && place.administrativeArea!.isNotEmpty) {
          addressComponents.add(place.administrativeArea!);
        }
        
        final address = addressComponents.join(', ');
        return address.isNotEmpty ? address : 'Unknown location';
      }
      
      return 'Unknown location';
    } catch (e) {
      debugPrint('Failed to resolve address: $e');
      return 'Address unavailable';
    }
  }

  @override
  Future<bool> hasLocationPermission() async {
    final permission = await Geolocator.checkPermission();
    return permission == LocationPermission.whileInUse || 
           permission == LocationPermission.always;
  }

  @override
  Future<bool> requestLocationPermission() async {
    final permission = await Geolocator.requestPermission();
    return permission == LocationPermission.whileInUse || 
           permission == LocationPermission.always;
  }

  @override
  Future<bool> isLocationServiceEnabled() async {
    return await Geolocator.isLocationServiceEnabled();
  }
}