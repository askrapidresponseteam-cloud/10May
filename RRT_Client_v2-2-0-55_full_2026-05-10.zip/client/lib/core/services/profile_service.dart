import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_app_installations/firebase_app_installations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../config/api_config.dart';

/// Service for managing user profile data in local storage
class ProfileService {
  static const String _nameKey = 'user_name';
  static const String _mobileKey = 'user_mobile';
  static const String _termsAcceptedKey = 'terms_accepted';
  static const String _userIdKey = 'user_id';
  
  static const Uuid _uuid = Uuid();

  /// Save user profile data
  static Future<void> saveProfile({
    required String name,
    required String mobile,
  }) async {
    // Normalize at the service boundary so every caller (and every
    // downstream consumer - backend dedup, FCM topic registration,
    // SOS payload) sees a single canonical representation.
    final cleanName = name.trim();
    final cleanMobile = normalizeIndianMobile(mobile);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_nameKey, cleanName);
    await prefs.setString(_mobileKey, cleanMobile);

    // Generate and save user ID if it doesn't exist
    if (!prefs.containsKey(_userIdKey)) {
      final userId = _uuid.v4();
      await prefs.setString(_userIdKey, userId);
    }
  }
  
  /// Get or generate a unique user ID
  /// This ID persists across profile changes (name, mobile changes)
  static Future<String> getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString(_userIdKey);
    
    // If no user ID exists, generate one
    if (userId == null) {
      userId = _uuid.v4();
      await prefs.setString(_userIdKey, userId);
    }
    
    return userId;
  }

  /// Get user name
  static Future<String?> getUserName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_nameKey);
  }

  /// Get user mobile number
  static Future<String?> getUserMobile() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_mobileKey);
  }

  /// Normalize an Indian mobile number to a bare 10-digit string.
  ///
  /// Strips all non-digit characters and removes a leading country code
  /// (`91` or `091`) if one is present. Returns the cleaned string even
  /// if it isn't a valid Indian mobile - validity is the caller's
  /// concern via [isValidIndianMobile]. We keep this lenient so we
  /// don't silently drop edge cases (e.g. someone typing extra digits
  /// by accident); validation surfaces those instead.
  static String normalizeIndianMobile(String mobile) {
    // Strip everything that isn't a digit.
    var digits = mobile.replaceAll(RegExp(r'[^\d]'), '');
    // Trim a leading "0" or "91" / "091" country prefix if present and
    // the remaining string still looks like a 10-digit Indian mobile.
    if (digits.length == 13 && digits.startsWith('091')) {
      digits = digits.substring(3);
    } else if (digits.length == 12 && digits.startsWith('91')) {
      digits = digits.substring(2);
    } else if (digits.length == 11 && digits.startsWith('0')) {
      digits = digits.substring(1);
    }
    return digits;
  }

  /// Validate Indian mobile number.
  ///
  /// Uses [normalizeIndianMobile] so the form, storage, and any backend
  /// payloads all agree on what "the same number" means. A user who
  /// pastes "+91 94973-44991" should be considered the same person as
  /// one who types "9497344991".
  static bool isValidIndianMobile(String mobile) {
    final cleanMobile = normalizeIndianMobile(mobile);
    final mobileRegex = RegExp(r'^[6-9]\d{9}$');
    return mobileRegex.hasMatch(cleanMobile);
  }

  /// Set terms and conditions acceptance status
  static Future<void> setTermsAccepted(bool accepted) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_termsAcceptedKey, accepted);
  }

  /// Delete user documents from sos_alerts and subscribed_users Firestore collections.
  /// Fire-and-forget - non-fatal if it fails (local data is cleared regardless).
  static Future<void> deleteUserFirestoreData() async {
    try {
      final fid = await FirebaseInstallations.instance.getId();
      final response = await http.post(
        Uri.parse(ApiConfig.deleteUserDataEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'fid': fid}),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        debugPrint('✅ Firestore user data deleted for FID: $fid');
      } else {
        debugPrint('⚠️ Firestore user data deletion failed: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint('⚠️ Firestore user data deletion error: $e');
    }
  }

  /// Delete all user data from local storage
  /// This includes profile data, user ID, terms acceptance, alerts, and all other app data
  /// Required for GDPR/DPDPA compliance (right to deletion)
  static Future<void> deleteAllData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }

  /// Check if profile exists (used to determine if user needs onboarding)
  static Future<bool> hasProfile() async {
    final name = await getUserName();
    final mobile = await getUserMobile();
    return name != null && name.isNotEmpty && mobile != null && mobile.isNotEmpty;
  }
}