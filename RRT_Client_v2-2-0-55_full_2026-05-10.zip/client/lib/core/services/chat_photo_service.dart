import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import '../config/api_config.dart';

/// Maximum number of photos a single user can attach to one chat
/// conversation, matching the backend cap (CHAT_MAX_PHOTOS_PER_CONV
/// in index.js). The cap covers all photos in the conversation, not
/// just yours; per-active-SOS-session reset happens on the backend
/// when an SOS ends.
const int kMaxChatPhotos = 3;

/// Soft target for compressed photo size. Same value used by
/// SosPhotoService - keeps chat photos comparable in size to SOS
/// photos so storage cost and upload time are predictable.
const int kMaxChatPhotoBytes = 2 * 1024 * 1024; // 2 MB

/// Hard ceiling. If compression can't get below this, we still upload
/// (best-effort) but log loudly. Same rationale as SosPhotoService -
/// a user who actually managed to capture an 8 MB image deserves to
/// see their message go through, even slowly.
const int kChatPhotoHardCapBytes = 8 * 1024 * 1024;

/// Compression quality steps. Quality only - no minWidth/minHeight,
/// since that parameter forces dimensions and stretches photos with
/// non-default aspect ratios.
const List<int> _qualityLadder = [85, 75, 65, 55, 45, 35];

/// Outcome of a single capture+upload attempt. Mirrors
/// SosPhotoService.PhotoCaptureResult shape so the chat screen can
/// surface the right snackbar for each path.
enum ChatPhotoCaptureStatus {
  success,
  cancelled,
  atLimit,
  permissionDenied,
  uploadFailed,
  /// Bytes uploaded to Firebase Storage successfully but the follow-up
  /// /chat/attach-photo call failed. The photo is in Storage but not
  /// referenced from the conversation. Caller should tell the user to
  /// retry. Storage object is left intact - the daily safety-net sweep
  /// (purgeChatMediaAtMidnightIST) cleans up orphans whose parent
  /// conversation is gone.
  linkFailed,
}

class ChatPhotoCaptureResult {
  const ChatPhotoCaptureResult.success(this.url)
      : status = ChatPhotoCaptureStatus.success;
  const ChatPhotoCaptureResult.cancelled()
      : status = ChatPhotoCaptureStatus.cancelled,
        url = null;
  const ChatPhotoCaptureResult.atLimit()
      : status = ChatPhotoCaptureStatus.atLimit,
        url = null;
  const ChatPhotoCaptureResult.permissionDenied()
      : status = ChatPhotoCaptureStatus.permissionDenied,
        url = null;
  const ChatPhotoCaptureResult.uploadFailed()
      : status = ChatPhotoCaptureStatus.uploadFailed,
        url = null;
  const ChatPhotoCaptureResult.linkFailed()
      : status = ChatPhotoCaptureStatus.linkFailed,
        url = null;

  final ChatPhotoCaptureStatus status;
  final String? url;

  bool get isSuccess => status == ChatPhotoCaptureStatus.success;
}

/// Capture photos from the camera (rear-default, no gallery option) and
/// attach them to chat messages. Mirrors SosPhotoService closely, just
/// keyed on conv_id and using the /chat/attach-photo endpoint.
///
/// Why no gallery option: this is an emergency app. The whole reason
/// chat-media exists is "show what's happening NOW". Allowing the user
/// to attach an old photo from their gallery defeats that purpose and
/// also opens privacy edge cases (accidentally picking a personal
/// photo while panicking). Capture-only is the right constraint.
class ChatPhotoService {
  final ImagePicker _picker = ImagePicker();

  /// Capture a photo from the camera and attach it to a chat message.
  /// Returns [ChatPhotoCaptureResult] describing the outcome.
  ///
  /// [currentPhotoCount] is the number of photo messages already in
  /// the conversation - the caller computes this from the messages
  /// list (counting items where kind=='photo'). The check is best-effort
  /// here; the backend re-validates atomically inside its transaction
  /// so a stale count from the client can't slip past the cap.
  Future<ChatPhotoCaptureResult> captureAndUpload({
    required String convId,
    required String fromFid,
    required int currentPhotoCount,
  }) async {
    if (currentPhotoCount >= kMaxChatPhotos) {
      return const ChatPhotoCaptureResult.atLimit();
    }

    final XFile? picked;
    try {
      picked = await _picker.pickImage(
        source: ImageSource.camera,
        // Same notes as SosPhotoService: no imageQuality here, since
        // the OS pre-compression strips EXIF orientation on some
        // Android devices. We handle resize/quality via
        // flutter_image_compress with keepExif:true below.
        preferredCameraDevice: CameraDevice.rear,
      );
    } catch (e) {
      // pickImage throws on permission denied with platform-specific
      // exception types. We collapse them all into a single
      // permission-denied outcome so the caller can surface the right
      // snackbar.
      debugPrint('ChatPhotoService: pickImage threw: $e');
      final msg = e.toString().toLowerCase();
      if (msg.contains('permission') || msg.contains('denied')) {
        return const ChatPhotoCaptureResult.permissionDenied();
      }
      return const ChatPhotoCaptureResult.uploadFailed();
    }
    if (picked == null) return const ChatPhotoCaptureResult.cancelled();

    final File original = File(picked.path);
    int originalSize = 0;
    try {
      originalSize = await original.length();
    } catch (e) {
      debugPrint('ChatPhotoService: cannot stat picked file: $e');
    }
    debugPrint(
        'ChatPhotoService: captured ${(originalSize / 1024).toStringAsFixed(1)} KB');

    // Branch on size: if already small enough, skip the re-encode (so
    // EXIF stays intact); otherwise compress; if compression fails,
    // upload original (graceful degradation, never block the user).
    File fileToUpload = original;
    if (originalSize > kMaxChatPhotoBytes) {
      final File? compressed =
          await _safelyCompress(original, convId, currentPhotoCount);
      if (compressed != null) {
        try {
          final int newSize = await compressed.length();
          debugPrint(
              'ChatPhotoService: compressed to ${(newSize / 1024).toStringAsFixed(1)} KB');
          fileToUpload = compressed;
        } catch (_) {
          fileToUpload = compressed;
        }
      } else {
        debugPrint(
            'ChatPhotoService: compression failed; uploading original (${(originalSize / 1024 / 1024).toStringAsFixed(1)} MB)');
      }
    }

    final String? url = await _uploadToFirebaseStorage(
      file: fileToUpload,
      convId: convId,
      index: currentPhotoCount,
    );
    if (url == null) {
      return const ChatPhotoCaptureResult.uploadFailed();
    }

    final bool linked = await _attachOnBackend(convId, fromFid, url);
    if (!linked) {
      debugPrint(
          'ChatPhotoService: upload OK but /chat/attach-photo failed - '
          'photo orphaned in Storage');
      return const ChatPhotoCaptureResult.linkFailed();
    }
    return ChatPhotoCaptureResult.success(url);
  }

  /// Compression wrapped in a top-level try/catch so a single bad codec
  /// call cannot kill the chat flow.
  Future<File?> _safelyCompress(File file, String convId, int index) async {
    try {
      return await _compress(file, convId, index);
    } catch (e, st) {
      debugPrint('ChatPhotoService: compress threw: $e');
      debugPrint('$st');
      return null;
    }
  }

  Future<File?> _compress(File file, String convId, int index) async {
    final Directory tmp = await getTemporaryDirectory();
    final ts = DateTime.now().millisecondsSinceEpoch;
    final String outPath =
        path.join(tmp.path, 'chat_${convId}_${index}_${ts}_c.jpg');

    File? lastSuccess;
    for (final int q in _qualityLadder) {
      try {
        final XFile? r = await FlutterImageCompress.compressAndGetFile(
          file.path,
          outPath,
          quality: q,
          format: CompressFormat.jpeg,
          // keepExif preserves orientation, GPS, capture time. Critical
          // for not having photos render rotated 90 degrees on the
          // recipient's phone.
          keepExif: true,
        );
        if (r == null) continue;
        final File c = File(r.path);
        final int sz = await c.length();
        lastSuccess = c;
        if (sz <= kMaxChatPhotoBytes) {
          debugPrint(
              'ChatPhotoService: compress q=$q -> ${(sz / 1024).toStringAsFixed(1)} KB OK');
          return c;
        }
        debugPrint(
            'ChatPhotoService: compress q=$q -> ${(sz / 1024).toStringAsFixed(1)} KB still over cap');
      } catch (e) {
        debugPrint('ChatPhotoService: compress q=$q error: $e');
      }
    }

    // Hit the floor without going under target - return whatever we
    // got if it's smaller than the original, else null.
    if (lastSuccess != null) {
      try {
        final origSize = await file.length();
        final compSize = await lastSuccess.length();
        if (compSize < origSize) {
          debugPrint(
              'ChatPhotoService: compress hit floor at ${(compSize / 1024).toStringAsFixed(1)} KB; using anyway');
          return lastSuccess;
        }
      } catch (_) { /* fall through */ }
    }
    return null;
  }

  Future<String?> _uploadToFirebaseStorage({
    required File file,
    required String convId,
    required int index,
  }) async {
    try {
      try {
        final size = await file.length();
        if (size > kChatPhotoHardCapBytes) {
          debugPrint(
              'ChatPhotoService: WARNING uploading ${(size / 1024 / 1024).toStringAsFixed(1)} MB photo (above ${kChatPhotoHardCapBytes ~/ (1024 * 1024)} MB hard cap)');
        }
      } catch (_) { /* stat failure - proceed anyway */ }

      final String fileName =
          'chat_${convId}_${index}_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final Reference ref = FirebaseStorage.instance
          .ref()
          .child('chat_photos')
          .child(convId)
          .child(fileName);

      final UploadTask task = ref.putFile(
        file,
        SettableMetadata(contentType: 'image/jpeg'),
      );

      final TaskSnapshot snapshot =
          await task.timeout(const Duration(seconds: 90));
      final String url = await snapshot.ref.getDownloadURL();
      debugPrint('ChatPhotoService: uploaded -> $url');
      return url;
    } catch (e, st) {
      debugPrint('ChatPhotoService: upload error: $e');
      debugPrint('$st');
      return null;
    }
  }

  /// POST /chat/attach-photo. Returns true on 200, false on anything else.
  /// The backend returns 200 for both first-time attaches and idempotent
  /// re-attaches, both of which are success from the client's perspective.
  ///
  /// Backend semantics (mirrors what SosPhotoService documents):
  ///   200: attached, or already present (idempotent)
  ///   400: malformed body or URL prefix mismatch
  ///   403: caller not a participant of the conversation
  ///   404: conversation doesn't exist
  ///   409: photo limit reached or 200-message cap hit
  ///   429: rate limited
  Future<bool> _attachOnBackend(String convId, String fromFid, String url) async {
    try {
      final res = await http
          .post(
            Uri.parse(ApiConfig.chatAttachPhotoEndpoint),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({
              'conv_id': convId,
              'from_fid': fromFid,
              'url': url,
            }),
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return true;
      debugPrint(
          'ChatPhotoService: attach-photo failed status=${res.statusCode} body=${res.body}');
      return false;
    } catch (e) {
      debugPrint('ChatPhotoService: attach-photo error: $e');
      return false;
    }
  }

  /// Delete a single photo by URL. Goes through /chat/detach-photo so
  /// the backend can update the conversation messages array AND delete
  /// the underlying Storage object atomically.
  Future<bool> deletePhoto({
    required String convId,
    required String fromFid,
    required String url,
  }) async {
    try {
      final res = await http
          .post(
            Uri.parse(ApiConfig.chatDetachPhotoEndpoint),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({
              'conv_id': convId,
              'from_fid': fromFid,
              'url': url,
            }),
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return true;
      debugPrint(
          'ChatPhotoService: detach-photo failed status=${res.statusCode} body=${res.body}');
      return false;
    } catch (e) {
      debugPrint('ChatPhotoService: detach-photo error: $e');
      return false;
    }
  }
}
