import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_app_installations/firebase_app_installations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';
import 'location_service.dart';
import 'profile_service.dart';

/// Service to handle district-based FCM subscriptions for emergency alerts
class DistrictSubscriptionService {
  static const String _lastDistrictKey = 'last_subscribed_district';
  static const String _lastSubscriptionTimeKey = 'last_subscription_time';
  
  /// Get district information from backend based on coordinates.
  ///
  /// History: this used to POST `/api/get-district` which DOES NOT EXIST
  /// on the backend - every call returned 404 and the user silently got
  /// "Could not determine your district". The real endpoint is
  /// `GET /geocode/district?lat=&lng=` which is also what
  /// `geolocator_location_service._getDistrictFromOla` uses correctly.
  /// This method is kept for API compatibility but in practice is dead
  /// code on the happy path - the geolocator service is the primary
  /// district-resolution path.
  Future<String?> getDistrictFromLocation(double latitude, double longitude) async {
    try {
      final uri = Uri.parse(ApiConfig.geocodeDistrictEndpoint)
          .replace(queryParameters: {
        'lat': latitude.toString(),
        'lng': longitude.toString(),
      });
      final response =
          await http.get(uri).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        // Response shape from /geocode/district is just { district: ... }
        // - no { success } wrapper. The old code's "success" check was
        // for the non-existent /api/get-district which would never reply.
        return data['district'] as String?;
      }
      debugPrint('District lookup failed: ${response.statusCode}');
      return null;
    } catch (e) {
      debugPrint('District lookup failed: $e');
      return null;
    }
  }
  
  /// Subscribe to FCM topic for a specific district
  Future<bool> subscribeToDistrict(String district) async {
    try {
      final topic = 'district-$district';
      await FirebaseMessaging.instance.subscribeToTopic(topic);

      // Save subscription info
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_lastDistrictKey, district);
      await prefs.setInt(_lastSubscriptionTimeKey, DateTime.now().millisecondsSinceEpoch);
      
      return true;
    } catch (e) {
      debugPrint('District subscribe failed for $district: $e');
      return false;
    }
  }
  
  /// Unsubscribe from FCM topic for a specific district
  Future<bool> unsubscribeFromDistrict(String district) async {
    try {
      final topic = 'district-$district';
      await FirebaseMessaging.instance.unsubscribeFromTopic(topic);
      return true;
    } catch (e) {
      debugPrint('District unsubscribe failed for $district: $e');
      return false;
    }
  }

  /// Register/update the device in the subscribed_users Firestore collection.
  /// Called after a successful FCM topic subscription so the backend knows
  /// which district each user is watching and can show them in the admin panel.
  /// [state] is optional - pass null if unavailable.
  Future<void> registerSubscribedUser(String district, {String? state}) async {
    try {
      final fid = await FirebaseInstallations.instance.getId();
      final fcmToken = await FirebaseMessaging.instance.getToken();
      final name = await ProfileService.getUserName();
      final number = await ProfileService.getUserMobile();

      final body = <String, dynamic>{
        'fid': fid,
        'district': district,
      };
      if (name != null && name.isNotEmpty) body['name'] = name;
      if (number != null && number.isNotEmpty) body['number'] = number;
      if (state != null && state.isNotEmpty) body['state'] = state;
      if (fcmToken != null && fcmToken.isNotEmpty) body['fcm_token'] = fcmToken;

      final response = await http.post(
        Uri.parse(ApiConfig.subscribeUserEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        debugPrint('subscribed_users registration success for district: $district');
      } else {
        debugPrint('subscribed_users registration failed: ${response.statusCode}');
      }
    } catch (e) {
      // Non-fatal - FCM subscription already succeeded; log and continue.
      debugPrint('subscribed_users registration error: $e');
    }
  }

  /// Get the last subscribed district from preferences
  Future<String?> getLastSubscribedDistrict() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final lastDistrict = prefs.getString(_lastDistrictKey);
      return lastDistrict;
    } catch (e) {
      debugPrint('Failed to read last district: $e');
      return null;
    }
  }
  
  /// Check if subscription is recent (within last hour)
  Future<bool> isSubscriptionRecent() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final lastTime = prefs.getInt(_lastSubscriptionTimeKey);
      if (lastTime == null) return false;
      
      final now = DateTime.now().millisecondsSinceEpoch;
      const oneHourInMs = 60 * 60 * 1000;
      
      return (now - lastTime) < oneHourInMs;
    } catch (e) {
      debugPrint('Failed to check subscription time: $e');
      return false;
    }
  }
  
  /// Main function to update district subscription based on current location
  /// Returns the district name on success, null on failure
  Future<String?> updateDistrictSubscription(LocationService locationService) async {
    try {
      // Check if we have a recent subscription to avoid frequent updates
      if (await isSubscriptionRecent()) {
        // Return cached district if subscription is recent
        return await getLastSubscribedDistrict();
      }
      
      // Get current location
      final locationData = await locationService.getCurrentLocation();
      if (locationData == null) {
        return null;
      }
      
      // Get district from native geocoding
      final newDistrict = await locationService.getDistrictFromCoordinates(
        locationData.latitude, 
        locationData.longitude
      );
      
      if (newDistrict == null) {
        return null;
      }

      // Get state for subscribed_users registration (device-side geocoding, no API cost)
      final state = await locationService.getStateFromCoordinates(
        locationData.latitude,
        locationData.longitude,
      );
      
      // Check if we need to change subscription
      final lastDistrict = await getLastSubscribedDistrict();
      
      if (lastDistrict == newDistrict) {
        // Update timestamp to mark as recent, and refresh last_online in backend
        final prefs = await SharedPreferences.getInstance();
        await prefs.setInt(_lastSubscriptionTimeKey, DateTime.now().millisecondsSinceEpoch);
        unawaited(registerSubscribedUser(newDistrict, state: state));
        return newDistrict;
      }
      
      // Unsubscribe from old district if exists
      if (lastDistrict != null) {
        await unsubscribeFromDistrict(lastDistrict);
      }
      
      // Subscribe to new district and register with backend
      final subscribed = await subscribeToDistrict(newDistrict);
      if (subscribed) {
        unawaited(registerSubscribedUser(newDistrict, state: state));
      }

      return subscribed ? newDistrict : null;
      
    } catch (e) {
      debugPrint('District subscription update failed: $e');
      return null;
    }
  }
  
  /// Initialize district subscription on app start with retry logic
  /// Returns the district name on success, null on failure
  Future<String?> initializeDistrictSubscription(LocationService locationService) async {
    // Wait a bit to ensure location services are ready
    await Future.delayed(const Duration(seconds: 2));
    
    // Try to get location with exponential backoff (max 2 retries)
    String? district;
    int retryCount = 0;
    const maxRetries = 2;
    
    while (district == null && retryCount < maxRetries) {
      district = await updateDistrictSubscription(locationService);
      
      if (district == null && retryCount < maxRetries - 1) {
        // Wait before retry (exponential backoff: 5s, 10s)
        final waitTime = Duration(seconds: 5 * (retryCount + 1));
        debugPrint('Location fetch failed, retrying in ${waitTime.inSeconds}s...');
        await Future.delayed(waitTime);
        retryCount++;
      } else {
        break;
      }
    }
    
    if (district == null) {
      debugPrint('Failed to initialize district subscription after $maxRetries attempts');
    }
    
    return district;
  }
}
