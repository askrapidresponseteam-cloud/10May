import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import '../config/api_config.dart';

const int kMaxSosPhotos = 3;
const int kMaxPhotoBytes = 2 * 1024 * 1024; // 2 MB target

/// Outcome of a single capture+upload attempt. The previous String?
/// return type collapsed cancel, upload-fail, and link-fail into a
/// single `null`, which is what masked the Firestore-append failure
/// from the user. Now the screen can show the right message for
/// each path.
enum PhotoCaptureStatus {
  success,
  cancelled,
  atLimit,
  uploadFailed,
  /// Bytes uploaded to Firebase Storage successfully, but the
  /// follow-up write to sos_alerts/{senderId}.photo_urls failed.
  /// The photo is in Storage but not visible to responders. Caller
  /// should tell the user to retry. (We deliberately do NOT delete
  /// the orphan in Storage here - retention purge handles cleanup
  /// when the alert ends.)
  linkFailed,
}

class PhotoCaptureResult {
  const PhotoCaptureResult.success(this.url)
      : status = PhotoCaptureStatus.success;
  const PhotoCaptureResult.cancelled()
      : status = PhotoCaptureStatus.cancelled,
        url = null;
  const PhotoCaptureResult.atLimit()
      : status = PhotoCaptureStatus.atLimit,
        url = null;
  const PhotoCaptureResult.uploadFailed()
      : status = PhotoCaptureStatus.uploadFailed,
        url = null;
  const PhotoCaptureResult.linkFailed()
      : status = PhotoCaptureStatus.linkFailed,
        url = null;

  final PhotoCaptureStatus status;
  final String? url;

  bool get isSuccess => status == PhotoCaptureStatus.success;
}

/// Soft-cap for the upload pipeline. If compression fails to land below
/// [kMaxPhotoBytes] we still allow upload up to this hard ceiling so the
/// SOS sender never gets blocked by a stubborn JPEG. Above this we still
/// upload the original anyway (best-effort), but log loudly.
const int kPhotoHardCapBytes = 8 * 1024 * 1024; // 8 MB

/// Compression quality steps. Quality only - we deliberately do NOT pass
/// minWidth / minHeight here because that would force a specific aspect
/// ratio and stretch portrait photos into landscape (visible squeezing).
const List<int> _qualityLadder = [85, 75, 65, 55, 45, 35];

class SosPhotoService {
  final ImagePicker _picker = ImagePicker();

  /// Capture a photo from the camera and upload it to the active SOS.
  /// Returns a [PhotoCaptureResult] describing the outcome - the
  /// caller is expected to surface errors (especially [linkFailed])
  /// to the user. Previously returned String? which silently
  /// collapsed cancel, upload-fail, and link-fail into one value.
  ///
  /// Compression is best-effort. If every compression step fails we
  /// still upload the original file so the user never gets a
  /// "photo failed" dead-end while reporting an emergency.
  Future<PhotoCaptureResult> captureAndUpload({
    required String senderId,
    required int currentPhotoCount,
  }) async {
    if (currentPhotoCount >= kMaxSosPhotos) {
      return const PhotoCaptureResult.atLimit();
    }

    final XFile? picked = await _picker.pickImage(
      source: ImageSource.camera,
      // Do NOT pass imageQuality here. The OS pre-compression strips EXIF
      // orientation metadata on some Android devices, which is what causes
      // "squeezed sideways" rendering on the responder's phone. We handle
      // resizing/quality ourselves via flutter_image_compress, which
      // correctly preserves orientation by default (autoCorrectionAngle).
      preferredCameraDevice: CameraDevice.rear,
    );
    if (picked == null) return const PhotoCaptureResult.cancelled();

    final File original = File(picked.path);
    int originalSize = 0;
    try {
      originalSize = await original.length();
    } catch (e) {
      debugPrint('SosPhotoService: cannot stat picked file: $e');
      // Even if stat fails, try to upload anyway.
    }
    debugPrint(
        'SosPhotoService: captured ${(originalSize / 1024).toStringAsFixed(1)} KB');

    // Choose what to upload. Three branches:
    //   1. Already <= 2 MB - upload the original directly. No re-encode,
    //      so EXIF orientation, color space, and metadata are preserved.
    //   2. > 2 MB - try compression. If it succeeds, upload that.
    //   3. > 2 MB and compression fails - upload original anyway (graceful
    //      degradation). The SOS user comes first.
    File fileToUpload = original;
    if (originalSize > kMaxPhotoBytes) {
      final File? compressed =
          await _safelyCompress(original, senderId, currentPhotoCount);
      if (compressed != null) {
        try {
          final int newSize = await compressed.length();
          debugPrint(
              'SosPhotoService: compressed to ${(newSize / 1024).toStringAsFixed(1)} KB');
          fileToUpload = compressed;
        } catch (_) {
          // Stat failure - still prefer compressed since it's likely smaller
          fileToUpload = compressed;
        }
      } else {
        debugPrint(
            'SosPhotoService: compression failed; uploading original (${(originalSize / 1024 / 1024).toStringAsFixed(1)} MB)');
      }
    }

    final String? url = await _uploadToFirebaseStorage(
      file: fileToUpload,
      senderId: senderId,
      index: currentPhotoCount,
    );
    if (url == null) {
      return const PhotoCaptureResult.uploadFailed();
    }

    final bool linked = await _attachOnBackend(senderId, url);
    if (!linked) {
      debugPrint(
          'SosPhotoService: upload OK but Firestore link failed - photo orphaned in Storage');
      return const PhotoCaptureResult.linkFailed();
    }
    return PhotoCaptureResult.success(url);
  }

  /// Wraps compression in a try/catch so a single bad codec call cannot
  /// kill the entire SOS flow. Returns null on any failure - the caller
  /// is expected to fall back to uploading the original.
  Future<File?> _safelyCompress(File file, String senderId, int index) async {
    try {
      return await _compress(file, senderId, index);
    } catch (e, st) {
      debugPrint('SosPhotoService: compress threw: $e');
      debugPrint('$st');
      return null;
    }
  }

  /// Step the JPEG quality ladder until the file is under [kMaxPhotoBytes],
  /// or until we exhaust quality options. Critically, we do NOT pass
  /// minWidth / minHeight - that parameter forces dimensions and would
  /// stretch the photo if the source aspect ratio differs (visible
  /// squeezing). Reducing only the JPEG quality preserves dimensions and
  /// aspect ratio perfectly.
  Future<File?> _compress(File file, String senderId, int index) async {
    final Directory tmp = await getTemporaryDirectory();
    final ts = DateTime.now().millisecondsSinceEpoch;
    final String outPath =
        path.join(tmp.path, 'sos_${senderId}_${index}_${ts}_c.jpg');

    File? lastSuccess;
    for (final int q in _qualityLadder) {
      try {
        final XFile? r = await FlutterImageCompress.compressAndGetFile(
          file.path,
          outPath,
          quality: q,
          format: CompressFormat.jpeg,
          // keepExif preserves orientation, GPS, capture time.
          // Without this some Android devices rotate the image 90 degrees
          // because the rotation lives in EXIF, not pixels.
          keepExif: true,
        );
        if (r == null) continue;
        final File c = File(r.path);
        final int sz = await c.length();
        lastSuccess = c;
        if (sz <= kMaxPhotoBytes) {
          debugPrint(
              'SosPhotoService: compress q=$q -> ${(sz / 1024).toStringAsFixed(1)} KB OK');
          return c;
        }
        debugPrint(
            'SosPhotoService: compress q=$q -> ${(sz / 1024).toStringAsFixed(1)} KB still over cap');
      } catch (e) {
        debugPrint('SosPhotoService: compress q=$q error: $e');
        // Continue to next quality step.
      }
    }

    // None hit the target. If we got SOMETHING that compressed (smaller
    // than original even if still over cap), return it - any reduction
    // is better than uploading the raw camera output. If even that
    // failed, return null so caller falls back to original.
    if (lastSuccess != null) {
      try {
        final origSize = await file.length();
        final compSize = await lastSuccess.length();
        if (compSize < origSize) {
          debugPrint(
              'SosPhotoService: compress hit floor at ${(compSize / 1024).toStringAsFixed(1)} KB; using anyway');
          return lastSuccess;
        }
      } catch (_) {/* fall through */}
    }
    return null;
  }

  Future<String?> _uploadToFirebaseStorage({
    required File file,
    required String senderId,
    required int index,
  }) async {
    try {
      // Sanity-cap file size to avoid runaway uploads on flaky networks.
      // We still go ahead even above the soft 2 MB cap - this is just
      // defensive against truly huge files (e.g. a 50 MB raw DSLR JPEG
      // somehow making it through compression). Above kPhotoHardCapBytes
      // we still upload but warn so it can be diagnosed in logs.
      try {
        final size = await file.length();
        if (size > kPhotoHardCapBytes) {
          debugPrint(
              'SosPhotoService: WARNING uploading ${(size / 1024 / 1024).toStringAsFixed(1)} MB photo (above ${kPhotoHardCapBytes ~/ (1024 * 1024)} MB soft hard-cap)');
        }
      } catch (_) {/* stat failure - proceed anyway */}

      final String fileName =
          'sos_${senderId}_${index}_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final Reference ref = FirebaseStorage.instance
          .ref()
          .child('sos_photos')
          .child(senderId)
          .child(fileName);

      final UploadTask task = ref.putFile(
        file,
        SettableMetadata(contentType: 'image/jpeg'),
      );

      final TaskSnapshot snapshot =
          await task.timeout(const Duration(seconds: 90));
      final String url = await snapshot.ref.getDownloadURL();
      debugPrint('SosPhotoService: uploaded -> $url');
      return url;
    } catch (e, st) {
      debugPrint('SosPhotoService: upload error: $e');
      debugPrint('$st');
      return null;
    }
  }

  /// Asks the backend to attach the uploaded photo URL to the alert
  /// document. Returns true on success.
  ///
  /// History: this used to write to sos_alerts.photo_urls directly via
  /// Firestore set(merge:true). That was always blocked by Security
  /// Rules in production - sos_alerts is backend-write-only - which is
  /// why "Android allows but nothing saves" was the symptom. Now goes
  /// through POST /sos/attach-photo, which validates the URL prefix
  /// matches the sender's storage path before merging server-side.
  ///
  /// Backend semantics:
  ///   200: attached, or already present (idempotent re-attach)
  ///   400: malformed body or URL prefix mismatch (caller bug)
  ///   404: alert doc doesn't exist for this senderId (race - retry)
  ///   409: alert is inactive, or photo limit reached
  ///   429: rate limited (caller is hammering the endpoint)
  ///   5xx: server error
  Future<bool> _attachOnBackend(String senderId, String url) async {
    try {
      final res = await http
          .post(
            Uri.parse(ApiConfig.attachPhotoEndpoint),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({'sender_id': senderId, 'url': url}),
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return true;
      debugPrint(
          'SosPhotoService: attach-photo failed status=${res.statusCode} body=${res.body}');
      return false;
    } catch (e) {
      debugPrint('SosPhotoService: attach-photo error: $e');
      return false;
    }
  }

  /// Deletes every photo currently attached to the alert. Goes through
  /// the backend's /sos/detach-photo for each URL so the server-side
  /// admin SDK both updates the alert doc and deletes the underlying
  /// Storage objects atomically.
  ///
  /// History: used to do the Storage delete client-side and then write
  /// `photo_urls: []` to Firestore. The Firestore write was blocked by
  /// rules; user saw photos disappear from the strip locally but
  /// they reappeared on the next snapshot.
  Future<void> deleteAllPhotos(String senderId) async {
    try {
      // Pull the current list from Firestore so we know what to detach.
      // A read is allowed (sos_alerts.read is open).
      final snap = await FirebaseFirestore.instance
          .collection('sos_alerts')
          .doc(senderId)
          .get();
      final urls = List<String>.from(snap.data()?['photo_urls'] ?? const []);
      for (final url in urls) {
        await _detachOnBackend(senderId, url);
      }
    } catch (e) {
      debugPrint('SosPhotoService: deleteAllPhotos error: $e');
    }
  }

  /// End-of-life cleanup invoked when an SOS ends - either by user-initiated
  /// stop, by 60-minute auto-expiry, or when the app re-launches and finds
  /// a stale alert past TTL. Best-effort and tolerant: silently swallows
  /// any error (e.g. doc already gone, network down) so this can be
  /// fire-and-forget from any teardown path without blocking it.
  static Future<void> purgeAll(String senderId) async {
    try {
      final result = await FirebaseStorage.instance
          .ref()
          .child('sos_photos')
          .child(senderId)
          .listAll();
      for (final ref in result.items) {
        try {
          await ref.delete();
        } catch (_) {/* already gone - fine */}
      }
    } catch (e) {
      debugPrint('SosPhotoService.purgeAll: storage list/delete error: $e');
    }
    // Don't try to write back to the Firestore doc here - the alert
    // document itself is owned by the backend stop flow. We only own
    // the bytes in Storage and the local upload artefacts.
  }

  /// Delete a single photo by URL. Goes through /sos/detach-photo so
  /// the backend can update Firestore (rules-blocked from client) and
  /// delete the underlying Storage object server-side.
  Future<void> deletePhoto(
      {required String senderId, required String url}) async {
    await _detachOnBackend(senderId, url);
  }

  /// Shared helper for the detach-photo backend call. Returns true on
  /// success but the public methods don't currently care - their
  /// callers don't gate UX on the result.
  Future<bool> _detachOnBackend(String senderId, String url) async {
    try {
      final res = await http
          .post(
            Uri.parse(ApiConfig.detachPhotoEndpoint),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({'sender_id': senderId, 'url': url}),
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return true;
      debugPrint(
          'SosPhotoService: detach-photo failed status=${res.statusCode} body=${res.body}');
      return false;
    } catch (e) {
      debugPrint('SosPhotoService: detach-photo error: $e');
      return false;
    }
  }

  Stream<List<String>> photoUrlsStream(String senderId) {
    return FirebaseFirestore.instance
        .collection('sos_alerts')
        .doc(senderId)
        .snapshots()
        .map((doc) {
      if (!doc.exists) return <String>[];
      return List<String>.from(doc.data()?['photo_urls'] ?? []);
    });
  }
}
