import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'profile_service.dart';

/// Persists post-SOS feedback both locally (so we never re-prompt the same
/// alert) and remotely (so the team can review feedback in aggregate).
///
/// Storage layout:
///   • SharedPreferences: a Set<String> of "feedback_seen" keys, where each
///     key is "${senderId}:${activatedAtMillis}". Skipping the dialog also
///     adds the key - once an alert is dismissed it stays dismissed.
///   • Firestore: a document at `sos_feedback/{senderId}_{activatedAtMillis}`
///     holding the structured response plus the sender's name and mobile
///     so an admin can follow up directly without joining against
///     subscribed_users by FID.
class FeedbackService {
  static const String _seenSetKey = 'sos_feedback_seen_v1';

  static String _key(String senderId, int activatedAtMillis) =>
      '$senderId:$activatedAtMillis';

  /// Returns true if feedback for this alert has already been submitted or
  /// dismissed. Used by the trigger site to short-circuit re-prompting.
  static Future<bool> alreadyHandled({
    required String senderId,
    required int activatedAtMillis,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final set = prefs.getStringList(_seenSetKey)?.toSet() ?? <String>{};
    return set.contains(_key(senderId, activatedAtMillis));
  }

  /// Marks an alert as handled regardless of whether feedback was actually
  /// submitted. Called from both the success path and the skip path.
  static Future<void> markHandled({
    required String senderId,
    required int activatedAtMillis,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final set = prefs.getStringList(_seenSetKey)?.toSet() ?? <String>{};
    set.add(_key(senderId, activatedAtMillis));
    await prefs.setStringList(_seenSetKey, set.toList());
  }

  /// Submits the structured feedback payload to Firestore. Sender name
  /// and mobile are read from ProfileService here (not passed in) so
  /// the screen API stays minimal and there's a single source of truth
  /// for which fields the document gains. If profile read fails for any
  /// reason, the feedback still submits without those fields - the
  /// admin can fall back to joining by FID.
  ///
  /// Uses `set` with merge so a later submission for the same alert
  /// (which the UI guards against, but be safe) won't blow away
  /// earlier data.
  static Future<void> submit({
    required String senderId,
    required int activatedAtMillis,
    required int rating,
    required String helpArrived,
    String? responseSpeed,
    String? outcome,
    String? comment,
  }) async {
    // Read profile - tolerant of missing values. We don't block the
    // submission if profile read fails; the admin still has the FID.
    String? senderName;
    String? senderMobile;
    try {
      senderName = await ProfileService.getUserName();
    } catch (e) {
      debugPrint('FeedbackService.submit: profile name read failed: $e');
    }
    try {
      senderMobile = await ProfileService.getUserMobile();
    } catch (e) {
      debugPrint('FeedbackService.submit: profile mobile read failed: $e');
    }

    final docId = '${senderId}_$activatedAtMillis';
    await FirebaseFirestore.instance
        .collection('sos_feedback')
        .doc(docId)
        .set({
      'sender_id': senderId,
      'activated_at_millis': activatedAtMillis,
      'rating': rating,
      'help_arrived': helpArrived,
      if (responseSpeed != null) 'response_speed': responseSpeed,
      if (outcome != null) 'outcome': outcome,
      if (comment != null && comment.isNotEmpty) 'comment': comment,
      // Captured for follow-up. Both are nullable; written only when
      // available. The field names mirror the alert doc's userInfo
      // shape (sender_name / mobile_number) for admin-side consistency.
      if (senderName != null && senderName.isNotEmpty) 'sender_name': senderName,
      if (senderMobile != null && senderMobile.isNotEmpty)
        'mobile_number': senderMobile,
      'submitted_at': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    await markHandled(
      senderId: senderId,
      activatedAtMillis: activatedAtMillis,
    );
  }
}
