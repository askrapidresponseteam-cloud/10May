import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:flutter/foundation.dart';

class RemoteConfigService {
  static const String _cloudFunctionBaseUrlKey = 'cloud_function_base_url';

  static const String _defaultBaseUrl =
      'https://us-central1-rrt-sos.cloudfunctions.net/api';

  static final FirebaseRemoteConfig _remoteConfig =
      FirebaseRemoteConfig.instance;

  static Future<void> initialize() async {
    try {
      await _remoteConfig.setDefaults({
        _cloudFunctionBaseUrlKey: _defaultBaseUrl,
      });

      await _remoteConfig.setConfigSettings(RemoteConfigSettings(
        // During development, fetch fresh values every 30 seconds.
        // In production, Firebase enforces a minimum 12-hour interval.
        fetchTimeout: const Duration(seconds: 10),
        minimumFetchInterval: kDebugMode
            ? const Duration(seconds: 30)
            : const Duration(hours: 12),
      ));

      await _remoteConfig.fetchAndActivate();
    } catch (e) {
      // Remote Config fetch failed - the app continues with the default URL.
      debugPrint('RemoteConfigService: fetch failed, using defaults. Error: $e');
    }
  }

  static String get cloudFunctionBaseUrl {
    final val = _remoteConfig.getString(_cloudFunctionBaseUrlKey);
    return val.isNotEmpty ? val : _defaultBaseUrl;
  }
}
