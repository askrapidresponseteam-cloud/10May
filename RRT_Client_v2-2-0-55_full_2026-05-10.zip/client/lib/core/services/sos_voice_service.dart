import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:record/record.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'package:just_audio/just_audio.dart';
import '../config/api_config.dart';

const Duration kMaxVoiceDuration = Duration(seconds: 60);

class SosVoiceService {
  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _player = AudioPlayer();

  String? _currentRecordingPath;
  bool _isRecording = false;
  bool get isRecording => _isRecording;

  Future<bool> startRecording(String senderId) async {
    try {
      // Refuse overlapping recordings on this service instance. Two concurrent
      // _recorder.start() calls would otherwise interrupt each other and leave
      // both _currentRecordingPath and the underlying file in inconsistent
      // states. The UI normally guards against this, but a race (double-tap,
      // re-entry from a stream listener, etc) could slip through.
      if (_isRecording) {
        debugPrint('SosVoiceService: start ignored - already recording');
        return false;
      }

      final bool hasPermission = await _recorder.hasPermission();
      if (!hasPermission) {
        debugPrint('SosVoiceService: microphone permission denied');
        return false;
      }

      final Directory tmp = await getTemporaryDirectory();

      // Opportunistically clean up STALE sos_voice_* files in the temp
      // dir from previous record-cancel-record cycles, app crashes, or
      // aborted uploads. The OS eventually purges the temp dir on its
      // own, but doing it here keeps disk usage bounded for long-running
      // app sessions.
      //
      // We delete only files older than 5 minutes. A previous recording
      // may still be uploading from disk - putFile streams chunks rather
      // than buffering the whole file - and on the rare slow network the
      // upload could still be in flight. Five minutes is well past any
      // legitimate upload of a 60-second voice note (ours is capped to
      // 5MB / 60s, ~30s upload at the worst usable speed). Anything
      // older than that is genuine leftover.
      //
      // Best-effort: a single failure to delete one stale file should
      // never block the new recording starting.
      try {
        final DateTime staleCutoff =
            DateTime.now().subtract(const Duration(minutes: 5));
        final List<FileSystemEntity> entries = tmp.listSync(followLinks: false);
        for (final FileSystemEntity ent in entries) {
          if (ent is! File) continue;
          final String base = path.basename(ent.path);
          if (!base.startsWith('sos_voice_') || !base.endsWith('.m4a')) continue;
          try {
            final FileStat stat = ent.statSync();
            if (stat.modified.isBefore(staleCutoff)) {
              ent.deleteSync();
            }
          } catch (_) { /* in use, race, fine */ }
        }
      } catch (e) {
        debugPrint('SosVoiceService: temp cleanup warning (non-fatal): $e');
      }

      // Unique filename per recording. Without the timestamp suffix two
      // recordings by the same sender share a path, and an upload reading
      // bytes from disk while a fresh recording is being written produces
      // a corrupted upload. The local file is independent of the upload
      // filename used inside uploadRecording() - we just want
      // guaranteed-fresh bytes on disk for each session.
      final int nowMs = DateTime.now().millisecondsSinceEpoch;
      _currentRecordingPath = path.join(
        tmp.path,
        'sos_voice_${senderId}_$nowMs.m4a',
      );

      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 64000,
          sampleRate: 44100,
          noiseSuppress: true,
          echoCancel: true,
        ),
        path: _currentRecordingPath!,
      );

      _isRecording = true;
      debugPrint('SosVoiceService: recording started → $_currentRecordingPath');
      return true;
    } catch (e) {
      debugPrint('SosVoiceService: start error: $e');
      // Reset state on failure so the next attempt isn't blocked by
      // stale flags. _recorder.start may have partially set up and
      // thrown - we don't claim to be recording in that case.
      _isRecording = false;
      _currentRecordingPath = null;
      return false;
    }
  }

  Future<File?> stopRecording() async {
    try {
      final String? filePath = await _recorder.stop();
      _isRecording = false;
      if (filePath == null) return null;
      final File file = File(filePath);
      final int size = await file.length();
      debugPrint('SosVoiceService: recorded ${(size / 1024).toStringAsFixed(1)} KB');
      return file;
    } catch (e) {
      debugPrint('SosVoiceService: stop error: $e');
      _isRecording = false;
      return null;
    }
  }

  Future<String?> uploadRecording({
    required File file,
    required String senderId,
  }) async {
    try {
      final String fileName = 'sos_voice_${senderId}_${DateTime.now().millisecondsSinceEpoch}.m4a';
      final Reference ref = FirebaseStorage.instance
          .ref()
          .child('sos_voice')
          .child(senderId)
          .child(fileName);

      final UploadTask task = ref.putFile(
        file,
        // audio/mp4 is the IANA registered type for M4A. We use it here
        // (rather than audio/m4a) because Firebase Storage rules
        // allowlist that exact value.
        SettableMetadata(contentType: 'audio/mp4'),
      );

      final TaskSnapshot snapshot = await task.timeout(const Duration(seconds: 60));
      final String url = await snapshot.ref.getDownloadURL();

      // Storage upload succeeded. Now ask the backend to attach the
      // URL to sos_alerts/{senderId}.voice_url. Firestore rules deny
      // direct client writes to sos_alerts; the backend goes through
      // admin SDK after validating the URL prefix matches the sender's
      // own storage path.
      final bool linked = await _attachOnBackend(senderId, url);
      if (!linked) {
        debugPrint(
            'SosVoiceService: upload OK but backend attach failed - '
            'voice orphaned in Storage');
        return null;
      }
      debugPrint('SosVoiceService: uploaded → $url');
      return url;
    } catch (e) {
      debugPrint('SosVoiceService: upload error: $e');
      return null;
    }
  }

  /// Asks the backend to attach the uploaded voice URL. See
  /// SosPhotoService._attachOnBackend for full notes on response codes.
  Future<bool> _attachOnBackend(String senderId, String url) async {
    try {
      final res = await http
          .post(
            Uri.parse(ApiConfig.attachVoiceEndpoint),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({'sender_id': senderId, 'url': url}),
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return true;
      debugPrint(
          'SosVoiceService: attach-voice failed status=${res.statusCode} body=${res.body}');
      return false;
    } catch (e) {
      debugPrint('SosVoiceService: attach-voice error: $e');
      return false;
    }
  }

  /// Delete the voice recording. Goes through /sos/detach-voice which
  /// clears voice_url server-side and deletes the underlying Storage
  /// object via admin SDK. (Direct Firestore writes are blocked by
  /// rules; direct Storage delete works for our own object but leaves
  /// voice_url stale on the alert doc.)
  Future<void> deleteVoiceRecording(String senderId) async {
    try {
      final res = await http
          .post(
            Uri.parse(ApiConfig.detachVoiceEndpoint),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode({'sender_id': senderId}),
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode != 200) {
        debugPrint(
            'SosVoiceService: detach-voice failed status=${res.statusCode} body=${res.body}');
      }
    } catch (e) {
      debugPrint('SosVoiceService: detach-voice error: $e');
    }
  }

  /// End-of-life cleanup invoked when an SOS ends - either by user-initiated
  /// stop, by 60-minute auto-expiry, or when the app re-launches and finds
  /// a stale alert past TTL. Best-effort and tolerant: silently swallows
  /// any error so this can be fire-and-forget from any teardown path.
  static Future<void> purgeAll(String senderId) async {
    try {
      final result = await FirebaseStorage.instance
          .ref()
          .child('sos_voice')
          .child(senderId)
          .listAll();
      for (final ref in result.items) {
        try {
          await ref.delete();
        } catch (_) {/* already gone - fine */}
      }
    } catch (e) {
      debugPrint('SosVoiceService.purgeAll: storage list/delete error: $e');
    }
    // Same note as SosPhotoService.purgeAll: we don't touch the Firestore
    // sos_alerts doc here. The backend's stop flow owns that document's
    // lifecycle. We're only purging the bytes we uploaded.
  }

  Future<void> deleteLocalRecording() async {
    try {
      if (_currentRecordingPath != null) {
        final File f = File(_currentRecordingPath!);
        if (await f.exists()) await f.delete();
        _currentRecordingPath = null;
      }
    } catch (e) {
      debugPrint('SosVoiceService: delete local error: $e');
    }
  }

  Future<void> playFromUrl(String url) async {
    try {
      await _player.setUrl(url);
      await _player.play();
    } catch (e) {
      debugPrint('SosVoiceService: play error: $e');
    }
  }

  /// Loads a URL into the player without starting playback. Used when the
  /// UI wants to render a populated scrub bar (with total duration) before
  /// the user taps play.
  Future<void> prepareUrl(String url) async {
    try {
      await _player.setUrl(url);
    } catch (e) {
      debugPrint('SosVoiceService: prepare error: $e');
    }
  }

  /// Resumes a paused/stopped track without re-loading the source. Pairs
  /// with [pausePlayback] for play/pause toggling.
  Future<void> resumePlayback() async {
    try {
      await _player.play();
    } catch (e) {
      debugPrint('SosVoiceService: resume error: $e');
    }
  }

  /// Pauses playback without releasing the source - unlike [stopPlayback]
  /// which fully halts it. Use when you want play/pause behavior.
  Future<void> pausePlayback() async {
    try {
      await _player.pause();
    } catch (e) {
      debugPrint('SosVoiceService: pause error: $e');
    }
  }

  /// Seeks to an absolute position in the currently loaded track.
  Future<void> seek(Duration position) async {
    try {
      await _player.seek(position);
    } catch (e) {
      debugPrint('SosVoiceService: seek error: $e');
    }
  }

  Future<void> stopPlayback() async {
    try {
      await _player.stop();
    } catch (e) {
      debugPrint('SosVoiceService: stop playback error: $e');
    }
  }

  Stream<PlayerState> get playerStateStream => _player.playerStateStream;
  Stream<Duration> get positionStream => _player.positionStream;
  Duration? get duration => _player.duration;

  Stream<String?> voiceUrlStream(String senderId) {
    return FirebaseFirestore.instance
        .collection('sos_alerts')
        .doc(senderId)
        .snapshots()
        .map((doc) {
      if (!doc.exists) return null;
      return doc.data()?['voice_url'] as String?;
    });
  }

  void dispose() {
    _recorder.dispose();
    _player.dispose();
  }
}
