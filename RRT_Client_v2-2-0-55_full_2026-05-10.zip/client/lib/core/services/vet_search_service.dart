import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../config/api_config.dart';

/// One vet, normalised to the fields we actually render.
///
/// Source-agnostic so we can swap Ola for Google Places or stitch
/// in a curated directory later without touching the screen layer.
class Vet {
  final String placeId;
  final String name;
  final String? address;
  // Coordinates are optional. Ola Maps Nearby Search does NOT return
  // lat/lng - it returns distance_meters server-side instead. We only
  // get coordinates if the data came from a different source (Place
  // Details API, or a future curated directory).
  final double? latitude;
  final double? longitude;
  final double? distanceMeters;
  final String? phone;

  const Vet({
    required this.placeId,
    required this.name,
    this.latitude,
    this.longitude,
    this.address,
    this.distanceMeters,
    this.phone,
  });

  Map<String, dynamic> toJson() => {
        'place_id': placeId,
        'name': name,
        'address': address,
        'lat': latitude,
        'lng': longitude,
        'distance_m': distanceMeters,
        'phone': phone,
      };

  factory Vet.fromJson(Map<String, dynamic> j) => Vet(
        placeId: j['place_id'] as String,
        name: j['name'] as String,
        address: j['address'] as String?,
        latitude: (j['lat'] as num?)?.toDouble(),
        longitude: (j['lng'] as num?)?.toDouble(),
        distanceMeters: (j['distance_m'] as num?)?.toDouble(),
        phone: j['phone'] as String?,
      );
}

/// Result envelope so the screen can distinguish "no vets found" (empty
/// list, success) from "couldn't reach Ola at all" (error). Both lead
/// to different UI - empty state vs. retry / Google Maps fallback.
class VetSearchResult {
  final List<Vet> vets;
  final int radiusMeters;
  final DateTime fetchedAt;

  /// Cache provenance, exposed for debugging / analytics. Not shown to
  /// the user, but useful in logs to understand cache hit rates.
  final VetCacheSource source;

  const VetSearchResult({
    required this.vets,
    required this.radiusMeters,
    required this.fetchedAt,
    required this.source,
  });

  bool get isEmpty => vets.isEmpty;
}

enum VetCacheSource { memory, prefs, firestore, network }

/// Where the user is looking for vets. Snapped to a grid cell upstream
/// so cache keys are stable across small position changes.
class _CellKey {
  final int latCell;
  final int lngCell;
  final int radiusMeters;

  const _CellKey(this.latCell, this.lngCell, this.radiusMeters);

  /// The grid is ~1km in latitude (0.01 deg ~ 1.11 km). Longitude cell
  /// size varies with latitude but the variation is small at Indian
  /// latitudes (8-37 deg N), so we use the same factor and accept a
  /// little asymmetry. The point is stable cache keys, not surveying.
  static const _gridFactor = 0.01;

  static _CellKey from({
    required double lat,
    required double lng,
    required int radiusMeters,
  }) {
    return _CellKey(
      (lat / _gridFactor).round(),
      (lng / _gridFactor).round(),
      radiusMeters,
    );
  }

  /// Stable string for use in shared_preferences and Firestore document
  /// IDs. Format: `r15_lat1334_lng7474` - radius prefix means a 15km
  /// search and a 50km search at the same coords cache separately.
  String get id =>
      'r${(radiusMeters / 1000).round()}_lat${latCell}_lng${lngCell}';
}

/// Read-through cache for vet searches.
///
/// Lookup order on every search:
///   1. In-memory map (free, microseconds, lost on app restart)
///   2. shared_preferences (free, milliseconds, survives restart)
///   3. Firestore vet_cache/{cellId} (free at our scale, survives
///      across users - first user in a cell pays the API cost,
///      everyone after rides for free)
///   4. Ola Maps Nearby Search HTTP call (counts against the 500K
///      monthly free tier)
///
/// On a network success at level 4, we write back through all three
/// cache layers so the next caller hits memory or prefs.
///
/// TTLs:
///   - Populated results: 7 days. Vet directory data doesn't change
///     much; weekly refresh balances staleness against API cost.
///   - Empty results: 24 hours. Shorter so a newly-listed vet in a
///     sparse town surfaces within a day, not a week.
///
/// Empty-result caching is important: without it, every user in a vet
/// desert would fire a fresh API call. With it, the second user in
/// that town gets the same "no vets" answer for free.
class VetSearchService {
  static const Duration _populatedTtl = Duration(days: 7);
  static const Duration _emptyTtl = Duration(hours: 24);
  static const String _firestoreCollection = 'vet_cache';
  static const String _prefsPrefix = 'vet_cache_v1_';
  static const Duration _httpTimeout = Duration(seconds: 8);

  final FirebaseFirestore _firestore;
  final http.Client _httpClient;

  /// In-memory cache. Lost on app restart, which is fine - prefs and
  /// Firestore are still warm. Bounded by the number of distinct
  /// (cell, radius) tuples a single session asks for, which is ~1.
  final Map<String, _CachedEntry> _memoryCache = {};

  VetSearchService({
    FirebaseFirestore? firestore,
    http.Client? httpClient,
  })  : _firestore = firestore ?? FirebaseFirestore.instance,
        _httpClient = httpClient ?? http.Client();

  /// Find vets near (lat, lng) within radiusMeters.
  ///
  /// Returns a [VetSearchResult] on success (which may be empty if the
  /// search succeeded but found nothing). Throws on hard network/API
  /// failure - the screen catches this and renders an error state with
  /// the Google Maps fallback button.
  Future<VetSearchResult> findNearby({
    required double lat,
    required double lng,
    int radiusMeters = 15000,
  }) async {
    final key = _CellKey.from(lat: lat, lng: lng, radiusMeters: radiusMeters);

    final memHit = _readMemory(key);
    if (memHit != null) return memHit;

    final prefsHit = await _readPrefs(key);
    if (prefsHit != null) {
      _writeMemory(key, prefsHit);
      return prefsHit;
    }

    final firestoreHit = await _readFirestore(key);
    if (firestoreHit != null) {
      _writeMemory(key, firestoreHit);
      // Backfill prefs so the next launch on this device skips Firestore
      // entirely. Fire-and-forget; the in-memory write above is what
      // matters for the current session.
      unawaited(_writePrefs(key, firestoreHit));
      return firestoreHit;
    }

    // Cold cache. If Ola is disabled (no key compiled in), surface that
    // honestly to the screen so it can render the Google Maps fallback
    // without showing a misleading "no results" state.
    if (!ApiConfig.olaMapsEnabled) {
      throw const VetSearchUnavailable(
        'Vet directory is not available in this build.',
      );
    }

    final fresh = await _fetchFromOla(
      lat: lat,
      lng: lng,
      radiusMeters: radiusMeters,
    );

    final result = VetSearchResult(
      vets: fresh,
      radiusMeters: radiusMeters,
      fetchedAt: DateTime.now(),
      source: VetCacheSource.network,
    );

    _writeMemory(key, result);
    unawaited(_writePrefs(key, result));
    unawaited(_writeFirestore(key, result));

    return result;
  }

  // ---- Memory layer ------------------------------------------------------

  VetSearchResult? _readMemory(_CellKey key) {
    final entry = _memoryCache[key.id];
    if (entry == null) return null;
    if (entry.isExpired) {
      _memoryCache.remove(key.id);
      return null;
    }
    return entry.toResult(VetCacheSource.memory);
  }

  void _writeMemory(_CellKey key, VetSearchResult result) {
    _memoryCache[key.id] = _CachedEntry.fromResult(result);
  }

  // ---- shared_preferences layer ------------------------------------------

  Future<VetSearchResult?> _readPrefs(_CellKey key) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('$_prefsPrefix${key.id}');
      if (raw == null) return null;
      final entry = _CachedEntry.fromJson(
        jsonDecode(raw) as Map<String, dynamic>,
      );
      if (entry.isExpired) {
        await prefs.remove('$_prefsPrefix${key.id}');
        return null;
      }
      return entry.toResult(VetCacheSource.prefs);
    } catch (e) {
      debugPrint('VetSearchService._readPrefs: $e');
      return null;
    }
  }

  Future<void> _writePrefs(_CellKey key, VetSearchResult result) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        '$_prefsPrefix${key.id}',
        jsonEncode(_CachedEntry.fromResult(result).toJson()),
      );
    } catch (e) {
      debugPrint('VetSearchService._writePrefs: $e');
    }
  }

  // ---- Firestore layer ---------------------------------------------------

  Future<VetSearchResult?> _readFirestore(_CellKey key) async {
    try {
      final doc = await _firestore
          .collection(_firestoreCollection)
          .doc(key.id)
          .get();
      if (!doc.exists) return null;
      final data = doc.data();
      if (data == null) return null;

      final entry = _CachedEntry.fromJson(data);
      if (entry.isExpired) return null;
      return entry.toResult(VetCacheSource.firestore);
    } catch (e) {
      debugPrint('VetSearchService._readFirestore: $e');
      return null;
    }
  }

  Future<void> _writeFirestore(_CellKey key, VetSearchResult result) async {
    try {
      await _firestore
          .collection(_firestoreCollection)
          .doc(key.id)
          .set(_CachedEntry.fromResult(result).toJson());
    } catch (e) {
      debugPrint('VetSearchService._writeFirestore: $e');
    }
  }

  // ---- Ola Maps Nearby Search -------------------------------------------

  /// Hit Ola's Nearby Search API and parse the response into Vet
  /// records. Filters to veterinary-related results client-side as a
  /// safety net - Ola's `types` parameter may not always be a perfect
  /// filter, so we double-check by name.
  ///
  /// Returns an empty list on a successful "no results" response.
  /// Throws on transport failure or non-2xx HTTP status.
  Future<List<Vet>> _fetchFromOla({
    required double lat,
    required double lng,
    required int radiusMeters,
  }) async {
    // The exact Ola `types` value for vets needs to be confirmed against
    // the live supported-types list. Common values across maps APIs:
    //   - veterinary_care   (Google Places)
    //   - veterinarian      (some OSM-derived APIs)
    //   - vet               (rare)
    // We pass `veterinary_care` as our primary attempt. If that returns
    // zero_results consistently in production, swap to a Text Search
    // call (different endpoint, query=veterinary).
    final uri = Uri.parse(ApiConfig.olaMapsNearbySearchEndpoint).replace(
      queryParameters: {
        'location': '$lat,$lng',
        'types': 'veterinary_care',
        'radius': radiusMeters.toString(),
        'api_key': ApiConfig.olaMapsApiKey,
      },
    );

    final res = await _httpClient.get(uri).timeout(_httpTimeout);

    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw VetSearchException(
        'Ola Maps returned ${res.statusCode}: ${res.body}',
      );
    }

    final body = jsonDecode(res.body);
    if (body is! Map<String, dynamic>) {
      throw const VetSearchException('Unexpected Ola response shape');
    }

    final predictions = body['predictions'];
    if (predictions is! List) return const [];

    final results = <Vet>[];
    for (final p in predictions) {
      if (p is! Map<String, dynamic>) continue;
      final vet = _parseOlaPrediction(p, originLat: lat, originLng: lng);
      if (vet == null) continue;
      // Belt-and-braces: drop anything that doesn't look vet-related by
      // name, in case the type filter let through unrelated POIs.
      if (!_looksVetRelated(vet.name)) continue;
      results.add(vet);
    }

    // Sort by distance ascending. Ola usually does this server-side but
    // we re-sort defensively after our client-side name filter, which
    // could otherwise leave the list in odd order.
    results.sort((a, b) {
      final da = a.distanceMeters ?? double.infinity;
      final db = b.distanceMeters ?? double.infinity;
      return da.compareTo(db);
    });

    return results;
  }

  // ---- Ola Maps Place Details (lazy coordinate hydration) -------------

  /// Fetch coordinates for a vet from Ola's Place Details endpoint and
  /// return a copy with latitude/longitude populated. Returns the
  /// original Vet unchanged if the call fails or returns no coordinates
  /// — callers can fall back to address-string URLs in that case.
  ///
  /// Why this exists: Nearby Search responses don't include lat/lng
  /// (verified empirically — they return distance_meters instead). For
  /// the "Directions" button to land at the EXACT vet rather than
  /// Google Maps' best-guess interpretation of the name, we need real
  /// coordinates. Place Details is the only Ola endpoint that returns
  /// them, so we call it on-demand when the user taps Directions.
  ///
  /// Cost: one extra HTTPS call per unique place_id ever tapped on
  /// this device. Cached permanently in shared_preferences once
  /// fetched (places don't move, so any TTL would just waste re-fetches).
  /// Cache key: `vet_coords:{place_id}`.
  ///
  /// We don't write hydrated coords to the per-cell Firestore cache
  /// because that document is shared across users; many concurrent
  /// writes from clients tapping Directions create unnecessary write
  /// contention, and Place Details responses change on geological
  /// timescales. Local cache is sufficient for the per-user UX win.
  ///
  /// Response shape (verified empirically with curl against the
  /// /places/v1/details endpoint, May 2026):
  ///   result.geometry.location.lat   double
  ///   result.geometry.location.lng   double
  /// Phone numbers and opening hours are also returned but mostly
  /// come back empty / "NA" for tier-2 city clinics, so we don't try
  /// to use them.
  Future<Vet> hydrateWithCoordinates(Vet v) async {
    // Fast path: already have coordinates (e.g. some future caller
    // populated them, or we already hydrated this place earlier in
    // the session and the in-memory list still holds the result).
    if (v.latitude != null && v.longitude != null) return v;

    // No key compiled in -> can't hydrate. Return the vet unchanged;
    // the caller falls back to address-string URLs.
    if (!ApiConfig.olaMapsEnabled) return v;

    // Local cache check — most subsequent taps for the same vet
    // resolve here without an HTTP call.
    final cached = await _readCoordsCache(v.placeId);
    if (cached != null) {
      return Vet(
        placeId: v.placeId,
        name: v.name,
        address: v.address,
        distanceMeters: v.distanceMeters,
        phone: v.phone,
        latitude: cached.$1,
        longitude: cached.$2,
      );
    }

    // Cache miss -> hit Ola Place Details.
    try {
      final uri = Uri.parse(ApiConfig.olaMapsPlaceDetailsEndpoint).replace(
        queryParameters: {
          'place_id': v.placeId,
          'api_key': ApiConfig.olaMapsApiKey,
        },
      );
      final res = await _httpClient.get(uri).timeout(_httpTimeout);
      if (res.statusCode < 200 || res.statusCode >= 300) {
        debugPrint(
            'VetSearchService.hydrate: HTTP ${res.statusCode} for ${v.placeId}');
        return v;
      }
      final body = jsonDecode(res.body);
      if (body is! Map<String, dynamic>) return v;
      final result = body['result'];
      if (result is! Map<String, dynamic>) return v;
      final geometry = result['geometry'];
      if (geometry is! Map<String, dynamic>) return v;
      final location = geometry['location'];
      if (location is! Map<String, dynamic>) return v;
      final lat = (location['lat'] as num?)?.toDouble();
      final lng = (location['lng'] as num?)?.toDouble();
      if (lat == null || lng == null) return v;

      // Persist to local cache for future taps (this device only).
      await _writeCoordsCache(v.placeId, lat, lng);

      return Vet(
        placeId: v.placeId,
        name: v.name,
        address: v.address,
        distanceMeters: v.distanceMeters,
        phone: v.phone,
        latitude: lat,
        longitude: lng,
      );
    } catch (e) {
      // Any failure (timeout, JSON parse error, network) -> return
      // vet unchanged. Caller falls back to address-string URL.
      debugPrint('VetSearchService.hydrate: $e');
      return v;
    }
  }

  /// Read cached coordinates for a place_id from shared_preferences.
  /// Returns (lat, lng) tuple on hit, null on miss or parse failure.
  /// Stored as the simple string "lat,lng" — no JSON wrapping needed
  /// for two doubles, and the simpler format means a corrupted entry
  /// just fails the parse and triggers a re-fetch.
  Future<(double, double)?> _readCoordsCache(String placeId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('vet_coords:$placeId');
      if (raw == null) return null;
      final parts = raw.split(',');
      if (parts.length != 2) return null;
      final lat = double.tryParse(parts[0]);
      final lng = double.tryParse(parts[1]);
      if (lat == null || lng == null) return null;
      return (lat, lng);
    } catch (e) {
      debugPrint('VetSearchService._readCoordsCache: $e');
      return null;
    }
  }

  /// Write coordinates for a place_id to shared_preferences. Errors
  /// are swallowed — failing to cache just means a re-fetch next time,
  /// which is harmless.
  Future<void> _writeCoordsCache(
      String placeId, double lat, double lng) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('vet_coords:$placeId', '$lat,$lng');
    } catch (e) {
      debugPrint('VetSearchService._writeCoordsCache: $e');
    }
  }

  /// Parse one prediction from Ola's response into a Vet.
  ///
  /// Ola's Nearby Search response shape (verified empirically):
  ///   - place_id: required
  ///   - description: full address string
  ///   - structured_formatting.main_text: the place name
  ///   - structured_formatting.secondary_text: address minus the name
  ///   - distance_meters: server-computed distance from query location
  ///   - types: array of category strings
  ///   - terms: tokenised address parts (we don't use these)
  ///
  /// Notably absent: latitude/longitude. Nearby Search does not return
  /// coordinates. To get coordinates we'd need a separate Place Details
  /// API call per result, which would multiply our API count by ~10x.
  /// Instead we rely on Ola's server-side distance_meters and pass the
  /// vet's name+address to Google Maps for directions/calls (Google
  /// resolves it to the right place card from the search query alone).
  Vet? _parseOlaPrediction(
    Map<String, dynamic> p, {
    required double originLat,
    required double originLng,
  }) {
    final placeId = p['place_id'] as String?;
    if (placeId == null || placeId.isEmpty) return null;

    final structured = p['structured_formatting'];
    String? name;
    String? secondary;
    if (structured is Map<String, dynamic>) {
      name = structured['main_text'] as String?;
      secondary = structured['secondary_text'] as String?;
    }
    name ??= p['description'] as String?;
    if (name == null || name.isEmpty) return null;

    final distance = (p['distance_meters'] as num?)?.toDouble();

    return Vet(
      placeId: placeId,
      name: name,
      address: secondary ?? p['description'] as String?,
      distanceMeters: distance,
      // latitude/longitude intentionally null - Nearby Search doesn't
      // return them. Directions/Call actions resolve via name+address
      // in the screen layer.
    );
  }

  /// Light keyword filter so a stray "Sai Pet Shop" or "Cattle Feed
  /// Store" doesn't slip through as a "vet". Case-insensitive,
  /// match-any. Tuned for Indian English clinic naming conventions.
  static bool _looksVetRelated(String name) {
    final lower = name.toLowerCase();
    const keywords = [
      'vet',
      'veterinary',
      'veterinarian',
      'pet clinic',
      'animal hospital',
      'animal care',
      'pet hospital',
      'pet care',
      'pashu',
    ];
    return keywords.any(lower.contains);
  }

  /// Great-circle distance in meters between two lat/lng points.
  /// Standard haversine formula. Earth radius 6371 km.
  static double _haversineMeters(
    double lat1,
    double lng1,
    double lat2,
    double lng2,
  ) {
    const earthRadiusMeters = 6371000.0;
    final dLat = _toRadians(lat2 - lat1);
    final dLng = _toRadians(lng2 - lng1);
    final sinDLat = math.sin(dLat / 2);
    final sinDLng = math.sin(dLng / 2);
    final a = sinDLat * sinDLat +
        math.cos(_toRadians(lat1)) *
            math.cos(_toRadians(lat2)) *
            sinDLng * sinDLng;
    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
    return earthRadiusMeters * c;
  }

  static double _toRadians(double deg) => deg * math.pi / 180.0;
}

class _CachedEntry {
  final List<Vet> vets;
  final int radiusMeters;
  final DateTime fetchedAt;

  const _CachedEntry({
    required this.vets,
    required this.radiusMeters,
    required this.fetchedAt,
  });

  factory _CachedEntry.fromResult(VetSearchResult r) => _CachedEntry(
        vets: r.vets,
        radiusMeters: r.radiusMeters,
        fetchedAt: r.fetchedAt,
      );

  /// Empty results expire faster than populated ones. Vet directories
  /// in maps services do get updated; a 24h TTL on an empty result
  /// means a newly-listed vet shows up the next day, not next week.
  bool get isExpired {
    final ttl = vets.isEmpty
        ? VetSearchService._emptyTtl
        : VetSearchService._populatedTtl;
    return DateTime.now().difference(fetchedAt) > ttl;
  }

  VetSearchResult toResult(VetCacheSource source) => VetSearchResult(
        vets: vets,
        radiusMeters: radiusMeters,
        fetchedAt: fetchedAt,
        source: source,
      );

  Map<String, dynamic> toJson() => {
        'vets': vets.map((v) => v.toJson()).toList(),
        'radius_m': radiusMeters,
        'fetched_at_ms': fetchedAt.millisecondsSinceEpoch,
      };

  factory _CachedEntry.fromJson(Map<String, dynamic> j) {
    final vetsRaw = j['vets'];
    final vets = vetsRaw is List
        ? vetsRaw
            .whereType<Map<String, dynamic>>()
            .map(Vet.fromJson)
            .toList()
        : <Vet>[];
    return _CachedEntry(
      vets: vets,
      radiusMeters: (j['radius_m'] as num?)?.toInt() ?? 15000,
      fetchedAt: DateTime.fromMillisecondsSinceEpoch(
        (j['fetched_at_ms'] as num?)?.toInt() ??
            DateTime.now().millisecondsSinceEpoch,
      ),
    );
  }
}

/// Hard error from the Ola call path. The screen catches and shows
/// the Google Maps fallback alongside a retry option.
class VetSearchException implements Exception {
  final String message;
  const VetSearchException(this.message);
  @override
  String toString() => 'VetSearchException: $message';
}

/// Soft "feature is off" signal - distinct from a real failure. The
/// screen handles this by skipping the list entirely and showing only
/// the "Open in Google Maps" button.
class VetSearchUnavailable implements Exception {
  final String message;
  const VetSearchUnavailable(this.message);
  @override
  String toString() => 'VetSearchUnavailable: $message';
}
