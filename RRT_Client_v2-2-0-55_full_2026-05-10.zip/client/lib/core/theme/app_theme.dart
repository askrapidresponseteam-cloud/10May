import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// App theme - 100% matching RRT_Redesign HTML.
///
/// Centralises the exact color palette, typography scales, and
/// spacing rules used across every screen. No rounded corners anywhere
/// (the design is strictly square / zero-radius).
class AppTheme {
  // ───────── EXACT HTML PALETTE ─────────
  static const Color red = Color(0xFFE52222); // --red
  static const Color black = Color(0xFF111111); // --black
  static const Color white = Color(0xFFFFFFFF);
  static const Color offWhite = Color(0xFFF7F6F4); // --offwhite
  static const Color grey = Color(0xFF888888); // --gray
  static const Color lightGrey = Color(0xFFE8E8E8); // --light-gray
  static const Color border = Color(0xFFE2E2E2); // --border
  static const Color amber = Color(0xFFF59E0B); // --amber
  static const Color amberBg = Color(0xFFFFFBEB); // --amber-bg
  static const Color amberBorder = Color(0xFFFDE68A); // --amber-border
  static const Color amberIcon = Color(0xFFD97706); // darker amber for icons
  static const Color amberText = Color(0xFF92400E); // dark amber text
  static const Color successGreen = Color(0xFF22C55E); // online indicator
  static const Color successGreenDark = Color(0xFF16A34A); // dark green
  static const Color successGreenBg = Color(0xFFF0FDF4); // active pill bg
  static const Color successGreenBorder = Color(0xFFBBF7D0);
  static const Color dangerBg = Color(0xFFFFF5F5); // danger zone bg
  static const Color dangerBorder = Color(0xFFFECACA);
  static const Color subtleGrey = Color(0xFFBBBBBB);
  static const Color veryLightGrey = Color(0xFFEFEFEF); // divider lines
  static const Color disabledGrey = Color(0xFFCCCCCC);
  static const Color fadedGrey = Color(0xFFAAAAAA);

  // ───────── TYPOGRAPHY ─────────
  static TextStyle barlow({
    double fontSize = 14,
    FontWeight fontWeight = FontWeight.w400,
    Color color = black,
    double? letterSpacing,
    double? height,
    FontStyle? fontStyle,
    TextDecoration? decoration,
  }) {
    return GoogleFonts.barlow(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
      fontStyle: fontStyle,
      decoration: decoration,
    );
  }

  static TextStyle barlowCondensed({
    double fontSize = 14,
    FontWeight fontWeight = FontWeight.w400,
    Color color = black,
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.barlowCondensed(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
    );
  }

  static TextStyle barlowSemiCondensed({
    double fontSize = 14,
    FontWeight fontWeight = FontWeight.w400,
    Color color = black,
    double? letterSpacing,
    double? height,
  }) {
    return GoogleFonts.barlowSemiCondensed(
      fontSize: fontSize,
      fontWeight: fontWeight,
      color: color,
      letterSpacing: letterSpacing,
      height: height,
    );
  }

  // Cross-screen reusable text styles.
  static TextStyle labelCaps({
    double fontSize = 10,
    double letterSpacing = 2,
    Color color = grey,
    FontWeight fontWeight = FontWeight.w600,
  }) =>
      barlow(
        fontSize: fontSize,
        fontWeight: fontWeight,
        color: color,
        letterSpacing: letterSpacing,
      );

  /// Light theme.
  static ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: red,
      brightness: Brightness.light,
    ),
    scaffoldBackgroundColor: white,
    splashFactory: NoSplash.splashFactory,
    appBarTheme: AppBarTheme(
      backgroundColor: black,
      foregroundColor: white,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: barlow(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: white,
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: black,
        foregroundColor: white,
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        elevation: 0,
        textStyle: barlow(
          fontSize: 13,
          fontWeight: FontWeight.w800,
          color: white,
          letterSpacing: 2,
        ),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: white,
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: const OutlineInputBorder(
        borderRadius: BorderRadius.zero,
        borderSide: BorderSide(color: border, width: 1.5),
      ),
      enabledBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.zero,
        borderSide: BorderSide(color: border, width: 1.5),
      ),
      focusedBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.zero,
        borderSide: BorderSide(color: black, width: 1.5),
      ),
      errorBorder: const OutlineInputBorder(
        borderRadius: BorderRadius.zero,
        borderSide: BorderSide(color: red, width: 1.5),
      ),
      hintStyle: barlow(fontSize: 14, color: grey),
    ),
  );
}
