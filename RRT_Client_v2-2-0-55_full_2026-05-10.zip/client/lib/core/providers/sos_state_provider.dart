import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/app_constants.dart';
import '../services/sos_photo_service.dart';
import '../services/sos_voice_service.dart';

@immutable
class SosState {
  final bool isLoaded;
  final bool isActive;
  final String? senderId;
  final String? location;
  final int? activatedAtMillis;

  const SosState({
    required this.isLoaded,
    required this.isActive,
    this.senderId,
    this.location,
    this.activatedAtMillis,
  });

  const SosState.initial()
      : isLoaded = false,
        isActive = false,
        senderId = null,
        location = null,
        activatedAtMillis = null;
}

class SosStateNotifier extends StateNotifier<SosState> {
  SosStateNotifier() : super(const SosState.initial()) {
    Future.microtask(() async {
      await _loadFromStorage(reload: true);
    });
  }

  static const String _sosActiveKey = 'sos_active';
  static const String _activeSenderIdKey = 'active_sender_id';
  static const String _activeLocationKey = 'active_location';
  static const String _activeSosTimestampKey = 'active_sos_timestamp';
  /// Wall-clock millis at which the last SOS was stopped (by user, admin,
  /// or auto-expiry). Used to enforce a short rate-limit before allowing
  /// the user to send a brand-new SOS - prevents accidental double-trigger
  /// and abuse.
  static const String _lastStoppedAtKey = 'sos_last_stopped_at';
  /// Cooldown after stop before next SOS may be sent. Tunable; 30s is
  /// long enough to filter accidental re-triggers but short enough that a
  /// genuine second emergency in the same area isn't blocked unreasonably.
  static const Duration sendCooldown = Duration(seconds: 30);

  Timer? _expiryTimer;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _backendWatch;

  @override
  void dispose() {
    _expiryTimer?.cancel();
    _backendWatch?.cancel();
    super.dispose();
  }

  Future<void> activate({
    required String senderId,
    String? location,
    int? activatedAtMillis,
  }) async {
    final activatedAt = activatedAtMillis ?? DateTime.now().millisecondsSinceEpoch;
    state = SosState(
      isLoaded: true,
      isActive: true,
      senderId: senderId,
      location: location,
      activatedAtMillis: activatedAt,
    );
    await _saveToStorage();
    _scheduleExpiry(activatedAt);
    _watchBackend(senderId);
  }

  /// Listens to the user's own SOS document on the backend. Whenever the
  /// document's `active` field flips to false (because the user pressed
  /// STOP elsewhere, an admin stopped it from the dashboard, or the
  /// backend's TTL job expired it), we mirror that locally - purge any
  /// uploaded media and flip our state to inactive. This keeps the
  /// sender's screen in sync with reality even when the local stop path
  /// wasn't the one that triggered the change.
  void _watchBackend(String senderId) {
    _backendWatch?.cancel();
    try {
      _backendWatch = FirebaseFirestore.instance
          .collection('sos_alerts')
          .doc(senderId)
          .snapshots()
          .listen(
        (snap) {
          if (!snap.exists) return;
          final data = snap.data();
          if (data == null) return;
          final active = data['active'];
          // Only act when backend explicitly says inactive. If the field is
          // missing, that's a partial doc - don't make assumptions.
          if (active == false && state.isActive) {
            debugPrint('SosStateNotifier: backend marked alert inactive; '
                'syncing local state.');
            _purgeMedia(state.senderId);
            _setInactive();
          }
        },
        onError: (e) {
          // Network failure here is non-fatal - local state remains the
          // source of truth and the alert will still expire on its own
          // TTL timer or via the user pressing STOP.
          debugPrint('SosStateNotifier: backend watch error: $e');
        },
      );
    } catch (e) {
      debugPrint('SosStateNotifier: failed to start backend watch: $e');
    }
  }

  Future<void> deactivate() async {
    // Caller is responsible for purging media (the active SOS screen does
    // it before calling deactivate, since it has the service instances at
    // hand). This path is for app-state cleanup only.
    await _setInactive();
  }

  /// Fire-and-forget purge of uploaded photos + voice for the given alert.
  /// Used by the expiry timer and the stale-alert path on app launch where
  /// the UI layer isn't around to do it. Tolerant of all failures.
  static void _purgeMedia(String? senderId) {
    if (senderId == null || senderId.isEmpty) return;
    SosPhotoService.purgeAll(senderId);
    SosVoiceService.purgeAll(senderId);
  }

  Future<void> refreshFromStorage() async {
    await _loadFromStorage(reload: true);
  }

  void _scheduleExpiry(int activatedAtMillis) {
    _expiryTimer?.cancel();
    final expiresAt = DateTime.fromMillisecondsSinceEpoch(activatedAtMillis)
        .add(AppConstants.alertTtl);
    final remaining = expiresAt.difference(DateTime.now());

    if (remaining.isNegative || remaining == Duration.zero) {
      // Past TTL already - purge any lingering media before going inactive.
      _purgeMedia(state.senderId);
      _setInactive();
      return;
    }

    _expiryTimer = Timer(remaining, () {
      // Auto-expiry: purge media first, then flip state.
      _purgeMedia(state.senderId);
      _setInactive();
    });
  }

  Future<void> _loadFromStorage({bool reload = false}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (reload) {
        await prefs.reload();
      }

      final isActive = prefs.getBool(_sosActiveKey) ?? false;
      final senderId = prefs.getString(_activeSenderIdKey);
      final location = prefs.getString(_activeLocationKey);
      final storedTimestamp = prefs.getInt(_activeSosTimestampKey);
      final nowMillis = DateTime.now().millisecondsSinceEpoch;

      if (isActive) {
        final activatedAt = storedTimestamp ?? nowMillis;
        final age = Duration(milliseconds: nowMillis - activatedAt);

        if (age >= AppConstants.alertTtl) {
          // Stale alert discovered on cold start - purge any media that
          // lingered past TTL before clearing local state.
          _purgeMedia(senderId);
          await _setInactive(markLoaded: true);
          return;
        }

        state = SosState(
          isLoaded: true,
          isActive: true,
          senderId: senderId,
          location: location,
          activatedAtMillis: activatedAt,
        );

        _scheduleExpiry(activatedAt);
        if (senderId != null && senderId.isNotEmpty) {
          _watchBackend(senderId);
        }

        if (storedTimestamp == null) {
          await _saveToStorage();
        }
      } else {
        state = const SosState(isLoaded: true, isActive: false);
        _expiryTimer?.cancel();
        if (senderId != null || location != null || storedTimestamp != null) {
          await _saveToStorage();
        }
      }
    } catch (e) {
      debugPrint('SOS state load failed: $e');
      state = const SosState(isLoaded: true, isActive: false);
    }
  }

  Future<void> _setInactive({bool markLoaded = false}) async {
    _expiryTimer?.cancel();
    _expiryTimer = null;
    _backendWatch?.cancel();
    _backendWatch = null;
    state = SosState(
      isLoaded: markLoaded ? true : state.isLoaded,
      isActive: false,
    );
    await _saveToStorage();
    // Stamp the wall-clock at which we just went inactive. The home screen
    // reads this to enforce the send cooldown.
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(
          _lastStoppedAtKey, DateTime.now().millisecondsSinceEpoch);
    } catch (e) {
      debugPrint('Failed to stamp last stopped at: $e');
    }
  }

  /// Returns the remaining cooldown (zero if the user is free to send).
  /// Reads from SharedPreferences each call so the home screen always sees
  /// the latest value even if the notifier was rebuilt.
  static Future<Duration> remainingSendCooldown() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final lastStopped = prefs.getInt(_lastStoppedAtKey);
      if (lastStopped == null) return Duration.zero;
      final elapsed = Duration(
          milliseconds: DateTime.now().millisecondsSinceEpoch - lastStopped);
      final remaining = sendCooldown - elapsed;
      return remaining.isNegative ? Duration.zero : remaining;
    } catch (_) {
      return Duration.zero;
    }
  }

  Future<void> _saveToStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_sosActiveKey, state.isActive);
      if (state.senderId != null) {
        await prefs.setString(_activeSenderIdKey, state.senderId!);
      } else {
        await prefs.remove(_activeSenderIdKey);
      }
      if (state.location != null) {
        await prefs.setString(_activeLocationKey, state.location!);
      } else {
        await prefs.remove(_activeLocationKey);
      }
      if (state.activatedAtMillis != null) {
        await prefs.setInt(_activeSosTimestampKey, state.activatedAtMillis!);
      } else {
        await prefs.remove(_activeSosTimestampKey);
      }
    } catch (e) {
      debugPrint('SOS state save failed: $e');
    }
  }
}

final sosStateProvider = StateNotifierProvider<SosStateNotifier, SosState>((ref) {
  return SosStateNotifier();
});
