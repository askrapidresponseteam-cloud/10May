import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_app_installations/firebase_app_installations.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../config/api_config.dart';
import 'district_provider.dart';

/// True when the Alerts tab is the active/visible tab.
/// Driven by MainNavigationScreen on every tab tap.
/// Used to gate seen_by writes so off-screen snapshot updates don't count.
final alertsScreenActiveProvider = StateProvider<bool>((ref) => false);

/// The currently selected bottom-nav tab index.
/// Exposed as a provider so NotificationService can switch tabs without a BuildContext.
final activeTabIndexProvider = StateProvider<int>((ref) => 0);

/// In-memory cache of already-seen alert instance keys.
/// Key format: "{sender_id}:{timestamp_ms}" - the timestamp component ensures
/// a repeated SOS from the same sender is treated as a fresh unseen alert.
/// Not autoDispose - intentionally survives tab switches within a session.
final seenAlertCacheProvider = StateProvider<Set<String>>((ref) => {});

/// Builds the cache key for an alert map entry.
String _cacheKey(Map<String, dynamic> alert) =>
    '${alert['sender_id']}:${alert['timestamp']}';

/// True iff at least one alert in [activeAlertsProvider] has not yet been
/// marked-seen for the current user. Powers the red dot beside the ALERTS
/// tab in the bottom nav: the dot appears the moment a fresh alert lands
/// and clears as soon as the user opens the Alerts tab (which triggers
/// mark-seen and updates [seenAlertCacheProvider]).
///
/// Returns false during loading/error states - better to under-show than
/// to flash a phantom dot.
final hasUnseenAlertsProvider = Provider<bool>((ref) {
  final alertsAsync = ref.watch(activeAlertsProvider);
  final seen = ref.watch(seenAlertCacheProvider);
  final alerts = alertsAsync.valueOrNull ?? const [];
  for (final a in alerts) {
    if (!seen.contains(_cacheKey(a))) return true;
  }
  return false;
});

/// Fire-and-forget: POST /sos/mark-seen only for alerts not yet in the cache.
/// Returns the set of cache keys that were newly sent so the caller can update
/// [seenAlertCacheProvider] - keeping ref out of this pure helper.
Future<Set<String>> markAlertsSeen(
  List<Map<String, dynamic>> alerts,
  String fid,
  Set<String> alreadySeen,
) async {
  final unseen = alerts.where((a) => !alreadySeen.contains(_cacheKey(a))).toList();
  if (unseen.isEmpty) return {};

  final alertIds = unseen
      .map((a) => a['sender_id'] as String?)
      .whereType<String>()
      .toList();

  if (alertIds.isEmpty) return {};

  try {
    await http.post(
      Uri.parse(ApiConfig.markSeenEndpoint),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'fid': fid, 'alert_ids': alertIds}),
    ).timeout(const Duration(seconds: 10));
    debugPrint('👁️  mark-seen sent for ${alertIds.length} alert(s)');
  } catch (e) {
    debugPrint('mark-seen failed (non-fatal): $e');
  }

  // Return keys regardless of HTTP success - if the call fails the backend
  // is idempotent, and we don't want to hammer it on every snapshot retry.
  return unseen.map(_cacheKey).toSet();
}

/// Streams active SOS alerts from Firestore for the user's district.
/// Firestore is the single source of truth; FCM only signals new alerts.
final activeAlertsProvider = StreamProvider.autoDispose<List<Map<String, dynamic>>>((ref) {
  final districtAsync = ref.watch(currentDistrictProvider);

  return districtAsync.when(
    data: (district) {
      if (district == null || district.isEmpty) {
        return Stream.value(<Map<String, dynamic>>[]);
      }
      return _alertsStreamForDistrict(district);
    },
    loading: () => Stream.value(<Map<String, dynamic>>[]),
    error: (e, _) {
      debugPrint('District load error for alerts: $e');
      return Stream.value(<Map<String, dynamic>>[]);
    },
  );
});

/// Firestore stream: active alerts for district, filtered to exclude own alerts
Stream<List<Map<String, dynamic>>> _alertsStreamForDistrict(String district) async* {
  try {
    final currentSenderId = await FirebaseInstallations.instance.getId();

    await for (final snapshot in FirebaseFirestore.instance
        .collection('sos_alerts')
        .where('district', isEqualTo: district)
        .where('active', isEqualTo: true)
        .orderBy('timestamp', descending: true)
        .limit(50)
        .snapshots()) {
      final alerts = <Map<String, dynamic>>[];
      for (final doc in snapshot.docs) {
        final data = doc.data();
        final senderId = doc.id;

        // Exclude own alerts
        if (senderId == currentSenderId) continue;

        final userInfo = data['userInfo'] as Map<String, dynamic>? ?? {};
        final location = data['location'] as Map<String, dynamic>? ?? {};

        final timestampValue = data['timestamp'];
        int timestampMs = DateTime.now().millisecondsSinceEpoch;
        if (timestampValue != null) {
          if (timestampValue is Timestamp) {
            timestampMs = timestampValue.millisecondsSinceEpoch;
          } else if (timestampValue is int) {
            timestampMs = timestampValue;
          }
        }

        // NOTE: there used to be a client-side filter here that hid
        // alerts whose age (DateTime.now() - timestampMs) exceeded 60
        // minutes. That was unsafe: the device clock is user-mutable,
        // and a phone whose clock was set into the future would
        // silently hide live emergencies from the responder's list -
        // a much worse failure than briefly showing a stale alert that
        // the server has not yet flipped to inactive.
        //
        // The server is now the authoritative source of truth for
        // whether an alert is current:
        //   - The Firestore query above already filters on active==true.
        //   - A 60-min Cloud Task auto-expire flips active->false.
        //   - An hourly fallback sweep catches any that the task missed.
        //   - Both paths fire a resolution FCM that dismisses the
        //     responder's notification tray entry.
        // So an active==true doc should always represent a current
        // emergency. We trust that flag here instead of the device clock.
        // _ = timestampMs;  // kept on the alert map below for display only

        alerts.add({
          'sender_id': senderId,
          'sender_name': userInfo['name'] ?? 'Unknown User',
          'name': userInfo['name'] ?? 'Unknown User',
          'district': data['district'] ?? '',
          'approx_loc': data['approx_loc'] ?? userInfo['location'] ?? data['district'] ?? 'Unknown Location',
          'exact_lat': _parseDouble(location['latitude']),
          'exact_lng': _parseDouble(location['longitude']),
          'message': userInfo['message'] ?? 'Emergency assistance needed',
          'mobile_number': userInfo['mobile_number'] ?? userInfo['phone'] ?? '',
          'timestamp': timestampMs,
          'photo_urls': List<String>.from(data['photo_urls'] ?? []),
          'voice_url': (data['voice_url'] as String?) ?? '',
          // Admin-raised alerts come from the dashboard, not a real device.
          // Chat would have nowhere to deliver replies, so the alert card
          // hides the CHAT button when this is true.
          'is_admin_raised': userInfo['is_admin_raised'] == true ||
              data['is_admin_raised'] == true,
        });
      }
      debugPrint('✅ Firestore alerts updated: ${alerts.length} for district $district');
      yield alerts;
    }
  } catch (e, st) {
    debugPrint('Firestore alerts stream error: $e\n$st');
    yield [];
  }
}

/// Streams the seen_by count for the current user's own active SOS alert.
/// Watches the single sos_alerts/{senderId} document and returns the number
/// of map keys in seen_by - no extra queries, just one document listener.
final myAlertSeenCountProvider =
    StreamProvider.autoDispose.family<int, String>((ref, senderId) {
  return FirebaseFirestore.instance
      .collection('sos_alerts')
      .doc(senderId)
      .snapshots()
      .map((doc) {
    if (!doc.exists) return 0;
    final seenBy = doc.data()?['seen_by'] as Map<String, dynamic>?;
    return seenBy?.length ?? 0;
  });
});

/// Streams the server-written timestamp (ms) for the current user's own active
/// SOS alert. Used by the countdown timer in the home screen card.
/// Reuses the same Firestore document listener as [myAlertSeenCountProvider] -
/// no extra reads or connections.
final myAlertTimestampProvider =
    StreamProvider.autoDispose.family<int?, String>((ref, senderId) {
  return FirebaseFirestore.instance
      .collection('sos_alerts')
      .doc(senderId)
      .snapshots()
      .map((doc) {
    if (!doc.exists) return null;
    final ts = doc.data()?['timestamp'];
    if (ts == null) return null;
    if (ts is Timestamp) return ts.millisecondsSinceEpoch;
    if (ts is int) return ts;
    return null;
  });
});

double? _parseDouble(dynamic value) {
  if (value == null) return null;
  if (value is double) return value;
  if (value is int) return value.toDouble();
  if (value is String) return double.tryParse(value);
  return null;
}
