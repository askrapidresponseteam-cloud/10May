import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_app_installations/firebase_app_installations.dart';

/// Streams all conversations the current user participates in that have at
/// least one message, ordered by most recent message activity.
///
/// **What this provider does NOT do:** it does not check whether the linked
/// SOS alert is still active. That responsibility belongs entirely to
/// [chatSessionActiveProvider], which opens a live Firestore stream per
/// conversation and reacts instantly when an alert expires.
///
/// Keeping these concerns separate means:
///   - Zero extra Firestore reads here - only the sos_conversations query runs.
///   - Active/archived state is always real-time (stream, not a snapshot poll).
///   - Archived conversations remain visible in the list with a visual indicator
///     so users can review the chat history after an emergency resolves.
final conversationsProvider =
    StreamProvider.autoDispose<List<Map<String, dynamic>>>((ref) async* {
  String fid;
  try {
    fid = await FirebaseInstallations.instance.getId();
  } catch (e) {
    debugPrint('conversationsProvider: failed to get FID: $e');
    yield [];
    return;
  }

  await for (final snap in FirebaseFirestore.instance
      .collection('sos_conversations')
      .where('participants', arrayContains: fid)
      .orderBy('last_message_at', descending: true)
      .snapshots()) {
    final conversations = <Map<String, dynamic>>[];

    for (final doc in snap.docs) {
      // Only surface conversations that have at least one message -
      // prevents ghost chats from showing up when initiation races.
      final messages = doc.data()['messages'] as List<dynamic>? ?? [];
      if (messages.isEmpty) continue;

      conversations.add(<String, dynamic>{'conv_id': doc.id, ...doc.data()});
    }

    yield conversations;
  }
});

/// Streams a single conversation document by ID.
final conversationDocProvider =
    StreamProvider.autoDispose.family<Map<String, dynamic>?, String>(
        (ref, convId) {
  return FirebaseFirestore.instance
      .collection('sos_conversations')
      .doc(convId)
      .snapshots()
      .map((doc) {
    if (!doc.exists) return null;
    return <String, dynamic>{'conv_id': doc.id, ...doc.data()!};
  });
});

/// Streams whether a specific chat session is currently active.
///
/// Active means at least ONE of these holds:
///   1. Primary session: sos_alerts/{owner} is active and
///      active_session_id matches session
///   2. Secondary session: sos_alerts/{owner2} is active and
///      active_session_id matches session2
///
/// This supports bidirectional chat: when two users both have active SOS
/// alerts and both tap CHAT on each other's alerts, the conversation
/// stays active as long as EITHER person's SOS is still live.
///
/// The parameter is a record with 4 fields:
///   (owner, session, owner2, session2)
final chatSessionActiveProvider = StreamProvider.autoDispose
    .family<bool, ({String owner, String session, String owner2, String session2})>(
        (ref, params) {
  final hasPrimary = params.owner.isNotEmpty && params.session.isNotEmpty;
  final hasSecondary = params.owner2.isNotEmpty && params.session2.isNotEmpty;

  // No session info at all - inactive
  if (!hasPrimary && !hasSecondary) return Stream.value(false);

  // Single session (backward compatible with old conv docs)
  if (hasPrimary && !hasSecondary) {
    return FirebaseFirestore.instance
        .collection('sos_alerts')
        .doc(params.owner)
        .snapshots()
        .map((doc) {
      if (!doc.exists) return false;
      final data = doc.data()!;
      return data['active'] == true &&
          data['active_session_id'] == params.session;
    });
  }

  // Two sessions - merge with OR logic using a StreamController.
  // We capture both subscriptions explicitly so onDispose can cancel
  // them. Without these cancellations the underlying Firestore listeners
  // outlive the provider and silently keep paying for reads forever
  // (they emit into a closed controller which is a no-op, but the
  // network listener stays open until the app is force-quit).
  final controller = StreamController<bool>.broadcast();
  var state1 = false;
  var state2 = false;

  void emit() {
    if (!controller.isClosed) controller.add(state1 || state2);
  }

  final sub1 = FirebaseFirestore.instance
      .collection('sos_alerts')
      .doc(params.owner)
      .snapshots()
      .listen((doc) {
    if (!doc.exists) {
      state1 = false;
    } else {
      final data = doc.data()!;
      state1 = data['active'] == true &&
          data['active_session_id'] == params.session;
    }
    emit();
  });

  final sub2 = FirebaseFirestore.instance
      .collection('sos_alerts')
      .doc(params.owner2)
      .snapshots()
      .listen((doc) {
    if (!doc.exists) {
      state2 = false;
    } else {
      final data = doc.data()!;
      state2 = data['active'] == true &&
          data['active_session_id'] == params.session2;
    }
    emit();
  });

  // Cancel order matters: cancel the upstream subscriptions FIRST so
  // a late-arriving Firestore emission can't try to write into an
  // already-closed controller. The cancel() futures are not awaited
  // here (onDispose is sync) - that's fine, cancellation is best-effort
  // and the listen callback's isClosed guard above is the safety net.
  ref.onDispose(() {
    sub1.cancel();
    sub2.cancel();
    if (!controller.isClosed) controller.close();
  });

  return controller.stream;
});
