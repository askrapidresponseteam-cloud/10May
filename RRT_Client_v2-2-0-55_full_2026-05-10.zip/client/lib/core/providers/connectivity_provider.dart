import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Live network reachability status, surfaced to the UI as a simple bool.
///
/// Drives the dot in the top bar (green = online, red = offline). Using
/// `connectivity_plus` we get push-style updates from the OS the instant
/// wifi drops, mobile data toggles, or airplane mode is enabled - no
/// polling, no battery cost.
///
/// We treat anything that is not `ConnectivityResult.none` as online -
/// even "wifi without internet" reads as online, which is a deliberate
/// choice. The dot is a glance-level "do I have signal" indicator, not
/// a deep reachability probe.
final connectivityProvider = StreamProvider<bool>((ref) async* {
  final conn = Connectivity();

  // Emit the current status immediately so subscribers don't have to wait
  // for the first OS event after start-up.
  try {
    final initial = await conn.checkConnectivity();
    yield _isOnline(initial);
  } catch (e) {
    debugPrint('connectivityProvider: initial check failed: $e');
    // If we can't determine, optimistically assume online so the dot
    // doesn't flash red on a cold start with a healthy network.
    yield true;
  }

  // Stream subsequent changes.
  yield* conn.onConnectivityChanged.map(_isOnline);
});

bool _isOnline(List<ConnectivityResult> results) {
  // connectivity_plus 6.x emits a List (a device can have wifi + ethernet
  // simultaneously). Online iff at least one entry isn't `none`.
  if (results.isEmpty) return false;
  return results.any((r) => r != ConnectivityResult.none);
}
