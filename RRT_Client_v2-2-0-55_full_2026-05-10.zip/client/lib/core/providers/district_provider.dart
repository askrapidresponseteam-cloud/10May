import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/district_subscription_service.dart';

/// Provider for district subscription service
final districtSubscriptionServiceProvider = Provider<DistrictSubscriptionService>((ref) {
  return DistrictSubscriptionService();
});

/// District the user is subscribed to (for FCM topic + Firestore alerts query).
/// Uses last subscribed district from SharedPreferences.
final currentDistrictProvider = FutureProvider<String?>((ref) async {
  final service = ref.read(districtSubscriptionServiceProvider);
  return service.getLastSubscribedDistrict();
});
