import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Polled count of responders in a given district key.
///
/// Why this exists:
/// The conversations screen's district-strip used to live-stream the entire
/// `subscribed_users` collection just to display the responder count text
/// ("123 responders in this area"). For a district with N responders, that
/// cost N Firestore reads per screen mount, plus more on every snapshot
/// refresh. With many users opening the chat tab daily it dominated reads.
///
/// This provider replaces that with a polled Firestore `count()` aggregation:
///   • One read per poll regardless of district size (exact billing rule:
///     1 read per 1000 docs matched, per Firestore docs).
///   • Polled every 60s while the screen is open; cancelled automatically
///     when the widget disposes (StreamProvider.autoDispose + onDispose
///     cancels the periodic timer).
///   • Failure-tolerant: a network error emits 0 to the UI and retries on
///     the next tick rather than throwing a red Riverpod error to the user.
///
/// Tradeoff vs. the old streaming approach:
///   • The number won't tick up live — it can lag by up to 60s. For a
///     subtitle that just shows "X responders in this area", this is fine
///     and unobservable to users.
///
/// The full subscriber list in `_SubscribersSheet` and `RespondersScreen`
/// still uses live `.snapshots()` — those are opened on user tap (not on
/// every screen mount) so their cost is bounded and the live behavior is
/// still desirable when the user is actively reviewing the list.
final subscribersCountProvider =
    StreamProvider.autoDispose.family<int, String>((ref, districtKey) {
  // No district yet → emit 0 forever (no query at all).
  if (districtKey.isEmpty) {
    return Stream.value(0);
  }

  final controller = StreamController<int>();
  Timer? timer;
  var disposed = false;

  Future<void> fetch() async {
    if (disposed) return;
    try {
      final agg = await FirebaseFirestore.instance
          .collection('subscribed_users')
          .where('district', isEqualTo: districtKey)
          .count()
          .get();
      if (disposed || controller.isClosed) return;
      controller.add(agg.count ?? 0);
    } catch (e) {
      // Network/permission issues → emit 0 and try again on next tick.
      // Never propagate as an error: the UI is a passive subtitle and
      // we don't want the count widget to flash an error state for a
      // transient connectivity blip.
      debugPrint('subscribersCountProvider: count() failed: $e');
      if (!disposed && !controller.isClosed) {
        controller.add(0);
      }
    }
  }

  // Fire immediately so the badge shows up without waiting 60s.
  fetch();
  // Then poll. 60s is conservative — counts change slowly in practice
  // (a new responder onboarding is rare) and a longer interval keeps
  // costs predictable.
  timer = Timer.periodic(const Duration(seconds: 60), (_) => fetch());

  ref.onDispose(() {
    disposed = true;
    timer?.cancel();
    controller.close();
  });

  return controller.stream;
});
