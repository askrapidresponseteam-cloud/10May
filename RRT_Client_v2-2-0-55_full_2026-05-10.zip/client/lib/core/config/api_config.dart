import '../services/remote_config_service.dart';

/// Single source of truth for backend HTTP endpoints. If you find yourself
/// constructing a URL inline somewhere else in the codebase, add it here
/// instead - it makes the entire backend surface visible in one file.
class ApiConfig {
  static String get baseUrl => RemoteConfigService.cloudFunctionBaseUrl;

  // ---- SOS ---------------------------------------------------------------
  static String get sosEndpoint => '$baseUrl/sos';
  static String get markSeenEndpoint => '$baseUrl/sos/mark-seen';
  static String get attachPhotoEndpoint => '$baseUrl/sos/attach-photo';
  static String get detachPhotoEndpoint => '$baseUrl/sos/detach-photo';
  static String get attachVoiceEndpoint => '$baseUrl/sos/attach-voice';
  static String get detachVoiceEndpoint => '$baseUrl/sos/detach-voice';

  // ---- Subscriptions / user data ----------------------------------------
  static String get subscribeUserEndpoint => '$baseUrl/subscribe-user';
  static String get deleteUserDataEndpoint => '$baseUrl/delete-user-data';

  // ---- Chat --------------------------------------------------------------
  static String get chatInitiateEndpoint => '$baseUrl/chat/initiate';
  static String get chatSendMessageEndpoint => '$baseUrl/chat/send-message';
  static String get chatAttachPhotoEndpoint => '$baseUrl/chat/attach-photo';
  static String get chatDetachPhotoEndpoint => '$baseUrl/chat/detach-photo';
  static String get chatAttachVoiceEndpoint => '$baseUrl/chat/attach-voice';
  static String get chatDetachVoiceEndpoint => '$baseUrl/chat/detach-voice';

  // ---- Geocode / district lookup ----------------------------------------
  // GET with ?lat=&lng= query params; returns { district }.
  static String get geocodeDistrictEndpoint => '$baseUrl/geocode/district';

  // ---- Help / contact form ----------------------------------------------
  static String get feedbackEmailEndpoint => '$baseUrl/feedback';

  // NOTE: photo and voice BYTES are uploaded directly to Firebase Storage
  // (sos_photos/{senderId}/... and sos_voice/{senderId}/...). The URL
  // returned by Storage is then attached to the alert via the
  // attachPhotoEndpoint / attachVoiceEndpoint above. The client never
  // writes to sos_alerts directly - Firestore Security Rules deny that.

  // ---- Ola Maps (vet search) --------------------------------------------
  //
  // Ola Maps powers the "look up a vet" feature. We use ONE endpoint:
  // Nearby Search. Other Ola endpoints (Directions, Geocoding, Vector
  // Tiles, etc.) exist on the same Freemium-plan credential but we never
  // call them - simpler integration, smaller blast radius if the key
  // ever leaks.
  //
  // The search returns up to ~20 places ranked by distance. We cache
  // aggressively (memory -> shared_preferences -> Firestore cell cache)
  // so the actual HTTP call only fires on a full cold miss. See
  // VetSearchService for the cache layering.
  //
  // The API key is injected at build time via --dart-define. NEVER
  // hardcode it here, NEVER commit it to git. Build invocation:
  //   flutter build apk --dart-define=OLA_MAPS_API_KEY=<key>
  //
  // If the key is missing at runtime (empty string), the service skips
  // the Ola call entirely and the screen falls back to the "Open in
  // Google Maps" button. This means a build without the key still
  // ships a working feature - just a degraded one.
  static String get olaMapsNearbySearchEndpoint =>
      'https://api.olamaps.io/places/v1/nearbysearch';

  /// Place Details endpoint - used to fetch coordinates for a vet
  /// when the user taps "Directions". Nearby Search responses don't
  /// include lat/lng, so we lazy-fetch them per-vet only on demand.
  /// Cached permanently (per device) keyed by place_id once fetched,
  /// since places don't move.
  static String get olaMapsPlaceDetailsEndpoint =>
      'https://api.olamaps.io/places/v1/details';

  // Build-time key. Empty if not provided at compile time, in which case
  // VetSearchService disables the Ola call path and the feature degrades
  // to the Google Maps fallback only.
  static const String olaMapsApiKey = String.fromEnvironment(
    'OLA_MAPS_API_KEY',
    defaultValue: '',
  );

  static bool get olaMapsEnabled => olaMapsApiKey.isNotEmpty;
}
