import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

/// LocationBar - the grey pin + "District, State" row with a refresh icon.
/// Used at the top of Home and Active SOS screens.
/// Matches HTML style: 10px vertical padding, bottom border, grey text.
class LocationBar extends StatelessWidget {
  final String text;
  final VoidCallback? onRefresh;
  final bool isRefreshing;

  const LocationBar({
    super.key,
    required this.text,
    this.onRefresh,
    this.isRefreshing = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: AppTheme.border, width: 1)),
      ),
      child: Row(
        children: [
          const Icon(Icons.location_on_outlined, size: 14, color: AppTheme.grey),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              text,
              overflow: TextOverflow.ellipsis,
              style: AppTheme.barlow(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppTheme.black,
                letterSpacing: -0.2,
              ),
            ),
          ),
          GestureDetector(
            onTap: isRefreshing ? null : onRefresh,
            behavior: HitTestBehavior.opaque,
            child: isRefreshing
                ? const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                      strokeWidth: 1.5,
                      valueColor: AlwaysStoppedAnimation<Color>(AppTheme.grey),
                    ),
                  )
                : const Icon(Icons.refresh, size: 16, color: AppTheme.grey),
          ),
        ],
      ),
    );
  }
}

/// AmberNotice - the warning/notice box with amber border and icon.
/// Used on Home to show "Important Notice - volunteers NOT emergency services".
class AmberNotice extends StatelessWidget {
  final String title;
  final String body;

  const AmberNotice({super.key, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 14, 20, 0),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.amberBg,
        border: Border.all(color: AppTheme.amberBorder, width: 1),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 1),
            child: Icon(Icons.warning_amber_rounded,
                size: 16, color: AppTheme.amberIcon),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title.toUpperCase(),
                  style: AppTheme.barlow(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.amberIcon,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  body,
                  style: AppTheme.barlow(
                    fontSize: 12,
                    color: AppTheme.amberText,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
