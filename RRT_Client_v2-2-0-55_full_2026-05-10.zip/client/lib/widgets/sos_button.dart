import 'dart:async';
import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

/// SosButton - the animated hold-to-send red circle.
///
/// Matches the HTML HomeScreen button exactly:
///   • Outer pulse ring (220×220) - faint red radial gradient
///   • Mid ring (174×174) - 1px hairline red border at 18% opacity
///   • Shell (167×167) - red radial gradient (#ff4444 → #cc1111),
///     heavy layered drop-shadow, subtle inner highlight
///   • Inner recessed core (141×141) - darker gradient,
///     inset shadow, white glass-shine blob near the top
///   • Circular progress arc drawn over the core while held
///   • "SOS" label in Barlow Condensed 900 44px, 3px letter-spacing
///
/// User interaction:
///   • Hold for [holdDuration] → triggers [onComplete]
///   • Release early → cancels, rings animate back
class SosButton extends StatefulWidget {
  final VoidCallback onComplete;

  /// Called the instant the user presses the button, BEFORE the hold
  /// animation begins. Return `false` to abort the press - the ring
  /// animation won't start and `onComplete` won't fire. Use this for
  /// pre-flight validation (mandatory description, rate-limit cooldown,
  /// missing permission etc.) so the user gets immediate feedback
  /// instead of having to hold for the full duration first.
  ///
  /// If null, presses always proceed.
  final bool Function()? onHoldStart;

  final Duration holdDuration;
  final bool enabled;

  const SosButton({
    super.key,
    required this.onComplete,
    this.onHoldStart,
    this.holdDuration = const Duration(seconds: 3),
    this.enabled = true,
  });

  @override
  State<SosButton> createState() => _SosButtonState();
}

class _SosButtonState extends State<SosButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  bool _held = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: widget.holdDuration,
    )..addStatusListener((status) {
        if (status == AnimationStatus.completed) {
          _held = false;
          widget.onComplete();
          _controller.reset();
          if (mounted) setState(() {});
        }
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _start() {
    if (!widget.enabled) return;
    // Pre-flight check: lets the parent veto the hold (e.g. when the
    // mandatory description is empty or a cooldown is active). The
    // callback is responsible for surfacing its own user-facing
    // feedback - we just respect its decision.
    if (widget.onHoldStart != null && !widget.onHoldStart!()) {
      return;
    }
    setState(() => _held = true);
    _controller.forward();
  }

  void _end() {
    if (!_held) return;
    setState(() => _held = false);
    _controller.reset();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 220,
      height: 220,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // OUTER PULSE (220x220) - faint red radial glow
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
            width: 220 * (_held ? 1.18 : 1.0),
            height: 220 * (_held ? 1.18 : 1.0),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  AppTheme.red.withValues(alpha: _held ? 0.18 : 0.13),
                  AppTheme.red.withValues(alpha: _held ? 0.06 : 0.04),
                  Colors.transparent,
                ],
                stops: const [0.0, 0.55, 0.72],
              ),
            ),
          ),
          // MID RING (174x174) - hairline
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
            width: 174 * (_held ? 1.06 : 1.0),
            height: 174 * (_held ? 1.06 : 1.0),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: AppTheme.red.withValues(alpha: 0.18),
                width: 1,
              ),
            ),
          ),
          // OUTER SHELL (167x167) - gradient + shadow
          GestureDetector(
            onTapDown: (_) => _start(),
            onTapUp: (_) => _end(),
            onTapCancel: _end,
            behavior: HitTestBehavior.opaque,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              curve: Curves.easeOut,
              width: 167,
              height: 167,
              transform: _held
                  ? (Matrix4.identity()
                    ..translate(0.0, 2.0)
                    ..scale(0.96))
                  : Matrix4.identity(),
              transformAlignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  begin: Alignment(-0.5, -0.8),
                  end: Alignment(0.5, 0.8),
                  colors: [Color(0xFFFF4444), Color(0xFFCC1111)],
                ),
                boxShadow: _held
                    ? [
                        BoxShadow(
                          color: AppTheme.red.withValues(alpha: 0.3),
                          offset: const Offset(0, 2),
                          blurRadius: 8,
                        ),
                        BoxShadow(
                          color: AppTheme.red.withValues(alpha: 0.55),
                          offset: const Offset(0, 16),
                          blurRadius: 48,
                        ),
                      ]
                    : [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.25),
                          offset: const Offset(0, 4),
                          blurRadius: 12,
                        ),
                        BoxShadow(
                          color: AppTheme.red.withValues(alpha: 0.45),
                          offset: const Offset(0, 16),
                          blurRadius: 40,
                        ),
                        BoxShadow(
                          color: AppTheme.red.withValues(alpha: 0.2),
                          offset: const Offset(0, 32),
                          blurRadius: 64,
                        ),
                      ],
              ),
              // INNER CORE (141x141) - darker gradient + inset + shine + arc
              child: Center(
                child: SizedBox(
                  width: 141,
                  height: 141,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Core disc
                      Container(
                        width: 141,
                        height: 141,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            begin: Alignment(-0.2, -1),
                            end: Alignment(0.2, 1),
                            colors: [
                              Color(0xFFD41010),
                              Color(0xFFB80C0C),
                              Color(0xFF9A0808),
                            ],
                            stops: [0.0, 0.6, 1.0],
                          ),
                        ),
                      ),
                      // Inset shadow simulation via a custom painter
                      CustomPaint(
                        size: const Size(141, 141),
                        painter: _InsetShadowPainter(),
                      ),
                      // Glass shine - small elliptical white highlight near top
                      Positioned(
                        top: 8,
                        child: Container(
                          width: 80,
                          height: 40,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.white.withValues(alpha: 0.28),
                                Colors.white.withValues(alpha: 0),
                              ],
                            ),
                            borderRadius:
                                const BorderRadius.all(Radius.elliptical(40, 20)),
                          ),
                        ),
                      ),
                      // Progress arc (only while held) - sweeps clockwise
                      if (_held)
                        AnimatedBuilder(
                          animation: _controller,
                          builder: (_, __) => CustomPaint(
                            size: const Size(141, 141),
                            painter: _ArcPainter(_controller.value),
                          ),
                        ),
                      // SOS label
                      Text(
                        'SOS',
                        style: AppTheme.barlowCondensed(
                          fontSize: 44,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          height: 1,
                          letterSpacing: 3,
                        ).copyWith(
                          shadows: const [
                            Shadow(
                              color: Color(0x4D000000),
                              offset: Offset(0, 2),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Paints a subtle inset shadow on the inner core to fake the CSS
/// `inset 0 3px 12px rgba(0,0,0,0.35)` from the HTML.
class _InsetShadowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    // Top inset darkening arc - a thin ring on the top edge
    final paint = Paint()
      ..shader = RadialGradient(
        center: const Alignment(0, -0.7),
        radius: 0.9,
        colors: [
          Colors.black.withValues(alpha: 0.0),
          Colors.black.withValues(alpha: 0.35),
        ],
        stops: const [0.85, 1.0],
      ).createShader(Rect.fromCircle(center: c, radius: r));
    canvas.drawCircle(c, r, paint);
  }

  @override
  bool shouldRepaint(_) => false;
}

/// Paints a circular progress arc stroke for the hold-to-send affordance.
/// Matches HTML: stroke = rgba(255,255,255,0.3), width 4, cap round.
class _ArcPainter extends CustomPainter {
  final double progress; // 0..1
  _ArcPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 6.5; // r=64 in 141/2 coordinate space
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: 0.3)
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final rect = Rect.fromCircle(center: center, radius: radius);
    // -pi/2 start = 12 o'clock, clockwise to 2*pi*progress
    canvas.drawArc(rect, -1.5707963267948966, 6.283185307179586 * progress,
        false, paint);
  }

  @override
  bool shouldRepaint(covariant _ArcPainter old) => old.progress != progress;
}
