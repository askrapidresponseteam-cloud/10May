import 'package:flutter/material.dart';

/// PawIcon - the RRT brand mark.
/// Uses Material's built-in `Icons.pets` which renders as a paw print.
class PawIcon extends StatelessWidget {
  final double size;
  final Color color;
  const PawIcon({super.key, this.size = 18, this.color = Colors.white});

  @override
  Widget build(BuildContext context) {
    return Icon(Icons.pets, size: size, color: color);
  }
}
