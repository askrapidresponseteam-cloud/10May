import 'dart:io';
import 'package:flutter/material.dart';
import '../core/services/force_update_service.dart';
import '../core/theme/app_theme.dart';

/// Full-screen non-dismissible blocker shown when the installed build is
/// behind the latest store release.
///
/// Design language matches the rest of the app:
///   • Strict zero border-radius (square corners everywhere).
///   • Barlow / Barlow Condensed type, weights 400 / 800.
///   • AppTheme.red primary CTA, all-caps + 1.5 letter-spacing.
///   • Pure white surface, hairline 1px border (AppTheme.border).
///   • No drop shadows, no Material elevation.
///
/// The back button and barrier tap are both disabled (PopScope canPop:
/// false + showDialog barrierDismissible: false). The only way out is
/// to tap UPDATE NOW which deep-links to the relevant store.
class ForceUpdateDialog extends StatelessWidget {
  final ForceUpdateInfo updateInfo;

  const ForceUpdateDialog({super.key, required this.updateInfo});

  /// Per-platform copy. We avoid hardcoding "Play Store" everywhere —
  /// iOS users would see wrong-store wording and lose trust.
  String get _storeName =>
      Platform.isIOS ? 'App Store' : Platform.isAndroid ? 'Play Store' : 'store';

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Dialog(
        backgroundColor: AppTheme.white,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        // Square corners — matches every other dialog/button in the app.
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        child: Container(
          decoration: const BoxDecoration(
            color: AppTheme.white,
            border: Border.fromBorderSide(
              BorderSide(color: AppTheme.border, width: 1),
            ),
          ),
          padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Red kicker label — same pattern used on alerts & onboarding.
              Text(
                'UPDATE REQUIRED',
                style: AppTheme.barlow(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.red,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 12),

              // Big condensed headline — same family used for "Need / Help?"
              // on the help screen and other big page titles.
              Text(
                'A new version is\navailable.',
                style: AppTheme.barlowCondensed(
                  fontSize: 32,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.black,
                  height: 1.05,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 14),

              // Body copy — Barlow regular, mid-grey. Matches StopConfirm
              // and other blocking dialogs.
              Text(
                'Please update to continue using Rapid '
                'Response Team. Newer builds include important '
                'fixes for SOS delivery and responder notifications.',
                style: AppTheme.barlow(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: const Color(0xFF555555),
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 18),

              // Hairline divider — same 1px AppTheme.border separator
              // used across cards/rows.
              Container(height: 1, color: AppTheme.border),
              const SizedBox(height: 14),

              // Version comparison row. Two small caps labels with
              // monospace-feeling alignment (achieved via fixed widths
              // + barlow w800 for the value).
              _VersionLine(
                label: 'INSTALLED',
                value: updateInfo.installedVersion,
              ),
              const SizedBox(height: 6),
              _VersionLine(
                label: 'AVAILABLE',
                value: updateInfo.latestVersion,
                emphasised: true,
              ),
              const SizedBox(height: 22),

              // Primary CTA — full-width red bar, caps + letter-spacing.
              // Mirrors the STOP SOS button on active_sos_screen.
              GestureDetector(
                onTap: () => _openStore(context),
                behavior: HitTestBehavior.opaque,
                child: Container(
                  height: 52,
                  width: double.infinity,
                  color: AppTheme.red,
                  alignment: Alignment.center,
                  child: Text(
                    'UPDATE NOW',
                    style: AppTheme.barlow(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.white,
                      letterSpacing: 2,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // Manual fallback line — platform-aware so iOS users
              // don't see "Play Store" wording.
              Text(
                'If the $_storeName doesn\'t open, search\n'
                '"Rapid Response Team" on the $_storeName.',
                textAlign: TextAlign.center,
                style: AppTheme.barlow(
                  fontSize: 11,
                  fontWeight: FontWeight.w400,
                  color: AppTheme.grey,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openStore(BuildContext context) async {
    // Android with Play Core immediate-update support: trigger Google's
    // native full-screen update flow. Downloads + installs in-app and
    // relaunches the app on the new version. No Play Store bounce.
    if (updateInfo.canUpdateInApp) {
      final ok = await ForceUpdateService.performImmediateAndroidUpdate();
      if (ok) {
        // OS already took over; if we somehow get back here the update
        // completed and the app was relaunched, so nothing to do.
        return;
      }
      // Native flow failed (user cancelled, Play Core error, etc.).
      // Fall through to the store-page fallback so they have a path.
    }

    final opened = await ForceUpdateService.openStorePage();
    if (!opened && context.mounted) {
      // Square, white-on-black snackbar — matches app theme.
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: AppTheme.black,
          behavior: SnackBarBehavior.floating,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.zero,
          ),
          content: Text(
            'Could not open the $_storeName. Please update manually.',
            style: AppTheme.barlow(
              fontSize: 13,
              fontWeight: FontWeight.w500,
              color: AppTheme.white,
            ),
          ),
          duration: const Duration(seconds: 4),
        ),
      );
    }
  }
}

/// Single label/value row used in the version-comparison strip.
/// Kept as a small private widget so the two rows align identically.
class _VersionLine extends StatelessWidget {
  final String label;
  final String value;
  final bool emphasised;

  const _VersionLine({
    required this.label,
    required this.value,
    this.emphasised = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 92,
          child: Text(
            label,
            style: AppTheme.barlow(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              color: AppTheme.grey,
              letterSpacing: 2,
            ),
          ),
        ),
        Text(
          value,
          style: AppTheme.barlow(
            fontSize: 13,
            fontWeight: FontWeight.w800,
            color: emphasised ? AppTheme.red : AppTheme.black,
            letterSpacing: -0.2,
          ),
        ),
      ],
    );
  }
}
