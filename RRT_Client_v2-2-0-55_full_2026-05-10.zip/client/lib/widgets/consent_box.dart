import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

/// ConsentBox - the HTML .consent-box.
///
/// Off-white background, red 20x20 square with a white checkmark on the left,
/// Barlow 500 13px consent text on the right.
///
/// Tappable to toggle. Matches the visual affordance in the HTML where the
/// checkbox is always shown filled - here we reflect [checked] state.
class ConsentBox extends StatelessWidget {
  final bool checked;
  final VoidCallback onTap;
  final String text;

  const ConsentBox({
    super.key,
    required this.checked,
    required this.onTap,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 20,
              height: 20,
              margin: const EdgeInsets.only(top: 1),
              color: checked ? AppTheme.red : AppTheme.white,
              alignment: Alignment.center,
              child: checked
                  ? const Icon(Icons.check, size: 14, color: Colors.white)
                  : Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                            color: AppTheme.border, width: 1.5),
                      ),
                    ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                text,
                style: AppTheme.barlow(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: AppTheme.black,
                  height: 1.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// InfoNotice - the grey circular "i" notice row used on the profile
/// onboarding screen.
class InfoNotice extends StatelessWidget {
  final String text;
  const InfoNotice({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 16,
            height: 16,
            margin: const EdgeInsets.only(top: 1),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppTheme.subtleGrey, width: 1.5),
            ),
            alignment: Alignment.center,
            child: Text(
              'i',
              style: AppTheme.barlow(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: AppTheme.grey,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: AppTheme.barlow(
                fontSize: 12,
                color: AppTheme.grey,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
