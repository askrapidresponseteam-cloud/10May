import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

enum NavTab { home, alerts, chats, profile, help }

/// BottomNav - the HTML .bottom-nav.
/// 74px tall, top border, 5 equal items, active tab = black, inactive = grey.
/// The "alerts" tab shows a tiny red dot top-right when [alertsHasDot] is
/// true - driven by [hasUnseenAlertsProvider] in the parent. The dot
/// represents *unread* alerts, not just "you're somewhere else"; it clears
/// the moment the user opens the Alerts tab (which fires mark-seen).
class BottomNav extends StatelessWidget {
  final NavTab active;
  final ValueChanged<NavTab> onChanged;
  final bool alertsHasDot;

  const BottomNav({
    super.key,
    required this.active,
    required this.onChanged,
    this.alertsHasDot = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 74,
      decoration: const BoxDecoration(
        color: AppTheme.white,
        border: Border(top: BorderSide(color: AppTheme.border, width: 1)),
      ),
      child: Row(
        children: [
          _item(NavTab.home, 'HOME', Icons.home_outlined),
          _item(NavTab.alerts, 'ALERTS', Icons.notifications_outlined,
              showDot: alertsHasDot),
          _item(NavTab.chats, 'CHATS', Icons.chat_bubble_outline),
          _item(NavTab.profile, 'PROFILE', Icons.person_outline),
          _item(NavTab.help, 'HELP', Icons.help_outline),
        ],
      ),
    );
  }

  Widget _item(NavTab tab, String label, IconData icon,
      {bool showDot = false}) {
    final selected = tab == active;
    final color = selected ? AppTheme.black : AppTheme.grey;
    return Expanded(
      child: GestureDetector(
        onTap: () => onChanged(tab),
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(icon, size: 22, color: color),
                if (showDot)
                  Positioned(
                    top: -3,
                    right: -3,
                    child: Container(
                      width: 7,
                      height: 7,
                      decoration: const BoxDecoration(
                        color: AppTheme.red,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: AppTheme.barlow(
                fontSize: 9,
                fontWeight: FontWeight.w700,
                color: color,
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
