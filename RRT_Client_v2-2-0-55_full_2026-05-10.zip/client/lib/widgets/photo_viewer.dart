import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../core/theme/app_theme.dart';

/// Full-screen, swipeable, pinch-to-zoom photo viewer that renders entirely
/// inside the app. Replaces the previous behaviour of handing image URLs to
/// `launchUrl(externalApplication)`, which on Android downloaded the JPEG to
/// /Download instead of showing it.
///
/// Used by:
///   • Alerts screen (volunteer side) - when responders tap a scene-photo
///     thumbnail attached to an alert.
///   • Active SOS screen (sender side) - when the sender taps one of their
///     own uploaded scene photos to review it.
///
/// Open with [PhotoViewerPage.show] to get a transparent push route with the
/// expected dim-and-fade behaviour, or push the widget directly into a route
/// of your own if you need custom transition control.
class PhotoViewerPage extends StatefulWidget {
  const PhotoViewerPage({
    super.key,
    required this.photos,
    required this.initialIndex,
    this.onDelete,
  });

  /// Image URLs to display, in display order. The viewer always renders the
  /// list as a horizontally swipeable [PageView]; pinch-to-zoom is enabled
  /// on each page via [InteractiveViewer].
  final List<String> photos;

  /// Which photo to show first.
  final int initialIndex;

  /// Optional async delete handler. When non-null, a delete affordance
  /// appears in the top-left of the viewer. The handler receives the URL
  /// of the currently-displayed photo and is expected to remove it from
  /// the underlying source (Firestore + Storage). It MUST return after
  /// the delete completes (success or failure) so the viewer can decide
  /// whether to pop.
  ///
  /// Gated rather than always-on because the same viewer is used in two
  /// contexts: the alerts screen (volunteer viewing the sender's photos
  /// — must NOT be able to delete) and the active SOS screen (sender
  /// reviewing their own photos — should be able to delete and re-add).
  /// Pass null on the alerts side; pass a real handler on the sender
  /// side.
  final Future<bool> Function(String url)? onDelete;

  /// Convenience launcher - pushes the viewer with a transparent barrier so
  /// the underlying screen briefly remains visible during the transition.
  /// Safe to call with [initialIndex] >= [photos.length]; clamped internally.
  static Future<void> show(
    BuildContext context, {
    required List<String> photos,
    required int initialIndex,
    Future<bool> Function(String url)? onDelete,
  }) {
    if (photos.isEmpty) return Future.value();
    final clamped = initialIndex.clamp(0, photos.length - 1);
    return Navigator.of(context).push(
      PageRouteBuilder(
        opaque: false,
        barrierColor: Colors.black87,
        pageBuilder: (_, __, ___) => PhotoViewerPage(
          photos: photos,
          initialIndex: clamped,
          onDelete: onDelete,
        ),
      ),
    );
  }

  @override
  State<PhotoViewerPage> createState() => _PhotoViewerPageState();
}

class _PhotoViewerPageState extends State<PhotoViewerPage> {
  late final PageController _controller =
      PageController(initialPage: widget.initialIndex);
  late int _current = widget.initialIndex;
  bool _deleting = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// Confirms the destructive action, then runs widget.onDelete with
  /// the URL of the currently-displayed photo. On success we pop the
  /// viewer; the caller's stream subscription will refresh the list
  /// (the photo has been removed from Firestore).
  ///
  /// We pop on success rather than trying to advance to the next photo
  /// in this same viewer because the photos list is captured at viewer-
  /// construction time and cannot retroactively shrink — staying in
  /// the viewer would show a now-deleted URL and a broken-image icon.
  /// Popping back to the SOS screen lets its StreamBuilder render the
  /// up-to-date list cleanly.
  Future<void> _confirmAndDelete() async {
    if (_deleting) return;
    if (widget.onDelete == null) return;
    if (_current >= widget.photos.length) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogCtx) => AlertDialog(
        backgroundColor: AppTheme.white,
        title: Text(
          'Delete photo?',
          style: AppTheme.barlow(
            fontSize: 17,
            fontWeight: FontWeight.w800,
            color: AppTheme.black,
          ),
        ),
        content: Text(
          'This removes the photo from your active SOS. '
          'Responders will no longer see it. You can add a new '
          'one in its place.',
          style: AppTheme.barlow(
            fontSize: 14,
            color: AppTheme.subtleGrey,
            height: 1.4,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogCtx).pop(false),
            child: Text(
              'CANCEL',
              style: AppTheme.barlow(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: AppTheme.grey,
                letterSpacing: 1.5,
              ),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogCtx).pop(true),
            child: Text(
              'DELETE',
              style: AppTheme.barlow(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: AppTheme.red,
                letterSpacing: 1.5,
              ),
            ),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;
    setState(() => _deleting = true);

    final url = widget.photos[_current];
    bool ok = false;
    try {
      ok = await widget.onDelete!(url);
    } catch (_) {
      ok = false;
    }
    if (!mounted) return;
    setState(() => _deleting = false);

    if (ok) {
      Navigator.of(context).pop();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Could not delete photo. Check your connection and try again.',
            style: AppTheme.barlow(fontSize: 13, color: AppTheme.white),
          ),
          backgroundColor: AppTheme.black,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            PageView.builder(
              controller: _controller,
              itemCount: widget.photos.length,
              onPageChanged: (i) => setState(() => _current = i),
              itemBuilder: (_, i) => InteractiveViewer(
                minScale: 1,
                maxScale: 4,
                child: Center(
                  child: CachedNetworkImage(
                    imageUrl: widget.photos[i],
                    fit: BoxFit.contain,
                    placeholder: (_, __) => const Center(
                      child: CircularProgressIndicator(
                        color: AppTheme.white,
                        strokeWidth: 2,
                      ),
                    ),
                    errorWidget: (_, __, ___) => const Icon(
                      Icons.broken_image_outlined,
                      color: AppTheme.white,
                      size: 48,
                    ),
                  ),
                ),
              ),
            ),
            // Close button (top-right)
            Positioned(
              top: 8,
              right: 8,
              child: Material(
                color: Colors.black54,
                shape: const CircleBorder(),
                child: IconButton(
                  icon: const Icon(Icons.close, color: AppTheme.white),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ),
            ),
            // Delete button (top-left) - only when caller passed an
            // onDelete handler (sender side, not volunteer side).
            if (widget.onDelete != null)
              Positioned(
                top: 8,
                left: 8,
                child: Material(
                  color: Colors.black54,
                  shape: const CircleBorder(),
                  child: IconButton(
                    icon: _deleting
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: AppTheme.white,
                            ),
                          )
                        : const Icon(Icons.delete_outline,
                            color: AppTheme.white),
                    onPressed: _deleting ? null : _confirmAndDelete,
                    tooltip: 'Delete photo',
                  ),
                ),
              ),
            // Index indicator (top-center) - only when there's more than one
            if (widget.photos.length > 1)
              Positioned(
                top: 16,
                left: 0,
                right: 0,
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '${_current + 1} / ${widget.photos.length}',
                      style: AppTheme.barlow(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
