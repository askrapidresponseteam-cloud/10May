import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import '../core/services/chat_photo_service.dart';
import '../core/theme/app_theme.dart';

/// Full-screen viewer for a chat photo. Shown when the user taps a
/// photo bubble in the chat. Black background, image centered,
/// transport controls in the top bar.
///
/// Capabilities:
///   - Close (×) — pops the route
///   - Save to gallery (⬇) — downloads bytes and writes via `gal`
///     package which handles both Android (MediaStore for Android 10+,
///     direct write to Pictures for older) and iOS (Photos app via
///     PHPhotoLibrary).
///   - Delete (🗑) — only visible if the viewer was opened by the
///     photo's original sender. Server-enforced regardless.
///
/// Not yet supported: pinch-zoom, swipe-between-photos. These would be
/// nice but add real complexity (interactive_viewer, pre-fetch, page
/// indicators). Keep the viewer simple in v1.
class FullScreenPhotoViewer extends StatefulWidget {
  final String url;
  final String senderName;
  final int? timestampMs;

  /// Whether this viewer was opened by the photo's original sender.
  /// Only the sender can delete - the backend enforces this regardless
  /// of what the client shows, but we hide the affordance for the
  /// other party so they don't see a button that 403s.
  final bool canDelete;

  /// Conv ID + from FID needed for the delete call. Only used if
  /// canDelete is true. Pass them anyway so the parent doesn't have
  /// to conditionally construct this widget.
  final String convId;
  final String fromFid;

  const FullScreenPhotoViewer({
    super.key,
    required this.url,
    required this.senderName,
    required this.timestampMs,
    required this.canDelete,
    required this.convId,
    required this.fromFid,
  });

  @override
  State<FullScreenPhotoViewer> createState() => _FullScreenPhotoViewerState();
}

class _FullScreenPhotoViewerState extends State<FullScreenPhotoViewer> {
  bool _saving = false;
  bool _deleting = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.black,
      body: SafeArea(
        child: Column(
          children: [
            _topBar(context),
            Expanded(child: _imageArea()),
            _bottomMeta(),
          ],
        ),
      ),
    );
  }

  Widget _topBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            behavior: HitTestBehavior.opaque,
            child: Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              child: const Icon(Icons.close,
                  color: AppTheme.white, size: 22),
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: _saving ? null : _saveToGallery,
            behavior: HitTestBehavior.opaque,
            child: Opacity(
              opacity: _saving ? 0.4 : 1.0,
              child: Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                child: _saving
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppTheme.white,
                        ),
                      )
                    : const Icon(Icons.download,
                        color: AppTheme.white, size: 20),
              ),
            ),
          ),
          if (widget.canDelete)
            GestureDetector(
              onTap: _deleting ? null : _confirmDelete,
              behavior: HitTestBehavior.opaque,
              child: Opacity(
                opacity: _deleting ? 0.4 : 1.0,
                child: Container(
                  width: 40,
                  height: 40,
                  alignment: Alignment.center,
                  child: _deleting
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: AppTheme.white,
                          ),
                        )
                      : const Icon(Icons.delete_outline,
                          color: AppTheme.white, size: 20),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _imageArea() {
    return CachedNetworkImage(
      imageUrl: widget.url,
      fit: BoxFit.contain,
      placeholder: (_, __) => const Center(
        child: CircularProgressIndicator(color: AppTheme.white),
      ),
      errorWidget: (_, __, ___) => const Center(
        child: Icon(Icons.broken_image_outlined,
            color: AppTheme.fadedGrey, size: 48),
      ),
    );
  }

  Widget _bottomMeta() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      child: Row(
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: const BoxDecoration(
              color: AppTheme.white,
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              widget.senderName.isEmpty
                  ? '?'
                  : widget.senderName[0].toUpperCase(),
              style: AppTheme.barlow(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: AppTheme.black,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.senderName,
                  style: AppTheme.barlow(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.white,
                  ),
                ),
                Text(
                  _fmtTimestamp(widget.timestampMs),
                  style: AppTheme.barlow(
                    fontSize: 11,
                    color: AppTheme.fadedGrey,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Download bytes from the URL and hand off to the OS gallery via gal.
  /// On Android: writes to Pictures/RRT (or via MediaStore on API 29+).
  /// On iOS: prompts for Photos permission first call, then saves to
  /// the user's Photos library.
  Future<void> _saveToGallery() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      // Check permission first (gal handles the actual permission
      // request through the OS dialog, but we want to show a clear
      // error if denied).
      final hasAccess = await Gal.hasAccess();
      if (!hasAccess) {
        final granted = await Gal.requestAccess();
        if (!granted) {
          if (!mounted) return;
          _toast('Photos permission needed to save.');
          return;
        }
      }

      // Download bytes. Use http instead of CachedNetworkImage's cache
      // because the cache stores in a format gal can't directly read
      // (it's keyed on URL hash, not extension), and writing via
      // bytes is the most reliable cross-platform path.
      final res = await http.get(Uri.parse(widget.url))
          .timeout(const Duration(seconds: 30));
      if (res.statusCode != 200) {
        if (!mounted) return;
        _toast('Could not download photo.');
        return;
      }

      // Write to a temp file then save - gal's saveImage takes a path,
      // not bytes. (saveImageBytes exists on some versions but path is
      // the more universally supported call.)
      final Uint8List bytes = res.bodyBytes;
      final tmpDir = Directory.systemTemp;
      final tmpFile = File(
        '${tmpDir.path}/rrt_save_${DateTime.now().millisecondsSinceEpoch}.jpg',
      );
      await tmpFile.writeAsBytes(bytes);

      await Gal.putImage(tmpFile.path, album: 'RRT');

      // Clean up the temp file - gal has already copied it.
      try {
        if (await tmpFile.exists()) await tmpFile.delete();
      } catch (_) { /* non-fatal */ }

      if (!mounted) return;
      _toast('Saved to Photos.');
    } catch (e) {
      debugPrint('FullScreenPhotoViewer._saveToGallery: $e');
      if (!mounted) return;
      _toast('Could not save photo.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _confirmDelete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: true,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: Text(
          'Delete this photo?',
          style: AppTheme.barlow(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: AppTheme.black,
          ),
        ),
        content: Text(
          "Once deleted it can't be recovered.",
          style: AppTheme.barlow(
            fontSize: 14,
            color: AppTheme.grey,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(
              'Cancel',
              style: AppTheme.barlow(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: AppTheme.grey,
              ),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(
              'Delete',
              style: AppTheme.barlow(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppTheme.red,
              ),
            ),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    if (!mounted) return;

    setState(() => _deleting = true);
    try {
      final ok = await ChatPhotoService().deletePhoto(
        convId: widget.convId,
        fromFid: widget.fromFid,
        url: widget.url,
      );
      if (!mounted) return;
      if (ok) {
        Navigator.of(context).pop(true); // signal parent to refresh
      } else {
        _toast('Could not delete photo. Try again.');
      }
    } finally {
      if (mounted) setState(() => _deleting = false);
    }
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppTheme.black,
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        content: Text(
          msg,
          style: AppTheme.barlow(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: AppTheme.white,
          ),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  static String _fmtTimestamp(int? ms) {
    if (ms == null) return '';
    final dt = DateTime.fromMillisecondsSinceEpoch(ms);
    final hh = dt.hour.toString().padLeft(2, '0');
    final mm = dt.minute.toString().padLeft(2, '0');
    return '$hh:$mm';
  }
}
