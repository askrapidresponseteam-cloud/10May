import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme/app_theme.dart';
import '../core/providers/connectivity_provider.dart';
import 'paw_icon.dart';

/// TopBar - the HTML .nav-bar (52px tall, bottom border).
///
/// Shows either:
///  - Paw mark + "Rapid Response Team" title
///  - Back arrow + title (when [onBack] is given)
///  - Back arrow + paw mark + title (when [onBack] is given AND [showLogo]
///    is true - used on the onboarding profile step so the header still
///    matches the post-onboarding screens visually).
///
/// Optional trailing [badge] text (e.g. "2 OF 3"). When [showOnline] is
/// true, a status dot is shown that reflects live device connectivity:
/// green when online, red when offline. Driven by `connectivityProvider`,
/// which uses platform connectivity events (no polling).
class TopBar extends ConsumerWidget {
  final String? badge;
  final VoidCallback? onBack;
  final bool showOnline;
  final bool showLogo;

  const TopBar({
    super.key,
    this.badge,
    this.onBack,
    this.showOnline = false,
    this.showLogo = false,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Resolve current connectivity. When the provider hasn't emitted yet
    // (very first frame), assume online so we don't flash red on launch.
    final connAsync = ref.watch(connectivityProvider);
    final isOnline = connAsync.maybeWhen(
      data: (online) => online,
      orElse: () => true,
    );

    return Container(
      height: 52,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      decoration: const BoxDecoration(
        color: AppTheme.white,
        border: Border(
          bottom: BorderSide(color: AppTheme.border, width: 1),
        ),
      ),
      child: Row(
        children: [
          // Leading: back arrow (optional), then paw square either always
          // (no back) or when showLogo is set alongside the back arrow.
          if (onBack != null) ...[
            GestureDetector(
              onTap: onBack,
              behavior: HitTestBehavior.opaque,
              child: const SizedBox(
                width: 44,
                height: 44,
                child: Center(
                  child: Icon(Icons.arrow_back_ios_new_rounded,
                      size: 18, color: AppTheme.black),
                ),
              ),
            ),
            if (showLogo)
              Container(
                width: 32,
                height: 32,
                color: AppTheme.red,
                alignment: Alignment.center,
                child: const PawIcon(size: 18, color: Colors.white),
              ),
          ] else
            Container(
              width: 32,
              height: 32,
              color: AppTheme.red,
              alignment: Alignment.center,
              child: const PawIcon(size: 18, color: Colors.white),
            ),
          const SizedBox(width: 10),

          // Title: "Rapid" bold + "Response Team" regular
          Expanded(
            child: RichText(
              overflow: TextOverflow.ellipsis,
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'Rapid ',
                    style: AppTheme.barlow(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.black,
                      letterSpacing: -0.3,
                    ),
                  ),
                  TextSpan(
                    text: 'Response Team',
                    style: AppTheme.barlow(
                      fontSize: 17,
                      fontWeight: FontWeight.w400,
                      color: AppTheme.black,
                      letterSpacing: -0.3,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Trailing: status dot (live, green/red) THEN badge (HTML order)
          if (showOnline) ...[
            _StatusDot(online: isOnline),
            const SizedBox(width: 10),
          ],
          if (badge != null)
            Text(
              badge!,
              style: AppTheme.barlow(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: AppTheme.grey,
                letterSpacing: 0.5,
              ),
            ),
        ],
      ),
    );
  }
}

/// 9px circular indicator that flips color based on connectivity.
///
/// While offline we add a soft pulsing halo so the change is noticeable
/// at a glance even on a busy screen. Online state stays still and
/// quiet - this is a status indicator, not an attention-seeker. We also
/// expose an OS-level Tooltip on long-press so curious users can confirm
/// what the dot means.
class _StatusDot extends StatelessWidget {
  final bool online;
  const _StatusDot({required this.online});

  @override
  Widget build(BuildContext context) {
    final color = online ? AppTheme.successGreen : AppTheme.red;
    return Tooltip(
      message: online ? 'Online' : 'No internet connection',
      child: SizedBox(
        width: 14,
        height: 14,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Subtle pulsing halo when offline. Built with TweenAnimation
            // looping forever so users notice the state change without
            // it being aggressive.
            if (!online)
              const _PulseHalo(),
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: 9,
              height: 9,
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PulseHalo extends StatefulWidget {
  const _PulseHalo();

  @override
  State<_PulseHalo> createState() => _PulseHaloState();
}

class _PulseHaloState extends State<_PulseHalo>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        // Halo grows from 9 -> 14 px and fades out across the cycle.
        final t = _ctrl.value;
        final size = 9.0 + (5.0 * t);
        final opacity = (1.0 - t) * 0.4;
        return Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: AppTheme.red.withValues(alpha: opacity),
            shape: BoxShape.circle,
          ),
        );
      },
    );
  }
}
