import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

enum CtaVariant { primary, outline, danger }

/// CtaButton - the HTML .cta-btn.
///
/// Full-width, 58px tall, zero radius, uppercase Barlow 800 at 13px with
/// 2px letter spacing. Optional trailing icon renders at 14px.
///
/// Variants:
///  - primary: black bg, white text (default)
///  - outline: white bg, black text, 2px black border
///  - danger:  red bg, white text (used on STOP SOS)
class CtaButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final CtaVariant variant;
  final IconData? trailingIcon;
  final IconData? leadingIcon;
  final bool isLoading;

  const CtaButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.variant = CtaVariant.primary,
    this.trailingIcon,
    this.leadingIcon,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    final Color bg;
    final Color fg;
    Border? border;
    switch (variant) {
      case CtaVariant.primary:
        bg = AppTheme.black;
        fg = AppTheme.white;
        break;
      case CtaVariant.outline:
        bg = AppTheme.white;
        fg = AppTheme.black;
        border = Border.all(color: AppTheme.black, width: 2);
        break;
      case CtaVariant.danger:
        bg = AppTheme.red;
        fg = AppTheme.white;
        break;
    }

    final disabled = onPressed == null || isLoading;

    return Opacity(
      opacity: disabled ? 0.6 : 1.0,
      child: GestureDetector(
        onTap: disabled ? null : onPressed,
        behavior: HitTestBehavior.opaque,
        child: Container(
          width: double.infinity,
          height: 58,
          decoration: BoxDecoration(
            color: bg,
            border: border,
          ),
          alignment: Alignment.center,
          child: isLoading
              ? SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(fg),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (leadingIcon != null) ...[
                      Icon(leadingIcon, size: 14, color: fg),
                      const SizedBox(width: 8),
                    ],
                    Text(
                      label,
                      style: AppTheme.barlow(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: fg,
                        letterSpacing: 2,
                      ),
                    ),
                    if (trailingIcon != null) ...[
                      const SizedBox(width: 8),
                      Icon(trailingIcon, size: 14, color: fg),
                    ],
                  ],
                ),
        ),
      ),
    );
  }
}
