import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_app_installations/firebase_app_installations.dart';
import 'core/services/remote_config_service.dart';
import 'core/services/force_update_service.dart';
import 'core/services/app_info_service.dart';
import 'core/theme/app_theme.dart';
import 'core/constants/app_constants.dart';
import 'core/services/notification_service.dart';
import 'core/services/offline_district_service.dart';
import 'core/services/profile_service.dart';
import 'screens/onboarding_screen.dart';
import 'screens/main_navigation_screen.dart';
import 'screens/alerts_screen.dart';
import 'widgets/force_update_dialog.dart';

/// Top-level function for handling background FCM messages
/// Required to be outside any class for Firebase to access it
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  
  // ✅ Background sender filtering: Check if this is a self-sent SOS alert
  final messageSenderId = message.data['sender_id'];
  if (messageSenderId != null) {
    try {
      // Use Firebase Installation ID directly for comparison
      final currentSenderId = await FirebaseInstallations.instance.getId();
      
      if (messageSenderId == currentSenderId) {
        // Filter out self-sent SOS alerts in background
        return;
      }
    } catch (e) {
      // Continue processing if we can't determine sender ID
    }
  }
  
  await NotificationService.handleBackgroundMessage(message);
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Lock app to portrait mode only
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Prime the app version cache so SOS payloads (and anywhere else that
  // builds telemetry) report the real build instead of a hardcoded
  // string. AppInfoService.initialize is internally fail-open; the
  // outer try/catch is belt-and-suspenders so a future regression in
  // the helper can't take down main().
  try {
    await AppInfoService.initialize();
  } catch (e) {
    debugPrint('AppInfoService.initialize failed (non-fatal): $e');
  }

  // Initialize Firebase (gracefully handle configuration errors)
  try {
    await Firebase.initializeApp();
    
    // Set up background message handler only if Firebase is initialized
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

    // Fetch Remote Config values (base URL, etc.) before the app renders
    await RemoteConfigService.initialize();
  } catch (e) {
    // Firebase configuration not found - app will run without Firebase features
    // Silent error handling - Firebase not configured
    // Error details suppressed for cleaner logs
  }
  
  runApp(const ProviderScope(child: RRTApp()));
}

/// Global navigator key for handling navigation from FCM notifications
/// This allows navigation from anywhere in the app, including background contexts
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

class RRTApp extends ConsumerStatefulWidget {
  const RRTApp({super.key});

  @override
  ConsumerState<RRTApp> createState() => _RRTAppState();
}

class _RRTAppState extends ConsumerState<RRTApp>
    with WidgetsBindingObserver {
  // Guard against showing more than one dialog at a time. The blocking
  // dialog is non-dismissible, but the lifecycle hooks could fire
  // overlapping checks (resume + first-frame on a cold start that races
  // with backgrounding) and we don't want two stacked.
  bool _updateDialogShown = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // First force-update check is deferred so it fires AFTER the
    // FutureBuilder in build() resolves _initializeAndCheckProfile(),
    // not in parallel with it. The previous setup used
    // addPostFrameCallback, which fired while the loading-spinner
    // Scaffold was still up; the dialog tried to attach to a context
    // whose route got replaced moments later, and the dialog never
    // appeared.
    //
    // 4 seconds is comfortably past the cold-start init window
    // (Firebase + RemoteConfig + profile read typically settles in
    // 1-3s). On the rare slow-network device where profile init is
    // still running at 4s, the next resume from background will
    // re-run the check via didChangeAppLifecycleState.
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted) _checkForceUpdate();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Re-check on resume. This catches the common case of a phone that
    // sat in the background for days/weeks across a release that bumped
    // min_version - without this, the user would only get the prompt
    // on a full cold start.
    if (state == AppLifecycleState.resumed) {
      _checkForceUpdate();
    }
  }

  /// Hits the store and, if the installed build is below the latest
  /// available version, shows the blocking ForceUpdateDialog. Failing
  /// open: any network/parse error means the dialog is not shown (the
  /// service logs and returns null).
  Future<void> _checkForceUpdate() async {
    debugPrint('_checkForceUpdate: entered (alreadyShown=$_updateDialogShown)');
    // Set the guard *before* the await so a resume firing mid-check
    // can't kick off a parallel run that ends up stacking dialogs.
    if (_updateDialogShown) return;
    _updateDialogShown = true;
    try {
      final info = await ForceUpdateService.checkForUpdate();
      debugPrint('_checkForceUpdate: service returned ${info == null ? "null (no update)" : "${info.installedVersion} -> ${info.latestVersion}"}');
      if (info == null) {
        // Allow the next resume to re-check. The dialog never went up.
        _updateDialogShown = false;
        return;
      }
      final ctx = navigatorKey.currentContext;
      if (ctx == null || !ctx.mounted) {
        debugPrint('_checkForceUpdate: navigatorKey context not ready, deferring');
        _updateDialogShown = false;
        return;
      }
      debugPrint('_checkForceUpdate: showing dialog');
      // barrierDismissible: false + the dialog's own PopScope(canPop:
      // false) make this a hard block until the user updates. There is
      // intentionally no "Later" button on the dialog itself.
      await showDialog<void>(
        context: ctx,
        barrierDismissible: false,
        builder: (_) => ForceUpdateDialog(updateInfo: info),
      );
      // If we ever get here (e.g. dialog dismissed via store-launch
      // back-nav), allow another check on next resume.
      _updateDialogShown = false;
    } catch (e, st) {
      debugPrint('_checkForceUpdate failed: $e\n$st');
      _updateDialogShown = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      theme: AppTheme.lightTheme,
      navigatorKey: navigatorKey, // Attach global navigator key
      home: FutureBuilder<Widget>(
        future: _initializeAndCheckProfile(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          }
          // Return the appropriate screen based on profile status
          return snapshot.data ?? const OnboardingScreen();
        },
      ),
      debugShowCheckedModeBanner: false,
      // Define named routes for navigation from notifications
      routes: {
        '/alerts': (context) => const AlertsScreen(),
      },
    );
  }
  
  /// Initialize async services and check profile status
  Future<Widget> _initializeAndCheckProfile() async {
    // Initialize both services in parallel to avoid blocking
    // Notification service (critical) and District service (non-critical) run simultaneously
    await Future.wait([
      // District service: Loads district boundaries (2-10 seconds)
      // Non-critical - can fail without breaking app functionality
      OfflineDistrictService.instance.initialize()
        .catchError((e) {
          debugPrint('District service initialization failed: $e');
          // Return null to satisfy Future.wait
          return null;
        }),
      
      // Notification service: Sets up FCM handlers and permissions (< 1 second)
      // Critical - must initialize quickly for push notifications to work
      NotificationService.initialize(navigatorKey, ref),
    ]);
    
    // Check if profile exists to determine initial screen
    try {
      final name = await ProfileService.getUserName();
      final mobile = await ProfileService.getUserMobile();
      
      if (name != null && name.isNotEmpty && mobile != null && mobile.isNotEmpty) {
        // Profile exists, go to main app
        return const MainNavigationScreen();
      } else {
        // No profile, start with onboarding
        return const OnboardingScreen();
      }
    } catch (e) {
      // If there's an error, show onboarding to be safe
      return const OnboardingScreen();
    }
  }
}
