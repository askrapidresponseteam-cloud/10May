import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/theme/app_theme.dart';
import '../core/services/profile_service.dart';
import '../widgets/top_bar.dart';
import '../widgets/cta_button.dart';
import '../widgets/consent_box.dart';
import 'profile_create_screen.dart';

/// Step 2 of 3. Mirrors the HTML `TermsScreen`:
/// - TopBar with "2 OF 3" badge
/// - Condensed 48pt "Terms & Conditions" heading
/// - Scrollable list of 10 numbered clauses
/// - ConsentBox above the CTA
/// - ACCEPT & CONTINUE → ProfileCreateScreen
class TermsAndConditionsScreen extends StatefulWidget {
  const TermsAndConditionsScreen({super.key});

  @override
  State<TermsAndConditionsScreen> createState() =>
      _TermsAndConditionsScreenState();
}

class _TermsAndConditionsScreenState extends State<TermsAndConditionsScreen> {
  bool _accepted = false;
  bool _busy = false;
  /// Locked to false until the user has scrolled the clauses list to the
  /// bottom at least once. Required for the consent checkbox AND the CTA
  /// to enable - we want to be sure the entire document was at least
  /// surfaced before the user accepts. Helpful both for UX clarity and
  /// for legal hygiene around informed consent.
  bool _scrolledToEnd = false;

  final ScrollController _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollCtrl.addListener(_onScroll);
    // Edge case: on tall screens the list may be shorter than the viewport
    // and not be scrollable at all. In that case there's nothing for the
    // user to scroll, so we mark them done after the first frame. This
    // also handles devices with small font scale + large screens.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (!_scrollCtrl.hasClients) return;
      final pos = _scrollCtrl.position;
      // maxScrollExtent is 0 when the content fits in the viewport.
      if (pos.maxScrollExtent <= 0) {
        setState(() => _scrolledToEnd = true);
      }
    });
  }

  @override
  void dispose() {
    _scrollCtrl.removeListener(_onScroll);
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrolledToEnd) return;
    if (!_scrollCtrl.hasClients) return;
    final pos = _scrollCtrl.position;
    // Treat "within 24 logical px of bottom" as reached, so users don't
    // have to bottom out the scroll exactly to satisfy the gate. This is
    // forgiving of overscroll dynamics on iOS and the small bottom spacer
    // we render after the privacy link.
    if (pos.pixels >= pos.maxScrollExtent - 24) {
      setState(() => _scrolledToEnd = true);
    }
  }

  // The 10 clauses from the HTML, verbatim.
  static const List<(String, String)> _clauses = [
    (
      '1. Acceptance',
      'By using Rapid Response Team, you agree to these Terms. If you do not agree, do not use the app.'
    ),
    (
      '2. Eligibility',
      'You must be 18 or older. You are responsible for the accuracy of your registered information.'
    ),
    (
      '3. Permitted Use',
      'RRT is for genuine animal emergencies only. Misuse, false alerts, or abuse of the platform is strictly prohibited.'
    ),
    (
      '4. SOS Alerts',
      'Sending an SOS alert notifies all registered volunteers in your district. Only use when genuinely needed.'
    ),
    (
      '5. Location Data',
      'Location is required to send an SOS. It is shared only with district volunteers during an active emergency.'
    ),
    (
      '6. Privacy',
      'Your name and mobile number are shared with volunteers during an active SOS. See our Privacy Policy for details.'
    ),
    (
      '7. Content',
      'Any media shared must be relevant to the emergency. Graphic, misleading, or abusive content is prohibited.'
    ),
    (
      '8. Suspension',
      'RRT may suspend or terminate access without notice for Terms violations, misuse, or legal/safety risks.'
    ),
    (
      '9. Liability',
      'To the maximum extent permitted by law, RRT is not liable for injuries, losses, or damages arising from use.'
    ),
    (
      '10. Governing Law',
      'These Terms may be updated periodically. Governed by the laws of India.\n\nLast Updated: 22/01/2026'
    ),
  ];

  Future<void> _accept() async {
    if (!_accepted || _busy) return;
    setState(() => _busy = true);
    await ProfileService.setTermsAccepted(true);
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ProfileCreateScreen()),
    );
  }

  Future<void> _openPrivacy() async {
    final url = Uri.parse(
      'https://askrapidresponseteam-cloud.github.io/rrt-privacy-policy',
    );
    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      }
    } catch (_) {
      // Silent fail - surfacing a snackbar here would clutter the clean
      // editorial layout. Users can still proceed.
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TopBar(
              badge: '2 OF 3',
              onBack: () => Navigator.pop(context),
              showLogo: true,
              showOnline: false,
            ),

            // Heading block
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Terms &',
                    textAlign: TextAlign.left,
                    style: AppTheme.barlowCondensed(
                      fontSize: 48,
                      fontWeight: FontWeight.w900,
                      color: AppTheme.black,
                      height: 1.0,
                      letterSpacing: -1,
                    ),
                  ),
                  Text(
                    'Conditions',
                    textAlign: TextAlign.left,
                    style: AppTheme.barlowCondensed(
                      fontSize: 48,
                      fontWeight: FontWeight.w900,
                      color: AppTheme.black,
                      height: 1.0,
                      letterSpacing: -1,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Please read before continuing.',
                    textAlign: TextAlign.left,
                    style: AppTheme.barlow(
                      fontSize: 13,
                      color: AppTheme.grey,
                    ),
                  ),
                ],
              ),
            ),

            // Divider (HTML .divider: 1px, margin 16px 24px)
            Container(
              height: 1,
              margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              color: AppTheme.border,
            ),

            // Scrollable clauses, with a soft fade hint at the bottom edge
            // until the user reaches the end. The fade lifts once they
            // have scrolled all the way down so the consent gate flips
            // open visually as well as functionally.
            Expanded(
              child: Stack(
                children: [
                  ScrollConfiguration(
                    behavior: _NoGlowBehavior(),
                    child: ListView(
                      controller: _scrollCtrl,
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      children: [
                        for (final clause in _clauses) _ClauseRow(clause),
                        // Small spacer at the bottom (HTML: div height:8)
                        const SizedBox(height: 8),
                        // Privacy policy link - HTML didn't surface one here
                        // but we preserve the legal obligation to link it.
                        GestureDetector(
                          onTap: _openPrivacy,
                          behavior: HitTestBehavior.opaque,
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Text(
                              'Read full Privacy Policy',
                              style: AppTheme.barlow(
                                fontSize: 13,
                                color: AppTheme.red,
                                fontWeight: FontWeight.w600,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Bottom fade-to-white overlay only while the user has
                  // not yet scrolled to the end. Visually telegraphs
                  // "there's more below". Using IgnorePointer so the fade
                  // never blocks scroll gestures.
                  if (!_scrolledToEnd)
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: IgnorePointer(
                        child: Container(
                          height: 36,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                AppTheme.white.withValues(alpha: 0.0),
                                AppTheme.white.withValues(alpha: 1.0),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  // Subtle "scroll down" cue centered at the bottom edge
                  // until reach. Disappears once the user scrolls to end.
                  if (!_scrolledToEnd)
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 6,
                      child: IgnorePointer(
                        child: Center(
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.keyboard_arrow_down_rounded,
                                size: 16,
                                color: AppTheme.grey,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'SCROLL TO READ ALL',
                                style: AppTheme.barlow(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w800,
                                  color: AppTheme.grey,
                                  letterSpacing: 1.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // Consent checkbox. Disabled until scrolled-to-end - tapping
            // before that does nothing, and we lower its opacity so the
            // gate is visually obvious.
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Opacity(
                opacity: _scrolledToEnd ? 1.0 : 0.45,
                child: ConsentBox(
                  checked: _accepted,
                  onTap: _scrolledToEnd
                      ? () => setState(() => _accepted = !_accepted)
                      : () {},
                  text:
                      'I have read and agree to the Terms & Conditions and Privacy Policy',
                ),
              ),
            ),

            // Bottom CTA. Requires BOTH scrolled-to-end AND consent box
            // checked, plus we're not mid-flight on accept. Without the
            // scroll gate the user could otherwise tap accept the moment
            // the screen loads.
            Container(
              color: AppTheme.white,
              padding: const EdgeInsets.fromLTRB(24, 12, 24, 32),
              child: CtaButton(
                label: 'ACCEPT & CONTINUE',
                onPressed:
                    (_scrolledToEnd && _accepted && !_busy) ? _accept : null,
                isLoading: _busy,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ClauseRow extends StatelessWidget {
  final (String, String) clause;
  const _ClauseRow(this.clause);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            clause.$1,
            style: AppTheme.barlow(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: AppTheme.black,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            clause.$2,
            style: AppTheme.barlow(
              fontSize: 13,
              color: const Color(0xFF666666),
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }
}

/// Removes the Android blue-glow overscroll effect so the scroll list
/// looks the same across platforms (matches the HTML clean look).
class _NoGlowBehavior extends ScrollBehavior {
  @override
  Widget buildOverscrollIndicator(
          BuildContext context, Widget child, ScrollableDetails details) =>
      child;
}
