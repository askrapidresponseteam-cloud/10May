import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_app_installations/firebase_app_installations.dart';
import '../core/theme/app_theme.dart';
import '../core/providers/sos_state_provider.dart';
import '../core/providers/alerts_provider.dart';
import '../widgets/bottom_nav.dart';
import 'home_screen.dart';
import 'alerts_screen.dart';
import 'conversations_screen.dart';
import 'profile_screen.dart';
import 'help_screen.dart';

/// Root shell for the 5 main tabs.
///
/// Preserves behaviour from the previous MainNavigationScreen:
///   • App lifecycle observer that re-reads SOS state from storage
///     on resume (debounced to 2s).
///   • activeTabIndexProvider kept in sync for notification-driven
///     tab switches.
///   • alertsScreenActiveProvider flips whenever the Alerts tab is
///     focused - the Firestore seen-by writer relies on this.
///   • IndexedStack keeps each tab alive (no state loss on switch).
class MainNavigationScreen extends ConsumerStatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  ConsumerState<MainNavigationScreen> createState() =>
      _MainNavigationScreenState();
}

class _MainNavigationScreenState extends ConsumerState<MainNavigationScreen>
    with WidgetsBindingObserver {
  NavTab _active = NavTab.home;
  DateTime? _lastRefreshTime;
  static const _refreshDebounce = Duration(seconds: 2);

  // Maps a NavTab enum to the index expected by activeTabIndexProvider
  // (home:0, alerts:1, chats:2, profile:3, help:4 - same as the old screen).
  int _indexOf(NavTab t) {
    switch (t) {
      case NavTab.home:
        return 0;
      case NavTab.alerts:
        return 1;
      case NavTab.chats:
        return 2;
      case NavTab.profile:
        return 3;
      case NavTab.help:
        return 4;
    }
  }

  NavTab _tabOf(int i) {
    switch (i) {
      case 1:
        return NavTab.alerts;
      case 2:
        return NavTab.chats;
      case 3:
        return NavTab.profile;
      case 4:
        return NavTab.help;
      case 0:
      default:
        return NavTab.home;
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // Note: a periodic heartbeat used to fire here to keep the user's
    // last_subscribed_at fresh, powering Online/Away/Offline status. That
    // feature has been removed (no user-facing value, drove avoidable
    // Firestore writes). The initial subscribe-user call still runs from
    // DistrictSubscriptionService when the user picks/changes a district,
    // which is the only thing that actually needs to happen.
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed) {
      _debouncedSosRefresh();
    }
  }

  void _debouncedSosRefresh() {
    final now = DateTime.now();
    if (_lastRefreshTime != null &&
        now.difference(_lastRefreshTime!) < _refreshDebounce) {
      return;
    }
    _lastRefreshTime = now;
    Future.microtask(() async {
      const maxRetries = 3;
      const retryDelay = Duration(milliseconds: 500);
      for (var attempt = 0; attempt < maxRetries; attempt++) {
        try {
          await ref.read(sosStateProvider.notifier).refreshFromStorage();
          break;
        } catch (_) {
          if (attempt < maxRetries - 1) await Future.delayed(retryDelay);
        }
      }
    });
  }

  void _onTabTap(NavTab tab) {
    setState(() => _active = tab);
    final idx = _indexOf(tab);
    ref.read(activeTabIndexProvider.notifier).state = idx;
    final isAlerts = tab == NavTab.alerts;
    ref.read(alertsScreenActiveProvider.notifier).state = isAlerts;

    if (isAlerts) {
      _markCurrentAlertsSeen();
    }
  }

  /// Fires `mark-seen` for every alert currently in [activeAlertsProvider]
  /// that hasn't been sent yet. The cache (seenAlertCacheProvider) prevents
  /// duplicate calls for the same {sender_id}:{timestamp} key, so this is
  /// safe to invoke on every alert-list update without spamming the backend.
  ///
  /// Called from three places:
  ///   1. _onTabTap when the user taps the Alerts tab.
  ///   2. The activeTabIndexProvider listener, when an external trigger
  ///      (e.g. a notification tap) switches to the Alerts tab.
  ///   3. The activeAlertsProvider listener, when new alerts stream in
  ///      while the user is *already* on the Alerts tab. Without this
  ///      hook the sender's view-count would never tick up for any
  ///      volunteer who happened to already be on the tab when the
  ///      alert landed.
  void _markCurrentAlertsSeen() {
    final alerts = ref.read(activeAlertsProvider).valueOrNull ?? [];
    if (alerts.isEmpty) return;
    final alreadySeen = ref.read(seenAlertCacheProvider);
    unawaited(
      FirebaseInstallations.instance.getId().then((fid) =>
          markAlertsSeen(alerts, fid, alreadySeen).then((newKeys) {
            if (newKeys.isNotEmpty) {
              ref
                  .read(seenAlertCacheProvider.notifier)
                  .update((s) => {...s, ...newKeys});
            }
          })),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Listen for external tab-switch requests (e.g. from notification taps).
    ref.listen<int>(activeTabIndexProvider, (_, newIndex) {
      final next = _tabOf(newIndex);
      if (next != _active) {
        setState(() => _active = next);
        final isAlerts = next == NavTab.alerts;
        ref.read(alertsScreenActiveProvider.notifier).state = isAlerts;
        // External switch to Alerts must also mark the visible alerts as
        // seen - otherwise notification-driven opens never count.
        if (isAlerts) _markCurrentAlertsSeen();
      }
    });

    // Mark-seen whenever the active alerts list updates AND we're already
    // viewing the Alerts tab. This catches alerts that arrive while the
    // tab is in the foreground (the tab-tap path above doesn't fire in
    // that case because no tap happens). Idempotent via the seen-cache.
    ref.listen<AsyncValue<List<Map<String, dynamic>>>>(
      activeAlertsProvider,
      (_, next) {
        if (_active != NavTab.alerts) return;
        if (next.valueOrNull?.isNotEmpty != true) return;
        _markCurrentAlertsSeen();
      },
    );

    return Scaffold(
      backgroundColor: AppTheme.white,
      body: SafeArea(
        bottom: false,
        child: IndexedStack(
          index: _indexOf(_active),
          children: const [
            HomeScreen(),
            AlertsScreen(),
            ConversationsScreen(),
            ProfileScreen(),
            HelpScreen(),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: BottomNav(
          active: _active,
          onChanged: _onTabTap,
          // Red dot = there's at least one alert in the active list that
          // this user hasn't yet been marked-seen for. Clears the moment
          // they open the Alerts tab (which triggers mark-seen).
          alertsHasDot: ref.watch(hasUnseenAlertsProvider),
        ),
      ),
    );
  }
}
