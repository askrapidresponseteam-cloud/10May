import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../widgets/top_bar.dart';
import '../widgets/cta_button.dart';
import 'terms_and_conditions_screen.dart';

/// OnboardingScreen - Step 1 of 3 (Welcome).
///
/// Mirrors the HTML `WelcomeScreen`:
///   • TopBar (paw + "Rapid Response Team")
///   • Dark hero block with fox photo at 55% opacity, left→right
///     dark gradient, red "EMERGENCY ANIMAL NETWORK" kicker,
///     90-ish "Help." in Barlow Condensed 900, "When seconds
///     matter." subline, 40×2 red rule.
///   • 3px red rule
///   • Three numbered feature rows divided by 1px hairlines
///   • Sticky bottom area with CTA → Terms
class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      body: SafeArea(
        child: Column(
          children: [
            const TopBar(),
            Expanded(child: _WelcomeBody()),
            _BottomArea(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const TermsAndConditionsScreen(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _WelcomeBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const _Hero(),
        // Thin red rule under hero (HTML: height:3, bg:#E52222)
        Container(height: 3, color: AppTheme.red),
        // Feature list - flex:1, centered vertically
        Expanded(child: _FeatureList()),
      ],
    );
  }
}

class _Hero extends StatelessWidget {
  const _Hero();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: AppTheme.black,
      padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
      child: Stack(
        children: [
          // Hero photo faded + slight grayscale feel (achieved via opacity
          // + ColorFiltered with a saturation desaturation).
          Positioned.fill(
            child: Opacity(
              opacity: 0.55,
              child: ColorFiltered(
                // Approximates CSS `filter: grayscale(20%)`.
                colorFilter: const ColorFilter.matrix(<double>[
                  0.8, 0.1, 0.1, 0, 0,
                  0.1, 0.8, 0.1, 0, 0,
                  0.1, 0.1, 0.8, 0, 0,
                  0, 0, 0, 1, 0,
                ]),
                child: Image.asset(
                  'assets/images/hero.jpg',
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          // Dark left→right gradient so the text stays readable.
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [
                    AppTheme.black.withValues(alpha: 0.85),
                    AppTheme.black.withValues(alpha: 0.3),
                  ],
                  stops: const [0.3, 1.0],
                ),
              ),
            ),
          ),
          // Foreground content
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'EMERGENCY ANIMAL NETWORK',
                style: AppTheme.barlow(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.red,
                  letterSpacing: 3,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                'Help.',
                style: AppTheme.barlowCondensed(
                  fontSize: 92,
                  fontWeight: FontWeight.w900,
                  color: AppTheme.white,
                  height: 0.88,
                  letterSpacing: -2,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'When seconds matter.',
                style: AppTheme.barlowCondensed(
                  fontSize: 26,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.white.withValues(alpha: 0.45),
                  height: 1.0,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 18),
              Container(width: 40, height: 2, color: AppTheme.red),
            ],
          ),
        ],
      ),
    );
  }
}

class _FeatureList extends StatelessWidget {
  static const _items = [
    ('01', 'One tap SOS',
        'Alert every volunteer in your district instantly'),
    ('02', 'Photo + voice from scene',
        'Help responders understand before they arrive'),
    ('03', 'Coordinate in real time',
        'Chat with the person who raised the alert'),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: _items
          .map((item) => _FeatureRow(
                number: item.$1,
                title: item.$2,
                description: item.$3,
              ))
          .toList(),
    );
  }
}

class _FeatureRow extends StatelessWidget {
  final String number;
  final String title;
  final String description;
  const _FeatureRow({
    required this.number,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: AppTheme.veryLightGrey, width: 1),
        ),
      ),
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              width: 56,
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: const BoxDecoration(
                border: Border(
                  right:
                      BorderSide(color: AppTheme.veryLightGrey, width: 1),
                ),
              ),
              alignment: Alignment.center,
              child: Text(
                number,
                style: AppTheme.barlowCondensed(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  color: AppTheme.red,
                  letterSpacing: 1,
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      title,
                      style: AppTheme.barlow(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.black,
                        letterSpacing: -0.2,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      description,
                      style: AppTheme.barlow(
                        fontSize: 13,
                        color: const Color(0xFF999999),
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BottomArea extends StatelessWidget {
  final VoidCallback onTap;
  const _BottomArea({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppTheme.white,
      padding: const EdgeInsets.fromLTRB(24, 14, 24, 32),
      child: Column(
        children: [
          CtaButton(label: 'GET STARTED', onPressed: onTap),
          const SizedBox(height: 10),
          Text(
            'Privacy Policy · Terms · v2.1.10',
            style: AppTheme.barlow(
              fontSize: 11,
              color: const Color(0xFFBBBBBB),
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }
}
