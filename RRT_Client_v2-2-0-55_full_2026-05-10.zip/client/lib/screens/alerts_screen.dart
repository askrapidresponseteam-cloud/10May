import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:firebase_app_installations/firebase_app_installations.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:just_audio/just_audio.dart';
import '../core/theme/app_theme.dart';
import '../core/providers/alerts_provider.dart';
import '../widgets/top_bar.dart';
import '../widgets/photo_viewer.dart';
import 'chat_screen.dart';

/// Alerts screen - live active-alert cards for the user's district.
///
/// Mirrors the HTML `AlertsScreen` exactly:
///   • TopBar (with green online dot)
///   • Scroll list of alert cards, each containing:
///       - ACTIVE red pill + "<relative>" timestamp (no distance text;
///         the previous "0-8 km away" string was a placeholder that
///         shipped without the underlying distance computation, so it
///         was misleading on cross-district alerts. The card already
///         shows the alert's location below — that's the honest signal.)
///       - "Emergency: <name>" heading
///       - pin + place
///       - speech-bubble + italic message preview
///       - CALL (black, filled) + DIRECTIONS (black, filled) 50/50
///       - CHAT (outline, full-width) below
///   • Empty state: "NO ACTIVE ALERTS" + body
///   • Footer note: contact detail privacy reminder
///
/// Data comes from [activeAlertsProvider]. Tapping CHAT derives a
/// deterministic conv_id (sorted FIDs joined by `_`) and pushes ChatScreen
/// with `shouldInitiate: true` so the backend upserts the conversation doc.
class AlertsScreen extends ConsumerWidget {
  const AlertsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final alertsAsync = ref.watch(activeAlertsProvider);

    return Scaffold(
      backgroundColor: AppTheme.white,
      body: Column(
        children: [
          const TopBar(showOnline: true),
          Expanded(
            child: alertsAsync.when(
              loading: () => const Center(
                child: CircularProgressIndicator(color: AppTheme.red),
              ),
              error: (_, __) => const _EmptyState(
                title: 'UNABLE TO LOAD ALERTS',
                body: 'Pull down to retry or check your connection.',
              ),
              data: (alerts) {
                if (alerts.isEmpty) {
                  return const _EmptyState(
                    title: 'NO ACTIVE ALERTS',
                    body:
                        'When volunteers in your district raise an alert, they will appear here.',
                  );
                }
                return RefreshIndicator(
                  color: AppTheme.red,
                  onRefresh: () async {
                    ref.invalidate(activeAlertsProvider);
                    await Future<void>.delayed(
                        const Duration(milliseconds: 400));
                  },
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    itemCount: alerts.length + 1, // +1 for footer
                    itemBuilder: (context, i) {
                      if (i == alerts.length) return const _FooterNote();
                      return _AlertCard(alert: alerts[i]);
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final String title;
  final String body;
  const _EmptyState({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: AppTheme.barlow(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: AppTheme.grey,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              body,
              textAlign: TextAlign.center,
              style: AppTheme.barlow(
                fontSize: 13,
                color: AppTheme.subtleGrey,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FooterNote extends StatelessWidget {
  const _FooterNote();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      child: Text(
        'CONTACT DETAILS ARE VISIBLE ONLY WHILE AN ALERT IS ACTIVE.',
        textAlign: TextAlign.center,
        style: AppTheme.barlow(
          fontSize: 10,
          color: AppTheme.disabledGrey,
          fontWeight: FontWeight.w600,
          letterSpacing: 2,
        ),
      ),
    );
  }
}

class _AlertCard extends StatelessWidget {
  final Map<String, dynamic> alert;
  const _AlertCard({required this.alert});

  @override
  Widget build(BuildContext context) {
    final name = (alert['sender_name'] as String?) ?? 'Unknown User';
    final message = (alert['message'] as String?) ?? '';
    final approx = (alert['approx_loc'] as String?) ?? '';
    final mobile = (alert['mobile_number'] as String?) ?? '';
    final ago = _relative(alert['timestamp']);
    final lat = alert['exact_lat'] as double?;
    final lng = alert['exact_lng'] as double?;
    final isAdminRaised = alert['is_admin_raised'] == true;

    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.white,
        border: Border.all(color: AppTheme.border, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            offset: const Offset(0, 2),
            blurRadius: 12,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ACTIVE pill + relative time
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                color: AppTheme.red,
                child: Text(
                  'ACTIVE',
                  style: AppTheme.barlow(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.white,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              const Spacer(),
              Flexible(
                child: Text(
                  ago,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.right,
                  style: AppTheme.barlow(
                    fontSize: 12,
                    color: AppTheme.grey,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            'Emergency: $name',
            style: AppTheme.barlow(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: AppTheme.black,
              letterSpacing: -0.3,
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              const Icon(Icons.location_on, size: 12, color: AppTheme.red),
              const SizedBox(width: 5),
              Expanded(
                child: Text(
                  approx.isEmpty ? 'Location unavailable' : approx,
                  overflow: TextOverflow.ellipsis,
                  style: AppTheme.barlow(
                    fontSize: 13,
                    color: AppTheme.grey,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          if (message.isNotEmpty) ...[
            const SizedBox(height: 4),
            // Tappable message preview. The Text widget shows up to 2 lines
            // on the card; if the message is longer it truncates with an
            // ellipsis and the user can tap the row to read the full text
            // in a dialog. Previously this Text had no `maxLines` and was
            // wrapped in `Expanded`, which silently capped it at one line -
            // users were missing information they needed to respond.
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => _showFullMessage(context, message),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(top: 3),
                    child: Icon(Icons.chat_bubble_outline,
                        size: 12, color: AppTheme.grey),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(
                      message,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: AppTheme.barlow(
                        fontSize: 13,
                        color: AppTheme.fadedGrey,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Padding(
                    padding: EdgeInsets.only(top: 2),
                    child: Icon(
                      Icons.chevron_right,
                      size: 14,
                      color: AppTheme.fadedGrey,
                    ),
                  ),
                ],
              ),
            ),
          ],
          // Photos uploaded by the sender
          _buildPhotos(alert),
          // Voice note uploaded by the sender
          _buildVoice(alert),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _ActionBtn(
                  icon: Icons.phone,
                  label: 'CALL',
                  filled: true,
                  onTap: mobile.isEmpty ? null : () => _call(context, mobile),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _ActionBtn(
                  icon: Icons.near_me_rounded,
                  label: 'DIRECTIONS',
                  filled: true,
                  onTap: (lat == null || lng == null)
                      ? null
                      : () => _directions(context, lat, lng),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (isAdminRaised)
            // Admin-raised alerts have no real device on the other end.
            // Surface this clearly so responders don't wait for a chat
            // reply that will never arrive - they should reply by call.
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: AppTheme.offWhite,
                border: Border.all(color: AppTheme.border, width: 1),
              ),
              child: Row(
                children: [
                  const Icon(Icons.shield_outlined,
                      size: 14, color: AppTheme.grey),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Admin-raised alert. Reply by call only.',
                      style: AppTheme.barlow(
                        fontSize: 12,
                        color: AppTheme.grey,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            )
          else
            _ActionBtn(
              icon: Icons.chat_bubble_outline,
              label: 'CHAT',
              filled: false,
              onTap: () => _openChat(context),
            ),
        ],
      ),
    );
  }

  Widget _buildPhotos(Map<String, dynamic> alert) {
    final photos = (alert['photo_urls'] as List<dynamic>? ?? []).cast<String>();
    if (photos.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.photo_library_outlined, size: 12, color: AppTheme.grey),
              const SizedBox(width: 5),
              Text(
                '${photos.length} PHOTO${photos.length > 1 ? 'S' : ''}',
                style: AppTheme.barlow(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.grey,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          SizedBox(
            height: 72,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: photos.length,
              separatorBuilder: (_, __) => const SizedBox(width: 6),
              itemBuilder: (context, i) => GestureDetector(
                onTap: () => _showPhotoViewer(context, photos, i),
                child: Container(
                  width: 72,
                  height: 72,
                  color: AppTheme.offWhite,
                  child: CachedNetworkImage(
                    imageUrl: photos[i],
                    fit: BoxFit.cover,
                    placeholder: (_, __) => const Center(
                      child: SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppTheme.grey,
                        ),
                      ),
                    ),
                    errorWidget: (_, __, ___) => const Icon(
                      Icons.broken_image_outlined,
                      color: AppTheme.grey,
                      size: 24,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVoice(Map<String, dynamic> alert) {
    final voiceUrl = alert['voice_url'] as String?;
    if (voiceUrl == null || voiceUrl.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Builder(
        builder: (ctx) => GestureDetector(
          onTap: () => _showVoicePlayer(ctx, voiceUrl),
          behavior: HitTestBehavior.opaque,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              border: Border.all(color: AppTheme.border, width: 1),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.play_circle_outline, size: 18, color: AppTheme.black),
                const SizedBox(width: 8),
                Text(
                  'PLAY VOICE NOTE',
                  style: AppTheme.barlow(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.black,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// In-app full-screen photo viewer with pinch-to-zoom and swipe between
  /// photos. Closes on tap-outside, X button, or system back. Does NOT open
  /// the system browser or trigger a download.
  /// Open the full alert message in a dialog. The card preview shows up to
  /// 2 lines and ellipsises after that; tapping the row opens this dialog
  /// so volunteers can read the full distress description before deciding
  /// to call, get directions, or chat.
  void _showFullMessage(BuildContext context, String message) {
    showDialog<void>(
      context: context,
      builder: (_) => _FullMessageDialog(message: message),
    );
  }

  void _showPhotoViewer(
    BuildContext context,
    List<String> photos,
    int initialIndex,
  ) {
    PhotoViewerPage.show(
      context,
      photos: photos,
      initialIndex: initialIndex,
    );
  }

  /// In-app voice-note player rendered as a bottom sheet. Streams audio via
  /// just_audio (the same package the rest of the app uses) instead of
  /// handing the URL off to the OS browser.
  void _showVoicePlayer(BuildContext context, String url) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.white,
      isScrollControlled: false,
      builder: (_) => _VoicePlayerSheet(url: url),
    );
  }

  Future<void> _call(BuildContext context, String number) async {
    try {
      await launchUrl(Uri(scheme: 'tel', path: number));
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not start call')),
        );
      }
    }
  }

  Future<void> _directions(
      BuildContext context, double lat, double lng) async {
    try {
      await launchUrl(
        Uri.parse(
            'https://www.google.com/maps/dir/?api=1&destination=$lat,$lng'),
        mode: LaunchMode.externalApplication,
      );
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open maps')),
        );
      }
    }
  }

  Future<void> _openChat(BuildContext context) async {
    final senderFid = alert['sender_id'] as String?;
    if (senderFid == null) return;
    try {
      final myFid = await FirebaseInstallations.instance.getId();
      final ids = <String>[myFid, senderFid]..sort();
      final convId = ids.join('_');
      if (!context.mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ChatScreen(
            convId: convId,
            otherFid: senderFid,
            otherName: (alert['sender_name'] as String?) ?? 'Volunteer',
            district: (alert['district'] as String?) ?? '',
            shouldInitiate: true,
          ),
        ),
      );
    } catch (_) {/* non-fatal */}
  }

  String _relative(dynamic ts) {
    int? ms;
    if (ts is int) ms = ts;
    if (ms == null) return 'Just now';
    final diff =
        DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ms));
    if (diff.inSeconds < 45) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}

/// _ActionBtn - 46px, filled or outline, icon + label.
class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool filled;
  final VoidCallback? onTap;
  const _ActionBtn({
    required this.icon,
    required this.label,
    required this.filled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    final fg = filled ? AppTheme.white : AppTheme.black;
    final bg = filled ? AppTheme.black : AppTheme.white;
    return Opacity(
      opacity: enabled ? 1.0 : 0.45,
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
          height: 46,
          decoration: BoxDecoration(
            color: bg,
            border:
                filled ? null : Border.all(color: AppTheme.black, width: 2),
          ),
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 14, color: fg),
              const SizedBox(width: 8),
              Text(
                label,
                style: AppTheme.barlow(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: fg,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


// ─────────── In-app voice-note player ───────────
//
// Bottom-sheet player that streams the voice note from Firebase Storage via
// just_audio. This replaces the previous behaviour of opening the URL in the
// system browser, which downloaded the .m4a file to the device.

class _VoicePlayerSheet extends StatefulWidget {
  const _VoicePlayerSheet({required this.url});

  final String url;

  @override
  State<_VoicePlayerSheet> createState() => _VoicePlayerSheetState();
}

class _VoicePlayerSheetState extends State<_VoicePlayerSheet> {
  final AudioPlayer _player = AudioPlayer();
  bool _ready = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      await _player.setUrl(widget.url);
      if (!mounted) return;
      setState(() => _ready = true);
      await _player.play();
    } catch (_) {
      if (!mounted) return;
      setState(() => _failed = true);
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.graphic_eq, size: 14, color: AppTheme.grey),
                const SizedBox(width: 6),
                Text(
                  'VOICE NOTE',
                  style: AppTheme.barlow(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.grey,
                    letterSpacing: 1.5,
                  ),
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close, color: AppTheme.grey),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (_failed)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  'Could not play voice note.',
                  style: AppTheme.barlow(
                    fontSize: 13,
                    color: AppTheme.grey,
                  ),
                ),
              )
            else if (!_ready)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(
                  child: CircularProgressIndicator(
                    color: AppTheme.red,
                    strokeWidth: 2,
                  ),
                ),
              )
            else
              StreamBuilder<PlayerState>(
                stream: _player.playerStateStream,
                builder: (_, stateSnap) {
                  final isPlaying = stateSnap.data?.playing ?? false;
                  final processing =
                      stateSnap.data?.processingState ?? ProcessingState.idle;
                  final isCompleted = processing == ProcessingState.completed;
                  return Row(
                    children: [
                      InkWell(
                        onTap: () async {
                          if (isCompleted) {
                            await _player.seek(Duration.zero);
                            await _player.play();
                          } else if (isPlaying) {
                            await _player.pause();
                          } else {
                            await _player.play();
                          }
                        },
                        child: Container(
                          width: 44,
                          height: 44,
                          decoration: const BoxDecoration(
                            color: AppTheme.black,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            isCompleted
                                ? Icons.replay
                                : (isPlaying ? Icons.pause : Icons.play_arrow),
                            color: AppTheme.white,
                            size: 22,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: StreamBuilder<Duration>(
                          stream: _player.positionStream,
                          builder: (_, posSnap) {
                            final pos = posSnap.data ?? Duration.zero;
                            final total =
                                _player.duration ?? Duration.zero;
                            final maxMs = total.inMilliseconds <= 0
                                ? 1.0
                                : total.inMilliseconds.toDouble();
                            final value = pos.inMilliseconds
                                .clamp(0, total.inMilliseconds)
                                .toDouble();
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SliderTheme(
                                  data: SliderTheme.of(context).copyWith(
                                    trackHeight: 2,
                                    thumbShape:
                                        const RoundSliderThumbShape(
                                            enabledThumbRadius: 6),
                                    overlayShape:
                                        const RoundSliderOverlayShape(
                                            overlayRadius: 12),
                                    activeTrackColor: AppTheme.black,
                                    inactiveTrackColor: AppTheme.offWhite,
                                    thumbColor: AppTheme.black,
                                    overlayColor:
                                        AppTheme.black.withValues(alpha: 0.1),
                                  ),
                                  child: Slider(
                                    min: 0,
                                    max: maxMs,
                                    value: value.clamp(0, maxMs).toDouble(),
                                    onChanged: total.inMilliseconds <= 0
                                        ? null
                                        : (v) => _player.seek(
                                              Duration(
                                                  milliseconds: v.toInt()),
                                            ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 4),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        _fmt(pos),
                                        style: AppTheme.barlow(
                                          fontSize: 11,
                                          color: AppTheme.grey,
                                        ),
                                      ),
                                      Text(
                                        _fmt(total),
                                        style: AppTheme.barlow(
                                          fontSize: 11,
                                          color: AppTheme.grey,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                    ],
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

/// Full-screen-friendly dialog that displays the complete alert message.
///
/// Used when the message text on an alert card is longer than fits in the
/// 2-line preview. Tapping the message row opens this dialog so the
/// responding volunteer can read everything the sender wrote before
/// deciding how to help.
///
/// Visual style matches the rest of the app's dialogs (sharp corners,
/// Barlow type, black/grey buttons).
class _FullMessageDialog extends StatelessWidget {
  const _FullMessageDialog({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    // Cap the dialog height at 60% of the screen so very long messages
    // get a scroll area instead of pushing the close button off-screen.
    final maxHeight = MediaQuery.of(context).size.height * 0.6;

    return Dialog(
      backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.chat_bubble_outline,
                    size: 14, color: AppTheme.red),
                const SizedBox(width: 8),
                Text(
                  'MESSAGE FROM SENDER',
                  style: AppTheme.barlow(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.red,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            ConstrainedBox(
              constraints: BoxConstraints(maxHeight: maxHeight),
              child: SingleChildScrollView(
                child: Text(
                  message,
                  style: AppTheme.barlow(
                    fontSize: 15,
                    color: AppTheme.black,
                    height: 1.5,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                const Spacer(),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  behavior: HitTestBehavior.opaque,
                  child: Container(
                    height: 44,
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    color: AppTheme.black,
                    alignment: Alignment.center,
                    child: Text(
                      'CLOSE',
                      style: AppTheme.barlow(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
