import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/constants/app_constants.dart';
import '../core/providers/alerts_provider.dart';
import '../core/providers/location_provider.dart';
import '../core/providers/sos_state_provider.dart';
import '../core/services/location_service.dart';
import '../core/services/vet_search_service.dart';
import '../core/theme/app_theme.dart';
import '../widgets/bottom_nav.dart';
import '../widgets/cta_button.dart';
import '../widgets/top_bar.dart';

/// Look-up screen for finding nearby vets.
///
/// Reachable from two places, with deliberately different chrome:
///
///   1. Help index entry "Look up a vet"
///      - Standard Help-mode chrome: TopBar with paw logo (no back arrow,
///        OS back gesture handles it), BottomNav at the foot anchored to
///        the Help tab. Matches HelpHowToScreen so the navigation feels
///        continuous between the two Help sub-pages.
///      - Eyebrow "02" red kicker + "Vets / near you" 64pt headline,
///        identical pattern to "01 / How to use the app".
///
///   2. "LOOK UP A VET" button on ActiveSOSScreen
///      - Stripped chrome: back-arrow TopBar, no BottomNav (we don't want
///        the user accidentally tab-switching away mid-emergency).
///      - Red "SOS STILL ACTIVE · MM:SS" breadcrumb under the TopBar so
///        the user knows the alert is still ticking and how much time is
///        left before it auto-expires.
///      - Smaller "Vets / near you" headline (56pt) so the breadcrumb +
///        results fit on a single phone screen without scrolling past
///        the SOS state cue.
///
/// The screen has four possible UI states:
///   • LOADING        - the cache miss + Ola call is in flight
///   • RESULTS        - vets list, with Call / Directions per row
///   • EMPTY_15KM     - 15km search returned nothing; offer to widen
///   • EMPTY_50KM     - even the wide search returned nothing
///   • UNAVAILABLE    - Ola disabled (no API key compiled in) or hard
///                      network error; show only the Google Maps button
///
/// In every state, a "Open in Google Maps" footer button is present.
/// That button is the universal escape hatch - it costs us zero API
/// calls, gives the user a one-tap exit to a richer search experience,
/// and means the screen is never a complete dead-end. This matters
/// because Ola Maps' POI coverage is thinner than Google's in tier-2
/// and tier-3 Indian cities, and you'll see vets in Google Maps that
/// don't appear in Ola's response.
class FindVetScreen extends ConsumerStatefulWidget {
  /// True when the screen was pushed during an active SOS. Drives the
  /// "BACK TO SOS · MM:SS" breadcrumb. When false (e.g. opened from the
  /// Help index), the breadcrumb is hidden and the TopBar is the only
  /// header.
  final bool fromActiveSos;

  const FindVetScreen({super.key, this.fromActiveSos = false});

  @override
  ConsumerState<FindVetScreen> createState() => _FindVetScreenState();
}

class _FindVetScreenState extends ConsumerState<FindVetScreen> {
  /// Single instance per screen lifetime. The service holds an in-memory
  /// cache that we want to share across rebuilds; instantiating it in
  /// `build` would defeat the memory layer entirely.
  final VetSearchService _service = VetSearchService();

  /// Default search radius. Wider expansions go through _expandRadius().
  static const int _defaultRadius = 15000;
  static const int _wideRadius = 50000;

  bool _loading = true;
  VetSearchResult? _result;
  Object? _error;
  LocationData? _origin;

  /// Tracks the currently-displayed radius (15 vs 50). Used by the
  /// headline copy and the empty-state branching - we only show the
  /// "Search wider area" option once, when we're at 15km.
  int _currentRadius = _defaultRadius;

  /// Live-ticking minutes/seconds for the BACK TO SOS strip. Only
  /// active when fromActiveSos is true.
  Timer? _sosTick;
  int _sosSecondsRemaining = 0;

  /// place_id of the vet whose Directions button is currently fetching
  /// coordinates from Ola Place Details. Drives a per-row spinner so
  /// the user knows the tap registered. null when no hydration is in
  /// flight. We track by place_id rather than list index so the right
  /// row keeps spinning if the list reorders mid-fetch.
  String? _hydratingPlaceId;

  @override
  void initState() {
    super.initState();
    _runSearch(_defaultRadius);
    if (widget.fromActiveSos) {
      _startSosTicker();
    }
  }

  @override
  void dispose() {
    _sosTick?.cancel();
    super.dispose();
  }

  void _startSosTicker() {
    _recomputeSosRemaining();
    _sosTick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(_recomputeSosRemaining);
      }
    });
  }

  void _recomputeSosRemaining() {
    final sos = ref.read(sosStateProvider);
    if (!sos.isActive || sos.activatedAtMillis == null) {
      _sosSecondsRemaining = 0;
      return;
    }
    final expiresAt =
        DateTime.fromMillisecondsSinceEpoch(sos.activatedAtMillis!)
            .add(AppConstants.alertTtl);
    final diff = expiresAt.difference(DateTime.now()).inSeconds;
    _sosSecondsRemaining = diff.clamp(0, 1 << 30);
  }

  Future<void> _runSearch(int radiusMeters) async {
    setState(() {
      _loading = true;
      _error = null;
      _currentRadius = radiusMeters;
    });

    try {
      final locService = ref.read(locationServiceProvider);
      // Use the cached location if available (fast). The user may have
      // come from the SOS screen which already forced a fresh fetch a
      // few seconds ago - re-fetching would just spin the GPS again.
      final loc = await locService.getCurrentLocation(forceFresh: false);
      if (loc == null) {
        throw const VetSearchException(
          'Could not read your location. Please check permissions.',
        );
      }
      _origin = loc;

      final result = await _service.findNearby(
        lat: loc.latitude,
        lng: loc.longitude,
        radiusMeters: radiusMeters,
      );

      if (!mounted) return;
      setState(() {
        _result = result;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e;
        _result = null;
        _loading = false;
      });
    }
  }

  Future<void> _expandRadius() => _runSearch(_wideRadius);

  Future<void> _openGoogleMaps() async {
    final origin = _origin;
    final lat = origin?.latitude;
    final lng = origin?.longitude;
    final url = (lat != null && lng != null)
        ? 'https://www.google.com/maps/search/veterinary+clinic/@$lat,$lng,14z'
        : 'https://www.google.com/maps/search/veterinary+clinic';
    try {
      final ok = await launchUrl(
        Uri.parse(url),
        mode: LaunchMode.externalApplication,
      );
      if (!ok && mounted) {
        _toast('Could not open Maps.');
      }
    } catch (e) {
      debugPrint('FindVetScreen._openGoogleMaps: $e');
      if (mounted) _toast('Could not open Maps.');
    }
  }

  Future<void> _callVet(Vet vet) async {
    final phone = vet.phone;
    if (phone == null || phone.isEmpty) {
      // No phone in our cached record. Push to Google Maps for the
      // canonical vet page, which has a tap-to-call there.
      await _openVetInMaps(vet);
      return;
    }
    try {
      final ok = await launchUrl(Uri(scheme: 'tel', path: phone));
      if (!ok && mounted) _toast('Could not open dialer.');
    } catch (e) {
      debugPrint('FindVetScreen._callVet: $e');
      if (mounted) _toast('Could not open dialer.');
    }
  }

  /// Open Google Maps directions to the given vet.
  ///
  /// Two-stage process:
  ///   1. Lazy-hydrate the vet's coordinates by calling Ola Place
  ///      Details (cached locally per device, so subsequent taps for
  ///      the same vet are free). Sets _hydratingPlaceId so the row
  ///      can show a small spinner on its Directions button.
  ///   2. Launch Google Maps. If we have coordinates, use a
  ///      lat/lng-pinned directions URL (always lands at the exact
  ///      vet). If hydration failed, fall back to a name+address
  ///      directions URL — Google's geocoder lands you near the
  ///      right place most of the time, falls back to a search page
  ///      worst case.
  ///
  /// We use `/maps/dir/` (directions) rather than `/maps/search/`
  /// (search). The old search URL was the source of the "wrong vet"
  /// bug: tapping Directions on Vandse Veterinary Hospital opened a
  /// search page with Govt. Veterinary Hospital at the top because
  /// Google's name resolver couldn't find "Vandse" but recognised
  /// "Veterinary Hospital" + the locality. With `/dir/`, Google starts
  /// directions immediately to the destination we specify.
  Future<void> _openVetInMaps(Vet vet) async {
    // Stage 1: hydrate coordinates if we don't have them.
    Vet hydrated = vet;
    if (vet.latitude == null || vet.longitude == null) {
      if (mounted) {
        setState(() {
          _hydratingPlaceId = vet.placeId;
        });
      }
      try {
        hydrated = await _service.hydrateWithCoordinates(vet);
      } finally {
        if (mounted) {
          setState(() {
            _hydratingPlaceId = null;
          });
        }
      }
    }

    // Stage 2: build the directions URL.
    //
    // Coordinate-based URL (preferred): Google Maps drops a pin at
    // exactly (lat, lng) and starts directions to it. No name
    // resolution, no ambiguity.
    //
    // Address-string fallback: when hydration failed (network error,
    // place_id no longer in Ola's database, key missing, etc.) we
    // construct a directions URL with the name+address as the
    // destination string. Google's geocoder usually resolves this to
    // the right address even when it doesn't recognise the vet's
    // name, but the failure mode is the search-page fallback we used
    // to always hit.
    final params = <String, String>{
      'api': '1',
    };
    if (hydrated.latitude != null && hydrated.longitude != null) {
      params['destination'] =
          '${hydrated.latitude},${hydrated.longitude}';
    } else {
      final query = vet.address != null && vet.address!.isNotEmpty
          ? '${vet.name}, ${vet.address}'
          : vet.name;
      params['destination'] = query;
    }
    final url = Uri.https('www.google.com', '/maps/dir/', params).toString();

    try {
      final ok = await launchUrl(
        Uri.parse(url),
        mode: LaunchMode.externalApplication,
      );
      if (!ok && mounted) _toast('Could not open Maps.');
    } catch (e) {
      debugPrint('FindVetScreen._openVetInMaps: $e');
      if (mounted) _toast('Could not open Maps.');
    }
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: AppTheme.barlow(color: AppTheme.white)),
        backgroundColor: AppTheme.black,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.fromActiveSos) {
      return _buildSosChrome(context);
    }
    return _buildHelpChrome(context);
  }

  /// SOS-mode chrome: back-arrow TopBar, red SOS breadcrumb, no
  /// BottomNav. Stripped down because the user is mid-emergency; we
  /// don't want them accidentally tab-switching away.
  Widget _buildSosChrome(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            TopBar(
              showOnline: true,
              onBack: () => Navigator.of(context).pop(),
            ),
            _buildSosBreadcrumb(),
            // ClipRect prevents the big condensed headline (which has
            // negative line height: 0.92 and aggressive letterSpacing)
            // from painting visually above its allocated layout box
            // and bleeding into the TopBar when the user scrolls. The
            // layout doesn't actually overlap; only the glyph paint does.
            Expanded(
              child: ClipRect(
                child: _buildBody(headlineMode: _HeadlineMode.compact),
              ),
            ),
            _buildFooter(),
          ],
        ),
      ),
    );
  }

  /// Help-mode chrome: paw-logo TopBar (no back arrow - OS back gesture
  /// pops the route), BottomNav anchored to the Help tab. Mirrors
  /// HelpHowToScreen exactly so the two Help sub-pages feel continuous.
  Widget _buildHelpChrome(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            const TopBar(showOnline: true),
            // See _buildSosChrome's ClipRect comment.
            Expanded(
              child: ClipRect(
                child: _buildBody(headlineMode: _HeadlineMode.help),
              ),
            ),
            _buildFooter(),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: BottomNav(
          active: NavTab.help,
          alertsHasDot: ref.watch(hasUnseenAlertsProvider),
          onChanged: (tab) {
            if (tab == NavTab.help) {
              // Already on Help - just go back to the index.
              Navigator.popUntil(context, (r) => r.isFirst);
              return;
            }
            // Pop the sub-page AND the help index, then ask the main
            // navigator to switch to the chosen tab.
            Navigator.popUntil(context, (r) => r.isFirst);
            ref.read(activeTabIndexProvider.notifier).state = _indexOf(tab);
          },
        ),
      ),
    );
  }

  /// Mirrors MainNavigationScreen._indexOf and HelpHowToScreen's copy.
  /// Kept private here so this file doesn't import the navigator's
  /// internals.
  static int _indexOf(NavTab t) {
    switch (t) {
      case NavTab.home:
        return 0;
      case NavTab.alerts:
        return 1;
      case NavTab.chats:
        return 2;
      case NavTab.profile:
        return 3;
      case NavTab.help:
        return 4;
    }
  }

  Widget _buildSosBreadcrumb() {
    final mm = (_sosSecondsRemaining ~/ 60).toString().padLeft(2, '0');
    final ss = (_sosSecondsRemaining % 60).toString().padLeft(2, '0');
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      decoration: BoxDecoration(
        color: AppTheme.dangerBg,
        border: Border(
          bottom: BorderSide(color: AppTheme.dangerBorder, width: 1),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: const BoxDecoration(
              color: AppTheme.red,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            'SOS STILL ACTIVE',
            style: AppTheme.barlow(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: AppTheme.red,
              letterSpacing: 1.5,
            ),
          ),
          const Spacer(),
          Text(
            '$mm:$ss',
            style: AppTheme.barlow(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: AppTheme.red,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody({required _HeadlineMode headlineMode}) {
    if (_loading) return _buildLoading(headlineMode);

    final err = _error;
    if (err != null) return _buildError(err, headlineMode);

    final result = _result;
    if (result == null || result.isEmpty) return _buildEmpty(headlineMode);

    return _buildResults(result, headlineMode);
  }

  Widget _buildLoading(_HeadlineMode mode) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 24),
          _buildHeadline(mode),
          const SizedBox(height: 32),
          Center(
            child: SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor:
                    AlwaysStoppedAnimation<Color>(AppTheme.black),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text(
              'Looking nearby…',
              style: AppTheme.barlow(
                fontSize: 13,
                color: AppTheme.grey,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildError(Object err, _HeadlineMode mode) {
    final isUnavailable = err is VetSearchUnavailable;
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 24),
          _buildHeadline(mode),
          const SizedBox(height: 24),
          Text(
            isUnavailable
                ? "We can't show vets in this build, but Google Maps "
                    'works fine for this.'
                : "We couldn't load the list right now. Try Google Maps "
                    'or retry in a moment.',
            style: AppTheme.barlow(
              fontSize: 14,
              color: AppTheme.black,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 16),
          if (!isUnavailable)
            CtaButton(
              label: 'RETRY',
              variant: CtaVariant.outline,
              onPressed: () => _runSearch(_currentRadius),
            ),
        ],
      ),
    );
  }

  Widget _buildEmpty(_HeadlineMode mode) {
    final atDefaultRadius = _currentRadius == _defaultRadius;
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 24),
          _buildHeadline(mode),
          const SizedBox(height: 8),
          Text(
            atDefaultRadius
                ? 'No vets found within ${_defaultRadius ~/ 1000} km.'
                : 'No vets found within ${_wideRadius ~/ 1000} km either.',
            style: AppTheme.barlow(
              fontSize: 14,
              color: AppTheme.grey,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 24),
          if (atDefaultRadius)
            CtaButton(
              label: 'SEARCH WIDER AREA',
              variant: CtaVariant.outline,
              onPressed: _expandRadius,
            ),
          if (!atDefaultRadius)
            Text(
              'Try opening Google Maps for a broader search, or raise '
              'an SOS - someone in the network may know a vet that '
              "isn't on a map.",
              style: AppTheme.barlow(
                fontSize: 13,
                color: AppTheme.grey,
                height: 1.4,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildResults(VetSearchResult result, _HeadlineMode mode) {
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      children: [
        const SizedBox(height: 24),
        _buildHeadline(mode),
        const SizedBox(height: 8),
        Text(
          '${result.vets.length} found within '
          '${(result.radiusMeters / 1000).round()} km · sorted by distance',
          style: AppTheme.barlow(
            fontSize: 12,
            color: AppTheme.grey,
            letterSpacing: 0.2,
          ),
        ),
        Container(
          margin: const EdgeInsets.only(top: 16),
          height: 1,
          color: AppTheme.black.withValues(alpha: 0.12),
        ),
        for (var i = 0; i < result.vets.length; i++)
          _VetRow(
            number: (i + 1).toString().padLeft(2, '0'),
            vet: result.vets[i],
            isLast: i == result.vets.length - 1,
            isHydrating: _hydratingPlaceId == result.vets[i].placeId,
            onCall: () => _callVet(result.vets[i]),
            onDirections: () => _openVetInMaps(result.vets[i]),
          ),
        const SizedBox(height: 16),
      ],
    );
  }

  /// Two-line "Vets / near you" headline. Two visual modes:
  ///
  /// help mode  - 64pt headline + "02" red eyebrow numeral, identical
  ///              dimensions to HelpHowToScreen's "01 / How to use the
  ///              app". Reached when fromActiveSos is false.
  /// compact    - 56pt headline, no eyebrow. Used in SOS mode where
  ///              vertical space is tight (the SOS breadcrumb above
  ///              and the footer button below are both already taking
  ///              real estate; we don't want the headline pushing the
  ///              first vet card below the fold on small phones).
  Widget _buildHeadline(_HeadlineMode mode) {
    final fontSize = mode == _HeadlineMode.help ? 64.0 : 56.0;
    final letterSpacing = mode == _HeadlineMode.help ? -1.5 : -1.4;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (mode == _HeadlineMode.help) ...[
          // Eyebrow numeral - matches the row index on HelpScreen so
          // navigation feels continuous. "Look up a vet" is row 02.
          Text(
            '02',
            style: AppTheme.barlowCondensed(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: AppTheme.red,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 6),
        ],
        Text(
          'Vets',
          style: AppTheme.barlowCondensed(
            fontSize: fontSize,
            fontWeight: FontWeight.w900,
            color: AppTheme.black,
            height: 0.92,
            letterSpacing: letterSpacing,
          ),
        ),
        Text(
          'near you',
          style: AppTheme.barlowCondensed(
            fontSize: fontSize,
            fontWeight: FontWeight.w900,
            color: AppTheme.red,
            height: 0.92,
            letterSpacing: letterSpacing,
          ),
        ),
        if (mode == _HeadlineMode.help)
          Container(
            margin: const EdgeInsets.symmetric(vertical: 24),
            height: 1,
            color: AppTheme.black.withValues(alpha: 0.12),
          ),
      ],
    );
  }

  /// Footer: always-present "Open in Google Maps" button + a one-line
  /// disclaimer. Costs zero API calls and means the screen is never a
  /// dead-end. The button stays in the same place across all states
  /// (loading, results, empty, error) so muscle memory wins.
  ///
  /// Wrapped in SafeArea(top: false) so the button doesn't get clipped
  /// by the system gesture-nav bar on phones that have one. Without
  /// this, on devices like Pixel 7+ with gesture nav, the bottom ~25dp
  /// of the footer disappears below the gesture pill.
  ///
  /// The disclaimer is intentionally explicit about what we are NOT:
  /// not a partnership, not an endorsement, not a directory we
  /// curate. The clinics shown come from a public maps service (Ola
  /// Maps), and the user is responsible for due diligence. Phrasing
  /// is firm but not condescending - the user knows how to call a
  /// clinic and read reviews; we just need to be clear that listing
  /// here is not a vouch.
  Widget _buildFooter() {
    return SafeArea(
      top: false,
      child: Container(
        color: AppTheme.white,
        padding: const EdgeInsets.fromLTRB(24, 12, 24, 16),
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppTheme.veryLightGrey)),
        ),
        child: Column(
          children: [
            CtaButton(
              label: 'OPEN IN GOOGLE MAPS',
              variant: CtaVariant.outline,
              leadingIcon: Icons.open_in_new,
              onPressed: _openGoogleMaps,
            ),
            const SizedBox(height: 12),
            Text(
              'These clinics come from a public maps directory. We do '
              "not verify, partner with, or endorse any of them. "
              'Please use your own judgement, call ahead to confirm '
              'hours and services, and check reviews before you go.',
              textAlign: TextAlign.center,
              style: AppTheme.barlow(
                fontSize: 11,
                color: AppTheme.grey,
                height: 1.4,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Visual mode for the headline. See _buildHeadline doc.
enum _HeadlineMode { help, compact }

/// One row in the vet list. Numbered kicker (red), vet name, address,
/// distance, plus two-button action row (Call + Directions). The visual
/// rhythm matches HelpScreen's _IndexRow.
class _VetRow extends StatelessWidget {
  final String number;
  final Vet vet;
  final bool isLast;
  /// True when this row's Directions button is currently fetching
  /// coordinates from Ola Place Details. Drives a small spinner in
  /// place of the icon so the user knows the tap registered.
  final bool isHydrating;
  final VoidCallback onCall;
  final VoidCallback onDirections;

  const _VetRow({
    required this.number,
    required this.vet,
    required this.isLast,
    required this.isHydrating,
    required this.onCall,
    required this.onDirections,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: isLast ? Colors.transparent : AppTheme.veryLightGrey,
            width: 1,
          ),
        ),
      ),
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                number,
                style: AppTheme.barlowCondensed(
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  color: AppTheme.red,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '· ${_formatDistance(vet.distanceMeters)}',
                style: AppTheme.barlowCondensed(
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  color: AppTheme.fadedGrey,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            vet.name,
            style: AppTheme.barlow(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: AppTheme.black,
              letterSpacing: -0.2,
            ),
          ),
          if (vet.address != null && vet.address!.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text(
              vet.address!,
              style: AppTheme.barlow(
                fontSize: 12,
                color: AppTheme.grey,
                height: 1.3,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _ActionButton(
                  label: 'CALL',
                  icon: Icons.phone,
                  onTap: onCall,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _ActionButton(
                  label: 'DIRECTIONS',
                  icon: Icons.directions,
                  isLoading: isHydrating,
                  onTap: isHydrating ? null : onDirections,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Format distance compactly: under 1km show meters, otherwise
  /// kilometres with one decimal.
  static String _formatDistance(double? meters) {
    if (meters == null) return '';
    if (meters < 1000) return '${meters.round()} M';
    return '${(meters / 1000).toStringAsFixed(1)} KM';
  }
}

/// Compact tap-target button used inside a vet row. Smaller than CTA -
/// these are secondary actions, the row itself is the primary unit.
///
/// Supports a loading state for the Directions button, which has to
/// hit Ola Place Details before it can launch Google Maps. While the
/// fetch is in flight (typically 200-400ms), we show a small spinner
/// where the icon would be and disable the tap so the user can't fire
/// a second hydration call.
class _ActionButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isLoading;
  /// Null when the button is disabled (e.g. mid-hydration).
  final VoidCallback? onTap;
  const _ActionButton({
    required this.label,
    required this.icon,
    required this.onTap,
    this.isLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    final disabled = onTap == null;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        height: 40,
        decoration: BoxDecoration(
          border: Border.all(
            color: disabled ? AppTheme.veryLightGrey : AppTheme.lightGrey,
            width: 1,
          ),
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isLoading)
              SizedBox(
                width: 14,
                height: 14,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor:
                      AlwaysStoppedAnimation<Color>(AppTheme.grey),
                ),
              )
            else
              Icon(icon, size: 14, color: AppTheme.black),
            const SizedBox(width: 6),
            Text(
              label,
              style: AppTheme.barlow(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: disabled ? AppTheme.grey : AppTheme.black,
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
