import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme/app_theme.dart';
import '../core/config/api_config.dart';
import '../core/providers/alerts_provider.dart';
import '../core/services/profile_service.dart';
import '../widgets/top_bar.dart';
import '../widgets/cta_button.dart';
import '../widgets/bottom_nav.dart';

/// "Contact us" detail screen.
///
/// Reached via tapping row 02 on [HelpScreen]. Visual chrome matches
/// the Help index ("Need Help?") exactly: TopBar with paw + title +
/// online dot (no back arrow - the bottom nav and the OS back gesture
/// handle exit), 24px gutter, "02" eyebrow + condensed headline +
/// hairline rule, and a BottomNav anchored at the bottom showing the
/// user is still inside the Help tab. Form behaviour preserved exactly:
///   • Pre-filled, locked Name field (read from ProfileService)
///   • Subject, Email, Message fields
///   • Required email + strict format validation
///   • "Did you mean?" typo suggestion below the email field, tappable
///   • Confirm-email popup at submit time, styled to match
///     `_DeleteConfirmDialog` on ProfileScreen
///   • Sticky SEND MESSAGE CTA at the bottom
class HelpContactScreen extends ConsumerStatefulWidget {
  const HelpContactScreen({super.key});

  @override
  ConsumerState<HelpContactScreen> createState() => _HelpContactScreenState();
}

class _HelpContactScreenState extends ConsumerState<HelpContactScreen> {
  final _subjectCtrl = TextEditingController();
  final _emailCtrl   = TextEditingController();
  final _messageCtrl = TextEditingController();
  final _emailFocus  = FocusNode();
  String _name = '';
  bool _sending = false;
  String? _emailError;
  String? _emailSuggestion;

  // Strict-but-pragmatic email regex. Requires non-empty local part with
  // allowed chars only, exactly one @, a domain with at least one dot,
  // and a TLD of 2+ letters (rules out "name@gmail" and "name@gmail.").
  static final _emailRegex = RegExp(
    r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
  );

  // Common domain typos for the top email providers used in India.
  // Covers Gmail, Yahoo, Outlook/Hotmail/Live, iCloud, Rediffmail,
  // ProtonMail, Zoho, AOL, GMX, Yandex, Mail.com, plus a couple of
  // Indian ISP domains we still see in the wild. We surface these as
  // a "Did you mean?" suggestion below the field rather than silently
  // rewriting - silent rewrites can be wrong (e.g. someone with a
  // vanity domain) and the user has no idea it happened.
  static const _typoMap = <String, String>{
    // Gmail
    'gmial.com': 'gmail.com', 'gmal.com': 'gmail.com', 'gmai.com': 'gmail.com',
    'gnail.com': 'gmail.com', 'gmil.com': 'gmail.com', 'gmaill.com': 'gmail.com',
    'gamil.com': 'gmail.com', 'gemail.com': 'gmail.com', 'gmail.co': 'gmail.com',
    'gmail.con': 'gmail.com', 'gmail.cm': 'gmail.com', 'gmail.om': 'gmail.com',
    'gmail.comm': 'gmail.com', 'gmaol.com': 'gmail.com',
    // Yahoo
    'yahooo.com': 'yahoo.com', 'yaho.com': 'yahoo.com', 'yhoo.com': 'yahoo.com',
    'yahoo.co': 'yahoo.com', 'yahoo.con': 'yahoo.com', 'yahooo.in': 'yahoo.in',
    'yaho.in': 'yahoo.in', 'yahoo.co.i': 'yahoo.co.in',
    // Hotmail / Outlook / Live
    'hotmial.com': 'hotmail.com', 'hotmai.com': 'hotmail.com',
    'hotmal.com': 'hotmail.com', 'hotamail.com': 'hotmail.com',
    'hotmail.co': 'hotmail.com', 'hotmail.con': 'hotmail.com',
    'outlok.com': 'outlook.com', 'outloo.com': 'outlook.com',
    'outlook.co': 'outlook.com', 'outlook.con': 'outlook.com',
    'outloook.com': 'outlook.com', 'live.co': 'live.com', 'live.con': 'live.com',
    // Apple
    'icloud.co': 'icloud.com', 'icloud.con': 'icloud.com',
    'iclould.com': 'icloud.com', 'icoud.com': 'icloud.com',
    'me.co': 'me.com', 'me.con': 'me.com',
    // Rediff
    'rediffmial.com': 'rediffmail.com', 'rediffmal.com': 'rediffmail.com',
    'redifmail.com': 'rediffmail.com', 'rediff.co': 'rediff.com',
    'rediffmail.co': 'rediffmail.com',
    // Proton
    'protonmial.com': 'protonmail.com', 'protonmal.com': 'protonmail.com',
    'protonmail.co': 'protonmail.com', 'proton.m': 'proton.me',
    // Zoho
    'zoho.co': 'zoho.com', 'zohomail.co': 'zohomail.com', 'zoh.com': 'zoho.com',
    // AOL / GMX / Yandex / Mail.com
    'aol.co': 'aol.com', 'aol.con': 'aol.com', 'oal.com': 'aol.com',
    'gmx.co': 'gmx.com', 'gmx.con': 'gmx.com',
    'yandex.co': 'yandex.com', 'yandez.com': 'yandex.com',
    'mail.co': 'mail.com', 'mial.com': 'mail.com',
    // Indian ISPs
    'bsnl.i': 'bsnl.in', 'airtelmail.i': 'airtelmail.in',
  };

  @override
  void initState() {
    super.initState();
    _loadName();
    _subjectCtrl.addListener(() => setState(() {}));
    _emailCtrl.addListener(_onEmailChanged);
    _messageCtrl.addListener(() => setState(() {}));
  }

  Future<void> _loadName() async {
    final n = await ProfileService.getUserName() ?? '';
    if (!mounted) return;
    setState(() => _name = n);
  }

  @override
  void dispose() {
    _subjectCtrl.dispose();
    _emailCtrl.removeListener(_onEmailChanged);
    _emailCtrl.dispose();
    _messageCtrl.dispose();
    _emailFocus.dispose();
    super.dispose();
  }

  // Live-detect typos and surface a "Did you mean?" line. We don't show
  // generic format errors mid-type - that's annoying when someone's
  // halfway through their address - but typo suggestions are helpful
  // because they're proactive and the user can apply them with one tap.
  void _onEmailChanged() {
    final raw = _emailCtrl.text.trim();
    String? suggestion;

    if (raw.isNotEmpty) {
      final atIdx = raw.indexOf('@');
      if (atIdx > 0 && atIdx < raw.length - 1) {
        final domain = raw.substring(atIdx + 1).toLowerCase();
        final fix = _typoMap[domain];
        if (fix != null) {
          suggestion = '${raw.substring(0, atIdx + 1)}$fix';
        }
      }
    }

    setState(() {
      // Clear any submit-time error the moment the user starts editing.
      _emailError = null;
      _emailSuggestion = suggestion;
    });
  }

  // Apply the suggestion to the email field, leaving the cursor at the
  // end so the user can keep editing if they want. Listener fires from
  // the assignment and clears _emailSuggestion automatically.
  void _applySuggestion() {
    final s = _emailSuggestion;
    if (s == null) return;
    _emailCtrl.value = TextEditingValue(
      text: s,
      selection: TextSelection.collapsed(offset: s.length),
    );
  }

  /// Validate the email at submit time. Returns null on success, an
  /// error string otherwise.
  String? _validateEmail() {
    final raw = _emailCtrl.text.trim();
    if (raw.isEmpty) return 'Please enter your email so we can reply.';
    if (raw.length > 254) return 'Email is too long.';
    if (!_emailRegex.hasMatch(raw)) {
      return 'Please enter a valid email address.';
    }
    return null;
  }

  // SEND is enabled only when message + email are non-empty. The full
  // format check + confirm dialog runs in _send.
  bool get _canSend {
    if (_sending) return false;
    if (_messageCtrl.text.trim().isEmpty) return false;
    if (_emailCtrl.text.trim().isEmpty) return false;
    return true;
  }

  Future<void> _send() async {
    if (!_canSend) return;

    // Format gate. Reject obvious malformed input outright so the
    // confirm popup isn't asking the user "is asdf correct?".
    final emailErr = _validateEmail();
    if (emailErr != null) {
      setState(() => _emailError = emailErr);
      _emailFocus.requestFocus();
      return;
    }

    // Confirm popup. Even with format validation, "karthik@gmial.com"
    // (which our typo map catches) or "karthik@gnial.com" (which it
    // might not) are well-formed but unreachable. Showing the address
    // back to the user catches typos far more reliably than any
    // heuristic list.
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _ConfirmEmailDialog(email: _emailCtrl.text.trim()),
    );
    if (confirmed != true) {
      // User chose "EDIT EMAIL" - focus the field so they can fix it.
      if (mounted) _emailFocus.requestFocus();
      return;
    }

    if (!mounted) return;
    setState(() => _sending = true);
    try {
      final res = await http.post(
        Uri.parse('${ApiConfig.baseUrl}/feedback'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'name':    _name.isEmpty ? 'Anonymous' : _name,
          'email':   _emailCtrl.text.trim(),
          'subject': _subjectCtrl.text.trim(),
          'message': _messageCtrl.text.trim(),
        }),
      ).timeout(const Duration(seconds: 15));

      if (!mounted) return;
      if (res.statusCode == 200) {
        _subjectCtrl.clear();
        _emailCtrl.clear();
        _messageCtrl.clear();
        setState(() {
          _emailError = null;
          _emailSuggestion = null;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Message sent! We\'ll get back to you soon.'),
            backgroundColor: AppTheme.successGreenDark,
            behavior: SnackBarBehavior.floating,
          ),
        );
      } else {
        final body = res.body.length > 80 ? res.body.substring(0, 80) : res.body;
        debugPrint('feedback failed: ${res.statusCode} - $body');
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to send (HTTP ${res.statusCode}). Please try again.'),
            backgroundColor: AppTheme.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (e) {
      debugPrint('feedback exception: $e');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Network error. Check your connection and try again.'),
          backgroundColor: AppTheme.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      // SafeArea(bottom: false) for status-bar inset; bottomNav has its
      // own SafeArea(top: false). Mirrors the chrome that
      // MainNavigationScreen wraps around its tab bodies - we lose that
      // wrapper when pushed as a full route, so re-add it here.
      body: SafeArea(
        bottom: false,
        // Same TopBar pattern as the Help index ("Need Help?"): paw +
        // title + online dot, NO back arrow. The back affordance is the
        // bottom nav (and the OS back gesture, which still pops the
        // route normally).
        child: Column(
          children: [
            const TopBar(showOnline: true),
            // Headline + eyebrow - matches the visual rhythm of HelpScreen.
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '02',
                  style: AppTheme.barlowCondensed(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: AppTheme.red,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Contact',
                  style: AppTheme.barlowCondensed(
                    fontSize: 64,
                    fontWeight: FontWeight.w900,
                    color: AppTheme.black,
                    height: 0.92,
                    letterSpacing: -1.5,
                  ),
                ),
                Text(
                  'us',
                  style: AppTheme.barlowCondensed(
                    fontSize: 64,
                    fontWeight: FontWeight.w900,
                    color: AppTheme.red,
                    height: 0.92,
                    letterSpacing: -1.5,
                  ),
                ),
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 20),
                  height: 1,
                  color: AppTheme.black.withValues(alpha: 0.12),
                ),
                Text(
                  'Have a question or feedback? Send us a message.',
                  style: AppTheme.barlow(
                    fontSize: 13,
                    color: AppTheme.grey,
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
              children: [
                // NAME - locked, lock icon, floating label
                _BoxField(
                  label: 'Name',
                  value: _name.isEmpty ? '' : _name,
                  locked: true,
                ),
                const SizedBox(height: 10),
                // SUBJECT
                _BoxField(
                  label: 'Subject',
                  controller: _subjectCtrl,
                  hint: 'Subject',
                ),
                const SizedBox(height: 10),
                // EMAIL - required, with optional external focus node so
                // we can refocus it after the user taps "EDIT EMAIL" in
                // the confirm popup.
                _BoxField(
                  label: 'Your Email *',
                  controller: _emailCtrl,
                  focusNode: _emailFocus,
                  hint: 'Your Email (required)',
                  keyboardType: TextInputType.emailAddress,
                ),
                if (_emailError != null) ...[
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.error_outline,
                          size: 14, color: AppTheme.red),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          _emailError!,
                          style: AppTheme.barlow(
                            fontSize: 12,
                            color: AppTheme.red,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
                if (_emailSuggestion != null && _emailError == null) ...[
                  const SizedBox(height: 6),
                  GestureDetector(
                    onTap: _applySuggestion,
                    behavior: HitTestBehavior.opaque,
                    child: Row(
                      children: [
                        const Icon(Icons.lightbulb_outline,
                            size: 14, color: AppTheme.grey),
                        const SizedBox(width: 6),
                        Expanded(
                          child: RichText(
                            text: TextSpan(
                              style: AppTheme.barlow(
                                fontSize: 12,
                                color: AppTheme.grey,
                              ),
                              children: [
                                const TextSpan(text: 'Did you mean '),
                                TextSpan(
                                  text: _emailSuggestion,
                                  style: AppTheme.barlow(
                                    fontSize: 12,
                                    color: AppTheme.black,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const TextSpan(text: '? Tap to use.'),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 10),
                // MESSAGE - tall box
                _BoxField(
                  label: 'Message',
                  controller: _messageCtrl,
                  hint: 'Message',
                  minLines: 6,
                  maxLines: 10,
                ),
              ],
            ),
          ),
          // SEND MESSAGE CTA
          Container(
            color: AppTheme.white,
            padding: const EdgeInsets.fromLTRB(24, 12, 24, 20),
            child: CtaButton(
              label: 'SEND MESSAGE',
              trailingIcon: Icons.arrow_forward,
              onPressed: _canSend ? _send : null,
              isLoading: _sending,
            ),
          ),
          ],
        ),
      ),
      // BottomNav anchored to Help. Tapping any other tab pops back to
      // the Help index and switches the main scaffold via the shared
      // activeTabIndexProvider listener in MainNavigationScreen.
      bottomNavigationBar: SafeArea(
        top: false,
        child: BottomNav(
          active: NavTab.help,
          alertsHasDot: ref.watch(hasUnseenAlertsProvider),
          onChanged: (tab) {
            if (tab == NavTab.help) {
              Navigator.popUntil(context, (r) => r.isFirst);
              return;
            }
            Navigator.popUntil(context, (r) => r.isFirst);
            ref.read(activeTabIndexProvider.notifier).state =
                _tabIndex(tab);
          },
        ),
      ),
    );
  }

  // Mirrors MainNavigationScreen._indexOf locally to avoid importing the
  // navigator's internals.
  static int _tabIndex(NavTab t) {
    switch (t) {
      case NavTab.home:
        return 0;
      case NavTab.alerts:
        return 1;
      case NavTab.chats:
        return 2;
      case NavTab.profile:
        return 3;
      case NavTab.help:
        return 4;
    }
  }
}

/// Single bordered box field - matches HTML contact form exactly.
/// locked fields show offWhite bg + lock icon.
/// unlocked fields show white bg with inline placeholder.
/// When a value is present, a floating label appears above the border.
class _BoxField extends StatefulWidget {
  final String label;
  final String? hint;
  final String? value;
  final TextEditingController? controller;
  final FocusNode? focusNode;
  final bool locked;
  final TextInputType? keyboardType;
  final int minLines;
  final int maxLines;

  const _BoxField({
    required this.label,
    this.hint,
    this.value,
    this.controller,
    this.focusNode,
    this.locked = false,
    this.keyboardType,
    this.minLines = 1,
    this.maxLines = 1,
  });

  @override
  State<_BoxField> createState() => _BoxFieldState();
}

class _BoxFieldState extends State<_BoxField> {
  late final FocusNode _focus;
  late final bool _ownsFocus;

  @override
  void initState() {
    super.initState();
    // Use the parent's focus node if one is provided so callers can
    // programmatically focus the field. Otherwise own a local one.
    _ownsFocus = widget.focusNode == null;
    _focus = widget.focusNode ?? FocusNode();
    _focus.addListener(_onFocusChanged);
  }

  void _onFocusChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _focus.removeListener(_onFocusChanged);
    if (_ownsFocus) _focus.dispose();
    super.dispose();
  }

  bool get _hasValue =>
      widget.locked
          ? (widget.value?.isNotEmpty ?? false)
          : (widget.controller?.text.isNotEmpty ?? false);

  @override
  Widget build(BuildContext context) {
    final focused = _focus.hasFocus;
    final borderColor = focused ? AppTheme.black : AppTheme.border;

    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          decoration: BoxDecoration(
            color: AppTheme.white,
            border: Border.all(color: borderColor, width: 1.5),
          ),
          padding: EdgeInsets.fromLTRB(
              14, widget.minLines > 1 ? 12 : 10, 14,
              widget.minLines > 1 ? 12 : 10),
          child: Row(
            crossAxisAlignment: widget.minLines > 1
                ? CrossAxisAlignment.start
                : CrossAxisAlignment.center,
            children: [
              Expanded(
                child: widget.locked
                    ? Text(
                        widget.value ?? '',
                        style: AppTheme.barlow(
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                          color: AppTheme.black,
                        ),
                      )
                    : TextField(
                        controller: widget.controller,
                        focusNode: _focus,
                        keyboardType: widget.keyboardType,
                        minLines: widget.minLines,
                        maxLines: widget.maxLines,
                        cursorColor: AppTheme.black,
                        style: AppTheme.barlow(
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                          color: AppTheme.black,
                        ),
                        decoration: InputDecoration(
                          isDense: true,
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          contentPadding: EdgeInsets.zero,
                          hintText: widget.hint,
                          hintStyle: AppTheme.barlow(
                            fontSize: 15,
                            color: const Color(0xFFCCCCCC),
                          ),
                        ),
                      ),
              ),
              if (widget.locked) ...[
                const SizedBox(width: 8),
                const Icon(Icons.lock_outline,
                    size: 14, color: Color(0xFFBBBBBB)),
              ],
            ],
          ),
        ),
        // Floating label - shown when field has a value
        if (_hasValue)
          Positioned(
            top: -8,
            left: 10,
            child: Container(
              color: AppTheme.white,
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                widget.label.toUpperCase(),
                style: AppTheme.barlow(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFFAAAAAA),
                  letterSpacing: 1,
                ),
              ),
            ),
          ),
      ],
    );
  }
}

/// Email confirm dialog.
///
/// Mirrors the styling of _DeleteConfirmDialog in profile_screen.dart:
///   • zero-radius Dialog, white bg
///   • Barlow 800 20px heading, -0.3 letter-spacing
///   • Body in #555 with 1.5 line-height
///   • Two side-by-side buttons; secondary = grey "EDIT EMAIL",
///     primary = red "YES, SEND" - same 44px height, 12px Barlow 800,
///     1.5 letter-spacing as the rest of the app.
class _ConfirmEmailDialog extends StatelessWidget {
  final String email;
  const _ConfirmEmailDialog({required this.email});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Is this email correct?',
              style: AppTheme.barlow(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: AppTheme.black,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFFAFAFA),
                border: Border.all(color: AppTheme.border, width: 1.5),
              ),
              child: SelectableText(
                email,
                style: AppTheme.barlow(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.black,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              "We'll reply to this address. Double-check there are no typos - "
              "we won't be able to reach you if it's wrong.",
              style: AppTheme.barlow(
                fontSize: 14,
                color: const Color(0xFF555555),
                height: 1.5,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context, false),
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      height: 44,
                      color: AppTheme.white,
                      alignment: Alignment.center,
                      child: Text(
                        'EDIT EMAIL',
                        style: AppTheme.barlow(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.grey,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context, true),
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      height: 44,
                      color: AppTheme.red,
                      alignment: Alignment.center,
                      child: Text(
                        'YES, SEND',
                        style: AppTheme.barlow(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.white,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
