import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_app_installations/firebase_app_installations.dart';
import '../core/config/api_config.dart';
import '../core/constants/app_constants.dart';
import '../core/providers/chat_provider.dart';
import '../core/providers/location_provider.dart';
import '../core/providers/sos_state_provider.dart';
import '../core/services/chat_photo_service.dart';
import '../core/services/chat_voice_service.dart';
import '../core/services/notification_service.dart';
import '../core/services/profile_service.dart';
import '../core/theme/app_theme.dart';
import '../widgets/full_screen_photo_viewer.dart';

/// 1:1 chat between a volunteer and an SOS sender.
///
/// Mirrors the HTML `ChatScreen`:
///   • 52px header: back + avatar circle with initial + name (bold, -0.3 ls)
///     + district subtitle + phone call icon on the right
///   • Message list with bubbles:
///       mine   → right-aligned, black bg, white text, BR corner 4px
///       theirs → left-aligned, offWhite bg, black text, BL corner 4px
///   • Grey 42px TextField with placeholder + 42×42 circular black send button
///
/// Preserved behaviour:
///   • NotificationService.setActiveChatConvId on init/dispose
///   • shouldInitiate → POST chatInitiateEndpoint
///   • POST chatSendMessageEndpoint on send, restore text on failure
class ChatScreen extends ConsumerStatefulWidget {
  final String convId;
  final String otherFid;
  final String otherName;
  final String district;
  final bool shouldInitiate;

  const ChatScreen({
    super.key,
    required this.convId,
    required this.otherFid,
    required this.otherName,
    required this.district,
    this.shouldInitiate = false,
  });

  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  // Voice service is owned for the lifetime of this screen because it
  // wraps a stateful AudioRecorder + AudioPlayer. Photo service is
  // stateless and constructed on demand per capture.
  final ChatVoiceService _voiceService = ChatVoiceService();

  String? _myFid;
  bool _sending = false;
  bool _fetchingLocation = false;
  bool _capturingPhoto = false;
  bool _initiating = false;
  String? _initError;

  /// True once we've successfully streamed a non-null conversation
  /// document at least once. Lets us distinguish "still loading" from
  /// "the document was here but disappeared" — the latter happens
  /// when the backend's daily midnight-IST wipe deletes a conversation
  /// while the user has the chat open. Without this flag we'd silently
  /// fall through to the empty-list state, which looks like a bug to
  /// the user. With it, we render an explicit "this chat ended" notice.
  bool _haveSeenConversation = false;

  // Recording state. When _isRecording is true, the composer is
  // replaced by the recording strip in _buildInput. _recordingTimer
  // ticks every 100ms to update the live duration counter.
  bool _isRecording = false;
  Duration _recordingElapsed = Duration.zero;
  Timer? _recordingTimer;

  // Which voice URL is currently loaded in the player. Lets the
  // voice bubbles know which one is "active" so they can render
  // play vs pause icons correctly. Single global active voice -
  // tapping a different bubble stops the previous one.
  String? _playingUrl;
  bool _isPlaying = false;
  StreamSubscription<PlayerState>? _playerStateSub;

  @override
  void initState() {
    super.initState();
    NotificationService.setActiveChatConvId(widget.convId);
    _playerStateSub = _voiceService.playerStateStream.listen((state) {
      if (!mounted) return;
      setState(() {
        _isPlaying = state.playing;
        // When the track finishes, clear _playingUrl so the next tap
        // on the same bubble starts from the beginning instead of
        // resuming a finished track.
        if (state.processingState == ProcessingState.completed) {
          _playingUrl = null;
          _isPlaying = false;
        }
      });
    });
    _init();
  }

  @override
  void dispose() {
    NotificationService.setActiveChatConvId(null);
    _recordingTimer?.cancel();
    _playerStateSub?.cancel();
    _voiceService.dispose();
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    try {
      _myFid = await FirebaseInstallations.instance.getId();
    } catch (_) {
      /* non-fatal */
    }
    if (widget.shouldInitiate && mounted) await _initiate();
  }

  Future<void> _initiate() async {
    if (!mounted) return;
    setState(() {
      _initiating = true;
      _initError = null;
    });
    try {
      final myName = await ProfileService.getUserName() ?? 'Unknown';
      final res = await http
          .post(
            Uri.parse(ApiConfig.chatInitiateEndpoint),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'responder_fid': _myFid,
              'responder_name': myName,
              'sender_fid': widget.otherFid,
              'sender_name': widget.otherName,
              'district': widget.district,
            }),
          )
          .timeout(const Duration(seconds: 15));
      if (!mounted) return;
      setState(() {
        _initiating = false;
        if (res.statusCode != 200) {
          _initError = 'Failed to start conversation. Please try again.';
        }
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _initiating = false;
          _initError = 'Network error. Please check your connection.';
        });
      }
    }
  }

  Future<void> _send() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _myFid == null || _sending) return;
    setState(() => _sending = true);
    _msgCtrl.clear();
    try {
      final res = await http
          .post(
            Uri.parse(ApiConfig.chatSendMessageEndpoint),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'conv_id': widget.convId,
              'from_fid': _myFid,
              'text': text,
            }),
          )
          .timeout(const Duration(seconds: 10));
      if (!mounted) return;
      if (res.statusCode != 200) {
        _msgCtrl.text = text;
        _showSnack('Failed to send message. Please try again.');
      } else {
        WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
      }
    } catch (_) {
      if (mounted) {
        _msgCtrl.text = text;
        _showSnack('Network error. Message not sent.');
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  /// Capture the device's current GPS once and send it as a chat
  /// message containing a Google Maps URL.
  ///
  /// Format: `📍 https://www.google.com/maps?q=LAT,LNG`
  ///
  /// The exact `📍 https://www.google.com/maps?q=` prefix is recognised
  /// by [_MessageBubble] which renders a tappable "Open in Maps" line
  /// below the bubble for new client builds. Old client builds (still
  /// in production for the next 1-2 weeks until users auto-update) see
  /// it as plain text - they can long-press to copy the URL and paste
  /// into a browser. No backend changes needed; the chat backend treats
  /// this exactly like any other text message.
  ///
  /// Permission: this app already requires location-while-using
  /// permission (granted on first SOS). If the user has denied it, we
  /// surface a snackbar instead of opening the OS settings dialog -
  /// they can grant from the SOS flow which has the proper rationale.
  Future<void> _sendLocation() async {
    if (_myFid == null || _sending || _fetchingLocation) return;
    setState(() => _fetchingLocation = true);
    try {
      final svc = ref.read(locationServiceProvider);

      // Permission gate. The existing SOS flow already handles the
      // request-and-explain dance, so here we only check; if not
      // granted, point the user at the SOS flow to grant.
      final hasPerm = await svc.hasLocationPermission();
      if (!hasPerm) {
        if (!mounted) return;
        _showSnack('Location permission needed. Open Profile to enable.');
        return;
      }

      // forceFresh=true mirrors what the SOS flow does, so the pin is
      // current rather than a possibly-stale cached fix.
      final loc = await svc.getCurrentLocation(forceFresh: true)
          .timeout(const Duration(seconds: 12));
      if (!mounted) return;

      if (loc == null) {
        _showSnack('Could not get current location. Try again.');
        return;
      }

      // 6 decimals = ~11cm precision, more than enough for "I'm here"
      // without being misleadingly precise.
      final lat = loc.latitude.toStringAsFixed(6);
      final lng = loc.longitude.toStringAsFixed(6);
      final body = '📍 https://www.google.com/maps?q=$lat,$lng';

      final res = await http
          .post(
            Uri.parse(ApiConfig.chatSendMessageEndpoint),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'conv_id': widget.convId,
              'from_fid': _myFid,
              'text': body,
            }),
          )
          .timeout(const Duration(seconds: 10));
      if (!mounted) return;
      if (res.statusCode != 200) {
        _showSnack('Failed to send location. Please try again.');
      } else {
        WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
      }
    } catch (e) {
      debugPrint('chat_screen: send location failed: $e');
      if (mounted) _showSnack('Could not send location.');
    } finally {
      if (mounted) setState(() => _fetchingLocation = false);
    }
  }

  // ──────────────────────────────────────────────────────────────────
  // Attach sheet + chat media flows
  // ──────────────────────────────────────────────────────────────────

  /// Count photo and voice messages in the current message list. Used
  /// both to gate the at-cap modal AND to render the "X of N" labels
  /// in the attach sheet rows.
  ({int photos, int voice}) _countMediaInMessages(
      List<Map<String, dynamic>> messages) {
    int p = 0;
    int v = 0;
    for (final m in messages) {
      final kind = m['kind'];
      if (kind == 'photo') p++;
      if (kind == 'voice') v++;
    }
    return (photos: p, voice: v);
  }

  /// Reads current messages from the conv provider. Mirrors the read
  /// in _downloadChat - we want the freshest list at sheet-open time
  /// so the cap counts reflect everything the user has done up to now.
  List<Map<String, dynamic>> _currentMessages() {
    final convAsync = ref.read(conversationDocProvider(widget.convId));
    final conv = convAsync.valueOrNull;
    final raw = conv?['messages'] as List<dynamic>? ?? const [];
    return raw.cast<Map<String, dynamic>>();
  }

  /// Bottom sheet: three rows (photo, voice, location). Each row
  /// shows "X of N" if at-cap. Tapping at-cap routes to the respective
  /// at-cap modal so the user can delete one and try again.
  void _showAttachSheet() {
    final counts = _countMediaInMessages(_currentMessages());

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      builder: (sheetCtx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              // Drag handle. Decorative only.
              Container(
                width: 36,
                height: 4,
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: AppTheme.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              _attachSheetRow(
                sheetCtx: sheetCtx,
                icon: Icons.camera_alt_outlined,
                title: 'Take photo',
                subtitle: 'Capture a new photo. Up to $kMaxChatPhotos per chat.',
                count: counts.photos,
                max: kMaxChatPhotos,
                onTap: () {
                  Navigator.pop(sheetCtx);
                  if (counts.photos >= kMaxChatPhotos) {
                    _showPhotoAtCapModal();
                  } else {
                    _handleTakePhoto();
                  }
                },
              ),
              _attachSheetRow(
                sheetCtx: sheetCtx,
                icon: Icons.mic_none_outlined,
                title: 'Record voice note',
                subtitle: 'Up to 30 seconds. Up to $kMaxChatVoiceNotes per chat.',
                count: counts.voice,
                max: kMaxChatVoiceNotes,
                onTap: () {
                  Navigator.pop(sheetCtx);
                  if (counts.voice >= kMaxChatVoiceNotes) {
                    _showVoiceAtCapModal();
                  } else {
                    _handleRecordVoice();
                  }
                },
              ),
              _attachSheetRow(
                sheetCtx: sheetCtx,
                icon: Icons.location_on_outlined,
                title: 'Share current location',
                subtitle: 'Sends a Google Maps pin.',
                count: null,
                max: null,
                onTap: () {
                  Navigator.pop(sheetCtx);
                  _sendLocation();
                },
              ),
              const SizedBox(height: 12),
            ],
          ),
        );
      },
    );
  }

  Widget _attachSheetRow({
    required BuildContext sheetCtx,
    required IconData icon,
    required String title,
    required String subtitle,
    required int? count,
    required int? max,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: const BoxDecoration(
                color: AppTheme.black,
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              alignment: Alignment.center,
              child: Icon(icon, size: 22, color: AppTheme.white),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTheme.barlow(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.black,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: AppTheme.barlow(
                      fontSize: 12,
                      color: AppTheme.grey,
                    ),
                  ),
                ],
              ),
            ),
            if (count != null && max != null)
              Text(
                '$count of $max',
                style: AppTheme.barlow(
                  fontSize: 11,
                  color: count >= max ? AppTheme.red : AppTheme.grey,
                  fontWeight:
                      count >= max ? FontWeight.w600 : FontWeight.w400,
                ),
              ),
          ],
        ),
      ),
    );
  }

  /// Capture a photo and attach to the conversation. Handles all
  /// outcome branches with a specific snackbar so the user knows what
  /// happened.
  Future<void> _handleTakePhoto() async {
    if (_capturingPhoto || _myFid == null) return;
    setState(() => _capturingPhoto = true);

    try {
      final messages = _currentMessages();
      final photoCount = _countMediaInMessages(messages).photos;

      final result = await ChatPhotoService().captureAndUpload(
        convId: widget.convId,
        fromFid: _myFid!,
        currentPhotoCount: photoCount,
      );
      if (!mounted) return;

      switch (result.status) {
        case ChatPhotoCaptureStatus.success:
          WidgetsBinding.instance
              .addPostFrameCallback((_) => _scrollToBottom());
          break;
        case ChatPhotoCaptureStatus.cancelled:
          // User backed out of the camera. No snackbar needed.
          break;
        case ChatPhotoCaptureStatus.atLimit:
          // Defensive - we already gated in _showAttachSheet but if
          // the cap is hit while the camera was open, surface clearly.
          _showPhotoAtCapModal();
          break;
        case ChatPhotoCaptureStatus.permissionDenied:
          _showSnack('Camera permission needed. Open Settings to grant.');
          break;
        case ChatPhotoCaptureStatus.uploadFailed:
          _showSnack('Could not upload photo. Try again.');
          break;
        case ChatPhotoCaptureStatus.linkFailed:
          _showSnack('Photo uploaded but failed to attach. Try again.');
          break;
      }
    } finally {
      if (mounted) setState(() => _capturingPhoto = false);
    }
  }

  /// Begin a voice recording. Switches the composer to the recording
  /// strip and starts the live duration timer. Auto-stops at 30s.
  Future<void> _handleRecordVoice() async {
    if (_isRecording || _myFid == null) return;

    final ok = await _voiceService.startRecording(widget.convId);
    if (!mounted) return;
    if (!ok) {
      _showSnack('Microphone permission needed. Open Settings to grant.');
      return;
    }

    setState(() {
      _isRecording = true;
      _recordingElapsed = Duration.zero;
    });

    // Tick the duration counter at 100ms granularity. At 0:30 we
    // auto-stop the recorder but stay on the strip waiting for
    // confirm/cancel - the user can still discard rather than send
    // a recording they didn't mean to make.
    _recordingTimer?.cancel();
    _recordingTimer = Timer.periodic(
      const Duration(milliseconds: 100),
      (timer) async {
        if (!mounted) {
          timer.cancel();
          return;
        }
        final elapsed = _voiceService.currentRecordingElapsed;
        if (elapsed == null) return;
        setState(() => _recordingElapsed = elapsed);
        if (elapsed >= kMaxChatVoiceDuration) {
          // Hit the cap. Stop the recorder but stay on the strip so
          // the user can confirm or discard.
          timer.cancel();
          if (_voiceService.isRecording) {
            await _voiceService.stopRecording();
          }
        }
      },
    );
  }

  /// Confirm and upload the current recording. Called when the user
  /// taps the green ✓ button on the recording strip.
  Future<void> _confirmRecording() async {
    if (_myFid == null) return;
    _recordingTimer?.cancel();
    final duration = _recordingElapsed;
    File? file;
    if (_voiceService.isRecording) {
      file = await _voiceService.stopRecording();
    } else {
      // Already auto-stopped at 30s. The service keeps the path
      // around until discard or successful upload, so we can recover
      // the file from there.
      final p = _voiceService.currentRecordingPath;
      if (p != null) {
        final f = File(p);
        if (await f.exists()) file = f;
      }
    }

    if (!mounted) return;
    setState(() {
      _isRecording = false;
      _recordingElapsed = Duration.zero;
    });

    if (file == null) {
      // Edge case: recorder returned no file. Treat as a quiet
      // discard rather than a noisy error.
      debugPrint('chat_screen: confirm recording but no file returned');
      _showSnack('Recording could not be saved.');
      return;
    }

    final result = await _voiceService.uploadAndAttach(
      file: file,
      convId: widget.convId,
      fromFid: _myFid!,
      duration: duration,
    );
    if (!mounted) return;

    switch (result.status) {
      case ChatVoiceCaptureStatus.success:
        WidgetsBinding.instance
            .addPostFrameCallback((_) => _scrollToBottom());
        break;
      case ChatVoiceCaptureStatus.uploadFailed:
        _showSnack('Could not upload voice note. Try again.');
        break;
      case ChatVoiceCaptureStatus.linkFailed:
        _showSnack('Voice uploaded but failed to attach. Try again.');
        break;
      // The other statuses don't arise from this entry point but the
      // switch needs to be exhaustive.
      case ChatVoiceCaptureStatus.cancelled:
      case ChatVoiceCaptureStatus.atLimit:
      case ChatVoiceCaptureStatus.permissionDenied:
      case ChatVoiceCaptureStatus.recordFailed:
        _showSnack('Voice note failed.');
        break;
    }
  }

  /// Discard the current recording without uploading. Called when the
  /// user taps the ✕ button on the recording strip.
  Future<void> _discardRecording() async {
    _recordingTimer?.cancel();
    if (_voiceService.isRecording) {
      await _voiceService.stopRecording();
    }
    await _voiceService.discardRecording();
    if (!mounted) return;
    setState(() {
      _isRecording = false;
      _recordingElapsed = Duration.zero;
    });
  }

  /// At-cap modal for photos. Lists existing photo messages with
  /// trash buttons. Tapping trash → confirm dialog → on confirm,
  /// detach and re-open the camera.
  void _showPhotoAtCapModal() {
    final messages = _currentMessages();
    final photos = messages
        .where((m) => m['kind'] == 'photo')
        .toList(growable: false);
    _showMediaAtCapModal(
      title: '$kMaxChatPhotos photos already attached',
      subtitle: 'Delete one to take a new photo.',
      items: photos,
      isPhoto: true,
    );
  }

  /// At-cap modal for voice notes.
  void _showVoiceAtCapModal() {
    final messages = _currentMessages();
    final voices = messages
        .where((m) => m['kind'] == 'voice')
        .toList(growable: false);
    _showMediaAtCapModal(
      title: '$kMaxChatVoiceNotes voice notes already attached',
      subtitle: 'Delete one to record a new voice note.',
      items: voices,
      isPhoto: false,
    );
  }

  void _showMediaAtCapModal({
    required String title,
    required String subtitle,
    required List<Map<String, dynamic>> items,
    required bool isPhoto,
  }) {
    showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (modalCtx) {
        return Dialog(
          backgroundColor: AppTheme.white,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          insetPadding: const EdgeInsets.symmetric(horizontal: 24),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: AppTheme.barlow(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.black,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  subtitle,
                  style: AppTheme.barlow(
                    fontSize: 13,
                    color: AppTheme.grey,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 16),
                ...items.asMap().entries.map((entry) {
                  final i = entry.key;
                  final m = entry.value;
                  final url = isPhoto
                      ? m['photo_url'] as String?
                      : m['voice_url'] as String?;
                  final ts = m['timestamp'];
                  final ownerFid = m['from'] as String?;
                  final canDelete = ownerFid == _myFid;
                  return _atCapRow(
                    label: isPhoto
                        ? 'Photo ${i + 1}'
                        : 'Voice note ${i + 1}',
                    timestamp: ts,
                    canDelete: canDelete,
                    onDelete: () async {
                      if (url == null) return;
                      final confirmed = await _confirmDeleteDialog(
                        modalCtx,
                        isPhoto
                            ? 'Delete this photo?'
                            : 'Delete this voice note?',
                      );
                      if (!confirmed) return;
                      bool ok;
                      if (isPhoto) {
                        ok = await ChatPhotoService().deletePhoto(
                          convId: widget.convId,
                          fromFid: _myFid!,
                          url: url,
                        );
                      } else {
                        ok = await _voiceService.deleteVoice(
                          convId: widget.convId,
                          fromFid: _myFid!,
                          url: url,
                        );
                      }
                      if (!mounted) return;
                      if (ok) {
                        Navigator.of(modalCtx).pop();
                        // Re-open the relevant capture flow so the
                        // user doesn't have to manually re-tap attach.
                        if (isPhoto) {
                          _handleTakePhoto();
                        } else {
                          _handleRecordVoice();
                        }
                      } else {
                        _showSnack('Could not delete. Try again.');
                      }
                    },
                  );
                }),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () => Navigator.of(modalCtx).pop(),
                    child: Text(
                      'Cancel',
                      style: AppTheme.barlow(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: AppTheme.grey,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _atCapRow({
    required String label,
    required dynamic timestamp,
    required bool canDelete,
    required VoidCallback onDelete,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(8),
      color: AppTheme.offWhite,
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            color: AppTheme.lightGrey,
            alignment: Alignment.center,
            child: const Icon(Icons.attachment,
                size: 20, color: AppTheme.grey),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: AppTheme.barlow(
                    fontSize: 13,
                    color: AppTheme.black,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _MessageBubble._fmtTime(timestamp),
                  style: AppTheme.barlow(
                    fontSize: 11,
                    color: AppTheme.grey,
                  ),
                ),
              ],
            ),
          ),
          if (canDelete)
            GestureDetector(
              onTap: onDelete,
              behavior: HitTestBehavior.opaque,
              child: Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  border: Border.all(color: AppTheme.dangerBorder),
                ),
                alignment: Alignment.center,
                child: const Icon(Icons.delete_outline,
                    size: 14, color: AppTheme.red),
              ),
            )
          else
            // Other party's media - they alone can delete it.
            const SizedBox(width: 32, height: 32),
        ],
      ),
    );
  }

  Future<bool> _confirmDeleteDialog(BuildContext ctx, String title) async {
    final confirmed = await showDialog<bool>(
      context: ctx,
      builder: (dCtx) => AlertDialog(
        backgroundColor: AppTheme.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        title: Text(
          title,
          style: AppTheme.barlow(
            fontSize: 15,
            fontWeight: FontWeight.w600,
            color: AppTheme.black,
          ),
        ),
        content: Text(
          "This can't be undone.",
          style: AppTheme.barlow(fontSize: 13, color: AppTheme.grey),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dCtx).pop(false),
            child: Text(
              'Cancel',
              style: AppTheme.barlow(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: AppTheme.grey,
              ),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(dCtx).pop(true),
            child: Text(
              'Delete',
              style: AppTheme.barlow(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppTheme.red,
              ),
            ),
          ),
        ],
      ),
    );
    return confirmed == true;
  }

  /// Toggle voice playback for a given URL. Called by voice bubbles
  /// when the user taps the play/pause button.
  ///
  /// Single global active player - tapping a different bubble stops
  /// the previous and loads the new one. Re-tapping the active one
  /// pauses (or resumes if already paused).
  Future<void> _toggleVoicePlayback(String url) async {
    if (_playingUrl == url) {
      // Same bubble - pause/resume.
      if (_isPlaying) {
        await _voiceService.pausePlayback();
      } else {
        await _voiceService.resumePlayback();
      }
    } else {
      // Different bubble - stop previous, load and play new.
      await _voiceService.stopPlayback();
      if (!mounted) return;
      // Optimistic: assume playback will start. The player state
      // listener will correct _isPlaying if loading fails. Without
      // this, the bubble briefly shows "play" even after the user
      // tapped it, until the listener fires.
      setState(() {
        _playingUrl = url;
        _isPlaying = true;
      });
      await _voiceService.playFromUrl(url);
    }
  }

  void _scrollToBottom() {
    if (_scrollCtrl.hasClients) {
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    }
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: AppTheme.red),
    );
  }

  /// Tries to open the device dialer pre-populated with the sender's mobile
  /// number. The number is only exposed while the sender's SOS alert is
  /// active - once the alert ends or expires, this falls back to the
  /// "only available while the alert is active" snackbar.
  ///
  /// Source of truth: `sos_alerts/{otherFid}` → `userInfo.mobile_number`.
  /// We additionally check the alert's age against [AppConstants.alertTtl]
  /// so a stale doc that hasn't been cleaned up yet doesn't leak the
  /// number after the privacy window has closed.
  Future<void> _call() async {
    String? mobile;
    try {
      final doc = await FirebaseFirestore.instance
          .collection('sos_alerts')
          .doc(widget.otherFid)
          .get();
      final data = doc.data();
      if (data != null) {
        // Honor TTL - if the alert exists but is past expiry, treat the
        // number as unavailable. Mirrors the gating used in
        // alerts_provider.dart.
        final tsField = data['timestamp'];
        int tsMs = 0;
        if (tsField is Timestamp) {
          tsMs = tsField.millisecondsSinceEpoch;
        } else if (tsField is int) {
          tsMs = tsField;
        }
        final ageMs = DateTime.now().millisecondsSinceEpoch - tsMs;
        final withinWindow = tsMs > 0 &&
            ageMs <= AppConstants.alertTtl.inMilliseconds;
        if (withinWindow) {
          final userInfo =
              data['userInfo'] as Map<String, dynamic>? ?? const {};
          final raw = (userInfo['mobile_number'] ?? userInfo['phone'] ?? '')
              .toString()
              .trim();
          if (raw.isNotEmpty) mobile = raw;
        }
      }
    } catch (e) {
      debugPrint('chat_screen: phone lookup failed: $e');
    }

    if (mobile == null || mobile.isEmpty) {
      // Pick a message that actually explains the privacy rule. The
      // generic "phone number is only available while the alert is
      // active" doesn't tell the user *why* they can't dial. The rule
      // is one-directional: only responders can call senders, never
      // the other way around. So:
      //   - If I'm currently the sender of an active SOS, the icon is
      //     a no-op for me. Tell me responders are the ones who can
      //     call, not me.
      //   - Otherwise (I'm a responder and the alert ended, or there's
      //     no active alert at all), the original framing is right -
      //     the number was only exposed during the active window.
      final iAmActiveSender = ref.read(sosStateProvider).isActive;
      final msg = iAmActiveSender
          ? 'Only responders can call you while your alert is active.'
          : 'Phone number is only available while the alert is active.';
      _showSnack(msg);
      return;
    }

    try {
      final ok = await launchUrl(Uri(scheme: 'tel', path: mobile));
      if (!ok) _showSnack('Could not open dialer on this device.');
    } catch (e) {
      debugPrint('chat_screen: launchUrl error: $e');
      _showSnack('Could not start call.');
    }
  }

  /// Show the chat-level menu (currently: download as text). Bottom sheet
  /// rather than PopupMenuButton because (a) it gives more touch area on
  /// phones, (b) it matches the modal-confirmation pattern used elsewhere
  /// in the app, and (c) it leaves room to add more options later
  /// without forcing a layout change.
  void _showChatMenu() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.download_outlined,
                    color: AppTheme.black),
                title: Text(
                  'Download chat as text',
                  style: AppTheme.barlow(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.black,
                  ),
                ),
                onTap: () {
                  Navigator.pop(ctx);
                  _downloadChat();
                },
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  /// Read the current message list, format it as plain text, write to a
  /// temp file, and open the system share sheet. The user can then save
  /// the file to Files / Drive / send via WhatsApp / email it / whatever.
  ///
  /// Failure modes - all caught, none crash the chat:
  ///   - empty conversation -> snackbar, no file written
  ///   - file write fails (disk full, permission) -> snackbar
  ///   - share sheet cancelled -> silent (user choice)
  Future<void> _downloadChat() async {
    try {
      // Read fresh from the provider rather than relying on whatever
      // build() last computed - if the user added messages between
      // tapping the menu icon and tapping download, we want those.
      final convAsync =
          ref.read(conversationDocProvider(widget.convId));
      final conv = convAsync.valueOrNull;
      final rawMessages = conv?['messages'] as List<dynamic>? ?? [];
      final messages = rawMessages.cast<Map<String, dynamic>>();

      if (messages.isEmpty) {
        _showSnack('No messages to download yet.');
        return;
      }

      final transcript = _formatTranscript(messages);

      // Filename: rrt_chat_{otherName}_{yyyy-MM-dd_HHmm}.txt
      // Sanitise otherName to be filesystem-safe (strip / \ : * ? " < > |)
      final safeName = widget.otherName
          .replaceAll(RegExp(r'[\\/:*?"<>|]'), '_')
          .trim();
      final now = DateTime.now();
      final stamp = '${now.year}-'
          '${now.month.toString().padLeft(2, '0')}-'
          '${now.day.toString().padLeft(2, '0')}_'
          '${now.hour.toString().padLeft(2, '0')}'
          '${now.minute.toString().padLeft(2, '0')}';
      final filename = 'rrt_chat_${safeName}_$stamp.txt';

      final tmp = await getTemporaryDirectory();
      final file = File('${tmp.path}/$filename');
      await file.writeAsString(transcript);

      // iOS 26 specific: share_plus throws PlatformException if
      // sharePositionOrigin is zero or absent. We pass a real anchor
      // rect derived from screen size - on iPhone the sheet centres
      // regardless, on iPad it positions the popover near the bottom
      // of the screen so the popover arrow is visible. See:
      // https://github.com/fluttercommunity/plus_plugins/issues/3685
      if (!mounted) return;
      final size = MediaQuery.of(context).size;
      final anchor = Rect.fromLTWH(
        size.width / 2 - 1,
        size.height - 80,
        2,
        2,
      );
      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'text/plain')],
        subject: 'RRT chat with ${widget.otherName}',
        sharePositionOrigin: anchor,
      );
    } catch (e, st) {
      debugPrint('chat_screen: download chat failed: $e\n$st');
      if (!mounted) return;
      _showSnack('Could not export chat. Please try again.');
    }
  }

  /// Build the plain-text transcript. Format chosen to be readable as
  /// a .txt file in any editor and also paste cleanly into messaging
  /// apps if the user shares it that way:
  ///
  ///   RRT chat with <otherName>
  ///   <conversation district> · exported <date time>
  ///   ────────────────────────────────────
  ///
  ///   [HH:MM, DD MMM YYYY] You: Hello
  ///   [HH:MM, DD MMM YYYY] <otherName>: Hi
  ///   ...
  String _formatTranscript(List<Map<String, dynamic>> messages) {
    final buf = StringBuffer();
    final exportedAt = DateTime.now();
    buf.writeln('RRT chat with ${widget.otherName}');
    buf.writeln('${_titleCase(widget.district.replaceAll('_', ' '))} · '
        'exported ${_fmtFullTimestamp(exportedAt)}');
    buf.writeln('────────────────────────────────────');
    buf.writeln();

    for (final m in messages) {
      final isMe = m['from'] == _myFid;
      final sender = isMe ? 'You' : widget.otherName;
      final text = (m['text'] as String?) ?? '';
      final ts = m['timestamp'];
      String when = '';
      if (ts is int) {
        when = _fmtFullTimestamp(DateTime.fromMillisecondsSinceEpoch(ts));
      }
      buf.writeln(when.isEmpty
          ? '$sender: $text'
          : '[$when] $sender: $text');
    }

    return buf.toString();
  }

  static String _fmtFullTimestamp(DateTime dt) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    final hh = dt.hour.toString().padLeft(2, '0');
    final mm = dt.minute.toString().padLeft(2, '0');
    return '$hh:$mm, ${dt.day} ${months[dt.month - 1]} ${dt.year}';
  }

  @override
  Widget build(BuildContext context) {
    final convAsync = ref.watch(conversationDocProvider(widget.convId));

    // Resolve "is the underlying SOS alert still active" once, so both the
    // header (phone icon visibility) and the body (input gating) see a
    // single source of truth. Header is hidden-by-default while loading -
    // we never want to expose a dial-tap on a stale number, even briefly.
    final conv = convAsync.valueOrNull;

    // Mark that we've successfully seen the conversation at least once.
    // This is what lets us tell "loading" apart from "deleted out from
    // under us" later. Set in a post-frame callback because we're inside
    // a build() call and can't setState directly.
    if (conv != null && !_haveSeenConversation) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && !_haveSeenConversation) {
          setState(() => _haveSeenConversation = true);
        }
      });
    }

    // Has the conversation been deleted while we had it open? This
    // happens when the daily midnight-IST wipe runs against a chat the
    // user is currently using. We treat it as a terminal state: show a
    // clear notice, disable input, do not silently fall through to an
    // empty list.
    final wasDeletedMidSession = _haveSeenConversation && conv == null;

    final activeOwner =
        conv?['active_alert_owner'] as String? ?? widget.otherFid;
    final sessionId = conv?['chat_sos_session_id'] as String? ?? '';
    final activeOwner2 =
        conv?['active_alert_owner_2'] as String? ?? '';
    final sessionId2 = conv?['chat_sos_session_id_2'] as String? ?? '';

    final sessionActiveAsync = ref.watch(chatSessionActiveProvider((
      owner: activeOwner,
      session: sessionId,
      owner2: activeOwner2,
      session2: sessionId2,
    )));

    // Phone icon: ONLY when we positively know the alert is active. Default
    // hidden during loading or unknown state (privacy-first). Also hidden
    // post-deletion - the underlying alert may still be active server-side
    // but we have no way to verify the chat session is still valid.
    final phoneVisible =
        !wasDeletedMidSession && sessionActiveAsync.valueOrNull == true;

    // Body input gating: optimistic during loading (existing behaviour) -
    // we don't want to disable typing just because the doc hasn't streamed
    // back yet. After a mid-session deletion, force-disable input - the
    // server would reject the message anyway.
    final bodyIsActive = wasDeletedMidSession
        ? false
        : conv == null
            ? true
            : sessionActiveAsync.valueOrNull ?? true;

    return Scaffold(
      backgroundColor: AppTheme.white,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(phoneVisible: phoneVisible),
            Expanded(
              child: convAsync.when(
                loading: () => const Center(
                  child: CircularProgressIndicator(color: AppTheme.red),
                ),
                error: (_, __) => _buildErrorState(),
                data: (conv) => _buildBody(
                  conv,
                  bodyIsActive,
                  wasDeletedMidSession: wasDeletedMidSession,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ────────────── header ──────────────

  Widget _buildHeader({required bool phoneVisible}) {
    return Container(
      height: 52,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: const BoxDecoration(
        color: AppTheme.white,
        border: Border(bottom: BorderSide(color: AppTheme.border, width: 1)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            behavior: HitTestBehavior.opaque,
            child: const Padding(
              padding: EdgeInsets.only(right: 10, top: 4, bottom: 4),
              child: Icon(Icons.arrow_back_ios_new_rounded,
                  size: 18, color: AppTheme.black),
            ),
          ),
          // Avatar circle
          Container(
            width: 34,
            height: 34,
            decoration: const BoxDecoration(
              color: AppTheme.black,
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              _initial(widget.otherName),
              style: AppTheme.barlowCondensed(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: AppTheme.white,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  widget.otherName,
                  overflow: TextOverflow.ellipsis,
                  style: AppTheme.barlow(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.black,
                    letterSpacing: -0.3,
                    height: 1.1,
                  ),
                ),
                // Only render the district subtitle when there's
                // actually text. An empty Text() still takes a full
                // line of vertical space (~14px line-height) which
                // pushes the name upward in the Row's centred layout
                // and produces the "name floats too high" misalignment.
                if (_titleCase(widget.district.replaceAll('_', ' ').trim())
                    .isNotEmpty)
                  Text(
                    _titleCase(widget.district.replaceAll('_', ' ').trim()),
                    overflow: TextOverflow.ellipsis,
                    style: AppTheme.barlow(
                      fontSize: 11,
                      color: AppTheme.grey,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 0.3,
                    ),
                  ),
              ],
            ),
          ),
          // Phone icon is rendered ONLY when the linked SOS alert is
          // actively in flight. Once the alert ends or expires, the icon
          // disappears in real time - the underlying mobile number stops
          // being available the moment the privacy window closes.
          if (phoneVisible)
            GestureDetector(
              onTap: _call,
              behavior: HitTestBehavior.opaque,
              child: Container(
                width: 36,
                height: 36,
                alignment: Alignment.center,
                child: const Icon(Icons.phone_outlined,
                    size: 18, color: AppTheme.black),
              ),
            ),
          // "More" menu - always visible. Currently exposes a single
          // option (download chat as text) but kept as a menu so future
          // chat-level actions (mute, report, etc.) can hang off the
          // same trigger without changing the header layout.
          GestureDetector(
            onTap: _showChatMenu,
            behavior: HitTestBehavior.opaque,
            child: Container(
              width: 36,
              height: 36,
              alignment: Alignment.center,
              child: const Icon(Icons.more_vert,
                  size: 20, color: AppTheme.black),
            ),
          ),
        ],
      ),
    );
  }

  // ────────────── body ──────────────

  Widget _buildBody(
    Map<String, dynamic>? conv,
    bool isActive, {
    bool wasDeletedMidSession = false,
  }) {
    if (_initiating) {
      return const Center(
        child: CircularProgressIndicator(color: AppTheme.red),
      );
    }
    if (_initError != null) {
      return _buildErrorState();
    }

    // Mid-session deletion path: the conversation document existed
    // earlier in this screen's lifetime but is now gone. The most
    // common cause is the backend's daily midnight-IST wipe firing
    // while the user has the chat open. Render an explicit notice
    // instead of the silent empty state — never let a chat just go
    // blank without explanation. Input is disabled (server would
    // reject anyway since the document no longer exists).
    if (wasDeletedMidSession) {
      return _buildEndedState();
    }

    // isActive is computed in build() and passed in - single source of
    // truth shared with the header's phone-icon visibility.

    final rawMessages = conv?['messages'] as List<dynamic>? ?? [];
    final messages = rawMessages.cast<Map<String, dynamic>>();

    return Column(
      children: [
        if (!isActive) _buildArchivedBanner(),
        Expanded(
          child: messages.isEmpty
              ? _buildEmpty(isActive)
              : ListView.builder(
                  controller: _scrollCtrl,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 14),
                  itemCount: messages.length,
                  itemBuilder: (_, i) {
                    final m = messages[i];
                    final isMe = m['from'] == _myFid;
                    final voiceUrl = m['voice_url'] as String?;
                    final isThisVoicePlaying =
                        voiceUrl != null && voiceUrl == _playingUrl && _isPlaying;
                    return _MessageBubble(
                      message: m,
                      isMe: isMe,
                      myFid: _myFid ?? '',
                      convId: widget.convId,
                      otherName: widget.otherName,
                      isVoicePlaying: isThisVoicePlaying,
                      onVoicePlayTap: voiceUrl == null
                          ? null
                          : () => _toggleVoicePlayback(voiceUrl),
                    );
                  },
                ),
        ),
        if (isActive) _buildInput(),
      ],
    );
  }

  Widget _buildEmpty(bool isActive) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.chat_bubble_outline,
                size: 42, color: AppTheme.border),
            const SizedBox(height: 14),
            Text(
              isActive ? 'NO MESSAGES YET' : 'CONVERSATION ARCHIVED',
              style: AppTheme.barlow(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: AppTheme.grey,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              isActive
                  ? 'Say hello, or share how you can help.'
                  : 'Chat resumes only when a new SOS is raised.',
              textAlign: TextAlign.center,
              style: AppTheme.barlow(
                fontSize: 13,
                color: AppTheme.subtleGrey,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Rendered when the conversation document was deleted while we
  /// had it open. Most common cause: the backend's daily midnight-IST
  /// wipe firing while the user was using the chat. Different from
  /// _buildErrorState (transient/network error) and _buildArchivedBanner
  /// (alert ended but conversation still exists). This state is
  /// terminal — the document is gone, future messages would fail.
  Widget _buildEndedState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.history_toggle_off,
                size: 42, color: AppTheme.grey),
            const SizedBox(height: 14),
            Text(
              'CHAT ENDED',
              style: AppTheme.barlow(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: AppTheme.grey,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'This conversation was cleared in the daily reset. '
              'Chats clear at midnight (IST) every day. If a new '
              'SOS is raised, a new chat will start.',
              textAlign: TextAlign.center,
              style: AppTheme.barlow(
                fontSize: 13,
                color: AppTheme.subtleGrey,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline, size: 42, color: AppTheme.grey),
            const SizedBox(height: 14),
            Text(
              'UNABLE TO LOAD CHAT',
              style: AppTheme.barlow(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: AppTheme.grey,
                letterSpacing: 2,
              ),
            ),
            if (_initError != null) ...[
              const SizedBox(height: 8),
              Text(
                _initError!,
                textAlign: TextAlign.center,
                style: AppTheme.barlow(
                    fontSize: 13, color: AppTheme.subtleGrey, height: 1.5),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: _initiate,
                behavior: HitTestBehavior.opaque,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                  color: AppTheme.black,
                  child: Text(
                    'RETRY',
                    style: AppTheme.barlow(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.white,
                      letterSpacing: 2,
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildArchivedBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      color: AppTheme.amberBg,
      child: Row(
        children: [
          const Icon(Icons.archive_outlined,
              size: 14, color: AppTheme.amberIcon),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Archived. Resumes when a new SOS is raised.',
              style: AppTheme.barlow(
                fontSize: 12,
                color: AppTheme.amberText,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput() {
    if (_isRecording) {
      return _buildRecordingStrip();
    }
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
      decoration: const BoxDecoration(
        color: AppTheme.white,
        border: Border(top: BorderSide(color: AppTheme.border, width: 1)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Single paperclip button (replaces the standalone 📍 button
          // from group A). Tapping it opens a bottom sheet with three
          // options: take photo / record voice / share location.
          // Disabled while a previous attach is in flight, to mirror
          // the send button's gating.
          GestureDetector(
            onTap: (_sending || _fetchingLocation || _capturingPhoto)
                ? null
                : _showAttachSheet,
            behavior: HitTestBehavior.opaque,
            child: Opacity(
              opacity: (_sending || _fetchingLocation || _capturingPhoto)
                  ? 0.4
                  : 1.0,
              child: Container(
                width: 42,
                height: 42,
                alignment: Alignment.center,
                child: (_capturingPhoto || _fetchingLocation)
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppTheme.black,
                        ),
                      )
                    : const Icon(Icons.attach_file,
                        size: 22, color: AppTheme.black),
              ),
            ),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Container(
              constraints: const BoxConstraints(minHeight: 42),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
              decoration: BoxDecoration(
                border: Border.all(color: AppTheme.border, width: 1),
              ),
              child: TextField(
                controller: _msgCtrl,
                maxLines: 4,
                minLines: 1,
                cursorColor: AppTheme.black,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                style: AppTheme.barlow(fontSize: 14, color: AppTheme.black),
                decoration: InputDecoration(
                  isDense: true,
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  hintText: 'Type a message',
                  hintStyle: AppTheme.barlow(
                    fontSize: 14,
                    color: AppTheme.subtleGrey,
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 10),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _sending ? null : _send,
            behavior: HitTestBehavior.opaque,
            child: Opacity(
              opacity: _sending ? 0.6 : 1.0,
              child: Container(
                width: 42,
                height: 42,
                decoration: const BoxDecoration(
                  color: AppTheme.black,
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: _sending
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Icon(Icons.send, size: 16, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Shown in place of the composer while a voice note is being
  /// recorded. Red dot, label, live counter (mm:ss / 0:30), and
  /// confirm/cancel buttons.
  Widget _buildRecordingStrip() {
    final secs = _recordingElapsed.inSeconds;
    final mm = (secs ~/ 60).toString().padLeft(1, '0');
    final ss = (secs % 60).toString().padLeft(2, '0');
    final maxSecs = kMaxChatVoiceDuration.inSeconds;
    final maxMm = (maxSecs ~/ 60).toString().padLeft(1, '0');
    final maxSs = (maxSecs % 60).toString().padLeft(2, '0');

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 14, 14),
      decoration: const BoxDecoration(
        color: AppTheme.dangerBg,
        border: Border(top: BorderSide(color: AppTheme.border, width: 1)),
      ),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: const BoxDecoration(
              color: AppTheme.red,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            'Recording',
            style: AppTheme.barlow(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppTheme.red,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            '$mm:$ss / $maxMm:$maxSs',
            style: AppTheme.barlow(
              fontSize: 13,
              color: AppTheme.red,
            ),
          ),
          const Spacer(),
          // Discard
          GestureDetector(
            onTap: _discardRecording,
            behavior: HitTestBehavior.opaque,
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: AppTheme.white,
                shape: BoxShape.circle,
                border: Border.all(color: AppTheme.dangerBorder),
              ),
              alignment: Alignment.center,
              child: const Icon(Icons.close,
                  size: 16, color: AppTheme.red),
            ),
          ),
          const SizedBox(width: 8),
          // Confirm
          GestureDetector(
            onTap: _confirmRecording,
            behavior: HitTestBehavior.opaque,
            child: Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(
                color: AppTheme.red,
                shape: BoxShape.circle,
              ),
              alignment: Alignment.center,
              child: const Icon(Icons.check,
                  size: 18, color: AppTheme.white),
            ),
          ),
        ],
      ),
    );
  }

  static String _initial(String n) =>
      n.trim().isEmpty ? '?' : n.trim()[0].toUpperCase();

  static String _titleCase(String s) => s
      .split(' ')
      .map((w) => w.isEmpty ? w : w[0].toUpperCase() + w.substring(1))
      .join(' ');
}

// ─────────── Bubble ───────────
class _MessageBubble extends StatelessWidget {
  /// The full message map from Firestore. Branches on `kind`:
  ///   - 'photo' → photo thumbnail bubble, tap → FullScreenPhotoViewer
  ///   - 'voice' → play/pause + decorative waveform + duration label
  ///   - text/location/missing → text or location bubble (preserved)
  final Map<String, dynamic> message;
  final bool isMe;
  final String myFid;
  final String convId;
  final String otherName;

  /// Whether this voice bubble is the currently-active one in the
  /// chat-screen-level player. Drives play vs pause icon.
  final bool isVoicePlaying;

  /// Callback to toggle this bubble's playback. Null for non-voice
  /// messages.
  final VoidCallback? onVoicePlayTap;

  const _MessageBubble({
    required this.message,
    required this.isMe,
    required this.myFid,
    required this.convId,
    required this.otherName,
    required this.isVoicePlaying,
    required this.onVoicePlayTap,
  });

  String get _text => (message['text'] as String?) ?? '';
  String? get _kind => message['kind'] as String?;
  String? get _photoUrl => message['photo_url'] as String?;
  String? get _voiceUrl => message['voice_url'] as String?;
  int? get _voiceDurationMs {
    final v = message['voice_duration_ms'];
    if (v is int) return v;
    if (v is double) return v.toInt();
    return null;
  }

  dynamic get _timestamp => message['timestamp'];

  /// Marker prefix we use to recognise location messages we sent from
  /// [_sendLocation]. Format must match exactly:
  ///   📍 https://www.google.com/maps?q=LAT,LNG
  static const String _locationPrefix = '📍 https://www.google.com/maps?q=';

  String? get _locationUrl {
    if (!_text.startsWith(_locationPrefix)) return null;
    final url = _text.substring('📍 '.length).trim();
    final uri = Uri.tryParse(url);
    if (uri == null || !uri.hasScheme) return null;
    return url;
  }

  Future<void> _openMaps(BuildContext context) async {
    final url = _locationUrl;
    if (url == null) return;
    try {
      final ok = await launchUrl(
        Uri.parse(url),
        mode: LaunchMode.externalApplication,
      );
      if (!ok && context.mounted) {
        _toast(context, 'Could not open Maps. Long-press to copy the link.');
      }
    } catch (e) {
      debugPrint('_MessageBubble._openMaps: $e');
    }
  }

  void _toast(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: AppTheme.barlow(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: AppTheme.white,
          ),
        ),
        backgroundColor: AppTheme.black,
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        mainAxisAlignment:
            isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.72,
            ),
            child: Column(
              crossAxisAlignment:
                  isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                _buildBubbleBody(context),
                const SizedBox(height: 3),
                Text(
                  _fmtTime(_timestamp),
                  style: AppTheme.barlow(
                    fontSize: 11,
                    color: AppTheme.fadedGrey,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Routes to the right bubble shape based on message kind. Photo and
  /// voice are wrapped in their own GestureDetectors (tap → viewer or
  /// play); text and location share the original behavior (long-press
  /// to copy, tap-on-location to open Maps).
  Widget _buildBubbleBody(BuildContext context) {
    if (_kind == 'photo' && _photoUrl != null) {
      return _photoBubble(context);
    }
    if (_kind == 'voice' && _voiceUrl != null) {
      return _voiceBubble(context);
    }
    return _textBubble(context);
  }

  // ─────────── Photo bubble ───────────

  Widget _photoBubble(BuildContext context) {
    final url = _photoUrl!;
    final radius = isMe
        ? const BorderRadius.only(bottomRight: Radius.circular(4))
        : const BorderRadius.only(bottomLeft: Radius.circular(4));

    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute<bool>(
            builder: (_) => FullScreenPhotoViewer(
              url: url,
              senderName: isMe ? 'You' : otherName,
              timestampMs: _timestamp is int ? _timestamp as int : null,
              canDelete: isMe,
              convId: convId,
              fromFid: myFid,
            ),
            fullscreenDialog: true,
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: isMe ? AppTheme.black : AppTheme.offWhite,
          borderRadius: radius,
        ),
        padding: const EdgeInsets.all(6),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: CachedNetworkImage(
            imageUrl: url,
            width: 180,
            height: 130,
            fit: BoxFit.cover,
            placeholder: (_, __) => Container(
              width: 180,
              height: 130,
              color: AppTheme.lightGrey,
              alignment: Alignment.center,
              child: const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: AppTheme.fadedGrey,
                ),
              ),
            ),
            errorWidget: (_, __, ___) => Container(
              width: 180,
              height: 130,
              color: AppTheme.lightGrey,
              alignment: Alignment.center,
              child: const Icon(Icons.broken_image_outlined,
                  size: 24, color: AppTheme.fadedGrey),
            ),
          ),
        ),
      ),
    );
  }

  // ─────────── Voice bubble ───────────

  Widget _voiceBubble(BuildContext context) {
    final radius = isMe
        ? const BorderRadius.only(bottomRight: Radius.circular(4))
        : const BorderRadius.only(bottomLeft: Radius.circular(4));
    final bg = isMe ? AppTheme.black : AppTheme.offWhite;
    final fg = isMe ? AppTheme.white : AppTheme.black;
    final durMs = _voiceDurationMs;
    final durLabel = durMs != null
        ? _fmtDuration(durMs)
        : '0:00';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(color: bg, borderRadius: radius),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          GestureDetector(
            onTap: onVoicePlayTap,
            behavior: HitTestBehavior.opaque,
            child: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: fg.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              alignment: Alignment.center,
              child: Icon(
                isVoicePlaying ? Icons.pause : Icons.play_arrow,
                size: 18,
                color: fg,
              ),
            ),
          ),
          const SizedBox(width: 10),
          // Decorative waveform - 15 vertical bars of varying heights.
          // Not data-real (not parsed from the audio file), but reads
          // visually as "this is a voice message" without the cost of
          // running an FFT on every bubble during scroll.
          SizedBox(
            width: 100,
            height: 22,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                _WaveBar(height: 4, color: fg.withOpacity(0.5)),
                _WaveBar(height: 8, color: fg.withOpacity(0.5)),
                _WaveBar(height: 12, color: fg.withOpacity(0.5)),
                _WaveBar(height: 6, color: fg.withOpacity(0.5)),
                _WaveBar(height: 14, color: fg.withOpacity(0.5)),
                _WaveBar(height: 10, color: fg.withOpacity(0.5)),
                _WaveBar(height: 16, color: fg.withOpacity(0.5)),
                _WaveBar(height: 8, color: fg.withOpacity(0.5)),
                _WaveBar(height: 4, color: fg.withOpacity(0.5)),
                _WaveBar(height: 12, color: fg.withOpacity(0.5)),
                _WaveBar(height: 14, color: fg.withOpacity(0.5)),
                _WaveBar(height: 6, color: fg.withOpacity(0.5)),
                _WaveBar(height: 10, color: fg.withOpacity(0.5)),
                _WaveBar(height: 8, color: fg.withOpacity(0.5)),
                _WaveBar(height: 4, color: fg.withOpacity(0.5)),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text(
            durLabel,
            style: AppTheme.barlow(
              fontSize: 11,
              color: fg.withOpacity(0.7),
            ),
          ),
        ],
      ),
    );
  }

  // ─────────── Text / location bubble (preserved from group A) ───────────

  Widget _textBubble(BuildContext context) {
    final bg = isMe ? AppTheme.black : AppTheme.offWhite;
    final fg = isMe ? AppTheme.white : AppTheme.black;
    final isLocation = _locationUrl != null;
    final radius = isMe
        ? const BorderRadius.only(bottomRight: Radius.circular(4))
        : const BorderRadius.only(bottomLeft: Radius.circular(4));

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: isLocation ? () => _openMaps(context) : null,
      onLongPress: () async {
        await Clipboard.setData(ClipboardData(text: _text));
        if (!context.mounted) return;
        _toast(context, 'Copied to clipboard');
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(color: bg, borderRadius: radius),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              isLocation ? '📍 Location' : _text,
              style: AppTheme.barlow(
                fontSize: 15,
                fontWeight: FontWeight.w500,
                color: fg,
                height: 1.4,
              ),
            ),
            if (isLocation) ...[
              const SizedBox(height: 6),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.open_in_new,
                      size: 13, color: fg.withOpacity(0.85)),
                  const SizedBox(width: 5),
                  Text(
                    'Tap to open in Maps',
                    style: AppTheme.barlow(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: fg.withOpacity(0.85),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  static String _fmtDuration(int ms) {
    final s = ms ~/ 1000;
    final mm = (s ~/ 60).toString();
    final ss = (s % 60).toString().padLeft(2, '0');
    return '$mm:$ss';
  }

  static String _fmtTime(dynamic ts) {
    int? ms;
    if (ts is int) ms = ts;
    if (ms == null) return '';
    final diff =
        DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ms));
    if (diff.inSeconds < 45) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    final dt = DateTime.fromMillisecondsSinceEpoch(ms);
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}

/// One vertical bar of the decorative waveform inside voice bubbles.
/// Heights are baked into the widget tree at construction time. Not
/// data-driven - just a visual cue that this is a voice message.
class _WaveBar extends StatelessWidget {
  final double height;
  final Color color;
  const _WaveBar({required this.height, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(width: 2, height: height, color: color);
  }
}
