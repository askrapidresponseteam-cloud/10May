import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme/app_theme.dart';
import '../core/services/feedback_service.dart';

/// Post-SOS feedback screen.
///
/// Shown after the sender stops their own SOS. Mirrors the editorial design
/// from the RRT Redesign HTML mock:
///   • Black header with red accent shapes, "SOS ENDED" eyebrow + giant
///     condensed "How did it go?" headline.
///   • Five sections with "01"-"05" red numerals + uppercase title.
///   • Dynamic question logic - see [_isQ3Visible] and [_outcomeOptions].
///   • Black submit CTA (disabled until required fields are answered),
///     "Skip for now" link below.
///   • Animated section reveal as the user answers - questions don't pop
///     into existence jarringly.
///   • Submit -> "THANK YOU." success screen for ~2s, then auto-pops back.
///
/// Lifecycle expectations (handled by the caller, not this screen):
///   • The caller has already confirmed the SOS was successfully stopped.
///   • The caller passes [senderId] + [activatedAtMillis] so this screen
///     can write a unique Firestore doc and mark the alert as handled in
///     SharedPreferences (so we never re-prompt the same alert).
///
/// To launch:
///   FeedbackScreen.show(context, senderId: ..., activatedAtMillis: ...);
class FeedbackScreen extends ConsumerStatefulWidget {
  const FeedbackScreen({
    super.key,
    required this.senderId,
    required this.activatedAtMillis,
  });

  final String senderId;
  final int activatedAtMillis;

  /// Convenience launcher. Returns when the user is done (submit or skip).
  static Future<void> show(
    BuildContext context, {
    required String senderId,
    required int activatedAtMillis,
  }) {
    return Navigator.of(context, rootNavigator: true).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => FeedbackScreen(
          senderId: senderId,
          activatedAtMillis: activatedAtMillis,
        ),
      ),
    );
  }

  @override
  ConsumerState<FeedbackScreen> createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends ConsumerState<FeedbackScreen> {
  // ─── Answers ────────────────────────────────────────────────────────────
  int? _rating;
  String? _helpArrived; // 'YES' | 'NO' | 'STILL EN ROUTE'
  String? _speed;       // bucket label, optional
  String? _outcome;     // outcome label, required when Q4 is visible
  final TextEditingController _commentCtrl = TextEditingController();

  bool _submitting = false;
  bool _submitted = false;

  // ─── Dynamic-question logic ─────────────────────────────────────────────

  /// Q3 (Response Speed) is only meaningful when help arrived. If help did
  /// not arrive, there's no response time to rate. If help is still en
  /// route, the user can't yet measure the total time.
  bool get _isQ3Visible => _helpArrived == 'YES';

  /// Q4 (Outcome) options are filtered by Q2:
  ///   • YES            - all five options apply
  ///   • NO             - drop the rescue/resolved options (help didn't
  ///                      arrive, so those outcomes aren't possible)
  ///   • STILL EN ROUTE - only the in-progress / unknown options
  /// If Q4 isn't visible yet (Q2 unanswered), no options are shown.
  List<({String label, Color dot})> get _outcomeOptions {
    const all = <({String label, Color dot})>[
      (label: 'Rescued & in care', dot: AppTheme.successGreen),
      (label: 'Situation resolved on site', dot: AppTheme.successGreenDark),
      (label: 'Needs further help', dot: AppTheme.amber),
      (label: 'Could not locate animal', dot: AppTheme.grey),
      (label: 'Other', dot: AppTheme.black),
    ];
    switch (_helpArrived) {
      case 'YES':
        return all;
      case 'NO':
        return all
            .where((o) => o.label != 'Rescued & in care'
                && o.label != 'Situation resolved on site')
            .toList();
      case 'STILL EN ROUTE':
        return all
            .where((o) => o.label == 'Needs further help'
                || o.label == 'Other')
            .toList();
      default:
        return const [];
    }
  }

  /// Submit is enabled only when the visible required questions are answered:
  /// rating + helpArrived always, outcome whenever Q4 is visible (i.e. once
  /// Q2 is set, since Q4 is always shown after Q2). Q3 stays optional.
  bool get _canSubmit {
    if (_submitting) return false;
    if (_rating == null || _helpArrived == null) return false;
    if (_outcomeOptions.isNotEmpty && _outcome == null) return false;
    return true;
  }

  // If the user changes Q2 in a way that invalidates earlier picks, clean
  // them up so we don't submit stale state.
  void _setHelpArrived(String value) {
    setState(() {
      _helpArrived = value;
      // Speed is only meaningful for YES - clear it otherwise.
      if (value != 'YES') _speed = null;
      // If the previously-picked outcome is no longer valid, drop it.
      if (_outcome != null &&
          !_outcomeOptions.any((o) => o.label == _outcome)) {
        _outcome = null;
      }
    });
  }

  // ─── Actions ────────────────────────────────────────────────────────────

  Future<void> _submit() async {
    if (!_canSubmit) return;
    setState(() => _submitting = true);
    try {
      // Short timeout so the user isn't stuck staring at a spinner if
      // Firestore is unreachable. 12s is generous for a single doc write.
      await FeedbackService.submit(
        senderId: widget.senderId,
        activatedAtMillis: widget.activatedAtMillis,
        rating: _rating!,
        helpArrived: _helpArrived!,
        responseSpeed: _speed,
        outcome: _outcome,
        comment: _commentCtrl.text.trim(),
      ).timeout(const Duration(seconds: 12));

      if (!mounted) return;
      setState(() {
        _submitted = true;
        _submitting = false;
      });
      // Auto-dismiss after the thank-you screen has been visible briefly.
      Future.delayed(const Duration(milliseconds: 2000), () {
        if (mounted) Navigator.of(context).pop();
      });
    } catch (e, st) {
      // Log the actual error - the silent `catch (_)` we had before hid
      // exactly the kind of issues we need to see (permission-denied from
      // Firestore rules, no network, etc).
      debugPrint('Feedback submit failed: $e\n$st');
      if (!mounted) return;
      setState(() => _submitting = false);
      // Categorise the message so users get actionable feedback. The
      // form's filled-in state is preserved either way - they can hit
      // SUBMIT again without re-typing anything.
      String msg;
      final s = e.toString().toLowerCase();
      if (s.contains('permission-denied') || s.contains('permission denied')) {
        msg = 'Could not save feedback (permission). Please try again later.';
      } else if (s.contains('timeout') ||
          s.contains('unavailable') ||
          s.contains('network') ||
          s.contains('socketexception')) {
        msg = 'No internet connection. Reconnect and try again.';
      } else {
        msg = 'Could not send feedback. Please try again.';
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(msg),
          backgroundColor: AppTheme.red,
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 4),
        ),
      );
    }
  }

  Future<void> _skip() async {
    // Mark this alert as handled even on skip - the user said "no thanks",
    // we shouldn't badger them again on next launch.
    await FeedbackService.markHandled(
      senderId: widget.senderId,
      activatedAtMillis: widget.activatedAtMillis,
    );
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _commentCtrl.dispose();
    super.dispose();
  }

  // ─── Build ──────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    if (_submitted) return _ThankYouScreen();

    return Scaffold(
      backgroundColor: AppTheme.white,
      body: Column(
        children: [
          _Header(),
          Expanded(child: _buildBody()),
          _buildBottom(),
        ],
      ),
    );
  }

  Widget _buildBody() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _Q1Rating(rating: _rating, onPick: (n) => setState(() => _rating = n)),
          // Subsequent sections animate in once their predecessor is answered.
          // This avoids a wall-of-form on first paint - questions reveal as
          // the user makes progress.
          _RevealOnAnswer(
            visible: _rating != null,
            child: _Q2HelpArrived(
              value: _helpArrived,
              onPick: _setHelpArrived,
            ),
          ),
          _RevealOnAnswer(
            visible: _helpArrived != null && _isQ3Visible,
            child: _Q3Speed(
              value: _speed,
              onPick: (s) => setState(() => _speed = s),
            ),
          ),
          _RevealOnAnswer(
            visible: _helpArrived != null,
            child: _Q4Outcome(
              options: _outcomeOptions,
              value: _outcome,
              onPick: (o) => setState(() => _outcome = o),
            ),
          ),
          _RevealOnAnswer(
            visible: _helpArrived != null,
            child: _Q5Comment(controller: _commentCtrl),
          ),
        ],
      ),
    );
  }

  Widget _buildBottom() {
    final enabled = _canSubmit;
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 20),
      decoration: const BoxDecoration(
        color: AppTheme.white,
        border: Border(top: BorderSide(color: AppTheme.border)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: enabled ? _submit : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.black,
                  disabledBackgroundColor: AppTheme.border,
                  foregroundColor: AppTheme.white,
                  disabledForegroundColor: AppTheme.fadedGrey,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.zero,
                  ),
                ),
                child: _submitting
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppTheme.white,
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'SUBMIT FEEDBACK',
                            style: AppTheme.barlow(
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              color: enabled
                                  ? AppTheme.white
                                  : AppTheme.fadedGrey,
                              letterSpacing: 1.5,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Icon(
                            Icons.arrow_forward,
                            size: 16,
                            color: enabled
                                ? AppTheme.white
                                : AppTheme.fadedGrey,
                          ),
                        ],
                      ),
              ),
            ),
            TextButton(
              onPressed: _submitting ? null : _skip,
              child: Text(
                'Skip for now',
                style: AppTheme.barlow(
                  fontSize: 13,
                  color: AppTheme.fadedGrey,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Header ──────────────────────────────────────────────────────────────

class _Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: AppTheme.black,
      child: SafeArea(
        bottom: false,
        child: Stack(
          clipBehavior: Clip.hardEdge,
          children: [
            // Red accent shapes top-right (per the HTML design)
            Positioned(
              top: -20,
              right: -20,
              child: Container(
                width: 80,
                height: 80,
                color: AppTheme.red.withValues(alpha: 0.12),
              ),
            ),
            Positioned(
              top: -10,
              right: 20,
              child: Container(
                width: 40,
                height: 40,
                color: AppTheme.red.withValues(alpha: 0.18),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 22, 24, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'SOS ENDED',
                    style: AppTheme.barlow(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.red,
                      letterSpacing: 3,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'How did\nit go?',
                    style: AppTheme.barlowCondensed(
                      fontSize: 58,
                      fontWeight: FontWeight.w900,
                      color: AppTheme.white,
                      height: 0.88,
                      letterSpacing: -1,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(width: 36, height: 2, color: AppTheme.red),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Section scaffolding ─────────────────────────────────────────────────

/// Small wrapper that fades + slides in the section once it's allowed to be
/// shown. Keeps the form from feeling like a wall on first paint.
class _RevealOnAnswer extends StatelessWidget {
  const _RevealOnAnswer({required this.visible, required this.child});
  final bool visible;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return AnimatedSize(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOut,
      alignment: Alignment.topCenter,
      child: AnimatedOpacity(
        opacity: visible ? 1 : 0,
        duration: const Duration(milliseconds: 220),
        child: visible ? child : const SizedBox(width: double.infinity),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({
    required this.num,
    required this.title,
    required this.child,
    this.optional = false,
    this.last = false,
  });

  final String num;
  final String title;
  final Widget child;
  final bool optional;
  final bool last;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: last
            ? null
            : const Border(bottom: BorderSide(color: AppTheme.border)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                num,
                style: AppTheme.barlowCondensed(
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  color: AppTheme.red,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title.toUpperCase(),
                  style: AppTheme.barlow(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.black,
                    letterSpacing: 1,
                  ),
                ),
              ),
              if (optional)
                Text(
                  'Optional',
                  style: AppTheme.barlow(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.subtleGrey,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

// ─── Q1: Rating ──────────────────────────────────────────────────────────

class _Q1Rating extends StatelessWidget {
  const _Q1Rating({required this.rating, required this.onPick});
  final int? rating;
  final ValueChanged<int> onPick;

  @override
  Widget build(BuildContext context) {
    return _Section(
      num: '01',
      title: 'Overall Experience',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              for (var n = 1; n <= 5; n++) ...[
                Expanded(child: _RatingTile(n: n, rating: rating, onPick: onPick)),
                if (n != 5) const SizedBox(width: 8),
              ],
            ],
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'POOR',
                style: AppTheme.barlow(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.subtleGrey,
                  letterSpacing: 0.5,
                ),
              ),
              Text(
                'EXCELLENT',
                style: AppTheme.barlow(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.subtleGrey,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RatingTile extends StatelessWidget {
  const _RatingTile({required this.n, required this.rating, required this.onPick});
  final int n;
  final int? rating;
  final ValueChanged<int> onPick;

  @override
  Widget build(BuildContext context) {
    final isSelected = rating == n;
    final isFilled = rating != null && n < rating!;
    final bg = isSelected
        ? AppTheme.black
        : isFilled
            ? AppTheme.offWhite
            : AppTheme.white;
    final fg = isSelected
        ? AppTheme.white
        : isFilled
            ? AppTheme.black
            : AppTheme.disabledGrey;
    return GestureDetector(
      onTap: () => onPick(n),
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        height: 52,
        decoration: BoxDecoration(
          color: bg,
          border: Border.all(
            color: isSelected ? AppTheme.black : AppTheme.border,
            width: 1.5,
          ),
        ),
        alignment: Alignment.center,
        child: Text(
          '$n',
          style: AppTheme.barlowCondensed(
            fontSize: 22,
            fontWeight: FontWeight.w900,
            color: fg,
          ),
        ),
      ),
    );
  }
}

// ─── Q2: Help arrived ────────────────────────────────────────────────────

class _Q2HelpArrived extends StatelessWidget {
  const _Q2HelpArrived({required this.value, required this.onPick});
  final String? value;
  final ValueChanged<String> onPick;

  @override
  Widget build(BuildContext context) {
    final options = <({String label, Color accent})>[
      (label: 'YES', accent: AppTheme.successGreen),
      (label: 'NO', accent: AppTheme.red),
      (label: 'STILL EN ROUTE', accent: AppTheme.amber),
    ];
    return _Section(
      num: '02',
      title: 'Did Help Arrive?',
      child: Row(
        children: [
          for (var i = 0; i < options.length; i++) ...[
            Expanded(
              child: _HelpButton(
                label: options[i].label,
                accent: options[i].accent,
                isSelected: value == options[i].label,
                onTap: () => onPick(options[i].label),
              ),
            ),
            if (i != options.length - 1) const SizedBox(width: 8),
          ],
        ],
      ),
    );
  }
}

class _HelpButton extends StatelessWidget {
  const _HelpButton({
    required this.label,
    required this.accent,
    required this.isSelected,
    required this.onTap,
  });
  final String label;
  final Color accent;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        height: 46,
        decoration: BoxDecoration(
          color: isSelected ? accent : AppTheme.white,
          border: Border.all(
            color: isSelected ? accent : AppTheme.border,
            width: 1.5,
          ),
        ),
        alignment: Alignment.center,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: FittedBox(
            child: Text(
              label,
              style: AppTheme.barlow(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                color: isSelected ? AppTheme.white : AppTheme.fadedGrey,
                letterSpacing: 1,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Q3: Response speed ──────────────────────────────────────────────────

class _Q3Speed extends StatelessWidget {
  const _Q3Speed({required this.value, required this.onPick});
  final String? value;
  final ValueChanged<String> onPick;

  static const List<String> _options = [
    'Under 5 min',
    '5-15 min',
    '15-30 min',
    '30+ min',
    'Not applicable',
  ];

  @override
  Widget build(BuildContext context) {
    return _Section(
      num: '03',
      title: 'Response Speed',
      optional: true,
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final opt in _options)
            _Chip(
              label: opt,
              active: value == opt,
              onTap: () => onPick(opt),
            ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.label, required this.active, required this.onTap});
  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          color: active ? AppTheme.black : AppTheme.white,
          border: Border.all(
            color: active ? AppTheme.black : AppTheme.border,
            width: 1.5,
          ),
        ),
        child: Text(
          label,
          style: AppTheme.barlow(
            fontSize: 12,
            fontWeight: active ? FontWeight.w800 : FontWeight.w700,
            color: active ? AppTheme.white : AppTheme.grey,
            letterSpacing: 1,
          ),
        ),
      ),
    );
  }
}

// ─── Q4: Outcome ─────────────────────────────────────────────────────────

class _Q4Outcome extends StatelessWidget {
  const _Q4Outcome({
    required this.options,
    required this.value,
    required this.onPick,
  });
  final List<({String label, Color dot})> options;
  final String? value;
  final ValueChanged<String> onPick;

  @override
  Widget build(BuildContext context) {
    return _Section(
      num: '04',
      title: 'What happened with the animal?',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (var i = 0; i < options.length; i++) ...[
            _OutcomeRow(
              label: options[i].label,
              dotColor: options[i].dot,
              isSelected: value == options[i].label,
              onTap: () => onPick(options[i].label),
            ),
            if (i != options.length - 1) const SizedBox(height: 8),
          ],
        ],
      ),
    );
  }
}

class _OutcomeRow extends StatelessWidget {
  const _OutcomeRow({
    required this.label,
    required this.dotColor,
    required this.isSelected,
    required this.onTap,
  });
  final String label;
  final Color dotColor;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.black : AppTheme.white,
          border: Border.all(
            color: isSelected ? AppTheme.black : AppTheme.border,
            width: 1.5,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: isSelected ? AppTheme.white : dotColor,
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                label,
                style: AppTheme.barlow(
                  fontSize: 13,
                  fontWeight:
                      isSelected ? FontWeight.w800 : FontWeight.w500,
                  color:
                      isSelected ? AppTheme.white : const Color(0xFF555555),
                  letterSpacing: -0.1,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Q5: Comment ─────────────────────────────────────────────────────────

class _Q5Comment extends StatelessWidget {
  const _Q5Comment({required this.controller});
  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return _Section(
      num: '05',
      title: 'Anything Else?',
      optional: true,
      last: true,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFFFAFAFA),
          border: Border.all(color: AppTheme.border, width: 1.5),
        ),
        child: TextField(
          controller: controller,
          minLines: 4,
          maxLines: 8,
          maxLength: 500,
          style: AppTheme.barlow(
            fontSize: 14,
            color: AppTheme.black,
            height: 1.5,
          ),
          decoration: InputDecoration(
            isDense: true,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
            border: InputBorder.none,
            hintText: 'Tell us what happened…',
            hintStyle: AppTheme.barlow(
              fontSize: 14,
              color: AppTheme.disabledGrey,
            ),
            counterText: '',
          ),
        ),
      ),
    );
  }
}

// ─── Thank you success state ─────────────────────────────────────────────

class _ThankYouScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.black,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                color: AppTheme.red,
                alignment: Alignment.center,
                child: const Icon(Icons.check, size: 28, color: AppTheme.white),
              ),
              const SizedBox(height: 24),
              Text(
                'THANK\nYOU.',
                textAlign: TextAlign.center,
                style: AppTheme.barlowCondensed(
                  fontSize: 52,
                  fontWeight: FontWeight.w900,
                  color: AppTheme.white,
                  height: 0.9,
                  letterSpacing: -1,
                ),
              ),
              const SizedBox(height: 12),
              Container(width: 40, height: 2, color: AppTheme.red),
              const SizedBox(height: 16),
              Text(
                'Your feedback helps us make the network stronger for every animal in need.',
                textAlign: TextAlign.center,
                style: AppTheme.barlow(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: AppTheme.white.withValues(alpha: 0.45),
                  height: 1.6,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
