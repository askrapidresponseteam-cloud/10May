import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

/// ConfirmAlertScreen - the HTML ConfirmAlertScreen overlay.
///
/// Presented via a transparent, dim-backdrop route. Returns:
///   • true  - user tapped SEND ALERT
///   • false/null - user tapped CANCEL, tapped outside, or pressed back
///
/// Matches HTML:
///   • Centered white modal, full-width minus 48px, no border radius
///   • 24px padding, Barlow 800 20px heading
///   • 3 info rows with SVG-equivalent icons + label + value
///   • Amber warning box about phone number visibility
///   • Continue? heading
///   • CANCEL (grey text on white) + SEND ALERT (red) split 50/50
class ConfirmAlertScreen extends StatelessWidget {
  final String name;
  final String phone;
  final String locationLabel;

  const ConfirmAlertScreen({
    super.key,
    required this.name,
    required this.phone,
    required this.locationLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: GestureDetector(
        onTap: () => Navigator.pop(context, false),
        behavior: HitTestBehavior.opaque,
        child: SafeArea(
          child: Center(
            child: GestureDetector(
              // Swallow taps on the modal itself.
              onTap: () {},
              behavior: HitTestBehavior.opaque,
              child: Container(
                width: MediaQuery.of(context).size.width - 48,
                padding: const EdgeInsets.all(24),
                color: AppTheme.white,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Confirm Emergency Alert',
                      style: AppTheme.barlow(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.black,
                        letterSpacing: -0.3,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'This will share your information with volunteers in your district:',
                      style: AppTheme.barlow(
                        fontSize: 14,
                        color: const Color(0xFF555555),
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 20),
                    _InfoRow(
                        icon: Icons.person_outline,
                        label: 'Name',
                        value: name),
                    const SizedBox(height: 14),
                    _InfoRow(
                        icon: Icons.phone_outlined,
                        label: 'Phone',
                        value: phone),
                    const SizedBox(height: 14),
                    _InfoRow(
                        icon: Icons.location_on_outlined,
                        label: 'Location',
                        value: locationLabel),
                    const SizedBox(height: 20),
                    // Amber warning
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: AppTheme.amberBg,
                        border: Border.all(
                            color: AppTheme.amberBorder, width: 1.5),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(top: 1),
                            child: Icon(Icons.info_outline,
                                size: 14, color: AppTheme.amberIcon),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Your phone number will be visible to volunteers who receive this alert.',
                              style: AppTheme.barlow(
                                fontSize: 12,
                                color: AppTheme.amberText,
                                height: 1.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'Continue?',
                      style: AppTheme.barlow(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.black,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: () => Navigator.pop(context, false),
                            behavior: HitTestBehavior.opaque,
                            child: Container(
                              height: 48,
                              color: AppTheme.white,
                              alignment: Alignment.center,
                              child: Text(
                                'CANCEL',
                                style: AppTheme.barlow(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  color: AppTheme.grey,
                                  letterSpacing: 1.5,
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: GestureDetector(
                            onTap: () => Navigator.pop(context, true),
                            behavior: HitTestBehavior.opaque,
                            child: Container(
                              height: 48,
                              color: AppTheme.red,
                              alignment: Alignment.center,
                              child: Text(
                                'SEND ALERT',
                                style: AppTheme.barlow(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  color: AppTheme.white,
                                  letterSpacing: 1.5,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _InfoRow(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 2),
          child: Icon(icon, size: 14, color: AppTheme.grey),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: AppTheme.barlow(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.fadedGrey,
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: AppTheme.barlow(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.black,
                  letterSpacing: -0.2,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
