import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/theme/app_theme.dart';

/// Responders bottom sheet - shown when the viewer-count row is tapped on
/// the Active SOS screen.
///
/// Layout (post-status-removal):
///   • Drag handle
///   • Header: "Responders" / "{District} District" + X close button
///   • Sub-line: "Responders available in your district."
///   • Scrollable list of responders, each row: 42px black initial avatar +
///     bold name. No status dots, no status text, no ACTIVE badge.
///   • Empty state: centered "No responders in this district yet."
///
/// Data is streamed live from Firestore `subscribed_users` collection,
/// filtered by the current district. Each doc only needs `name` and
/// `district`. Any `status` field on the doc is intentionally ignored -
/// online/offline tracking has been removed to cut Firestore-write cost
/// and avoid a feature that didn't add user value.
class RespondersScreen extends StatelessWidget {
  final String district;

  const RespondersScreen({super.key, required this.district});

  /// Show as a modal bottom sheet with a dimmed backdrop.
  static Future<void> show(BuildContext context, String district) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.5),
      builder: (_) => RespondersScreen(district: district),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Sheet's max height: 90% of screen, minus the top safe-area inset so
    // we never run under the status bar. The bottom safe-area is handled
    // by the SafeArea widget below - wrapping with SafeArea(bottom: true)
    // lifts the whole sheet above the system nav/gesture bar, which is
    // what was clipping the last responder before.
    final media = MediaQuery.of(context);
    final maxHeight =
        media.size.height * 0.90 - media.viewPadding.top;

    return Container(
      constraints: BoxConstraints(maxHeight: maxHeight),
      decoration: const BoxDecoration(color: AppTheme.white),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Drag handle
          Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.fromLTRB(0, 10, 0, 4),
            child: Container(
              width: 32,
              height: 4,
              color: const Color(0xFFE0E0E0),
            ),
          ),

          // Header: "Responders" / "{District} District" + X
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 10, 24, 0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Responders',
                        style: AppTheme.barlowCondensed(
                          fontSize: 28,
                          fontWeight: FontWeight.w900,
                          color: AppTheme.black,
                          letterSpacing: -0.5,
                          height: 1,
                        ),
                      ),
                      Text(
                        '${_titleCase(district.replaceAll('_', ' '))} District',
                        style: AppTheme.barlowCondensed(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.red,
                          letterSpacing: -0.3,
                          height: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  behavior: HitTestBehavior.opaque,
                  child: Container(
                    width: 32,
                    height: 32,
                    margin: const EdgeInsets.only(top: 2),
                    color: const Color(0xFFF5F5F5),
                    alignment: Alignment.center,
                    child: const Icon(Icons.close,
                        size: 14, color: AppTheme.black),
                  ),
                ),
              ],
            ),
          ),

          // Sub-line
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 10, 24, 14),
            child: Align(
              alignment: Alignment.center,
              child: Text(
                'Responders available in your district.',
                style: AppTheme.barlow(
                  fontSize: 13,
                  color: AppTheme.grey,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),

          // List streamed from Firestore
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('subscribed_users')
                  .where('district', isEqualTo: district)
                  .snapshots(),
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(color: AppTheme.red),
                  );
                }

                final docs = snap.data?.docs ?? [];
                final people = docs
                    .map((d) {
                      final data = d.data() as Map<String, dynamic>;
                      final name = (data['name'] as String?) ?? '';
                      return name.trim();
                    })
                    .where((n) => n.isNotEmpty)
                    .toList()
                  ..sort((a, b) =>
                      a.toLowerCase().compareTo(b.toLowerCase()));

                if (people.isEmpty) {
                  return Center(
                    child: Text(
                      'No responders in this district yet.',
                      style: AppTheme.barlow(
                        fontSize: 13,
                        color: AppTheme.grey,
                      ),
                    ),
                  );
                }

                return ListView.builder(
                  // SafeArea(bottom: true) on the parent already lifts the
                  // sheet above the system nav/gesture bar, so we only
                  // need a small visual cushion below the last item here.
                  padding: const EdgeInsets.only(top: 0, bottom: 16),
                  itemCount: people.length,
                  itemBuilder: (_, i) => _ResponderRow(name: people[i]),
                );
              },
            ),
          ),
        ],
      ),
      ),
    );
  }

  static String _titleCase(String s) => s
      .split(' ')
      .map((w) => w.isEmpty
          ? w
          : w[0].toUpperCase() + w.substring(1).toLowerCase())
      .join(' ');
}

// ─────────── Responder row ───────────
//
// 42px black initial avatar + bold name. No status indicators of any kind.
class _ResponderRow extends StatelessWidget {
  final String name;
  const _ResponderRow({required this.name});

  @override
  Widget build(BuildContext context) {
    final initial = name.trim().isEmpty ? '?' : name.trim()[0].toUpperCase();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 11),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Color(0xFFF5F5F5), width: 1),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: const BoxDecoration(
              color: AppTheme.black,
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              initial,
              style: AppTheme.barlowCondensed(
                fontSize: 17,
                fontWeight: FontWeight.w900,
                color: AppTheme.white,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              name,
              style: AppTheme.barlow(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: AppTheme.black,
                letterSpacing: -0.2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
