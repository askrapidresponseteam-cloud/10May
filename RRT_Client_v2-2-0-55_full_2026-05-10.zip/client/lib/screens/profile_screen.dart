import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/theme/app_theme.dart';
import '../core/services/profile_service.dart';
import '../widgets/top_bar.dart';
import '../widgets/cta_button.dart';
import 'onboarding_screen.dart';

/// Profile main screen (Profile tab).
///
/// This screen IS the profile editor. Name and Mobile Number are
/// editable in place; tapping UPDATE PROFILE persists via
/// ProfileService.saveProfile and shows a confirmation snackbar without
/// navigating anywhere. The CTA stays disabled while there are no
/// changes, the inputs are invalid, or a save is in flight.
///
/// Layout:
///   • TopBar with online dot
///   • "Your" (black) / "Profile" (red) 64pt headline
///   • Two underline-style editable fields with A-Z / +91 pill badges
///   • InfoNotice about phone number visibility during SOS
///   • Danger Zone - red DELETE MY DATA button that confirms then wipes
///     server + local data and resets navigation to onboarding
///   • Sticky UPDATE PROFILE CTA at bottom
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // Controllers + focus nodes for the two editable fields. Created here
  // (not lazily) so we can attach listeners in initState and dispose
  // them cleanly.
  final TextEditingController _nameCtrl = TextEditingController();
  final TextEditingController _mobileCtrl = TextEditingController();
  final FocusNode _nameFocus = FocusNode();
  final FocusNode _mobileFocus = FocusNode();

  // The on-disk values. We compare current controller text against
  // these to decide whether anything has actually changed - the CTA
  // disables when there's nothing to save.
  String _savedName = '';
  String _savedMobile = '';

  bool _loading = true;
  bool _saving = false;
  bool _deleting = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    // Rebuild on every keystroke so the CTA enabled state and inline
    // error message stay in sync with what's in the fields.
    _nameCtrl.addListener(_onChanged);
    _mobileCtrl.addListener(_onChanged);
    _load();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _mobileCtrl.dispose();
    _nameFocus.dispose();
    _mobileFocus.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final name = await ProfileService.getUserName() ?? '';
    final mobile = await ProfileService.getUserMobile() ?? '';
    if (!mounted) return;
    setState(() {
      _savedName = name;
      _savedMobile = mobile;
      // Use .value (not .text) so the caret lands at the end of the
      // prefilled value. Plain .text assignment leaves the caret at
      // offset 0 which on some Android IMEs makes the field look
      // frozen until you tap a second time.
      _nameCtrl.value = TextEditingValue(
        text: name,
        selection: TextSelection.collapsed(offset: name.length),
      );
      _mobileCtrl.value = TextEditingValue(
        text: mobile,
        selection: TextSelection.collapsed(offset: mobile.length),
      );
      _loading = false;
    });
  }

  void _onChanged() {
    // Clear any stale error the moment the user starts typing.
    if (_error != null) {
      setState(() => _error = null);
    } else {
      // Still need to rebuild so the CTA enabled-state recomputes.
      setState(() {});
    }
  }

  // The CTA enables when the user has made a real change to EITHER
  // field AND every field's current value is valid.
  //
  // Important: name and mobile are independent. Changing only the
  // mobile is allowed (name unchanged). Changing only the name is
  // allowed (mobile unchanged). The previous combined-AND comparison
  // worked in theory but produced edge-case failures in practice (a
  // user reported "can't save mobile-only changes"), so the rule is
  // restated here as two clear, separate predicates.
  bool get _canSave {
    if (_loading || _saving) return false;

    final name = _nameCtrl.text.trim();
    final mobile = _mobileCtrl.text.trim();

    // Both fields are mandatory - we never let the user save a blank
    // name or a malformed mobile, regardless of what changed.
    if (name.isEmpty) return false;
    if (mobile.isEmpty) return false;
    if (!ProfileService.isValidIndianMobile(mobile)) return false;

    // Has the name actually changed? Compare trimmed values.
    final nameChanged = name != _savedName.trim();

    // Has the mobile actually changed? Compare AFTER normalizing both
    // sides through the same normalizer the service uses, so a saved
    // "+91 9764994999" and a typed "9764994999" are treated as equal.
    final mobileChanged = ProfileService.normalizeIndianMobile(mobile) !=
        ProfileService.normalizeIndianMobile(_savedMobile);

    // Either field changing is enough. This is the line the bug
    // report was about: "should be able to change number even without
    // changing the name."
    return nameChanged || mobileChanged;
  }

  Future<void> _save() async {
    final name = _nameCtrl.text.trim();
    final mobile = _mobileCtrl.text.trim();

    // Defensive validation. _canSave already gates the button, but
    // hardware-keyboard Enter or programmatic submit could still get
    // here, so re-check and surface a clear inline error.
    if (name.isEmpty) {
      setState(() => _error = 'Please enter your name');
      return;
    }
    if (mobile.isEmpty) {
      setState(() => _error = 'Please enter your mobile number');
      return;
    }
    if (!ProfileService.isValidIndianMobile(mobile)) {
      setState(
          () => _error = 'Please enter a valid 10-digit Indian mobile number');
      return;
    }

    // Dismiss the keyboard so the snackbar isn't hidden behind it.
    FocusManager.instance.primaryFocus?.unfocus();

    setState(() {
      _saving = true;
      _error = null;
    });

    try {
      await ProfileService.saveProfile(name: name, mobile: mobile);
      if (!mounted) return;
      // Reload from disk so _savedName / _savedMobile reflect the
      // canonical normalized values (e.g. mobile gets stripped of any
      // country-code prefix the user may have typed). This also
      // disables the CTA again until the user makes another edit.
      await _load();
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Profile updated'),
          backgroundColor: AppTheme.successGreenDark,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _error = 'Failed to save profile. Please try again.';
      });
    }
  }

  Future<void> _confirmDelete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => _DeleteConfirmDialog(),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _deleting = true);
    try {
      await ProfileService.deleteUserFirestoreData();
      await ProfileService.deleteAllData();
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const OnboardingScreen()),
        (_) => false,
      );
      Future.delayed(const Duration(milliseconds: 400), () {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('All data deleted'),
            backgroundColor: AppTheme.successGreenDark,
          ),
        );
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _deleting = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to delete data: $e'),
          backgroundColor: AppTheme.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      // resizeToAvoidBottomInset=true (default) so the layout shifts up
      // when the keyboard opens for either of the editable fields.
      body: SafeArea(
        // Tap-outside-to-dismiss-keyboard. translucent (NOT opaque) so
        // child TextFields receive the tap first; opaque would let this
        // GestureDetector win the gesture arena over the fields and
        // make them appear frozen.
        child: GestureDetector(
          onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
          behavior: HitTestBehavior.translucent,
          child: Column(
            children: [
              const TopBar(showOnline: true),
              Expanded(
                child: _loading
                    ? const Center(
                        child:
                            CircularProgressIndicator(color: AppTheme.red))
                    : SingleChildScrollView(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 24),
                            Text(
                              'Your',
                              style: AppTheme.barlowCondensed(
                                fontSize: 64,
                                fontWeight: FontWeight.w900,
                                color: AppTheme.black,
                                height: 0.92,
                                letterSpacing: -1.5,
                              ),
                            ),
                            Text(
                              'Profile',
                              style: AppTheme.barlowCondensed(
                                fontSize: 64,
                                fontWeight: FontWeight.w900,
                                color: AppTheme.red,
                                height: 0.92,
                                letterSpacing: -1.5,
                              ),
                            ),
                            Container(
                              margin:
                                  const EdgeInsets.symmetric(vertical: 24),
                              height: 1,
                              color: AppTheme.black.withValues(alpha: 0.12),
                            ),
                            _LabeledUnderlineField(
                              label: 'NAME',
                              badge: 'A-Z',
                              hintText: 'Your name',
                              controller: _nameCtrl,
                              focusNode: _nameFocus,
                              keyboardType: TextInputType.name,
                              textCapitalization: TextCapitalization.words,
                              textInputAction: TextInputAction.next,
                              onSubmitted: (_) =>
                                  _mobileFocus.requestFocus(),
                            ),
                            const SizedBox(height: 20),
                            _LabeledUnderlineField(
                              label: 'MOBILE NUMBER',
                              badge: '+91',
                              hintText: '10-digit mobile',
                              controller: _mobileCtrl,
                              focusNode: _mobileFocus,
                              keyboardType: TextInputType.phone,
                              textInputAction: TextInputAction.done,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                                LengthLimitingTextInputFormatter(10),
                              ],
                              onSubmitted: (_) {
                                if (_canSave) _save();
                              },
                            ),
                            if (_error != null) ...[
                              const SizedBox(height: 12),
                              Text(
                                _error!,
                                style: AppTheme.barlow(
                                  fontSize: 13,
                                  color: AppTheme.red,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                            const SizedBox(height: 24),
                            _CircleInfoNotice(
                              text:
                                  'Your phone number is visible to district volunteers only while an SOS is active.',
                            ),
                            const SizedBox(height: 28),
                            _DangerZone(
                              onDelete: _confirmDelete,
                              busy: _deleting,
                            ),
                            const SizedBox(height: 24),
                          ],
                        ),
                      ),
              ),
              Container(
                color: AppTheme.white,
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 20),
                child: CtaButton(
                  label: 'UPDATE PROFILE',
                  // Disabled until the user has changed something AND
                  // the new values are valid. Also disabled while a
                  // save is in flight.
                  onPressed: _canSave ? _save : null,
                  isLoading: _saving,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────── Labeled underline field (editable) ───────────
//
// Mirrors profile_create_screen._LabeledUnderlineField so onboarding
// and edit-in-place share the same visual vocabulary:
//   - 10px Barlow 600 uppercase label, 2px letter-spacing
//   - 22px Barlow 500 value, letter-spacing -0.3
//   - 1.5px bottom border (border colour hardens to black on focus)
//   - Trailing pill badge in 12px Barlow 600 grey
//   - No box, no fill, no Material focus ring.
class _LabeledUnderlineField extends StatefulWidget {
  final String label;
  final String badge;
  final String hintText;
  final TextEditingController controller;
  final FocusNode focusNode;
  final TextInputType keyboardType;
  final TextInputAction textInputAction;
  final ValueChanged<String>? onSubmitted;
  final List<TextInputFormatter>? inputFormatters;
  final TextCapitalization textCapitalization;

  const _LabeledUnderlineField({
    required this.label,
    required this.badge,
    required this.hintText,
    required this.controller,
    required this.focusNode,
    this.keyboardType = TextInputType.text,
    this.textInputAction = TextInputAction.next,
    this.onSubmitted,
    this.inputFormatters,
    this.textCapitalization = TextCapitalization.none,
  });

  @override
  State<_LabeledUnderlineField> createState() =>
      _LabeledUnderlineFieldState();
}

class _LabeledUnderlineFieldState extends State<_LabeledUnderlineField> {
  bool _focused = false;

  @override
  void initState() {
    super.initState();
    widget.focusNode.addListener(_onFocus);
  }

  @override
  void dispose() {
    widget.focusNode.removeListener(_onFocus);
    super.dispose();
  }

  void _onFocus() {
    setState(() => _focused = widget.focusNode.hasFocus);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.label,
          style: AppTheme.labelCaps(
            fontSize: 10,
            letterSpacing: 2,
            color: AppTheme.grey,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: _focused ? AppTheme.black : AppTheme.border,
                width: 1.5,
              ),
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: TextField(
                  controller: widget.controller,
                  focusNode: widget.focusNode,
                  keyboardType: widget.keyboardType,
                  textInputAction: widget.textInputAction,
                  onSubmitted: widget.onSubmitted,
                  inputFormatters: widget.inputFormatters,
                  textCapitalization: widget.textCapitalization,
                  cursorColor: AppTheme.black,
                  style: AppTheme.barlow(
                    fontSize: 22,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.black,
                    letterSpacing: -0.3,
                  ),
                  decoration: InputDecoration(
                    isDense: true,
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    contentPadding:
                        const EdgeInsets.only(bottom: 10, top: 0),
                    hintText: widget.hintText,
                    hintStyle: AppTheme.barlow(
                      fontSize: 22,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.subtleGrey,
                      letterSpacing: -0.3,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  child: Text(
                    widget.badge,
                    style: AppTheme.barlow(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.grey,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─────────── Danger zone ───────────
class _DangerZone extends StatelessWidget {
  final VoidCallback onDelete;
  final bool busy;
  const _DangerZone({required this.onDelete, required this.busy});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.dangerBg,
        border: Border.all(color: AppTheme.dangerBorder, width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.warning_amber_rounded,
                  size: 16, color: AppTheme.red),
              const SizedBox(width: 8),
              Text(
                'DANGER ZONE',
                style: AppTheme.barlow(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.red,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Deleting your data is irreversible. It removes your profile, active alerts, and conversations from our servers and this device.',
            style: AppTheme.barlow(
              fontSize: 13,
              color: const Color(0xFF7A1515),
              height: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: busy ? null : onDelete,
            behavior: HitTestBehavior.opaque,
            child: Opacity(
              opacity: busy ? 0.6 : 1.0,
              child: Container(
                width: double.infinity,
                height: 46,
                decoration: BoxDecoration(
                  color: AppTheme.white,
                  border: Border.all(color: AppTheme.red, width: 2),
                ),
                alignment: Alignment.center,
                child: busy
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppTheme.red,
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.delete_outline,
                              size: 14, color: AppTheme.red),
                          const SizedBox(width: 8),
                          Text(
                            'DELETE MY DATA',
                            style: AppTheme.barlow(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color: AppTheme.red,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────── Confirm dialog ───────────
class _DeleteConfirmDialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Delete all your data?',
              style: AppTheme.barlow(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: AppTheme.black,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'This is permanent. Your profile, active alerts and conversations will be deleted from our servers and this device.',
              style: AppTheme.barlow(
                fontSize: 14,
                color: const Color(0xFF555555),
                height: 1.5,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context, false),
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      height: 44,
                      color: AppTheme.white,
                      alignment: Alignment.center,
                      child: Text(
                        'CANCEL',
                        style: AppTheme.barlow(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.grey,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context, true),
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      height: 44,
                      color: AppTheme.red,
                      alignment: Alignment.center,
                      child: Text(
                        'DELETE',
                        style: AppTheme.barlow(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.white,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────── Circle-i Info Notice (matches HTML spec) ───────────
class _CircleInfoNotice extends StatelessWidget {
  final String text;
  const _CircleInfoNotice({required this.text});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 16,
            height: 16,
            margin: const EdgeInsets.only(top: 1),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppTheme.grey, width: 1.5),
            ),
            alignment: Alignment.center,
            child: Text(
              'i',
              style: AppTheme.barlow(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: AppTheme.grey,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: AppTheme.barlow(
                fontSize: 12,
                color: AppTheme.grey,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
