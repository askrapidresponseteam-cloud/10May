import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme/app_theme.dart';
import '../core/providers/alerts_provider.dart';
import '../widgets/top_bar.dart';
import '../widgets/bottom_nav.dart';

/// "How to use the app" detail screen.
///
/// Reached via tapping row 01 on [HelpScreen]. Layout follows the same
/// editorial vocabulary as the rest of the app:
///   • TopBar with back arrow + paw logo (matches the rest of the app
///     so this doesn't feel like a different shell)
///   • Eyebrow numeral "01" in red Barlow Condensed
///   • Big condensed headline split: "How to use" black / "the app" red
///   • Hairline rule
///   • 6 step rows (red kicker + title + body), divided by 1px hairlines
///   • BottomNav pinned at the bottom showing the user is still inside
///     the Help tab. Tapping a different tab pops back to the index and
///     switches to that tab via activeTabIndexProvider.
class HelpHowToScreen extends ConsumerWidget {
  const HelpHowToScreen({super.key});

  static const _steps = [
    (
      'Step 1',
      'Accept Terms',
      'You must accept the Terms & Conditions to use the app.'
    ),
    (
      'Step 2',
      'One-Time Profile Setup',
      'Enter your full name and mobile number. Use accurate, genuine details to ensure community trust. This step is required only once.'
    ),
    (
      'Step 3',
      'Enable Location Access',
      'Allow location access when prompted. Location is mandatory to send an SOS. Without it, an SOS cannot be sent.'
    ),
    (
      'Step 4',
      'Sending an SOS',
      'Tap the SOS button when you require help. The SOS is delivered only to registered volunteers in your district. An active internet connection is required.'
    ),
    (
      'Step 5',
      'During an Active SOS',
      'Volunteers can see your name, live location, and phone number. This info is visible only while the SOS is active. Volunteers get a push notification.'
    ),
    (
      'Step 6',
      'Ending the SOS',
      'Tap Stop SOS at any time. The SOS is immediately removed from all volunteer screens. Auto-expires after 60 minutes.'
    ),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      // SafeArea(bottom: false) so the status bar doesn't overlap the
      // TopBar. Bottom is handled by bottomNavigationBar's own SafeArea.
      // This matches the chrome MainNavigationScreen wraps around its
      // tab bodies - we lose that wrapper when we push as a full route,
      // so we re-add it here.
      body: SafeArea(
        bottom: false,
        // Mirror the HelpScreen ("Need Help?") shell exactly:
        //   TopBar(showOnline: true)  - paw + title + online dot, NO
        //                                back arrow. The back affordance
        //                                is the bottom nav (and the OS
        //                                back gesture, which still pops
        //                                the route).
        //   SingleChildScrollView with horizontal padding 24
        //   24px top spacer, then 64pt eyebrow + headline + hairline.
        child: Column(
          children: [
            const TopBar(showOnline: true),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 24),
                    // Eyebrow numeral - matches the index page numeral
                    // exactly so the navigation feels continuous.
                    Text(
                      '01',
                      style: AppTheme.barlowCondensed(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        color: AppTheme.red,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 6),
                    // Big condensed headline - same 64pt / 0.92 height /
                    // -1.5 tracking as Need Help? / Your Profile etc.
                    Text(
                      'How to use',
                      style: AppTheme.barlowCondensed(
                        fontSize: 64,
                        fontWeight: FontWeight.w900,
                        color: AppTheme.black,
                        height: 0.92,
                        letterSpacing: -1.5,
                      ),
                    ),
                    Text(
                      'the app',
                      style: AppTheme.barlowCondensed(
                        fontSize: 64,
                        fontWeight: FontWeight.w900,
                        color: AppTheme.red,
                        height: 0.92,
                        letterSpacing: -1.5,
                      ),
                    ),
                    // Hairline rule - 12% black, identical to HelpScreen
                    Container(
                      margin: const EdgeInsets.symmetric(vertical: 24),
                      height: 1,
                      color: AppTheme.black.withValues(alpha: 0.12),
                    ),
                    // Step rows - content unchanged.
                    for (var i = 0; i < _steps.length; i++) ...[
                      _StepRow(
                        kicker: _steps[i].$1,
                        title: _steps[i].$2,
                        body: _steps[i].$3,
                      ),
                      if (i != _steps.length - 1)
                        const Divider(
                            height: 1, color: AppTheme.veryLightGrey),
                    ],
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      // BottomNav anchored to Help. Tapping any other tab pops back to
      // the Help index and switches the main scaffold via the shared
      // activeTabIndexProvider listener in MainNavigationScreen.
      bottomNavigationBar: SafeArea(
        top: false,
        child: BottomNav(
          active: NavTab.help,
          alertsHasDot: ref.watch(hasUnseenAlertsProvider),
          onChanged: (tab) {
            if (tab == NavTab.help) {
              // Already on Help - just go back to the index.
              Navigator.popUntil(context, (r) => r.isFirst);
              return;
            }
            // Pop the sub-page AND the help index, then ask the main
            // navigator to switch to the chosen tab.
            Navigator.popUntil(context, (r) => r.isFirst);
            ref.read(activeTabIndexProvider.notifier).state =
                _indexOf(tab);
          },
        ),
      ),
    );
  }

  // Mirrors MainNavigationScreen._indexOf - kept private here so this
  // file doesn't need to import the navigator's internals.
  static int _indexOf(NavTab t) {
    switch (t) {
      case NavTab.home:
        return 0;
      case NavTab.alerts:
        return 1;
      case NavTab.chats:
        return 2;
      case NavTab.profile:
        return 3;
      case NavTab.help:
        return 4;
    }
  }
}

/// _StepRow - identical to the version that previously lived in
/// help_screen.dart's _HowToTab. Visuals unchanged.
class _StepRow extends StatelessWidget {
  final String kicker;
  final String title;
  final String body;
  const _StepRow({
    required this.kicker,
    required this.title,
    required this.body,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      // Vertical-only padding now that the surrounding scroll view
      // owns the 24px horizontal gutter. (Was fromLTRB(24, 18, 24, 18)
      // when this widget lived inside an unpadded ListView.)
      padding: const EdgeInsets.symmetric(vertical: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            kicker.toUpperCase(),
            style: AppTheme.barlowCondensed(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: AppTheme.red,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: AppTheme.barlow(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: AppTheme.black,
              letterSpacing: -0.2,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            body,
            style: AppTheme.barlow(
              fontSize: 13,
              color: const Color(0xFF666666),
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}
