import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/theme/app_theme.dart';
import '../core/services/profile_service.dart';
import '../widgets/top_bar.dart';
import '../widgets/cta_button.dart';
import '../widgets/consent_box.dart';
import 'main_navigation_screen.dart';

/// Step 3 of 3. Mirrors the HTML `OnboardProfileScreen`:
///   • TopBar with "3 OF 3" badge + back arrow
///   • Big condensed heading: "Your" (black) / "Profile" (red)
///   • Two "labeled underline" fields with trailing pill badges:
///       - FULL NAME  → "A-Z"
///       - MOBILE NUMBER → "+91"
///   • ConsentBox (phone-exposure consent - REQUIRED)
///   • Grey info notice about location
///   • CTA "SAVE & ENTER THE NETWORK"
///
/// Preserves ProfileService behaviour from the old screen:
///   - validate name non-empty
///   - validate Indian mobile (6-9 prefix, 10 digits)
///   - auto-dismiss keyboard at 10 digits + haptic
///   - persist via saveProfile and replace-navigate to MainNavigationScreen
class ProfileCreateScreen extends StatefulWidget {
  /// When true, the screen loads existing profile values and acts as an
  /// edit screen - hides the "3 OF 3" badge, changes the CTA label to
  /// "SAVE CHANGES", and pops back on success instead of routing to
  /// MainNavigationScreen.
  final bool isEdit;

  const ProfileCreateScreen({super.key, this.isEdit = false});

  @override
  State<ProfileCreateScreen> createState() => _ProfileCreateScreenState();
}

class _ProfileCreateScreenState extends State<ProfileCreateScreen> {
  final _nameCtrl = TextEditingController();
  final _mobileCtrl = TextEditingController();
  final _nameFocus = FocusNode();
  final _mobileFocus = FocusNode();

  bool _phoneConsent = false;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _mobileCtrl.addListener(_onMobileChanged);
    // In edit mode, prefill from existing profile and auto-check consent
    // since the user already consented at sign-up.
    if (widget.isEdit) {
      _phoneConsent = true;
      _prefill();
    }
  }

  Future<void> _prefill() async {
    final name = await ProfileService.getUserName() ?? '';
    final mobile = await ProfileService.getUserMobile() ?? '';
    if (!mounted) return;
    // Use TextEditingController.value (not just .text) so we can set the
    // cursor at the end of the prefilled value. Assigning to .text places
    // the caret at offset 0, which on some Android IMEs makes the cursor
    // effectively invisible and the field appears frozen for editing.
    _nameCtrl.value = TextEditingValue(
      text: name,
      selection: TextSelection.collapsed(offset: name.length),
    );
    _mobileCtrl.value = TextEditingValue(
      text: mobile,
      selection: TextSelection.collapsed(offset: mobile.length),
    );
    setState(() {});
  }

  @override
  void dispose() {
    _mobileCtrl.removeListener(_onMobileChanged);
    _nameCtrl.dispose();
    _mobileCtrl.dispose();
    _nameFocus.dispose();
    _mobileFocus.dispose();
    super.dispose();
  }

  void _onMobileChanged() {
    if (_mobileCtrl.text.length == 10) {
      FocusScope.of(context).unfocus();
      HapticFeedback.lightImpact();
    }
    if (_error != null) setState(() => _error = null);
  }

  Future<void> _save() async {
    final name = _nameCtrl.text.trim();
    final mobile = _mobileCtrl.text.trim();

    if (name.isEmpty) {
      setState(() => _error = 'Please enter your name');
      return;
    }
    if (mobile.isEmpty) {
      setState(() => _error = 'Please enter your mobile number');
      return;
    }
    if (!ProfileService.isValidIndianMobile(mobile)) {
      setState(
          () => _error = 'Please enter a valid 10-digit Indian mobile number');
      return;
    }
    if (!_phoneConsent) {
      setState(() => _error = 'Please consent to sharing your details during an SOS');
      return;
    }

    setState(() {
      _busy = true;
      _error = null;
    });

    try {
      await ProfileService.saveProfile(name: name, mobile: mobile);
      if (!mounted) return;
      if (widget.isEdit) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Profile updated'),
            backgroundColor: AppTheme.successGreenDark,
            behavior: SnackBarBehavior.floating,
          ),
        );
        Navigator.pop(context, true);
      } else {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (_) => const MainNavigationScreen()),
          (route) => false,
        );
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = 'Failed to save profile. Please try again.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      // resizeToAvoidBottomInset=true by default - we want the keyboard
      // to lift the layout without the sticky bottom CTA staying over it
      body: SafeArea(
        // Tap-outside-to-dismiss-keyboard.
        //
        // IMPORTANT: this MUST use HitTestBehavior.translucent (not opaque).
        // With opaque, the GestureDetector claims hits within its bounds and
        // can win the gesture arena over the child TextFields - the result
        // is that tapping NAME / MOBILE NUMBER simply unfocuses (closing the
        // keyboard) instead of opening it, and the fields appear "frozen"
        // and uneditable. translucent lets child TextFields receive their
        // tap first, and onTap only fires when no child handled it.
        //
        // Also use FocusManager.instance.primaryFocus?.unfocus() instead of
        // FocusScope.of(context).unfocus(): the latter can throw if there is
        // no focused descendant in scope (e.g. on first frame in edit mode
        // before prefill completes).
        child: GestureDetector(
          onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
          behavior: HitTestBehavior.translucent,
          child: Column(
            children: [
              TopBar(
                badge: widget.isEdit ? null : '3 OF 3',
                onBack: () => Navigator.pop(context),
                // In onboarding mode, show the paw logo so the header
                // matches the Terms screen. Green dot is intentionally
                // hidden until the user has finished onboarding.
                showLogo: !widget.isEdit,
                showOnline: widget.isEdit,
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 24),
                      // Heading: "Your" (black) + "Profile" (red)
                      Text(
                        'Your',
                        style: AppTheme.barlowCondensed(
                          fontSize: 64,
                          fontWeight: FontWeight.w900,
                          color: AppTheme.black,
                          height: 0.92,
                          letterSpacing: -1.5,
                        ),
                      ),
                      Text(
                        'Profile',
                        style: AppTheme.barlowCondensed(
                          fontSize: 64,
                          fontWeight: FontWeight.w900,
                          color: AppTheme.red,
                          height: 0.92,
                          letterSpacing: -1.5,
                        ),
                      ),
                      // Hairline rule
                      Container(
                        margin:
                            const EdgeInsets.symmetric(vertical: 24),
                        height: 1,
                        color: AppTheme.black.withValues(alpha: 0.12),
                      ),
                      // Name field
                      _LabeledUnderlineField(
                        label: 'FULL NAME',
                        badge: 'A-Z',
                        controller: _nameCtrl,
                        focusNode: _nameFocus,
                        keyboardType: TextInputType.name,
                        textInputAction: TextInputAction.next,
                        onSubmitted: (_) =>
                            FocusScope.of(context).requestFocus(_mobileFocus),
                        hintText: 'Enter your full name',
                        textCapitalization: TextCapitalization.words,
                      ),
                      const SizedBox(height: 20),
                      // Mobile field (digits only, max 10)
                      _LabeledUnderlineField(
                        label: 'MOBILE NUMBER',
                        badge: '+91',
                        controller: _mobileCtrl,
                        focusNode: _mobileFocus,
                        keyboardType: TextInputType.phone,
                        textInputAction: TextInputAction.done,
                        onSubmitted: (_) => FocusScope.of(context).unfocus(),
                        hintText: '10-digit mobile',
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                          LengthLimitingTextInputFormatter(10),
                        ],
                      ),
                      const SizedBox(height: 28),
                      ConsentBox(
                        checked: _phoneConsent,
                        onTap: () => setState(() {
                          _phoneConsent = !_phoneConsent;
                          if (_error != null) _error = null;
                        }),
                        text:
                            'I consent to my details being shared with district volunteers during an active SOS.',
                      ),
                      if (_error != null) ...[
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            const Icon(Icons.error_outline,
                                size: 16, color: AppTheme.red),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                _error!,
                                style: AppTheme.barlow(
                                  fontSize: 12,
                                  color: AppTheme.red,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                      const SizedBox(height: 24),
                      const InfoNotice(
                        text:
                            "Location is required to send an SOS - you'll be prompted next.",
                      ),
                      const SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
              // Bottom CTA area
              Container(
                color: AppTheme.white,
                padding: const EdgeInsets.fromLTRB(24, 14, 24, 32),
                child: Column(
                  children: [
                    CtaButton(
                      label: widget.isEdit
                          ? 'SAVE CHANGES'
                          : 'SAVE & ENTER THE NETWORK',
                      onPressed: _busy ? null : _save,
                      isLoading: _busy,
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Privacy Policy · Terms · v2.1.10',
                      style: AppTheme.barlow(
                        fontSize: 11,
                        color: const Color(0xFFBBBBBB),
                        letterSpacing: 0.3,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// _LabeledUnderlineField - the minimalist underline input from the HTML.
///
/// The HTML renders filled read-only values ("Karthik", "9497344991").
/// For a real form we use a TextField with the same visual vocabulary:
///   - 10px Barlow 600 uppercase label with 2px letter-spacing
///   - 22px Barlow 500 value text, letter-spacing -0.3
///   - 1.5px bottom border (HTML: #e2e2e2)
///   - Trailing pill badge in offwhite with 12px Barlow 600
///   - No other chrome - no box, no fill, no focus ring other than the
///     bottom border colour hardening on focus.
class _LabeledUnderlineField extends StatefulWidget {
  final String label;
  final String badge;
  final String hintText;
  final TextEditingController controller;
  final FocusNode focusNode;
  final TextInputType keyboardType;
  final TextInputAction textInputAction;
  final ValueChanged<String>? onSubmitted;
  final List<TextInputFormatter>? inputFormatters;
  final TextCapitalization textCapitalization;

  const _LabeledUnderlineField({
    required this.label,
    required this.badge,
    required this.hintText,
    required this.controller,
    required this.focusNode,
    this.keyboardType = TextInputType.text,
    this.textInputAction = TextInputAction.next,
    this.onSubmitted,
    this.inputFormatters,
    this.textCapitalization = TextCapitalization.none,
  });

  @override
  State<_LabeledUnderlineField> createState() => _LabeledUnderlineFieldState();
}

class _LabeledUnderlineFieldState extends State<_LabeledUnderlineField> {
  bool _focused = false;

  @override
  void initState() {
    super.initState();
    widget.focusNode.addListener(_onFocus);
  }

  @override
  void dispose() {
    widget.focusNode.removeListener(_onFocus);
    super.dispose();
  }

  void _onFocus() {
    setState(() => _focused = widget.focusNode.hasFocus);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.label,
          style: AppTheme.labelCaps(
            fontSize: 10,
            letterSpacing: 2,
            color: AppTheme.grey,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: _focused ? AppTheme.black : AppTheme.border,
                width: 1.5,
              ),
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: TextField(
                  controller: widget.controller,
                  focusNode: widget.focusNode,
                  keyboardType: widget.keyboardType,
                  textInputAction: widget.textInputAction,
                  onSubmitted: widget.onSubmitted,
                  inputFormatters: widget.inputFormatters,
                  textCapitalization: widget.textCapitalization,
                  cursorColor: AppTheme.black,
                  style: AppTheme.barlow(
                    fontSize: 22,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.black,
                    letterSpacing: -0.3,
                  ),
                  decoration: InputDecoration(
                    isDense: true,
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    contentPadding:
                        const EdgeInsets.only(bottom: 10, top: 0),
                    hintText: widget.hintText,
                    hintStyle: AppTheme.barlow(
                      fontSize: 22,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.subtleGrey,
                      letterSpacing: -0.3,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  child: Text(
                    widget.badge,
                    style: AppTheme.barlow(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.grey,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
