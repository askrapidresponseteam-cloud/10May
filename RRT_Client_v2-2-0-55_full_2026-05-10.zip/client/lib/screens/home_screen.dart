import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:firebase_app_installations/firebase_app_installations.dart';
import '../core/theme/app_theme.dart';
import '../core/providers/district_provider.dart';
import '../core/providers/location_provider.dart';
import '../core/providers/sos_state_provider.dart';
import '../core/services/profile_service.dart';
import '../core/services/sos_service.dart';
import '../core/services/district_subscription_service.dart';
import '../core/services/app_info_service.dart';
import '../widgets/top_bar.dart';
import '../widgets/location_bar.dart';
import '../widgets/sos_button.dart';
import 'confirm_alert_screen.dart';
import 'active_sos_screen.dart';

/// Home (SOS send) screen.
///
/// Matches the HTML `HomeScreen` structurally:
///   • TopBar with green online dot
///   • Location bar (pin + district + refresh)
///   • Amber "Important Notice" box
///   • Red hold-to-send SOS button (3s hold) + helper text
///   • Description field (mandatory, 0/100)
///
/// Preserved behaviour from the prior implementation:
///   • Falls through to [ActiveSOSScreen] immediately if the shared
///     sosStateProvider already reports active - covers app restart /
///     backgrounding scenarios.
///   • Requests/refreshes location and district on pull-to-refresh.
///   • Goes through [ConfirmAlertScreen] before firing the HTTP call.
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final _descriptionCtrl = TextEditingController();
  bool _refreshing = false;
  String? _currentDistrict; // cached district - avoids re-fetch on SOS send

  // Local district service used to re-subscribe on refresh.
  final _districtService = DistrictSubscriptionService();

  @override
  void initState() {
    super.initState();
    _descriptionCtrl.addListener(() {
      if (mounted) setState(() {});
    });
    // Auto-init district subscription after a short delay (original pattern:
    // wait 2s so location services stabilise after cold start, then retry
    // up to 2 times with exponential backoff).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _initDistrictWithRetry();
    });
  }

  /// Single-shot district init on app load.
  /// initializeDistrictSubscription() already has its own 2-retry logic
  /// with 5s/10s backoff internally - no need to wrap it in another loop.
  Future<void> _initDistrictWithRetry() async {
    if (!mounted) return;
    final locService = ref.read(locationServiceProvider);
    final hasPerm = await locService.hasLocationPermission();
    if (!hasPerm) {
      // No permission yet - request it via refresh, then bail.
      // (We don't recurse - initializeDistrictSubscription would just fail
      //  again without permission. User can tap the refresh icon when ready.)
      await locService.requestLocationPermission();
      // Re-check: if user denied, give up silently.
      if (!await locService.hasLocationPermission()) return;
    }
    final district = await _districtService
        .initializeDistrictSubscription(locService);
    if (district != null && mounted) {
      setState(() => _currentDistrict = district);
      ref.invalidate(currentDistrictProvider);
    }
  }

  /// Returns cached district if available, otherwise fetches fresh.
  Future<String?> _getDistrict() async {
    if (_currentDistrict != null) return _currentDistrict;
    try {
      final locService = ref.read(locationServiceProvider);
      final d = await locService.getCurrentDistrict();
      if (d != null && mounted) setState(() => _currentDistrict = d);
      return d;
    } catch (_) {
      return null;
    }
  }

  @override
  void dispose() {
    _descriptionCtrl.dispose();
    super.dispose();
  }

  // ──────────────── location refresh ────────────────

  Future<void> _refreshLocation() async {
    if (_refreshing) return;
    setState(() => _refreshing = true);
    try {
      final locService = ref.read(locationServiceProvider);
      final hasPermission = await locService.hasLocationPermission();
      if (!hasPermission) await locService.requestLocationPermission();

      // Re-subscribe to FCM topic for current district.
      try {
        final district = await _districtService
            .initializeDistrictSubscription(locService);
        if (district != null && district.isNotEmpty) {
          if (mounted) setState(() => _currentDistrict = district);
          ref.invalidate(currentDistrictProvider);
        }
      } catch (_) {
        /* non-fatal */
      }
    } finally {
      if (mounted) setState(() => _refreshing = false);
    }
  }

  // ──────────────── SOS hold → confirm → send ────────────────

  /// Synchronous pre-flight check, run the moment the SOS button is
  /// pressed (before the 3-second hold animation starts).
  ///
  /// We do the cheap, immediate validations here so the user gets
  /// feedback instantly:
  ///   • mandatory description must be non-empty
  ///
  /// Returns `false` to abort the press. The async checks (rate-limit
  /// cooldown, location, profile lookup) still run in `_onHoldComplete`
  /// after the hold completes - they're much rarer failure modes and
  /// fine to surface at the end. Description is the common one and is
  /// always known synchronously.
  bool _onSosPressStart() {
    if (_descriptionCtrl.text.trim().isEmpty) {
      _showError('Please describe the emergency first.');
      return false;
    }
    return true;
  }

  Future<void> _onHoldComplete() async {
    // Rate-limit guard: bail early if the user just stopped a previous SOS
    // and is within the cooldown window. We check here so the user sees
    // the warning the instant they finish holding the button, not later
    // after description prompts.
    final cooldown = await SosStateNotifier.remainingSendCooldown();
    if (cooldown > Duration.zero) {
      if (!mounted) return;
      _showError(
          'You just stopped an alert. Please wait ${cooldown.inSeconds}s before sending another.');
      return;
    }

    if (!mounted) return;
    final desc = _descriptionCtrl.text.trim();
    if (desc.isEmpty) {
      _showError('Please describe the emergency first.');
      return;
    }

    // Gather profile + location synchronously as far as possible to build
    // the confirm dialog.
    final name = await ProfileService.getUserName() ?? 'Unknown';
    final mobile = await ProfileService.getUserMobile() ?? '';

    String locationLabel = 'Location unavailable';
    try {
      final address = await ref
          .read(locationServiceProvider)
          .getCurrentAddress();
      if (address != null && address.isNotEmpty) {
        locationLabel = address;
      } else {
        final district = await ref
            .read(locationServiceProvider)
            .getCurrentDistrict();
        if (district != null && district.isNotEmpty) locationLabel = district;
      }
    } catch (_) {
      /* keep default */
    }

    if (!mounted) return;
    final confirmed = await Navigator.push<bool>(
      context,
      PageRouteBuilder(
        opaque: false,
        barrierColor: Colors.black.withValues(alpha: 0.4),
        pageBuilder: (_, __, ___) => ConfirmAlertScreen(
          name: name,
          phone: mobile,
          locationLabel: locationLabel,
        ),
      ),
    );

    if (confirmed == true && mounted) {
      await _sendSos(desc, locationLabel);
    }
  }

  Future<void> _sendSos(String description, String locationLabel) async {
    // Rate-limit guard: block a new SOS if the user just stopped one a few
    // seconds ago. Prevents accidental double-trigger and abuse. We check
    // BEFORE showing the spinner so the user gets immediate feedback.
    final remaining = await SosStateNotifier.remainingSendCooldown();
    if (remaining > Duration.zero) {
      if (!mounted) return;
      _showError(
          'You just stopped an alert. Please wait ${remaining.inSeconds}s before sending another.');
      return;
    }

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(color: AppTheme.red),
      ),
    );

    try {
      final locService = ref.read(locationServiceProvider);
      final position = await _fetchPosition(locService);
      if (position == null) {
        if (mounted) Navigator.pop(context); // dismiss spinner
        _showError('Unable to get your location. Check GPS and try again.');
        return;
      }

      final name = await ProfileService.getUserName() ?? 'Unknown';
      final mobile = await ProfileService.getUserMobile() ?? '';
      // Use cached district (faster, avoids second network call during emergency).
      // The backend REQUIRES a non-empty district - without it it returns
      // "Missing district in userInfo" and the alert never fans out. Try
      // one direct geocode if cache is empty before giving up.
      String? district = await _getDistrict();
      if (district == null || district.isEmpty) {
        try {
          final locService = ref.read(locationServiceProvider);
          district = await locService.getDistrictFromCoordinates(
            position.latitude,
            position.longitude,
          );
        } catch (_) {
          /* fall through to the empty check below */
        }
      }
      if (district == null || district.isEmpty) {
        if (mounted) Navigator.pop(context); // dismiss spinner
        _showError(
            'Could not determine your district. Refresh location and try again.');
        return;
      }

      final sosService = ref.read(sosServiceProvider);
      final response = await sosService.sendSOSAlert(
        sosType: 'sos_alert',
        location: position,
        userInfo: {
          'deviceId': 'mobile-device',
          'platform': 'flutter',
          'appVersion': AppInfoService.versionString,
          'name': name,
          'mobile_number': mobile,
          'timestamp': DateTime.now().toIso8601String(),
          'message': description,
          'location': locationLabel,
          'district': district,
        },
      );

      if (!mounted) return;
      Navigator.pop(context); // dismiss spinner

      if (response.success) {
        final senderId = await FirebaseInstallations.instance.getId();
        await ref.read(sosStateProvider.notifier).activate(
              senderId: senderId,
              location: locationLabel,
            );
        _descriptionCtrl.clear();
        // No Navigator.push here - the build() method below watches
        // sosStateProvider and renders ActiveSOSScreen inline once
        // isActive flips, which preserves the bottom nav bar provided
        // by MainNavigationScreen. Pushing a new route would cover the
        // nav bar and force the user to press back to find the proper
        // screen (the duplicate-screen bug).
      } else {
        _showError(response.error ?? 'Failed to send SOS. Please try again.');
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      _showError('Failed to send SOS. Please try again.');
    }
  }

  Future<Position?> _fetchPosition(dynamic locService) async {
    try {
      // Ensure permission is granted before attempting GPS fetch.
      final hasPerm = await locService.hasLocationPermission();
      if (!hasPerm) {
        await locService.requestLocationPermission();
      }
      final data = await locService.getCurrentLocation(forceFresh: true);
      if (data == null) {
        debugPrint('_fetchPosition: getCurrentLocation returned null');
        return null;
      }
      // LocationData has only lat/lng/timestamp - no accuracy field.
      // (Old code tried to cast a non-existent field which crashed silently.)
      // data is dynamic - explicit casts avoid runtime type errors.
      final lat = (data.latitude as num).toDouble();
      final lng = (data.longitude as num).toDouble();
      final ts = data.timestamp is DateTime
          ? data.timestamp as DateTime
          : DateTime.now();
      return Position(
        latitude: lat,
        longitude: lng,
        timestamp: ts,
        accuracy: 0,
        altitude: 0,
        altitudeAccuracy: 0,
        heading: 0,
        headingAccuracy: 0,
        speed: 0,
        speedAccuracy: 0,
      );
    } catch (e, st) {
      debugPrint('_fetchPosition crashed: $e');
      debugPrint('$st');
      return null;
    }
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: AppTheme.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final districtAsync = ref.watch(currentDistrictProvider);

    // Build location label: prefer cached address, fall back to district,
    // then a placeholder. We watch the district stream so the UI stays live.
    final locationLabel = districtAsync.when(
      data: (d) => (d == null || d.isEmpty) ? 'Locating…' : d,
      loading: () => 'Locating…',
      error: (_, __) => 'Location unavailable',
    );

    // When SOS is active, render the ActiveSOSScreen inline so the bottom
    // nav (provided by MainNavigationScreen) stays visible. Don't push it
    // as a new route - that would hide the nav.
    final sosState = ref.watch(sosStateProvider);
    if (sosState.isActive) {
      return const ActiveSOSScreen();
    }

    return Scaffold(
      backgroundColor: AppTheme.white,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            const TopBar(showOnline: true),
            LocationBar(
              text: locationLabel,
              onRefresh: _refreshLocation,
              isRefreshing: _refreshing,
            ),
            const AmberNotice(
              title: 'Important Notice',
              body:
                  'This app connects you with volunteer community members, NOT official emergency services.',
            ),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
    );
  }

  Widget _buildBody() {
    // Wrap in scroll view + IntrinsicHeight to prevent pixel overflow when
    // the soft keyboard appears and to handle small phones gracefully.
    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          padding: const EdgeInsets.only(top: 12, bottom: 12),
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.maxHeight),
            child: IntrinsicHeight(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  SosButton(
                    onComplete: _onHoldComplete,
                    // Run the description check the moment the user
                    // presses, BEFORE the 3-second hold begins. If the
                    // field is empty we show the error and return
                    // false, which aborts the hold - the user doesn't
                    // wait 3s only to be told they forgot to type.
                    onHoldStart: _onSosPressStart,
                  ),
                  Text(
                    'Hold for 3 seconds to send alert',
                    style: AppTheme.barlow(
                      fontSize: 13,
                      color: AppTheme.grey,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 0.2,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: _DescriptionField(controller: _descriptionCtrl),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Description field - the bordered grey box at the bottom of Home.
/// Matches HTML: 1.5px border #e2e2e2, padding 12/14, #fafafa background,
/// placeholder text + "Mandatory field" (red) / "0/100" (grey) footer row.
class _DescriptionField extends StatelessWidget {
  final TextEditingController controller;
  const _DescriptionField({required this.controller});

  @override
  Widget build(BuildContext context) {
    final count = controller.text.length;
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppTheme.border, width: 1.5),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: controller,
            maxLength: 100,
            minLines: 1,
            maxLines: 2,
            cursorColor: AppTheme.black,
            style: AppTheme.barlow(fontSize: 14, color: AppTheme.black),
            // Treat Enter as "done" - dismiss the keyboard rather than
            // insert a newline. The description is a short single field,
            // not a paragraph; line-wrapping for long text is purely
            // visual (maxLines: 2). The deny-newline formatter is a
            // belt-and-braces guard for keyboards that still inject \n
            // even when the action is set to done.
            textInputAction: TextInputAction.done,
            keyboardType: TextInputType.text,
            inputFormatters: [
              FilteringTextInputFormatter.deny(RegExp(r'[\r\n]')),
            ],
            onSubmitted: (_) => FocusScope.of(context).unfocus(),
            decoration: InputDecoration(
              isDense: true,
              contentPadding: EdgeInsets.zero,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              counterText: '',
              hintText: 'Please describe the emergency',
              hintStyle: AppTheme.barlow(
                fontSize: 14,
                color: AppTheme.subtleGrey,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Mandatory field',
                style: AppTheme.barlow(
                  fontSize: 11,
                  color: AppTheme.red,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
              Text(
                '$count/100',
                style: AppTheme.barlow(
                  fontSize: 11,
                  color: AppTheme.subtleGrey,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
