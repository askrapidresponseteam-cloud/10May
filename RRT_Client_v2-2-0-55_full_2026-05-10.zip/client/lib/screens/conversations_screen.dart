import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_app_installations/firebase_app_installations.dart';
import '../core/theme/app_theme.dart';
import '../core/providers/chat_provider.dart';
import '../core/providers/district_provider.dart';
import '../core/providers/subscribers_count_provider.dart';
import '../widgets/top_bar.dart';
import 'chat_screen.dart';

/// Conversations list - the "Chats" tab.
///
/// Mirrors HTML `ChatsScreen`:
///   • TopBar (with online dot)
///   • District header strip (offWhite): "Udupi, Karnataka" bold + subtitle
///   • Section row: "EMERGENCY CHATS" label + black count-pill
///   • List items: 46×46 avatar circle (black, first initial), name + time
///     (right), UPPERCASE district tracking 1.5, "You: <preview>" truncated,
///     grey dot indicator.
///
/// Data from [conversationsProvider]; each item has `conv_id`, `messages`,
/// `participants`, `last_message_at`, `participant_names` (map fid → name).
class ConversationsScreen extends ConsumerWidget {
  const ConversationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final convsAsync = ref.watch(conversationsProvider);
    final districtAsync = ref.watch(currentDistrictProvider);

    final districtLabel = districtAsync.when(
      data: (d) => (d == null || d.isEmpty) ? 'Locating…' : d,
      loading: () => 'Locating…',
      error: (_, __) => 'Location unavailable',
    );

    return Scaffold(
      backgroundColor: AppTheme.white,
      body: Column(
        children: [
          const TopBar(showOnline: true),
          _DistrictStrip(district: districtLabel),
          Expanded(
            child: convsAsync.when(
              loading: () => const Center(
                child: CircularProgressIndicator(color: AppTheme.red),
              ),
              error: (_, __) => const _Empty(
                title: 'UNABLE TO LOAD CHATS',
                body: 'Please check your connection and try again.',
              ),
              data: (convs) {
                if (convs.isEmpty) {
                  return const _Empty(
                    title: 'NO CHATS YET',
                    body:
                        'Chats appear here when you respond to alerts in your district.',
                  );
                }
                return RefreshIndicator(
                  color: AppTheme.red,
                  onRefresh: () async {
                    ref.invalidate(conversationsProvider);
                    await Future<void>.delayed(
                        const Duration(milliseconds: 400));
                  },
                  child: CustomScrollView(
                    slivers: [
                      SliverToBoxAdapter(child: _SectionHeader(count: convs.length)),
                      SliverList.builder(
                        itemCount: convs.length,
                        itemBuilder: (_, i) => _ConvItem(conv: convs[i]),
                      ),
                      // Retention disclaimer. Backend wipes all conversations
                      // at midnight IST every day (see cloud function
                      // wipeChatsAtMidnightIST in rrt-cloud-function-v45).
                      // Showing this here means a user who returns the next
                      // morning and finds their chats gone has the answer
                      // already, instead of reporting it as a bug.
                      const SliverToBoxAdapter(child: _RetentionDisclaimer()),
                      const SliverToBoxAdapter(child: SizedBox(height: 20)),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────── District key helper ───────────
/// Convert any district label into the canonical key used by both
/// the FCM topic and the `subscribed_users` Firestore docs.
String _toDistrictKey(String raw) {
  // 1. Drop everything from the first comma onward (state suffix from address).
  var s = raw.split(',').first;
  // 2. Lowercase, replace whitespace + hyphens with underscores.
  s = s.toLowerCase().trim();
  s = s.replaceAll(RegExp(r'[\s\-]+'), '_');
  // 3. Strip any non-alphanumeric/underscore character.
  s = s.replaceAll(RegExp(r'[^a-z0-9_]'), '');
  // 4. Strip trailing "_district" or "_dist" suffix if present.
  s = s.replaceAll(RegExp(r'_district$|_dist$'), '');
  // 5. Collapse multiple underscores.
  s = s.replaceAll(RegExp(r'_+'), '_');
  // 6. Trim leading/trailing underscores.
  s = s.replaceAll(RegExp(r'^_+|_+$'), '');
  return s;
}

/// Convert "udupi" → "Udupi", "dakshina_kannada" → "Dakshina Kannada".
String _titleCaseDistrict(String key) => key
    .split('_')
    .map((w) => w.isEmpty
        ? w
        : '${w[0].toUpperCase()}${w.substring(1).toLowerCase()}')
    .join(' ');

// ─────────── District strip ───────────
class _DistrictStrip extends ConsumerWidget {
  final String district;
  const _DistrictStrip({required this.district});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final districtKey = _toDistrictKey(district);
    final isLocating = district == 'Locating…' || district == 'Location unavailable';
    // Polled count() aggregation instead of streaming every doc. See
    // subscribersCountProvider for the cost rationale - this is the
    // single biggest Firestore-reads optimisation in the app.
    final count = isLocating
        ? 0
        : ref.watch(subscribersCountProvider(districtKey)).valueOrNull ?? 0;
    final subtitle = (!isLocating && count > 0)
        ? '$count responders in this area'
        : 'Responders in this area';
    final canOpen = !isLocating && count > 0;
    return GestureDetector(
      onTap: canOpen
          ? () => _SubscribersSheet.show(context, districtKey, district)
          : null,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isLocating
                        ? district
                        : _titleCaseDistrict(districtKey),
                    overflow: TextOverflow.ellipsis,
                    style: AppTheme.barlow(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.black,
                      letterSpacing: -0.2,
                    ),
                  ),
                  const SizedBox(height: 1),
                  Text(
                    subtitle,
                    style: AppTheme.barlow(
                      fontSize: 11,
                      color: AppTheme.grey,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.keyboard_arrow_right,
                size: 18, color: AppTheme.grey),
          ],
        ),
      ),
    );
  }
}

// ─────────── Subscribers bottom sheet ───────────
/// Shown when the district strip is tapped. Lists every volunteer subscribed
/// to alerts in this district by name. (Online/offline tracking has been
/// removed - only names are surfaced now.)
class _SubscribersSheet extends StatelessWidget {
  final String districtKey;
  final String districtLabel;
  const _SubscribersSheet({
    required this.districtKey,
    required this.districtLabel,
  });

  static Future<void> show(
    BuildContext context,
    String districtKey,
    String districtLabel,
  ) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.5),
      builder: (_) => _SubscribersSheet(
        districtKey: districtKey,
        districtLabel: districtLabel,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final maxHeight = MediaQuery.of(context).size.height * 0.7;
    // Build a clean display title from the canonical key, not the raw
    // label (which can contain comma-separated state suffixes like
    // "Koteshwara Proper, Karnataka").
    final prettyDistrict = _titleCaseDistrict(districtKey);
    return Container(
      constraints: BoxConstraints(maxHeight: maxHeight),
      decoration: const BoxDecoration(color: AppTheme.white),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Drag handle
          Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.fromLTRB(0, 10, 0, 4),
            child: Container(
              width: 32,
              height: 4,
              color: const Color(0xFFE0E0E0),
            ),
          ),
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 10, 24, 0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Responders',
                        style: AppTheme.barlowCondensed(
                          fontSize: 28,
                          fontWeight: FontWeight.w900,
                          color: AppTheme.black,
                          letterSpacing: -0.5,
                          height: 1,
                        ),
                      ),
                      Text(
                        '$prettyDistrict District',
                        style: AppTheme.barlowCondensed(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.red,
                          letterSpacing: -0.3,
                          height: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  behavior: HitTestBehavior.opaque,
                  child: Container(
                    width: 32,
                    height: 32,
                    margin: const EdgeInsets.only(top: 2),
                    color: const Color(0xFFF5F5F5),
                    alignment: Alignment.center,
                    child: const Icon(Icons.close,
                        size: 14, color: AppTheme.black),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 0, 24, 12),
            child: Text(
              'Responders available in your district.',
              style: AppTheme.barlow(
                fontSize: 12,
                color: AppTheme.grey,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Container(height: 1, color: const Color(0xFFF0F0F0)),
          Flexible(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('subscribed_users')
                  .where('district', isEqualTo: districtKey)
                  .snapshots(),
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(32),
                    child: Center(
                      child: CircularProgressIndicator(color: AppTheme.red),
                    ),
                  );
                }
                final docs = snap.data?.docs ?? [];
                if (docs.isEmpty) {
                  return Padding(
                    padding: const EdgeInsets.all(32),
                    child: Center(
                      child: Text(
                        'No responders found.',
                        style: AppTheme.barlow(
                          fontSize: 13,
                          color: AppTheme.grey,
                        ),
                      ),
                    ),
                  );
                }
                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(0, 4, 0, 24),
                  shrinkWrap: true,
                  itemCount: docs.length,
                  separatorBuilder: (_, __) =>
                      Container(height: 1, color: const Color(0xFFF5F5F5)),
                  itemBuilder: (_, i) {
                    final data =
                        docs[i].data() as Map<String, dynamic>? ?? {};
                    final name = (data['name'] as String?) ?? 'Responder';
                    return _ResponderRow(name: name);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  static String _titleCase(String s) => s
      .split(' ')
      .map((w) => w.isEmpty
          ? w
          : w[0].toUpperCase() + w.substring(1).toLowerCase())
      .join(' ');
}

class _ResponderRow extends StatelessWidget {
  final String name;
  const _ResponderRow({required this.name});

  @override
  Widget build(BuildContext context) {
    final initial = name.trim().isEmpty ? '?' : name.trim()[0].toUpperCase();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      child: Row(
        children: [
          // Plain initial avatar - no status dot.
          Container(
            width: 40,
            height: 40,
            decoration: const BoxDecoration(
              color: AppTheme.black,
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              initial,
              style: AppTheme.barlowCondensed(
                fontSize: 17,
                fontWeight: FontWeight.w900,
                color: AppTheme.white,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Text(
              name,
              overflow: TextOverflow.ellipsis,
              style: AppTheme.barlow(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: AppTheme.black,
                letterSpacing: -0.2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────── Section header ───────────
class _SectionHeader extends StatelessWidget {
  final int count;
  const _SectionHeader({required this.count});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
      child: Row(
        children: [
          Text(
            'EMERGENCY CHATS',
            style: AppTheme.barlow(
              fontSize: 10,
              fontWeight: FontWeight.w700,
              color: AppTheme.grey,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(width: 10),
          Container(
            constraints: const BoxConstraints(minWidth: 20, minHeight: 20),
            padding: const EdgeInsets.symmetric(horizontal: 7),
            decoration: const BoxDecoration(
              color: AppTheme.black,
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              '$count',
              style: AppTheme.barlow(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: AppTheme.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────── Conversation item ───────────
class _ConvItem extends ConsumerWidget {
  final Map<String, dynamic> conv;
  const _ConvItem({required this.conv});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final convId = (conv['conv_id'] as String?) ?? '';
    final participants =
        (conv['participants'] as List<dynamic>? ?? []).cast<String>();
    final names =
        (conv['participant_names'] as Map<String, dynamic>? ?? {});
    final messages =
        (conv['messages'] as List<dynamic>? ?? []).cast<Map<String, dynamic>>();
    final district = (conv['district'] as String?) ?? '';
    final lastMessageAt = conv['last_message_at'];

    return FutureBuilder<String>(
      future: FirebaseInstallations.instance.getId(),
      builder: (_, snap) {
        final myFid = snap.data;
        // Derive the "other" participant.
        String otherFid = '';
        for (final p in participants) {
          if (p != myFid) {
            otherFid = p;
            break;
          }
        }
        final otherName =
            (names[otherFid] as String?) ?? 'Volunteer';

        // Derive preview + prefix.
        String preview = '';
        String prefix = '';
        if (messages.isNotEmpty) {
          final last = messages.last;
          final fromMe = last['from'] == myFid;
          prefix = fromMe ? 'You: ' : '';
          preview = (last['text'] as String?) ?? '';
        }

        final timeLabel = _relative(lastMessageAt);

        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ChatScreen(
                  convId: convId,
                  otherFid: otherFid,
                  otherName: otherName,
                  district: district,
                  shouldInitiate: false,
                ),
              ),
            );
          },
          behavior: HitTestBehavior.opaque,
          child: Container(
            margin: const EdgeInsets.fromLTRB(20, 0, 20, 10),
            padding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: AppTheme.white,
              border: Border.all(color: AppTheme.border, width: 1),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.04),
                  offset: const Offset(0, 2),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: const BoxDecoration(
                    color: AppTheme.black,
                    shape: BoxShape.circle,
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    _initial(otherName),
                    style: AppTheme.barlowCondensed(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: AppTheme.white,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              otherName,
                              overflow: TextOverflow.ellipsis,
                              style: AppTheme.barlow(
                                fontSize: 15,
                                fontWeight: FontWeight.w800,
                                color: AppTheme.black,
                                letterSpacing: -0.2,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            timeLabel,
                            style: AppTheme.barlow(
                              fontSize: 11,
                              color: AppTheme.grey,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      if (district.isNotEmpty)
                        Text(
                          _titleCase(district.replaceAll('_', ' '))
                              .toUpperCase(),
                          style: AppTheme.barlow(
                            fontSize: 10,
                            color: AppTheme.grey,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 1.5,
                          ),
                        ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              preview.isEmpty ? 'No messages yet' : '$prefix$preview',
                              overflow: TextOverflow.ellipsis,
                              style: AppTheme.barlow(
                                fontSize: 13,
                                color: AppTheme.grey,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            width: 6,
                            height: 6,
                            decoration: const BoxDecoration(
                              color: AppTheme.subtleGrey,
                              shape: BoxShape.circle,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  static String _relative(dynamic ts) {
    int? ms;
    if (ts is int) ms = ts;
    if (ms == null) return '';
    final diff =
        DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ms));
    if (diff.inSeconds < 45) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m';
    if (diff.inHours < 24) return '${diff.inHours}h';
    if (diff.inDays < 7) return '${diff.inDays}d';
    final dt = DateTime.fromMillisecondsSinceEpoch(ms);
    return '${dt.day}/${dt.month}';
  }

  static String _initial(String n) =>
      n.trim().isEmpty ? '?' : n.trim()[0].toUpperCase();

  static String _titleCase(String s) => s
      .split(' ')
      .map((w) => w.isEmpty ? w : w[0].toUpperCase() + w.substring(1))
      .join(' ');
}

class _Empty extends StatelessWidget {
  final String title;
  final String body;
  const _Empty({required this.title, required this.body});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.chat_bubble_outline,
                size: 42, color: AppTheme.border),
            const SizedBox(height: 14),
            Text(
              title,
              style: AppTheme.barlow(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: AppTheme.grey,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              body,
              textAlign: TextAlign.center,
              style: AppTheme.barlow(
                fontSize: 13,
                color: AppTheme.subtleGrey,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Small grey footer line shown below the conversation list so a user
/// who returns the next morning and finds their chats gone has the
/// answer up front instead of reporting it as a bug.
///
/// Backend behaviour (cloud function wipeChatsAtMidnightIST in
/// rrt-cloud-function-v45/functions/index.js): every day at 00:00 IST
/// any sos_conversations document with last_message_at before the
/// start of today (IST) is deleted, along with its chat photos and
/// voice notes. Effective lifetime ranges from ~1 hour (chat right
/// before midnight) to ~24 hours (chat right after midnight).
///
/// We deliberately reference the export feature in the chat screen
/// rather than promising a specific lifetime: the variable lifetime
/// is harder to communicate honestly than "if you need to keep it,
/// export it now". Export already exists; we're just pointing at it.
class _RetentionDisclaimer extends StatelessWidget {
  const _RetentionDisclaimer();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 24, 24, 8),
      child: Text(
        'Chats clear at midnight (IST) every day. If you need to keep '
        'a conversation, open it and use Export before then.',
        textAlign: TextAlign.center,
        style: AppTheme.barlow(
          fontSize: 11,
          color: AppTheme.grey,
          height: 1.4,
        ),
      ),
    );
  }
}
