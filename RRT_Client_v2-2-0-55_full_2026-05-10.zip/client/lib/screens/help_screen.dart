import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../core/theme/app_theme.dart';
import '../widgets/top_bar.dart';
import 'find_vet_screen.dart';
import 'help_how_to_screen.dart';
import 'help_contact_screen.dart';

/// Help index - the entry point under the Help bottom-nav tab.
///
/// Replaces the previous 2-tab "How To Use | Contact Us" layout with a
/// magazine-style index of topics. Each row is a numbered, full-width
/// tappable entry that pushes a dedicated detail screen.
///
/// Visual vocabulary mirrors the rest of the app:
///   • TopBar with online dot
///   • Big condensed headline split across two lines: "Need" black /
///     "Help?" red - same pattern as "Your / Profile" on ProfileScreen
///   • Hairline rule (12% black) under the headline
///   • Numbered rows with red 'Barlow Condensed' kicker numerals (01,
///     02, ...) - same red-numeral pattern used on the post-SOS feedback
///     screen and the onboarding step-by-step blocks
///   • Right-aligned chevron arrow per row, 1px hairline divider between
///
/// Adding a section in future: append one entry to `_sections` and
/// create the corresponding detail screen. No layout reflow needed.
class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  // Ordered list of help topics. The numeral shown to the user is the
  // 1-based index, formatted as "01", "02", etc. - keep this list short
  // and meaningful; help screens that grow into a junk drawer are the
  // ones users stop reading.
  //
  // Each section either has a `builder` (push a sub-page) or an
  // `action` (run a callback in place, e.g. open the share sheet).
  // Exactly one of the two must be set - see _HelpSection assertion.
  static final List<_HelpSection> _sections = [
    _HelpSection(
      title: 'How to use the app',
      builder: (_) => const HelpHowToScreen(),
    ),
    _HelpSection(
      title: 'Look up a vet',
      // Browsing-mode entry into FindVetScreen. fromActiveSos=false so
      // there's no "SOS still active" breadcrumb - the user is just
      // looking, not in the middle of an emergency. The screen is
      // otherwise identical to the SOS-mode version.
      builder: (_) => const FindVetScreen(fromActiveSos: false),
    ),
    _HelpSection(
      title: 'Contact us',
      builder: (_) => const HelpContactScreen(),
    ),
    _HelpSection(
      title: 'Share the app',
      // Single cross-platform link: rapid-response.in detects the
      // visitor's platform and shows both Play Store and App Store
      // buttons. This avoids the failure case where an iPhone user
      // shares a Play-Store link to an Android friend and vice versa
      // (~30-40% of share-and-send-to-friend flows are cross-platform).
      // It also gives us a richer link preview in WhatsApp / iMessage
      // (the website's OG image instead of a generic store card).
      action: _shareApp,
      isAction: true,
    ),
  ];

  // Static so it can be referenced from the const-ish _sections list
  // builder above without needing an instance. Returns Future<void> -
  // we don't await the result here; if the user backs out of the
  // share sheet that's fine and silent.
  //
  // Voice / framing notes (mirrors rapid-response.in):
  //   - Lowercase. The website is consistently lowercase.
  //   - Hyphens, never em-dashes. Matches the site.
  //   - Describes WHAT THE NETWORK IS, not what it DELIVERS. The
  //     website's "what we are / what we aren't" section is explicit:
  //     "we aren't a guarantee. what comes back depends on who's in
  //     your district and who's free." So the share text deliberately
  //     does NOT list outcomes (vet at midnight, transport, etc.) -
  //     that would read as a service promise the network can't make.
  //   - "the more of us who're on it, the easier it gets to find each
  //     other when something comes up" carries the site's "be findable,
  //     so others can be too" message - capacity, not delivery.
  //   - Naming the five roles (feeders, pet parents, fosterers,
  //     rescuers, vets) lets recipients self-identify. People who
  //     don't see themselves in that list correctly self-select out,
  //     which is the right outcome for a peer network.
  //
  // Length: ~250 chars. Comfortably under WhatsApp's "Read more"
  // truncation window. iMessage / SMS / email all handle this length.
  /// Open the system share sheet.
  ///
  /// iOS 26 specific bug: `SharePlus.instance.share()` throws a
  /// PlatformException when `sharePositionOrigin` is zero or absent
  /// ("argument must be set, {{0, 0}, {0, 0}} must be non-zero and
  /// within coordinate space of source view"). The exception bubbles
  /// up async and gets swallowed by the framework, so from the user's
  /// perspective nothing happens at all - tap, no sheet, no error.
  ///
  /// Fix: compute a real anchor rect from the screen size. On iPhone
  /// the share sheet is a centred bottom sheet that ignores the rect
  /// once it's non-empty, so any non-zero rect works there. On iPad
  /// the share sheet is a popover that REQUIRES a real anchor near
  /// the source - we anchor to the bottom-centre of the screen so the
  /// popover arrow points roughly at the tapped row, which is good
  /// enough without plumbing a per-row GlobalKey through the list.
  ///
  /// Also wrap in try/catch with debugPrint so any future failures
  /// surface in logs rather than disappearing silently.
  ///
  /// See: https://github.com/fluttercommunity/plus_plugins/issues/3685
  static Future<void> _shareApp(BuildContext context) async {
    // Share message shown in the OS share sheet. Plain text only -
    // share targets (WhatsApp, SMS, email, etc.) auto-link bare URLs as
    // long as they include a scheme (https://) and no whitespace inside
    // the URL. Keep both URLs on their own lines for that reason.
    const body =
        'Rapid Response (rrt) is a free app for animal emergencies '
        '- injured community animals, lost pets, abuse, accidents, '
        'anything that needs help.\n\n'
        'raise an sos and everyone on the app in your district sees '
        'it - feeders, pet parents, fosterers, vets, rescuers. '
        'anyone nearby who can help, helps. no central team, no '
        'signup fee. just neighbours showing up for animals.\n\n'
        'Download the app from https://rapid-response.in\n\n'
        'Follow the team on https://www.instagram.com/rrtanimals';

    // Anchor the popover (iPad) / non-zero rect (iPhone iOS 26 fix) to
    // a 1pt-tall sliver near the bottom-centre of the screen. We can't
    // easily get the tapped row's rect from this static callback, but
    // bottom-centre is a reasonable approximation for a row roughly in
    // the middle of the Help index.
    final size = MediaQuery.of(context).size;
    final anchor = Rect.fromLTWH(
      size.width / 2 - 1,
      size.height - 80,
      2,
      2,
    );

    try {
      await Share.share(
        body,
        subject: 'Rapid Response - join the animal emergency '
            'network in your district',
        sharePositionOrigin: anchor,
      );
    } catch (e, st) {
      debugPrint('help_screen: share failed: $e\n$st');
    }
  }

  void _open(BuildContext context, _HelpSection section) {
    if (section.isAction) {
      // Action row (e.g. Share) - run the callback in place; do not
      // push a route. Pass the context so the action can compute a
      // real share-sheet anchor rect (matters on iPad).
      section.action?.call(context);
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(builder: section.builder!),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      body: Column(
        children: [
          const TopBar(showOnline: true),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 24),
                  // Headline: "Need" (black) / "Help?" (red)
                  Text(
                    'Need',
                    style: AppTheme.barlowCondensed(
                      fontSize: 64,
                      fontWeight: FontWeight.w900,
                      color: AppTheme.black,
                      height: 0.92,
                      letterSpacing: -1.5,
                    ),
                  ),
                  Text(
                    'Help?',
                    style: AppTheme.barlowCondensed(
                      fontSize: 64,
                      fontWeight: FontWeight.w900,
                      color: AppTheme.red,
                      height: 0.92,
                      letterSpacing: -1.5,
                    ),
                  ),
                  // Hairline rule - 12% black, 1px tall, same as the
                  // ProfileScreen / ProfileCreateScreen separator.
                  Container(
                    margin: const EdgeInsets.symmetric(vertical: 24),
                    height: 1,
                    color: AppTheme.black.withValues(alpha: 0.12),
                  ),
                  // Numbered topic rows
                  for (var i = 0; i < _sections.length; i++)
                    _IndexRow(
                      number: (i + 1).toString().padLeft(2, '0'),
                      title: _sections[i].title,
                      onTap: () => _open(context, _sections[i]),
                      isLast: i == _sections.length - 1,
                      isAction: _sections[i].isAction,
                    ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Internal helper - one row of the index list.
///
/// A section is either *navigational* (push a sub-page via [builder])
/// or an *action* (run [action] in place, e.g. open the share sheet).
/// Exactly one of the two must be set; the assertion enforces this so
/// a malformed entry fails loudly in debug rather than silently doing
/// nothing on tap.
class _HelpSection {
  final String title;
  final WidgetBuilder? builder;
  final Future<void> Function(BuildContext)? action;
  final bool isAction;
  const _HelpSection({
    required this.title,
    this.builder,
    this.action,
    this.isAction = false,
  }) : assert((builder != null) ^ (action != null),
            'Provide exactly one of builder or action');
}

/// _IndexRow - a numbered topic entry. Visual specs match the
/// red-numeral kicker pattern used throughout the app:
///   • 12px Barlow Condensed 900 red kicker, 2px tracking
///   • 16px Barlow 800 black title, -0.2 letter-spacing
///   • 14px chevron in subtle grey on the trailing edge for
///     navigational rows; share-glyph for action rows so the user gets
///     a hint that this is an action, not a navigation.
///   • 1px hairline divider between rows (none after the last row)
class _IndexRow extends StatelessWidget {
  final String number;
  final String title;
  final VoidCallback onTap;
  final bool isLast;
  final bool isAction;
  const _IndexRow({
    required this.number,
    required this.title,
    required this.onTap,
    required this.isLast,
    this.isAction = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: isLast ? Colors.transparent : AppTheme.veryLightGrey,
              width: 1,
            ),
          ),
        ),
        padding: const EdgeInsets.symmetric(vertical: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              number,
              style: AppTheme.barlowCondensed(
                fontSize: 12,
                fontWeight: FontWeight.w900,
                color: AppTheme.red,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: AppTheme.barlow(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.black,
                      letterSpacing: -0.2,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Action rows show a share-glyph; nav rows show the
                // standard chevron. Same size + colour so the rhythm
                // of the list isn't disturbed - just enough visual
                // difference to hint that the affordance is different.
                Icon(
                  isAction
                      ? Icons.ios_share
                      : Icons.arrow_forward_ios_rounded,
                  size: 14,
                  color: AppTheme.grey,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
