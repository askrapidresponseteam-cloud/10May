import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:just_audio/just_audio.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:permission_handler/permission_handler.dart';
import '../core/theme/app_theme.dart';
import '../core/constants/app_constants.dart';
import '../core/providers/sos_state_provider.dart';
import '../core/providers/alerts_provider.dart';
import '../core/providers/location_provider.dart';
import '../core/services/profile_service.dart';
import '../core/services/sos_photo_service.dart';
import '../core/services/sos_service.dart';
import '../core/services/app_info_service.dart';
import '../core/services/sos_voice_service.dart';
import '../core/services/district_subscription_service.dart';
import '../core/services/feedback_service.dart';
import '../widgets/top_bar.dart';
import '../widgets/location_bar.dart';
import '../widgets/cta_button.dart';
import '../widgets/photo_viewer.dart';
import 'feedback_screen.dart';
import 'find_vet_screen.dart';

/// Active SOS screen shown while an alert is live.
///
/// Mirrors the HTML ActiveSOSScreen layout & rhythm:
///   • TopBar (green dot)
///   • Location bar
///   • Thin red progress bar (ratio of remaining to total TTL)
///   • Hero timer row: red pulsing dot, "ALERT ACTIVE", MM:SS
///   • Viewer count row: chunky count + "RESPONDERS VIEWING" eyebrow + LIVE pulse
///   • Scene photos - 3 square slots, ADD tile drives captureAndUpload
///   • Voice message - 56px tappable box, RECORDING… wave animation
///   • Success toast (green) - "Emergency alert sent successfully!" - shown
///     for 10 seconds after fresh activation, then auto-hides
///   • STOP SOS CTA (danger) - deactivates SOS and pops back to home
class ActiveSOSScreen extends ConsumerStatefulWidget {
  const ActiveSOSScreen({super.key});

  @override
  ConsumerState<ActiveSOSScreen> createState() => _ActiveSOSScreenState();
}

class _ActiveSOSScreenState extends ConsumerState<ActiveSOSScreen> {
  Timer? _tick;
  int _secondsRemaining = AppConstants.alertTtl.inSeconds;

  final _photoService = SosPhotoService();
  final _voiceService = SosVoiceService();
  bool _recording = false;
  bool _busyPhoto = false;

  /// Per-channel consent: photo and voice each prompt the user the first
  /// time they tap that specific affordance within a single SOS. Resets on
  /// screen unmount (which happens automatically on deactivate/expiry, so a
  /// new alert always re-prompts). Kept separate so a user who only wanted
  /// to add a photo isn't silently opted in to also recording audio - the
  /// retention copy is the same but the act of granting microphone access
  /// is its own decision.
  bool _photoNoticeAcknowledged = false;
  bool _voiceNoticeAcknowledged = false;

  @override
  void initState() {
    super.initState();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      final sos = ref.read(sosStateProvider);
      if (!sos.isActive || sos.activatedAtMillis == null) return;
      final expiresAt = DateTime.fromMillisecondsSinceEpoch(
              sos.activatedAtMillis!)
          .add(AppConstants.alertTtl);
      final diff = expiresAt.difference(DateTime.now()).inSeconds;
      if (mounted) {
        setState(() => _secondsRemaining = diff.clamp(0, 1 << 30));
      }
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    _voiceService.dispose();
    super.dispose();
  }

  // ──────────────── actions ────────────────

  Future<void> _stopSos() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => _StopConfirmDialog(),
    );
    if (confirmed != true || !mounted) return;

    // ─────────────────────────────────────────────────────────────────────
    // CAPTURE NAVIGATOR + MESSENGER BEFORE ANY ASYNC WORK.
    //
    // Once we call deactivate() below, sosStateProvider flips inactive →
    // HomeScreen rebuilds → ActiveSOSScreen unmounts → this State is
    // disposed → `context` and `mounted` become unsafe.
    //
    // Previous attempts checked `mounted` inside a dismissSpinner() helper
    // — that's exactly why the spinner was getting stuck: by the time we
    // reached the dismiss, mounted was already false and the helper bailed.
    //
    // The fix: capture rootNavigator and ScaffoldMessenger right now, and
    // use ONLY those captured handles after this point. Never touch
    // `context` or `mounted` after the spinner is shown.
    // ─────────────────────────────────────────────────────────────────────
    final rootNav = Navigator.of(context, rootNavigator: true);
    final messenger = ScaffoldMessenger.of(context);

    // Snapshot SOS identity BEFORE any async work. We need senderId +
    // activatedAt to (a) key the feedback Firestore doc and (b) mark the
    // alert as already-handled in SharedPreferences. After deactivate()
    // these are cleared from the provider state.
    final sosSnapshot = ref.read(sosStateProvider);
    final feedbackSenderId = sosSnapshot.senderId;
    final feedbackActivatedAt = sosSnapshot.activatedAtMillis;

    // Show non-dismissible spinner. We use the captured rootNav for both
    // showing and (later) popping it — never `context` after this point.
    bool spinnerShowing = true;
    showDialog(
      context: rootNav.context,
      barrierDismissible: false,
      useRootNavigator: true,
      builder: (_) => const Center(
        child: CircularProgressIndicator(color: AppTheme.red),
      ),
    );

    // Spinner dismissal that does NOT depend on `mounted` or `context`.
    // The captured rootNav survives this widget's unmount because it
    // belongs to MaterialApp at the root of the tree.
    void killSpinner() {
      if (!spinnerShowing) return;
      spinnerShowing = false;
      try {
        if (rootNav.canPop()) rootNav.pop();
      } catch (_) {/* already gone */}
    }

    // Snackbar that uses the captured messenger — survives unmount.
    void postSnack(String msg, {Color? bg}) {
      try {
        messenger
          ..hideCurrentSnackBar()
          ..showSnackBar(
            SnackBar(
              content: Text(msg),
              backgroundColor: bg ?? AppTheme.red,
              duration: const Duration(seconds: 3),
              behavior: SnackBarBehavior.floating,
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 96),
            ),
          );
      } catch (_) {/* messenger gone — nothing we can do */}
    }

    try {
      final locService = ref.read(locationServiceProvider);
      final sosService = ref.read(sosServiceProvider);

      // ── Permission + location prereqs ──────────────────────────────────
      final hasPermission = await locService.hasLocationPermission();
      if (!hasPermission) {
        killSpinner();
        postSnack('Location permission required to stop alert.');
        return;
      }

      final locationData = await locService.getCurrentLocation(forceFresh: true);
      if (locationData == null) {
        killSpinner();
        postSnack('Unable to get current location. Check GPS and try again.');
        return;
      }

      final currentPosition = Position(
        latitude: locationData.latitude,
        longitude: locationData.longitude,
        timestamp: locationData.timestamp,
        accuracy: 0.0,
        altitude: 0.0,
        altitudeAccuracy: 0.0,
        heading: 0.0,
        headingAccuracy: 0.0,
        speed: 0.0,
        speedAccuracy: 0.0,
      );

      // ── userInfo for stop request ──────────────────────────────────────
      final userName = await ProfileService.getUserName() ?? 'Emergency Contact';
      final userMobile = await ProfileService.getUserMobile() ?? '';
      final currentAddress = await locService.getCurrentAddress() ??
          (sosSnapshot.location ?? 'Location unavailable');

      // District is REQUIRED — backend rejects stop with "Missing district"
      // otherwise. Try fresh geocode → fallback to last cached district.
      String? district = await locService.getDistrictFromCoordinates(
        currentPosition.latitude,
        currentPosition.longitude,
      );
      if (district == null || district.isEmpty) {
        district = await locService.getCurrentDistrict();
      }
      if (district == null || district.isEmpty) {
        district = await DistrictSubscriptionService().getLastSubscribedDistrict();
      }
      if (district == null || district.isEmpty) {
        killSpinner();
        postSnack('Could not determine your district. Check location and try again.');
        return;
      }

      // ── Backend stop with aggressive 15s timeout ───────────────────────
      // If the call hangs, we still flip local state via synthetic success.
      // The Firestore listener on sosStateProvider reconciles if/when the
      // backend eventually catches up; if not, the 60-min TTL handles it.
      final response = await sosService.sendSOSAlert(
        sosType: 'stop',
        location: currentPosition,
        userInfo: {
          'deviceId': 'mobile-device',
          'platform': 'flutter',
          'appVersion': AppInfoService.versionString,
          'name': userName,
          'mobile_number': userMobile,
          'timestamp': DateTime.now().toIso8601String(),
          'location': currentAddress,
          'district': district,
        },
      ).timeout(
        const Duration(seconds: 15),
        onTimeout: () {
          debugPrint('Stop SOS network call timed out — flipping local anyway');
          return SOSResponse(success: true);
        },
      );

      // ── Kill spinner FIRST, before deactivate() unmounts us ────────────
      // This is the line that broke before. Calling killSpinner() AFTER
      // deactivate() left it stuck because `mounted` had become false.
      killSpinner();

      // The stop network call has returned. From here on, ANY failure in
      // post-stop housekeeping (media purge, provider deactivate, feedback
      // form push, SharedPreferences read for "alreadyHandled") must NOT
      // surface a "Failed to stop emergency alert" snackbar — the stop
      // already succeeded as far as the backend is concerned. We therefore
      // run each side effect in its own try/catch and never let post-stop
      // exceptions reach the outer catch block.

      if (!response.success) {
        postSnack(response.error ?? 'Failed to stop emergency alert.');
        return;
      }

      // Purge uploaded media — fire-and-forget, runs in background.
      try {
        if (feedbackSenderId != null) {
          unawaited(SosPhotoService.purgeAll(feedbackSenderId));
          unawaited(SosVoiceService.purgeAll(feedbackSenderId));
        }
      } catch (e) {
        debugPrint('Post-stop purge scheduling failed (non-fatal): $e');
      }

      // Flip provider → HomeScreen rebuilds → ActiveSOSScreen unmounts.
      // We don't await this — the listener handles cleanup, and we don't
      // want to block on it because if Firestore is slow the await could
      // hang for seconds while the user stares at a stuck UI.
      try {
        unawaited(ref.read(sosStateProvider.notifier).deactivate());
      } catch (e) {
        debugPrint('Post-stop deactivate scheduling failed (non-fatal): $e');
      }

      // Confirmation snackbar via captured messenger (survives unmount).
      postSnack('Emergency alert stopped', bg: AppTheme.successGreenDark);

      // Feedback form: scheduled with 1.2s delay so the user sees the
      // home screen briefly before the form slides up. We push via the
      // captured rootNav, which is the MaterialApp's navigator and is
      // therefore always alive regardless of this widget's lifecycle.
      //
      // CRITICAL: this whole block is wrapped in try/catch because
      // `FeedbackService.alreadyHandled` reads SharedPreferences, which can
      // throw (rare, but it has — particularly on second SOS in the same
      // session). A throw here used to bubble to the outer catch and show
      // "Failed to stop emergency alert" even though the stop had already
      // succeeded. That's the ghost error the user was seeing.
      try {
        if (feedbackSenderId != null && feedbackActivatedAt != null) {
          final handled = await FeedbackService.alreadyHandled(
            senderId: feedbackSenderId,
            activatedAtMillis: feedbackActivatedAt,
          );
          if (!handled) {
            unawaited(
              Future.delayed(const Duration(milliseconds: 1200), () {
                try {
                  if (!rootNav.mounted) return;
                  rootNav.push(
                    MaterialPageRoute(
                      fullscreenDialog: true,
                      builder: (_) => FeedbackScreen(
                        senderId: feedbackSenderId,
                        activatedAtMillis: feedbackActivatedAt,
                      ),
                    ),
                  );
                } catch (e) {
                  debugPrint('Feedback push failed: $e');
                }
              }),
            );
          }
        }
      } catch (e, st) {
        // Feedback prompt failed to even decide whether to show. Silently
        // swallow — we'd rather skip the form than blame the stop.
        debugPrint('Feedback prompt setup failed (non-fatal): $e\n$st');
      }
    } catch (e, st) {
      // Only the *stop request itself* (network call, location fetch,
      // district lookup) can land here. Post-stop actions are guarded
      // above and never reach this catch.
      debugPrint('_stopSos error (pre-success): $e\n$st');
      postSnack('Failed to stop emergency alert. Please try again.');
    } finally {
      // Final safety net. killSpinner is idempotent — if we already popped,
      // this is a no-op. If any path above forgot, this rescues us.
      killSpinner();
    }
  }

  /// One-time-per-alert consent gate for **photos**. Shown the first time
  /// the user taps "Add scene photo" within a single SOS lifecycle. Returns
  /// true if the user confirmed (so the caller can proceed) or if the
  /// notice has already been confirmed earlier in this alert. Returns false
  /// if the user dismissed/cancelled - in which case the caller MUST abort
  /// the action.
  ///
  /// The dialog text is the canonical retention copy: "not stored
  /// permanently - removed when the SOS ends or after 60 minutes, whichever
  /// is sooner." Keep this aligned with the actual purgeAll() wiring in
  /// the provider/stop flow.
  Future<bool> _ensurePhotoNotice() async {
    if (_photoNoticeAcknowledged) return true;
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _MediaNoticeDialog(kind: _MediaNoticeKind.photo),
    );
    if (ok == true) {
      _photoNoticeAcknowledged = true;
      return true;
    }
    return false;
  }

  /// One-time-per-alert consent gate for **voice messages**. Mirror of
  /// [_ensurePhotoNotice] but with copy/icons tailored to audio. Each
  /// channel is consented to independently so a user who only wanted to
  /// share a photo isn't surprised when a microphone permission prompt
  /// later appears.
  Future<bool> _ensureVoiceNotice() async {
    if (_voiceNoticeAcknowledged) return true;
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _MediaNoticeDialog(kind: _MediaNoticeKind.voice),
    );
    if (ok == true) {
      _voiceNoticeAcknowledged = true;
      return true;
    }
    return false;
  }

  /// Surfaces a clear, actionable message when the OS reports a permission
  /// is permanently denied. Offers a button to open the app's settings page
  /// so the user can grant it manually without leaving the app trail.
  Future<void> _showPermanentDenialDialog({
    required String permissionLabel,
    required String reason,
  }) async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (_) => _PermissionDeniedDialog(
        permissionLabel: permissionLabel,
        reason: reason,
      ),
    );
  }

  Future<void> _addPhoto(int currentCount) async {
    if (_busyPhoto) return;
    final senderId = ref.read(sosStateProvider).senderId;
    if (senderId == null) return;

    // Show the photo retention/handling notice the first time the user
    // taps add-photo within this alert, before the OS camera permission
    // prompt fires.
    final consented = await _ensurePhotoNotice();
    if (!consented) return;

    // Pre-flight the camera permission. Important Android caveat: a
    // status read of `denied` is ambiguous - it could mean "never
    // asked" OR "permanently denied" - the OS does not distinguish
    // them on .status. Only the return value of .request() is
    // authoritative for the permanentlyDenied state. So we go straight
    // to .request() unless we already know we're granted.
    //
    // Background:
    //   https://github.com/Baseflow/flutter-permission-handler/issues/336
    //   https://github.com/Baseflow/flutter-permission-handler/issues/619
    final ok = await _ensurePermission(
      permission: Permission.camera,
      label: 'Camera',
      reason: 'Camera access is required to add a scene photo to your alert.',
      deniedSnack: 'Camera permission required to add a photo.',
    );
    if (!ok) return;

    setState(() => _busyPhoto = true);
    try {
      final result = await _photoService.captureAndUpload(
        senderId: senderId,
        currentPhotoCount: currentCount,
      );
      if (!mounted) return;
      switch (result.status) {
        case PhotoCaptureStatus.success:
          // No snack - the photo appearing in the strip is the
          // confirmation. Adding a snack here is noise.
          break;
        case PhotoCaptureStatus.cancelled:
          // User-initiated cancel of the camera. Stay silent.
          break;
        case PhotoCaptureStatus.atLimit:
          _snack('You can attach up to $kMaxSosPhotos photos.');
          break;
        case PhotoCaptureStatus.uploadFailed:
          _snack('Photo upload failed. Check your connection and try again.');
          break;
        case PhotoCaptureStatus.linkFailed:
          // Storage write succeeded but the alert document update
          // failed. Surface this clearly - previously this was
          // silently swallowed and the user thought their photo
          // was attached when responders couldn't see it.
          _snack(
              'Photo uploaded but could not attach to alert. Please tap again to retry.');
          break;
      }
    } finally {
      if (mounted) setState(() => _busyPhoto = false);
    }
  }

  /// Shared permission preflight for camera and microphone.
  ///
  /// Android-safe pattern: don't trust .status alone for the
  /// permanentlyDenied determination - it returns `denied` for both
  /// "never asked" and "permanently denied". Only the return value
  /// of .request() is authoritative on Android. We treat
  /// `isGranted || isLimited` as success (limited is iOS-only but
  /// represents a real granted state for photos).
  ///
  /// Returns true if the permission is now granted (or limited).
  /// Otherwise shows the appropriate UI (settings dialog for
  /// permanent denial / restriction, snackbar for plain denial)
  /// and returns false.
  Future<bool> _ensurePermission({
    required Permission permission,
    required String label,
    required String reason,
    required String deniedSnack,
  }) async {
    PermissionStatus status = await permission.status;
    if (status.isGranted || status.isLimited) return true;

    // Anything else: ask. .request() is a no-op when already granted,
    // and on Android it returns the *current* authoritative state -
    // which is the only way to reliably detect permanentlyDenied.
    status = await permission.request();
    if (status.isGranted || status.isLimited) return true;

    if (status.isPermanentlyDenied || status.isRestricted) {
      // .isRestricted means parental controls / MDM - the user
      // can't grant from inside the app either, so route to the
      // same Settings dialog.
      await _showPermanentDenialDialog(
        permissionLabel: label,
        reason: reason,
      );
      return false;
    }

    // Plain denied - user said no this time but can be asked again
    // next tap.
    if (mounted) _snack(deniedSnack);
    return false;
  }

  Future<void> _toggleRecording() async {
    final senderId = ref.read(sosStateProvider).senderId;
    if (senderId == null) return;

    if (!_recording) {
      // Show the voice retention/handling notice the first time the user
      // taps record within this alert, before the OS microphone permission
      // prompt fires.
      final consented = await _ensureVoiceNotice();
      if (!consented) return;

      final ok = await _ensurePermission(
        permission: Permission.microphone,
        label: 'Microphone',
        reason: 'Microphone access is required to record a voice message.',
        deniedSnack: 'Microphone permission required to record.',
      );
      if (!ok) return;

      final started = await _voiceService.startRecording(senderId);
      if (!started) {
        _snack('Could not start recording. Please try again.');
        return;
      }
      if (mounted) setState(() => _recording = true);
    } else {
      final file = await _voiceService.stopRecording();
      if (mounted) setState(() => _recording = false);
      if (file != null) {
        final url = await _voiceService.uploadRecording(
          senderId: senderId,
          file: file,
        );
        if (url == null) _snack('Failed to upload voice message.');
      }
    }
  }

  /// Removes the uploaded voice message from Firebase Storage + Firestore so
  /// the user can record a fresh one. Used by the "DELETE & RE-RECORD"
  /// affordance once a recording has been saved.
  Future<void> _deleteRecording() async {
    final senderId = ref.read(sosStateProvider).senderId;
    if (senderId == null) return;
    // Stop any ongoing playback before deleting the source.
    await _voiceService.stopPlayback();
    await _voiceService.deleteVoiceRecording(senderId);
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(msg),
          backgroundColor: AppTheme.red,
          behavior: SnackBarBehavior.floating,
          // Auto-dismiss after 3 seconds. Without an explicit duration the
          // default is 4s but combined with floating + bottom margin the
          // banner would overlap the STOP SOS button on small phones; we
          // also clear any prior snack first so banners do not stack.
          duration: const Duration(seconds: 3),
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 96),
        ),
      );
  }

  // ──────────────── build ────────────────

  @override
  Widget build(BuildContext context) {
    final sos = ref.watch(sosStateProvider);
    if (!sos.isActive) {
      // SOS was deactivated elsewhere (e.g. expired) - pop after frame.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && Navigator.canPop(context)) Navigator.pop(context);
      });
    }

    final senderId = sos.senderId;
    // Seen-by count stream (only if we have a senderId).
    final seenByCount = senderId == null
        ? 0
        : ref
            .watch(myAlertSeenCountProvider(senderId))
            .valueOrNull ??
            0;

    final total = AppConstants.alertTtl.inSeconds;
    final pct = (_secondsRemaining / total).clamp(0.0, 1.0);
    final mm = (_secondsRemaining ~/ 60).toString().padLeft(2, '0');
    final ss = (_secondsRemaining % 60).toString().padLeft(2, '0');

    return Scaffold(
      backgroundColor: AppTheme.white,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            const TopBar(showOnline: true),
            LocationBar(text: sos.location ?? 'Alert active'),
            // Red progress bar
            SizedBox(
              height: 3,
              child: Stack(
                children: [
                  Container(color: const Color(0xFFF0F0F0)),
                  FractionallySizedBox(
                    widthFactor: pct,
                    child: Container(color: AppTheme.red),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  _TimerHero(
                      location: sos.location ?? 'Your district',
                      mm: mm,
                      ss: ss),
                  _ViewersRow(seenBy: seenByCount),
                  _ScenePhotosSection(
                    senderId: senderId,
                    busy: _busyPhoto,
                    onAdd: _addPhoto,
                    photoService: _photoService,
                  ),
                  _VoiceSection(
                    senderId: senderId,
                    recording: _recording,
                    voiceService: _voiceService,
                    onTap: _toggleRecording,
                    onDelete: _deleteRecording,
                  ),
                  // "Look up a vet" - opens FindVetScreen as a route so
                  // the SOS state survives the navigation. The screen
                  // shows a "SOS still active · MM:SS" breadcrumb so
                  // the user doesn't forget the alert is running.
                  //
                  // We deliberately don't fetch vet results inline on
                  // this screen - that would burn a Firestore read on
                  // every SOS regardless of whether the user cares
                  // about vets. Push-to-load tracks intent.
                  const _LookUpVetSection(),
                  // Success toast - only on fresh activations (within 10s of
                  // activatedAt). The widget is responsible for auto-hiding
                  // when the window elapses, so we render it unconditionally
                  // and let it self-manage. We pass activatedAtMillis as a
                  // Key so a new activation rebuilds it from scratch.
                  if (ref.watch(sosStateProvider).activatedAtMillis != null)
                    _SuccessToast(
                      key: ValueKey(
                        ref.watch(sosStateProvider).activatedAtMillis,
                      ),
                      activatedAtMillis:
                          ref.watch(sosStateProvider).activatedAtMillis!,
                    ),
                ],
              ),
            ),
            Container(
              color: AppTheme.white,
              padding: const EdgeInsets.fromLTRB(24, 12, 24, 16),
              child: CtaButton(
                label: 'STOP SOS',
                variant: CtaVariant.danger,
                leadingIcon: Icons.stop,
                onPressed: _stopSos,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────── Timer hero ───────────
class _TimerHero extends StatelessWidget {
  final String location;
  final String mm;
  final String ss;
  const _TimerHero(
      {required this.location, required this.mm, required this.ss});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFFF0F0F0))),
      ),
      child: Row(
        children: [
          const _PulsingDot(),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'ALERT ACTIVE',
                  style: AppTheme.barlow(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.red,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'District notified · $location',
                  overflow: TextOverflow.ellipsis,
                  style: AppTheme.barlow(
                    fontSize: 12,
                    color: AppTheme.grey,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '$mm:$ss',
                style: AppTheme.barlowCondensed(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.black,
                  letterSpacing: -0.5,
                ),
              ),
              Text(
                'remaining',
                style: AppTheme.barlow(
                  fontSize: 10,
                  color: AppTheme.subtleGrey,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PulsingDot extends StatefulWidget {
  const _PulsingDot();
  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final t = _c.value;
        final opacity = 1 - (0.6 * t);
        final scale = 1 - (0.2 * t);
        return Opacity(
          opacity: opacity,
          child: Transform.scale(
            scale: scale,
            child: Container(
              width: 8,
              height: 8,
              decoration: const BoxDecoration(
                color: AppTheme.red,
                shape: BoxShape.circle,
              ),
            ),
          ),
        );
      },
    );
  }
}

// ─────────── Viewers row ───────────
//
// Visual design notes:
//   • Mirrors the _TimerHero rhythm: chunky condensed numeric on the left,
//     small all-caps eyebrow label + muted sub-line in the middle.
//   • A subtle green "LIVE" pulse on the right signals real-time updates.
//   • No identity chips - only an aggregate count is shown. We never reveal
//     who specifically viewed the alert.
//   • Tapping the row still opens the responders sheet for the district.
//   - The row is informational only - it shows that responders are aware,
//     without exposing identities. Tapping does nothing intentionally;
//     the responder list is reachable from the Chats tab if needed.
class _ViewersRow extends StatelessWidget {
  final int seenBy;
  const _ViewersRow({required this.seenBy});

  @override
  Widget build(BuildContext context) {
    final hasViewers = seenBy > 0;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFFF0F0F0))),
      ),
      child: Row(
        children: [
          // Big count - animated swap when it changes so the user sees
          // momentum as more responders see their alert.
          SizedBox(
            width: 44,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 220),
              transitionBuilder: (child, anim) => FadeTransition(
                opacity: anim,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, 0.25),
                    end: Offset.zero,
                  ).animate(anim),
                  child: child,
                ),
              ),
              child: Text(
                '$seenBy',
                key: ValueKey<int>(seenBy),
                style: AppTheme.barlowCondensed(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  color: hasViewers ? AppTheme.black : AppTheme.fadedGrey,
                  letterSpacing: -0.5,
                  height: 1,
                ),
              ),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              hasViewers
                  ? (seenBy == 1 ? 'RESPONDER VIEWED' : 'RESPONDERS VIEWED')
                  : 'NOTIFYING DISTRICT',
              style: AppTheme.barlow(
                fontSize: 11,
                fontWeight: FontWeight.w800,
                color: hasViewers ? AppTheme.red : AppTheme.grey,
                letterSpacing: 2,
              ),
            ),
          ),
          // LIVE indicator with pulsing green dot - visual cue that the
          // count above updates in real time.
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'LIVE',
                style: AppTheme.barlow(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.successGreenDark,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(width: 6),
              const _LivePulse(),
            ],
          ),
        ],
      ),
    );
  }
}

/// Small pulsing green dot used in the viewers row to denote "live updates".
/// Independent of [_PulsingDot] (red, larger) so the two animations don't
/// conflict visually.
class _LivePulse extends StatefulWidget {
  const _LivePulse();
  @override
  State<_LivePulse> createState() => _LivePulseState();
}

class _LivePulseState extends State<_LivePulse>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final t = _c.value;
        final opacity = 0.4 + 0.6 * t;
        return Opacity(
          opacity: opacity,
          child: Container(
            width: 7,
            height: 7,
            decoration: const BoxDecoration(
              color: AppTheme.successGreenDark,
              shape: BoxShape.circle,
            ),
          ),
        );
      },
    );
  }
}

// ─────────── Scene photos ───────────
class _ScenePhotosSection extends StatelessWidget {
  final String? senderId;
  final bool busy;
  final Future<void> Function(int current) onAdd;
  final SosPhotoService photoService;
  const _ScenePhotosSection({
    required this.senderId,
    required this.busy,
    required this.onAdd,
    required this.photoService,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 16),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFFF0F0F0))),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Text(
                    'SCENE PHOTOS',
                    style: AppTheme.barlow(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.black,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Up to $kMaxSosPhotos',
                    style: AppTheme.barlow(
                      fontSize: 11,
                      color: AppTheme.subtleGrey,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              Text(
                'Helps responders',
                style: AppTheme.barlow(
                  fontSize: 11,
                  color: AppTheme.red,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (senderId == null)
            _photoPlaceholder()
          else
            StreamBuilder<List<String>>(
              stream: photoService.photoUrlsStream(senderId!),
              builder: (context, snap) {
                final urls = snap.data ?? const <String>[];
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        for (var i = 0; i < kMaxSosPhotos; i++)
                          Padding(
                            padding: EdgeInsets.only(
                                right: i == kMaxSosPhotos - 1 ? 0 : 10),
                            child: _PhotoTile(
                              url: i < urls.length ? urls[i] : null,
                              isAddSlot: i == urls.length,
                              busy: busy,
                              // Three onTap regimes:
                              //   • Filled slot  → open in-app full-screen viewer
                              //                    focused on this photo. Without
                              //                    this, the sender had no way to
                              //                    review what they uploaded. The
                              //                    viewer also exposes a delete
                              //                    affordance via the onDelete
                              //                    callback below.
                              //   • ADD slot     → trigger camera capture flow.
                              //   • Empty slot   → no-op (visual placeholder).
                              onTap: i < urls.length
                                  ? () => PhotoViewerPage.show(
                                        context,
                                        photos: urls,
                                        initialIndex: i,
                                        // Sender side: allow deletion. The
                                        // backend's /sos/detach-photo endpoint
                                        // (called via SosPhotoService.deletePhoto)
                                        // removes from Firestore + Storage; the
                                        // photoUrlsStream subscription a few lines
                                        // up will then emit a shorter list and
                                        // the deleted slot becomes the next ADD
                                        // slot automatically.
                                        onDelete: (url) async {
                                          if (senderId == null) return false;
                                          try {
                                            await photoService.deletePhoto(
                                              senderId: senderId!,
                                              url: url,
                                            );
                                            return true;
                                          } catch (_) {
                                            return false;
                                          }
                                        },
                                      )
                                  : i == urls.length
                                      ? () => onAdd(urls.length)
                                      : null,
                            ),
                          ),
                      ],
                    ),
                    // Hint line. Only shown once there's at least one
                    // photo - before that the "ADD" tile already implies
                    // the action. The hint communicates the (otherwise
                    // invisible) tap-to-delete affordance in the viewer.
                    if (urls.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(
                        'Tap a photo to view, replace or delete',
                        style: AppTheme.barlow(
                          fontSize: 11,
                          color: AppTheme.subtleGrey,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ],
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _photoPlaceholder() => Row(
        children: List.generate(kMaxSosPhotos, (i) {
          return Padding(
            padding: EdgeInsets.only(right: i == kMaxSosPhotos - 1 ? 0 : 10),
            child: const _PhotoTile(
                url: null, isAddSlot: false, busy: false, onTap: null),
          );
        }),
      );
}

class _PhotoTile extends StatelessWidget {
  final String? url;
  final bool isAddSlot;
  final bool busy;
  final VoidCallback? onTap;
  const _PhotoTile({
    required this.url,
    required this.isAddSlot,
    required this.busy,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final hasPhoto = url != null;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 76,
        height: 76,
        decoration: BoxDecoration(
          border: Border.all(
            color: AppTheme.border,
            width: 1.5,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: hasPhoto
            ? CachedNetworkImage(
                imageUrl: url!,
                fit: BoxFit.cover,
                placeholder: (_, __) => const Center(
                  child: SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppTheme.grey,
                    ),
                  ),
                ),
                errorWidget: (_, __, ___) => const Icon(
                  Icons.broken_image_outlined,
                  color: AppTheme.grey,
                  size: 20,
                ),
              )
            : isAddSlot
                ? Center(
                    child: busy
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: AppTheme.grey,
                            ),
                          )
                        : Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.photo_camera_outlined,
                                  size: 20, color: AppTheme.subtleGrey),
                              const SizedBox(height: 5),
                              Text(
                                'ADD',
                                style: AppTheme.barlow(
                                  fontSize: 9,
                                  fontWeight: FontWeight.w800,
                                  color: AppTheme.disabledGrey,
                                  letterSpacing: 1.5,
                                ),
                              ),
                            ],
                          ),
                  )
                : null,
      ),
    );
  }
}

// ─────────── Voice section ───────────
class _VoiceSection extends StatelessWidget {
  final String? senderId;
  final bool recording;
  final SosVoiceService voiceService;
  final VoidCallback onTap;
  final Future<void> Function() onDelete;

  const _VoiceSection({
    required this.senderId,
    required this.recording,
    required this.voiceService,
    required this.onTap,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'VOICE MESSAGE',
                style: AppTheme.barlow(
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.black,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'Max 60s',
                style: AppTheme.barlow(
                  fontSize: 11,
                  color: AppTheme.subtleGrey,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Branch on whether an uploaded voice note exists. While recording
          // is in progress we always show the active recorder UI even if a
          // previous URL exists - it'll be overwritten on stop+upload.
          if (senderId == null || recording)
            _RecorderTile(recording: recording, onTap: onTap)
          else
            StreamBuilder<String?>(
              stream: voiceService.voiceUrlStream(senderId!),
              builder: (context, snap) {
                final url = snap.data;
                if (url == null || url.isEmpty) {
                  return _RecorderTile(recording: false, onTap: onTap);
                }
                return _PlaybackTile(
                  url: url,
                  voiceService: voiceService,
                  onDelete: () => _confirmDelete(context),
                );
              },
            ),
        ],
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: AppTheme.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Delete voice message?',
                style: AppTheme.barlow(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.black,
                  letterSpacing: -0.3,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Responders will no longer hear this message. You can record a new one right after.',
                style: AppTheme.barlow(
                  fontSize: 13,
                  color: AppTheme.grey,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: Text(
                      'CANCEL',
                      style: AppTheme.barlow(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.grey,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  TextButton(
                    onPressed: () => Navigator.pop(ctx, true),
                    child: Text(
                      'DELETE',
                      style: AppTheme.barlow(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.red,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
    if (confirmed == true) {
      await onDelete();
    }
  }
}

/// Idle / recording state - the 58px primary-CTA tile that says either
/// "RECORD VOICE MESSAGE" (black) or "RECORDING…" (red, with the wave
/// animation). Sized and styled to match [CtaButton] so it sits visually
/// alongside GET STARTED / ACCEPT & CONTINUE / STOP SOS as a peer CTA.
class _RecorderTile extends StatelessWidget {
  final bool recording;
  final VoidCallback onTap;
  const _RecorderTile({required this.recording, required this.onTap});

  @override
  Widget build(BuildContext context) {
    // Mirrors CtaButton on purpose: 58px tall, no radius, Barlow 800 at 13px
    // with 2 letter-spacing. Idle uses the primary black/white treatment so
    // it reads as a real CTA next to GET STARTED / ACCEPT & CONTINUE rather
    // than a thin secondary outline. Recording flips to the red/white CTA
    // treatment used for STOP SOS so the active state feels visually live
    // and matches the emergency palette.
    final bg = recording ? AppTheme.red : AppTheme.black;
    final fg = AppTheme.white;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: double.infinity,
        height: 58,
        decoration: BoxDecoration(color: bg),
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (recording) ...[
              // White wave on the red bg keeps the bars legible against the
              // emergency-red recording state.
              const _RecordingWave(color: AppTheme.white),
              const SizedBox(width: 10),
              Text(
                'RECORDING…',
                style: AppTheme.barlow(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: fg,
                  letterSpacing: 2,
                ),
              ),
            ] else ...[
              Icon(Icons.mic_none_outlined, size: 14, color: fg),
              const SizedBox(width: 8),
              Text(
                'RECORD VOICE MESSAGE',
                style: AppTheme.barlow(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: fg,
                  letterSpacing: 2,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// Playback state - shown after a voice message has been uploaded. Lets the
/// sender review what they recorded with a play/pause toggle and scrub bar,
/// and offers a "DELETE & RE-RECORD" affordance just below the tile.
class _PlaybackTile extends StatefulWidget {
  final String url;
  final SosVoiceService voiceService;
  final VoidCallback onDelete;

  const _PlaybackTile({
    required this.url,
    required this.voiceService,
    required this.onDelete,
  });

  @override
  State<_PlaybackTile> createState() => _PlaybackTileState();
}

class _PlaybackTileState extends State<_PlaybackTile> {
  bool _ready = false;
  bool _failed = false;
  String? _loadedUrl;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(_PlaybackTile oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Re-load if the URL changed (new recording uploaded after redo).
    if (oldWidget.url != widget.url) {
      _ready = false;
      _failed = false;
      _load();
    }
  }

  Future<void> _load() async {
    try {
      if (_loadedUrl != widget.url) {
        // Make sure nothing else is playing before we swap sources.
        await widget.voiceService.stopPlayback();
        // Load without auto-play - we want the user to tap to start, but
        // we still want the scrub bar to know the total duration up front.
        await widget.voiceService.prepareUrl(widget.url);
        _loadedUrl = widget.url;
      }
      if (mounted) setState(() => _ready = true);
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          height: 56,
          decoration: BoxDecoration(
            color: AppTheme.white,
            border: Border.all(color: AppTheme.black, width: 1.5),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: _failed
              ? Center(
                  child: Text(
                    'COULD NOT LOAD',
                    style: AppTheme.barlow(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.grey,
                      letterSpacing: 2,
                    ),
                  ),
                )
              : !_ready
                  ? const Center(
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppTheme.black,
                        ),
                      ),
                    )
                  : StreamBuilder<PlayerState>(
                      stream: widget.voiceService.playerStateStream,
                      builder: (_, stateSnap) {
                        final isPlaying = stateSnap.data?.playing ?? false;
                        final processing = stateSnap.data?.processingState ??
                            ProcessingState.idle;
                        final isCompleted =
                            processing == ProcessingState.completed;
                        return Row(
                          children: [
                            // Play/pause button
                            InkWell(
                              onTap: () async {
                                if (isCompleted) {
                                  // Track finished - rewind to start, then play.
                                  await widget.voiceService
                                      .seek(Duration.zero);
                                  await widget.voiceService.resumePlayback();
                                } else if (isPlaying) {
                                  await widget.voiceService.pausePlayback();
                                } else {
                                  await widget.voiceService.resumePlayback();
                                }
                              },
                              child: Container(
                                width: 36,
                                height: 36,
                                decoration: const BoxDecoration(
                                  color: AppTheme.black,
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  isCompleted
                                      ? Icons.replay
                                      : (isPlaying
                                          ? Icons.pause
                                          : Icons.play_arrow),
                                  color: AppTheme.white,
                                  size: 20,
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            // Scrubber + timestamps
                            Expanded(
                              child: StreamBuilder<Duration>(
                                stream: widget.voiceService.positionStream,
                                builder: (_, posSnap) {
                                  final pos = posSnap.data ?? Duration.zero;
                                  final total = widget.voiceService.duration ??
                                      Duration.zero;
                                  final maxMs = total.inMilliseconds <= 0
                                      ? 1.0
                                      : total.inMilliseconds.toDouble();
                                  final value = pos.inMilliseconds
                                      .clamp(0, total.inMilliseconds)
                                      .toDouble();
                                  return Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                    children: [
                                      SliderTheme(
                                        data: SliderTheme.of(context).copyWith(
                                          trackHeight: 2,
                                          thumbShape:
                                              const RoundSliderThumbShape(
                                            enabledThumbRadius: 5,
                                          ),
                                          overlayShape:
                                              const RoundSliderOverlayShape(
                                            overlayRadius: 10,
                                          ),
                                          activeTrackColor: AppTheme.black,
                                          inactiveTrackColor: AppTheme.offWhite,
                                          thumbColor: AppTheme.black,
                                          overlayColor: AppTheme.black
                                              .withValues(alpha: 0.1),
                                        ),
                                        child: Slider(
                                          min: 0,
                                          max: maxMs,
                                          value: value
                                              .clamp(0, maxMs)
                                              .toDouble(),
                                          onChanged: total.inMilliseconds <= 0
                                              ? null
                                              : (v) => widget.voiceService
                                                  .seek(Duration(
                                                      milliseconds: v.toInt())),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 4),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              _fmt(pos),
                                              style: AppTheme.barlow(
                                                fontSize: 10,
                                                color: AppTheme.grey,
                                              ),
                                            ),
                                            Text(
                                              _fmt(total),
                                              style: AppTheme.barlow(
                                                fontSize: 10,
                                                color: AppTheme.grey,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  );
                                },
                              ),
                            ),
                          ],
                        );
                      },
                    ),
        ),
        const SizedBox(height: 8),
        // Delete & re-record affordance - secondary action, red for clarity.
        GestureDetector(
          onTap: widget.onDelete,
          behavior: HitTestBehavior.opaque,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(
              children: [
                const Icon(Icons.delete_outline,
                    size: 14, color: AppTheme.red),
                const SizedBox(width: 6),
                Text(
                  'DELETE & RE-RECORD',
                  style: AppTheme.barlow(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.red,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _RecordingWave extends StatefulWidget {
  /// Color of the animated bars. Defaults to red so the wave reads as
  /// "active recording" when shown standalone. The new full-bleed CTA
  /// recorder tile passes white so the bars stay legible against the red
  /// background when recording.
  const _RecordingWave({this.color = AppTheme.red});

  final Color color;

  @override
  State<_RecordingWave> createState() => _RecordingWaveState();
}

class _RecordingWaveState extends State<_RecordingWave>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const heights = [14, 20, 12, 24, 10, 18, 14];
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: List.generate(heights.length, (i) {
        final delay = i * 0.1;
        return Padding(
          padding: EdgeInsets.only(right: i == heights.length - 1 ? 0 : 3),
          child: AnimatedBuilder(
            animation: _c,
            builder: (_, __) {
              final phase = ((_c.value + delay) % 1.0);
              final scale = 0.5 + (1 - (phase - 0.5).abs() * 2) * 0.5;
              return Container(
                width: 3,
                height: heights[i] * scale,
                decoration: BoxDecoration(
                  color: widget.color,
                  borderRadius: BorderRadius.circular(2),
                ),
              );
            },
          ),
        );
      }),
    );
  }
}

// ─────────── Look up a vet ───────────
//
// Compact bordered button, 56px tall, sits below the Voice tile and
// above the STOP SOS CTA in the scrolling area. Tapping pushes
// FindVetScreen with fromActiveSos=true, which gives it a "SOS still
// active · MM:SS" breadcrumb so the navigation feels safe.
//
// Outline button on purpose - filled black or red here would compete
// visually with STOP SOS, which is the wrong tradeoff on an emergency
// screen. The outline reads as "available action" without shouting.
class _LookUpVetSection extends StatelessWidget {
  const _LookUpVetSection();

  @override
  Widget build(BuildContext context) {
    // Single bordered tile, no eyebrow header. The button label is
    // self-explanatory; the prior "NEED A VET?" header added weight to
    // an already busy active-SOS screen without saying anything the
    // tile didn't already convey.
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 16),
      child: GestureDetector(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) =>
                const FindVetScreen(fromActiveSos: true),
          ),
        ),
        behavior: HitTestBehavior.opaque,
        child: Container(
          height: 56,
          decoration: BoxDecoration(
            border: Border.all(color: AppTheme.black, width: 1.5),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              const Icon(Icons.medical_services_outlined,
                  size: 20, color: AppTheme.black),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Look up a vet near you',
                  style: AppTheme.barlow(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.black,
                    letterSpacing: -0.2,
                  ),
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded,
                  size: 14, color: AppTheme.grey),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────── Success toast ───────────
//
// Inline green confirmation banner shown briefly after a fresh SOS
// activation. Auto-hides 10 seconds after activatedAtMillis, with a fade
// for graceful disappearance. Because we key it on activatedAtMillis, a
// re-activation rebuilds it from zero and the timer restarts.
class _SuccessToast extends StatefulWidget {
  const _SuccessToast({
    super.key,
    required this.activatedAtMillis,
  });

  final int activatedAtMillis;

  @override
  State<_SuccessToast> createState() => _SuccessToastState();
}

class _SuccessToastState extends State<_SuccessToast>
    with SingleTickerProviderStateMixin {
  static const Duration _visibleFor = Duration(seconds: 10);
  static const Duration _fadeOut = Duration(milliseconds: 350);

  Timer? _hideTimer;
  late final AnimationController _fade = AnimationController(
    vsync: this,
    duration: _fadeOut,
    value: 1, // start fully visible
  );
  bool _gone = false;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now().millisecondsSinceEpoch;
    final ageMs = now - widget.activatedAtMillis;
    final remainingMs = _visibleFor.inMilliseconds - ageMs;

    if (remainingMs <= 0) {
      // Already past the window (e.g. user came back to the screen later).
      _gone = true;
      return;
    }

    _hideTimer = Timer(Duration(milliseconds: remainingMs), () async {
      if (!mounted) return;
      await _fade.reverse();
      if (!mounted) return;
      setState(() => _gone = true);
    });
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    _fade.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_gone) return const SizedBox.shrink();
    return FadeTransition(
      opacity: _fade,
      child: Container(
        color: AppTheme.successGreenDark,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Row(
          children: [
            Container(
              width: 20,
              height: 20,
              decoration: const BoxDecoration(
                color: AppTheme.white,
                shape: BoxShape.circle,
              ),
              alignment: Alignment.center,
              child: const Icon(Icons.check,
                  size: 12, color: AppTheme.successGreenDark),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'Emergency alert sent successfully!',
                style: AppTheme.barlow(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────── Stop confirm dialog ───────────
// ─────────── Media-handling notice ───────────
//
// Shown once per SOS the first time the user attempts to add a photo or
// record a voice message — once for each channel, since each requires its
// own OS permission and reveals different information. Explains:
//   • What gets captured (photo or voice clip - tailored to [kind]).
//   • Where it goes (visible to nearby responders during the alert).
//   • How long it's retained - the canonical phrasing the rest of the
//     codebase commits to: "removed when the SOS ends or after 60
//     minutes, whichever is sooner". Aligned with SosStateNotifier's
//     expiry timer (AppConstants.alertTtl) and SosPhotoService.purgeAll
//     / SosVoiceService.purgeAll being called on stop and on expiry.
//
// Two actions:
//   • CONTINUE - proceeds with the OS permission prompt + capture.
//   • NOT NOW  - closes the dialog without capturing anything.

/// Which channel this consent dialog is gating - drives the title, the
/// bullet copy and the lead icon. Keeping these distinct (vs. one combined
/// "photos & voice" notice) makes the dialog feel relevant to whatever the
/// user just tapped instead of dumping every disclosure on them at once.
enum _MediaNoticeKind { photo, voice }

class _MediaNoticeDialog extends StatelessWidget {
  const _MediaNoticeDialog({required this.kind});

  final _MediaNoticeKind kind;

  bool get _isPhoto => kind == _MediaNoticeKind.photo;

  String get _title => _isPhoto
      ? 'About scene photos'
      : 'About voice messages';

  String get _visibilityCopy => _isPhoto
      ? 'Photos you add are visible to responders in your district while '
          'the alert is active.'
      : 'Voice messages you record are audible to responders in your '
          'district while the alert is active.';

  String get _retentionCopy => _isPhoto
      ? 'Photos are not stored permanently. They are removed when this '
          'SOS ends or after 60 minutes, whichever is sooner.'
      : 'Voice messages are not stored permanently. They are removed '
          'when this SOS ends or after 60 minutes, whichever is sooner.';

  String get _safetyCopy => _isPhoto
      ? 'Add only what helps responders locate the animal - avoid '
          'capturing other people or identifying details.'
      : 'Share only what helps responders locate the animal - avoid '
          'mentioning other people or identifying details.';

  IconData get _leadIcon =>
      _isPhoto ? Icons.photo_camera_outlined : Icons.mic_none_outlined;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Eyebrow tag in the screen's red so the dialog feels of-a-piece
            // with the alert UI above it.
            Text(
              'BEFORE YOU CONTINUE',
              style: AppTheme.barlow(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                color: AppTheme.red,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              _title,
              style: AppTheme.barlow(
                fontSize: 19,
                fontWeight: FontWeight.w800,
                color: AppTheme.black,
                letterSpacing: -0.3,
                height: 1.15,
              ),
            ),
            const SizedBox(height: 14),
            _NoticeBullet(
              icon: _leadIcon,
              text: _visibilityCopy,
            ),
            const SizedBox(height: 12),
            _NoticeBullet(
              icon: Icons.timer_outlined,
              text: _retentionCopy,
            ),
            const SizedBox(height: 12),
            _NoticeBullet(
              icon: Icons.shield_outlined,
              text: _safetyCopy,
            ),
            const SizedBox(height: 22),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context, false),
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      height: 44,
                      color: AppTheme.white,
                      alignment: Alignment.center,
                      child: Text(
                        'NOT NOW',
                        style: AppTheme.barlow(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.grey,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context, true),
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      height: 44,
                      color: AppTheme.black,
                      alignment: Alignment.center,
                      child: Text(
                        'CONTINUE',
                        style: AppTheme.barlow(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.white,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _NoticeBullet extends StatelessWidget {
  const _NoticeBullet({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 16, color: AppTheme.grey),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            text,
            style: AppTheme.barlow(
              fontSize: 13,
              color: const Color(0xFF555555),
              height: 1.45,
            ),
          ),
        ),
      ],
    );
  }
}

// ─────────── Permanent denial → open Settings ───────────
//
// Shown when an OS-level permission (camera/microphone) is reported as
// permanently denied. We can't prompt again from inside the app - the user
// has to grant it from Settings. This dialog explains why we need it and
// gives a one-tap shortcut to the relevant page in Settings.

class _PermissionDeniedDialog extends StatelessWidget {
  const _PermissionDeniedDialog({
    required this.permissionLabel,
    required this.reason,
  });

  final String permissionLabel;
  final String reason;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      insetPadding: const EdgeInsets.symmetric(horizontal: 24),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '$permissionLabel access blocked',
              style: AppTheme.barlow(
                fontSize: 19,
                fontWeight: FontWeight.w800,
                color: AppTheme.black,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              '$reason\n\nPermission is currently turned off for this app. Please enable it from the app settings to continue.',
              style: AppTheme.barlow(
                fontSize: 13,
                color: const Color(0xFF555555),
                height: 1.5,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      height: 44,
                      color: AppTheme.white,
                      alignment: Alignment.center,
                      child: Text(
                        'CANCEL',
                        style: AppTheme.barlow(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.grey,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () async {
                      Navigator.pop(context);
                      await openAppSettings();
                    },
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      height: 44,
                      color: AppTheme.black,
                      alignment: Alignment.center,
                      child: Text(
                        'OPEN SETTINGS',
                        style: AppTheme.barlow(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.white,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _StopConfirmDialog extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Stop Emergency Alert?',
              style: AppTheme.barlow(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: AppTheme.black,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'This will remove the alert from all volunteer screens immediately.',
              style: AppTheme.barlow(
                fontSize: 14,
                color: const Color(0xFF555555),
                height: 1.5,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context, false),
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      height: 44,
                      color: AppTheme.white,
                      alignment: Alignment.center,
                      child: Text(
                        'KEEP ACTIVE',
                        style: AppTheme.barlow(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.grey,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context, true),
                    behavior: HitTestBehavior.opaque,
                    child: Container(
                      height: 44,
                      color: AppTheme.red,
                      alignment: Alignment.center,
                      child: Text(
                        'STOP SOS',
                        style: AppTheme.barlow(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.white,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
