# Changelog
All notable changes to this project will be documented in this file.

The format is based on Keep a Changelog (https://keepachangelog.com/en/1.1.0/)
and this project follows Semantic Versioning (https://semver.org/).

## [2.1.10+45] - 2026-04-30

### IMPORTANT: deploy order

This release ships paired client + backend changes. The backend MUST be
deployed BEFORE the client APK/IPA. If clients update first, the new
attach endpoints don't exist yet and every photo/voice upload fails. See
`DEPLOY_GUIDE.md` in the release bundle for the exact sequence.

### Fixed (backend wiring — this is what was breaking the app for users)
- **Firestore Security Rules were blocking half the app.** The deployed
  `firestore-security-rules.txt` only declared rules for `sos_alerts`,
  `admins`, and `blocked_users`. Firestore default-deny meant
  `sos_conversations`, `subscribed_users`, and `sos_feedback` were all
  inaccessible from the client - so the conversations list was empty,
  the responder count was permanently 0, the responder list was empty,
  and post-SOS feedback writes were silently rejected with
  `permission-denied` (then debugPrint'd into the void). Replaced with a
  complete rules file covering every collection the client touches.
- **Photo and voice attach to alert was blocked.** Even before the rules
  fix, `sos_alerts.write = false` meant the client's
  `set(merge:true)` write to `photo_urls` / `voice_url` was rejected.
  v44 fixed the Firestore write SHAPE but not the AUTHORISATION; v45
  fixes both by routing the URL attachment through new backend
  endpoints (see "Added" below).
- **`/api/get-district` doesn't exist on the backend.** Every call from
  `district_subscription_service.dart` returned 404. Switched to the
  real endpoint `GET /geocode/district?lat=&lng=` which the geolocator
  service already uses correctly. Response shape adjusted accordingly
  (no `success` wrapper).
- **`/delete-user-data` required Firebase Auth that mobile users don't
  have.** Mobile users aren't Firebase Auth users (they're identified by
  Firebase Installation ID); the auth middleware rejected every call
  with 401, so "Delete account" deleted local SharedPreferences but
  never the server-side data. GDPR/DPDPA right-to-erasure violation.
  Backend now drops the auth middleware on this endpoint and rate-limits
  by FID at 1 delete per hour to prevent abuse.

### Added (backend)
- **`POST /sos/attach-photo`**, **`POST /sos/detach-photo`**,
  **`POST /sos/attach-voice`**, **`POST /sos/detach-voice`** — the
  client uploads bytes to Firebase Storage as before, then asks the
  backend to attach the URL to the alert. The backend validates the URL
  prefix matches the sender's own storage path (`sos_photos/{senderId}/`
  or `sos_voice/{senderId}/`) before merging via admin SDK. This means
  even if a caller forges a `senderId` on the wire, they can only
  attach a URL that they themselves uploaded, and only to their own
  alert. Rate-limited per-FID at 1 attach per 2 seconds.
- **Daily chat wipe scheduled function** (`wipeChatsAtMidnightIST`).
  Runs at 00:00 IST every day and deletes every `sos_conversations`
  document whose `last_message_at` is before the start of the current
  day in IST. Paginated 500/batch with per-batch error tolerance so a
  single bad doc can't stall the whole sweep. Idempotent: re-running in
  the same window simply finds no further docs.
- **Storage Security Rules** (`storage.rules` — there were none in the
  repo before, so the bucket was running on whatever was in the Firebase
  Console). Allowlists `sos_photos/{senderId}/*.jpg` (`image/jpeg`,
  ≤10 MB) and `sos_voice/{senderId}/*.m4a` (`audio/mp4`, ≤5 MB);
  default-denies everything else.
- **Firestore composite indexes** (`firestore.indexes.json` — also new):
  - `sos_conversations` on `(participants array-contains, last_message_at desc)` for the conversations list query
  - `sos_alerts` on `(district asc, active asc, timestamp desc)` for the alerts-in-district stream
  Without these the client queries throw `failed-precondition` and the
  affected lists are silently empty. They've probably been missing in
  production - the repo had no `firestore.indexes.json` file.
- **Generic per-FID rate limiter** (`makeRateLimiter` in `index.js`).
  Backs the new media attach endpoints and the `delete-user-data`
  cooldown.

### Changed (client to match new backend contract)
- **`SosPhotoService` no longer writes to Firestore directly.**
  `_appendToFirestore` removed; replaced with `_attachOnBackend` which
  POSTs to `/sos/attach-photo`. Same for `deletePhoto` /
  `deleteAllPhotos` → `/sos/detach-photo`. The link-failed branch of
  `PhotoCaptureResult` now triggers when the backend rejects the
  attach (404 alert-not-found, 409 limit-reached, 429 rate-limited,
  5xx). Surface message unchanged: "Photo uploaded but could not
  attach to alert. Please tap again to retry."
- **`SosVoiceService` parallel changes.** Storage upload still goes
  client → Firebase Storage; URL attachment now goes through the
  `/sos/attach-voice` and `/sos/detach-voice` endpoints. Content-type
  fixed from `audio/m4a` to `audio/mp4` to match the new Storage rules
  (M4A is technically a subset of MP4; `audio/mp4` is the IANA-
  registered type).
- **`FeedbackService.submit` now captures sender name and mobile**
  from `ProfileService` and writes them to `sos_feedback/{docId}` as
  `sender_name` and `mobile_number`. Previously only `sender_id`
  (FID) was written, which meant admin review couldn't reach out to
  the sender without joining against `subscribed_users` by FID. Both
  fields are nullable and the submit still succeeds without them if
  profile read fails.
- **`ApiConfig`** extended with the new attach/detach endpoints plus
  the previously-inline `feedbackEmailEndpoint` and
  `geocodeDistrictEndpoint`. The entire HTTP surface is now visible
  in one file.
- **`firebase.json`** now wires Firestore rules, indexes, AND Storage
  rules in one deploy (`firebase deploy --only firestore,storage,functions`).
- **Stale `firestore-security-rules.txt`** removed in favour of the
  new `.rules` file. The CLI auto-detects the latter from
  `firebase.json`.
- **Catch-all 404 endpoint advertisement** now lists the new endpoints
  plus `/feedback` and `/app-version` which were previously omitted.

### Notes
- v45 is the first release where the photo/voice attach pipeline can
  actually succeed in production. v43 silently failed at `update()`,
  v44 silently failed at Firestore Security Rules, v45 succeeds via
  the new backend endpoints with admin-SDK writes.
- The chat wipe runs at midnight IST. If your active hours bridge
  midnight, expect conversations to disappear at 00:00 sharp. This is
  by design and meets the data-minimisation principle for sensitive
  emergency conversations.
- App Check is NOT enabled. The new attach endpoints rate-limit by
  self-asserted FID, which is sufficient given Firebase Installation
  IDs aren't easily enumerable, but App Check is the right next step.

## [2.1.10+44] - 2026-04-29

### Fixed
- **iOS camera/microphone permission "blocked" despite OS Settings showing
  permission granted.** Root cause was two-fold and fully on the iOS build
  side, not in Dart:
    1. `ios/Podfile` was missing the `permission_handler` preprocessor
       macros. Without `PERMISSION_CAMERA=1` and `PERMISSION_MICROPHONE=1`
       the plugin compiles those code paths out of the binary and returns
       `denied` instantly without ever surfacing the iOS system prompt -
       so the user has no path from inside the app to grant access. Added
       the full macro block (camera, microphone, photos, location,
       notifications enabled; everything else explicitly =0 to keep the
       binary clean and avoid spurious App Store rejections for missing
       usage descriptions).
    2. The committed `Podfile.lock` was stale - it predated the addition
       of camera/mic/storage features and did NOT contain
       `permission_handler_apple`, `record_darwin`, `image_picker_ios`,
       `firebase_storage`, or `just_audio`. So the iOS build was running
       against a pod set that had no native implementation for any of
       these plugins. Removed the stale lock so a fresh `pod install`
       on macOS regenerates it correctly. See `IOS_REBUILD.md` for the
       exact commands.
- **Android: photo/voice "uploaded" but never appeared on the alert.**
  Both `SosPhotoService._appendToFirestore` and
  `SosVoiceService._saveUrlToFirestore` used `doc.update(...)` to write
  the media URL onto `sos_alerts/{senderId}`. `update()` throws
  `not-found` if the document doesn't yet exist on the client - which
  happens any time the backend's create-alert call hasn't propagated to
  this client's Firestore cache (offline, slow network, freshly-issued
  installation ID). The error was caught and only debugPrinted, so the
  user saw the upload "complete" while the URL was lost. The bytes were
  correctly in Firebase Storage but no responder ever saw them.
  Switched both writes to `set({...}, SetOptions(merge: true))` which
  creates the document if needed and is the correct primitive for this
  pattern. Both helpers now return `bool` so the caller can react.
- **Silent failure of the photo Firestore link is now surfaced.**
  `SosPhotoService.captureAndUpload` returned `String?` which collapsed
  user-cancel, upload-fail, and link-fail into a single `null` - which
  is what hid the Android save bug for so long. Replaced with
  `PhotoCaptureResult` carrying a `PhotoCaptureStatus` enum (success,
  cancelled, atLimit, uploadFailed, linkFailed). `_addPhoto` switches
  on the status and shows a precise snackbar for each failure path,
  including a "uploaded but could not attach to alert - tap again to
  retry" message for the link-fail case.
- **Android-safe permission flow.** `Permission.camera.status` and
  `Permission.microphone.status` cannot reliably distinguish "never
  asked" from "permanently denied" on Android - the OS only returns
  `denied` or `granted` to a status read. Only the return value of
  `.request()` is authoritative for the permanentlyDenied state
  (Baseflow/flutter-permission-handler issues #336, #523, #619). The
  old preflight branched on `.status` returning `permanentlyDenied`
  before requesting, which could fire spuriously on Android in stale-
  status conditions and pop the "blocked" dialog at users who had
  granted the permission. New shared `_ensurePermission` helper:
  fast-path on `isGranted || isLimited`, otherwise call `.request()`
  unconditionally and trust its return value; treat
  `permanentlyDenied || restricted` as the settings-dialog path.
- Softened the permanent-denial dialog copy from "You previously denied
  permission" to "Permission is currently turned off for this app" -
  the old copy was wrong any time the dialog fired without a prior
  user denial (e.g. fresh install where Settings has the toggle off
  but the user never saw a prompt).

### Notes
- iOS build: AFTER pulling these changes you must run `pod install` on
  a Mac before the iOS app will pick up the new permission_handler
  macros. See `IOS_REBUILD.md` in the repo root for exact commands.
  The macros bake into the compiled pod at native build time - a
  plain `flutter run` will not regenerate them.

## [2.1.10+43] - 2026-04-28

### Fixed
- Profile tab: UPDATE PROFILE now enables for ANY valid change to
  either field. Previously, a user reported they couldn't save a
  mobile-only edit unless they also changed the name. The rule was
  restated as two explicit predicates (`nameChanged`, `mobileChanged`)
  so each field's change is detected independently and either is
  sufficient to enable the button. Both fields still have to be
  non-empty and the mobile still has to pass
  `isValidIndianMobile`. Mobile equality compares
  `normalizeIndianMobile(typed)` against `normalizeIndianMobile(saved)`
  so any historical "+91" prefix on the stored value doesn't make a
  legitimate change look identical.

### Changed
- Share-app message: em-dash replaced with a hyphen ("Response Team -
  volunteers..." instead of "Response Team — volunteers..."). Looks
  cleaner across messaging apps that don't render em-dashes well.

### Notes
- Footer version bumped to `v2.1.10`.
- No behavioural change to the onboarding profile-create flow or to
  any other screen.

## [2.1.9+42] - 2026-04-28

### Added
- Help -> "Share the app" row. Tapping it opens the native OS share
  sheet (UIActivityViewController on iOS, Intent.ACTION_SEND on
  Android) pre-filled with a short pitch and a single cross-platform
  link to https://rapid-response.in.
  - rapid-response.in is the canonical landing page that surfaces
    both Play Store and App Store buttons, so a Pixel user sharing
    with an iPhone friend (or vice versa) Just Works - the link
    doesn't dump them on the wrong store.
  - Bonus: WhatsApp / iMessage / Slack will show the website's OG
    preview card instead of a generic store-link card, so the share
    looks branded.
  - Implementation: extended `_HelpSection` to support either a
    `builder` (push a sub-page, the existing pattern) OR an `action`
    callback (run in place, no navigation). Added `share_plus: ^10.1.4`
    to pubspec. Trailing icon on the share row is `Icons.ios_share`
    instead of the chevron, so users get a hint that it's an action,
    not a navigation.

### Notes
- Footer version bumped to `v2.1.9`.
- Existing rows ("How to use the app", "Contact us") are unchanged.
- The share message text and link are hard-coded in
  `help_screen.dart::_shareApp`. To tweak copy or add UTM tags, edit
  that one method.

## [2.1.8+41] - 2026-04-28

### Added
- Force-update flow is now actually wired up. `ForceUpdateService` and
  `ForceUpdateDialog` were already implemented but never called from
  anywhere - the check has been added to `_RRTAppState`:
  - On first frame after launch (`addPostFrameCallback`), so
    `navigatorKey.currentContext` exists when `showDialog` runs.
  - On `AppLifecycleState.resumed`, so a phone that sat in the
    background across a release that bumped `min_version` gets the
    prompt without needing a full cold start.
  - Guarded by a `_updateDialogShown` flag so overlapping lifecycle
    events don't stack two dialogs.
  - Fails open: any network/parse error in `checkForUpdate()` returns
    null, the dialog is skipped, and the user proceeds normally.
- Footer version bumped to `v2.1.8`.

### Notes
- The dialog itself is unchanged from what was already in the repo:
  full-screen blocking (`PopScope(canPop: false)` +
  `barrierDismissible: false`), no "Later" button, "Update Now" opens
  the Play Store / App Store.
- Server contract: `GET ${baseUrl}/app-version` -> `{ min_version,
  current_version, play_store_url, app_store_url,
  force_update_message }`. To force everyone below 2.1.8 to update,
  set `min_version: "2.1.8"` server-side.

## [2.1.7+40] - 2026-04-28

### Fixed
- "How to use the app" and "Contact us" sub-pages of the Help tab now
  use the EXACT same chrome as the Help index ("Need Help?"):
  - TopBar(showOnline: true) - paw + "Rapid Response Team" + online
    dot, NO back arrow. The previous fix had `onBack` AND `showLogo`
    together, which jammed the back-arrow and paw mark on top of each
    other. Exit is via the bottom nav (any tab) or the OS back gesture.
  - Body wrapped in SafeArea(bottom: false) so the status bar doesn't
    overlap the TopBar. Sub-pages don't inherit MainNavigationScreen's
    SafeArea since they're full-screen routes.
  - SingleChildScrollView with horizontal padding 24, then a 24px
    spacer before the eyebrow numeral - same vertical rhythm as the
    index. The previous fix had no top spacer, so the headline kissed
    the TopBar.
  - Step rows in How-To: padding switched to vertical-only (parent
    scroll view now owns the horizontal gutter, so a row that paded 24
    on top of a 24-padded parent was double-padded to 48).

### Notes
- BottomNav behaviour from 2.1.6+39 unchanged: tapping any other tab
  pops back to the Help index and switches the main scaffold via
  activeTabIndexProvider.

## [2.1.6+39] - 2026-04-28

### Fixed
- "How to use the app" and "Contact us" sub-pages of the Help tab now
  match the rest of the app's chrome:
  - TopBar shows the paw mark + "Rapid Response Team" title alongside
    the back arrow (`showLogo: true`). Previously it was just a back
    arrow with the title, which made the screens feel orphaned.
  - BottomNav is pinned at the bottom of both screens. Tapping any tab
    pops back to the Help index and switches the main scaffold via the
    existing `activeTabIndexProvider` listener in
    `MainNavigationScreen` - no navigator-architecture refactor.
- Chat screen phone-icon: when the dialer-tap fails, the snackbar now
  reflects the actual privacy rule. If the current user is themselves
  the sender of an active SOS, the message reads "Only responders can
  call you while your alert is active." (clarifies the rule is
  one-directional). For everyone else (responders after the alert
  ended, or no active alert), the wording is unchanged.

### Notes
- `HelpHowToScreen` migrated from `StatelessWidget` to
  `ConsumerWidget`; `HelpContactScreen` migrated from `StatefulWidget`
  to `ConsumerStatefulWidget`. Form behaviour and validation are
  unchanged.
- Footer version string bumped to `v2.1.6` on onboarding and onboard
  profile screens.

## [2.1.5+38] - 2026-04-28

### Changed
- SOS button: mandatory-description check now runs the instant the
  user presses, not after the 3-second hold completes. If the
  description field is empty, the "Please describe the emergency
  first." snackbar appears immediately and the hold animation doesn't
  begin - the user no longer waits 3s only to be told they forgot to
  type. Implemented via a new optional `onHoldStart` callback on
  `SosButton`; returning `false` aborts the press cleanly. Original
  check inside `_onHoldComplete` is kept as a defensive belt-and-
  braces guard. Async checks (rate-limit cooldown, location, profile
  lookup) still run after the hold - they're much rarer.
- Footer version string bumped to `v2.1.5` on onboarding and onboard
  profile screens.

## [2.1.4+37] - 2026-04-28

### Changed
- Profile tab is now editable in place. Name and Mobile Number on the
  Profile screen are TextFields, and tapping UPDATE PROFILE saves
  inline (snackbar confirmation, no navigation). Previously the screen
  was read-only and UPDATE PROFILE pushed a separate edit form, which
  felt redundant — there's nothing to "view" on a profile that you
  yourself entered. The CTA stays disabled until the user has made a
  real change AND the values pass the same validation as onboarding
  (non-empty name, valid 10-digit Indian mobile).

### Notes
- `ProfileCreateScreen` is unchanged and still used by the onboarding
  flow (`terms_and_conditions_screen` → `ProfileCreateScreen(isEdit:
  false)`). Only the in-app Profile tab edit path is consolidated.
- Footer version string bumped to `v2.1.4` on onboarding and onboard
  profile screens.

## [2.1.3+36] - 2026-04-28

### Fixed
- Profile edit screen: NAME and MOBILE NUMBER fields are now editable.
  The outer `GestureDetector` used for "tap-outside-to-dismiss-keyboard"
  was using `HitTestBehavior.opaque`, which let it win the gesture arena
  over the child `TextField` tap recognizers. Tapping a field fired
  `unfocus()` instead of focusing it, so the keyboard never opened and
  the fields appeared frozen — superseding the cursor-position patch in
  2.1.2+35, which addressed a different symptom of the same root cause.
  Switched to `HitTestBehavior.translucent` so child taps are received
  first, and to `FocusManager.instance.primaryFocus?.unfocus()` for
  null-safety on the first frame before prefill completes.
- Footer version string on the onboarding and profile-edit screens now
  reads `v2.1.3` (was stuck on `v2.1.0`).

## [2.1.2+35] - 2026-04-27

### Fixed
- Profile edit screen: cursor now lands at the end of the prefilled name
  and mobile values when "UPDATE PROFILE" is tapped. Previously the
  controller was set via `.text =`, which places the caret at offset 0;
  on some Android IMEs that made the cursor effectively invisible and
  the field appeared frozen for editing. Switched to setting the full
  `TextEditingValue` with `TextSelection.collapsed(offset: text.length)`.

### Changed
- Contact form (Help → Contact us) now requires an email address. SEND
  button stays disabled until both email and message are filled.
- Contact form: email field is now strictly format-validated at submit
  time. Inputs like `asdf`, `name@gmail` (missing TLD), or `name@gmail.`
  are rejected with an inline red error that focuses the field.
- Contact form: added a "Did you mean?" suggestion line below the email
  field that detects common domain typos for the top providers used in
  India (Gmail, Yahoo, Outlook/Hotmail/Live, iCloud, Rediffmail,
  ProtonMail, Zoho, AOL, GMX, Yandex, Mail.com, plus a couple of Indian
  ISP domains). Tapping the suggestion applies it.
- Contact form: tapping SEND with a valid-format email now shows a
  confirm popup ("Is this email correct?") that displays the address
  back to the user before submitting. Styling mirrors the existing
  `_DeleteConfirmDialog` on the profile screen — zero-radius, Barlow
  800 heading, side-by-side EDIT EMAIL (grey) / YES, SEND (red)
  buttons. Catches typos that aren't in the heuristic map.
- `ProfileService.saveProfile` now normalizes the mobile number at the
  service boundary via a new `normalizeIndianMobile` helper (strips
  non-digits, removes leading `0`, `91`, or `091` country prefix). Name
  is trimmed. Every existing call site benefits without changes; future
  backend dedup logic will receive a clean canonical phone string.
- `ProfileService.isValidIndianMobile` now uses the same normalize
  helper, so form validation, storage, and any future backend payloads
  agree on what "the same number" means. Pasting `+91 94973-44991` is
  now treated as equivalent to typing `9497344991`.

### Redesigned
- Help screen replaced the previous 2-tab "How To Use | Contact Us"
  layout with a magazine-style index page. The screen now opens to a
  big editorial headline ("Need / Help?") followed by numbered topic
  rows ("01 How to use the app", "02 Contact us") that push dedicated
  detail screens. Adding a future topic is appending one row to a list
  and creating a sibling screen — no layout reflow needed. Visual
  vocabulary reuses the existing app tokens exclusively (Barlow
  Condensed 64pt headlines, red kicker numerals, 12% black hairline
  rules, AppTheme colors only). Two new files:
  `lib/screens/help_how_to_screen.dart` (the 6 steps, content
  identical to the previous tab) and `lib/screens/help_contact_screen.dart`
  (the contact form with all of the above fixes integrated).

## [2.1.0+33] - 2026-04-26
Reconciliation note: internal pre-release versions tracked through 2.2.x
were never shipped to either store. The last public release on Play and
TestFlight was 2.0.1 (versionCode 32 / iOS build 4). This release ships
the accumulated improvements as 2.1.0+33 — versionCode 33 clears the Play
Store monotonic-increase rule (must exceed 32) and 2.1.0 is a minor bump
from 2.0.1 reflecting the scope of what's in this build. iOS CFBundleVersion
33 is fine for App Store Connect since CFBundleShortVersionString has
moved up too.

### Changed
- Photo and voice consent are now gated independently within a single SOS.
  Previously a single `_mediaNoticeAcknowledged` flag covered both channels:
  tapping the photo affordance first meant the voice tap never showed any
  notice at all. Split into `_photoNoticeAcknowledged` /
  `_voiceNoticeAcknowledged` with paired `_ensurePhotoNotice()` /
  `_ensureVoiceNotice()` helpers, and made `_MediaNoticeDialog` accept a
  `_MediaNoticeKind` so the title, lead icon and bullet copy are tailored
  to whichever channel the user just tapped (photo vs voice). Each channel
  now always prompts on first use - matching the photo-capture pattern the
  user expected to also see for voice.
- "RECORD VOICE MESSAGE" tile re-skinned to match `CtaButton`: full-width,
  58px tall, primary black/white CTA when idle (so it reads as a peer of
  GET STARTED / ACCEPT & CONTINUE rather than a thin outlined secondary)
  and red/white CTA when recording (mirroring the STOP SOS treatment, and
  keeping the audio wave legible against the red background via a new
  `color` param on `_RecordingWave`).
- Post-stop feedback prompt is now delayed by ~2.2s after the user taps
  STOP SOS. Previously the FeedbackScreen pushed immediately, which made
  the green "Emergency alert stopped" snackbar feel skipped and left some
  users unsure whether the SOS had actually ended. The delay lets the home
  screen settle into its idle state and the confirmation toast register
  before asking the user to reflect. Wrapped in `unawaited(Future.delayed)`
  with a `rootNav.mounted` guard so the spinner finalisation isn't blocked
  and a backgrounded app doesn't try to push onto a dead navigator.

### Includes everything from internal 2.2.1–2.2.5
(See entries below — those internal-version-numbered sections preserve the
historical record of what was built between the 2.0.1 store release and
this 2.1.0 store release.)

## [internal 2.2.5+16]
### Changed
- Photo/voice consent split + record CTA + delayed feedback (now folded
  into 2.1.0+33 above; this section retained for internal history only).

## [2.2.4+15]
### Fixed
- Responders bottom sheet was still clipping the last name behind the
  system nav bar even after the v2.2.3 fix. The previous fix added bottom
  padding to the inner ListView, but the sheet's outer Container was
  itself flush to the screen edge — so the last list item rendered
  *correctly* relative to the sheet but the sheet's bottom was hidden
  under the OS nav bar. Wrapped the sheet contents in a
  `SafeArea(top: false)` so the entire sheet now sits above the system
  gesture/nav bar regardless of device. The redundant
  `viewPadding.bottom` inside the ListView was dropped to avoid double
  padding.

## [2.2.3+14]
### Fixed
- Red dot beside the ALERTS tab now reflects unread state, not just
  "you're somewhere else." It only appears when there's at least one
  alert in the active list whose `{sender_id}:{timestamp}` key is not
  in `seenAlertCacheProvider`. Backed by a new `hasUnseenAlertsProvider`
  watched by `MainNavigationScreen` and passed into `BottomNav`. Clears
  the moment the user opens the Alerts tab (mark-seen → cache update →
  derived provider re-emits false).
- Pressing Enter on the emergency description field used to insert a
  newline. Now follows mobile-form best practice: `textInputAction:
  TextInputAction.done`, an `onSubmitted` that explicitly unfocuses the
  field, and a `FilteringTextInputFormatter.deny(RegExp(r'[\r\n]'))`
  belt-and-braces guard for keyboards that still inject newlines on
  multi-line fields. Visual line-wrapping (maxLines: 2) is preserved
  for long descriptions.
- Responders bottom sheet was clipping the last item behind the system
  nav/gesture bar. Sheet now uses up to 90% of screen height (was 82%)
  minus the top safe-area inset, and the inner ListView reserves
  `media.viewPadding.bottom` of bottom padding so the last responder
  always clears the home indicator.

## [2.2.2+13]
### Changed
- Phone icon in the chat header now appears only while the linked SOS
  alert is actively in flight. Once the alert ends or expires (live
  Firestore stream), the icon disappears in real time. Previously the
  icon was rendered unconditionally and only the dial-tap was gated —
  this aligns the UI with the actual privacy contract: the number is
  only available during the alert window. Single source of truth shared
  with the body's input gating; header is hidden-by-default during
  loading to avoid briefly exposing a dial-tap on a stale state.

## [2.2.1+12]
### Fixed
- Phone icon in chat header was a no-op — tapping it only showed the
  "phone number is only available while the alert is active" snackbar,
  even when the alert was active. It now actually fetches
  `sos_alerts/{otherFid}.userInfo.mobile_number` and opens the device
  dialer (`tel:` scheme) with the number pre-populated. Privacy gate
  preserved: if the alert doc is missing, has no number, or is past
  the 60-minute TTL, the same snackbar fires. Sender-tapping-volunteer
  also falls through to the snackbar (volunteers don't expose phone
  numbers via this icon).

## [2.2.0+11]
### Added
- Media-handling consent dialog. Shown once per SOS, the first time the
  user attempts to add a photo or record a voice message. Explains
  visibility (responders in district, while alert is active), retention
  ("not stored permanently — removed when the SOS ends or after 60 minutes,
  whichever is sooner"), and a privacy nudge ("avoid capturing other people
  or identifying details"). Two actions: NOT NOW (cancel) / CONTINUE
  (proceeds to OS permission prompt). Acknowledgement persists for the
  lifetime of the alert; new alerts re-prompt.
- Permission handling for camera + microphone with proper recovery from
  permanent denial. Pre-flight uses permission_handler to detect denied /
  permanently-denied states and surfaces a clear dialog with an OPEN
  SETTINGS button instead of letting image_picker / record fail silently.

### Changed
- Media retention is now actually enforced. Added static `purgeAll` methods
  on `SosPhotoService` and `SosVoiceService` that delete all uploaded
  bytes for a given senderId from Firebase Storage. Wired into three
  lifecycle endpoints:
    1. User-initiated stop (`_stopSos` in active_sos_screen).
    2. 60-minute auto-expiry (`_scheduleExpiry` Timer in sosStateProvider).
    3. Stale-alert discovery on app cold start (`_loadFromStorage`).
  Previously the deletion methods existed but were never invoked outside
  the manual "DELETE & RE-RECORD" action, so media lingered in Storage
  indefinitely. The consent-dialog claim is now backed by code.
- Privacy policy updated to match: removed inaccurate "Photos, videos, or
  media files" bullet under "Information We Do NOT Collect", and added an
  explicit retention clause under §4.2 covering scene photos and voice
  messages. Note: the hosted privacy policy at
  askrapidresponseteam-cloud.github.io/rrt-privacy-policy is a separate
  repo and needs a parallel commit there.

## [2.1.0+10]
### Added
- Post-SOS feedback popup. After the sender confirms STOP SOS and the
  backend acknowledges, a feedback screen pushes onto the root navigator.
  Mirrors the editorial design from the redesign mock — black header with
  red accent shapes, "SOS ENDED" eyebrow, "How did it go?" hero, five
  red-numbered sections (overall rating, did help arrive, response speed,
  outcome, free comment), black submit CTA, "Skip for now" link, and a
  "THANK YOU." success state that auto-dismisses after 2 seconds.
- Dynamic question logic: response-speed only appears when help arrived,
  outcome options are filtered by Q2 (e.g. rescue/resolved options hidden
  when help didn't arrive). Sections fade + slide in as predecessors are
  answered. Submit enables only once required visible questions are set;
  Q3 stays optional even when shown.
- Per-alert idempotency. Feedback is keyed by `{senderId}_{activatedAtMillis}`
  and tracked in SharedPreferences (`sos_feedback_seen_v1`). Skipping the
  dialog also marks the alert handled — no re-prompts.
- Feedback writes directly to Firestore at `sos_feedback/{key}` so no new
  backend endpoint is required.
- Triggered only on user-initiated stop, never on the 90-min auto-expiry.

### Fixed
- Terms & Conditions heading was visually centered because the outer
  `SafeArea > Column` had no `crossAxisAlignment`, defaulting to centered
  layout. Added `CrossAxisAlignment.start` so the heading hugs the same
  24px left edge as Profile screen's "Your Profile" hero.

## [2.0.6+9]
### Fixed
- Tapping a scene-photo thumbnail on the Active SOS screen (sender side)
  did nothing. The tile only had a tap handler for the ADD slot, so the
  sender had no way to review the photos they'd uploaded. Filled photo
  slots now open the same in-app full-screen viewer used on the Alerts
  screen — pinch to zoom, swipe between photos, X or back to close.

### Changed
- Lifted the photo viewer out of `alerts_screen.dart` into a shared
  `lib/widgets/photo_viewer.dart` so both the Active SOS screen and the
  Alerts screen share a single source of truth.
- Active SOS scene-photo thumbnails now use `CachedNetworkImage` (matching
  the Alerts screen) so they don't re-fetch on every Firestore stream
  emission.

## [2.0.5+8]
### Fixed
- View count on the Active SOS screen now reliably ticks up when responders
  open their Alerts tab. Previously, mark-seen only fired when a volunteer
  TAPPED the Alerts tab — if they were already on the tab when the alert
  arrived (or were deep-linked there from a notification), the alert was
  visible but never counted. The mark-seen flow now triggers from three
  paths: tab tap, external tab switch, and new alerts arriving while the
  Alerts tab is in the foreground. The seen-cache prevents duplicate POSTs.

### Changed
- Replaced the four hardcoded `T R H P` decorative chips on the Active SOS
  viewer row with an in-style count-led layout: chunky condensed number on
  the left (animated swap when it ticks), red "RESPONDERS VIEWING" eyebrow,
  muted sub-line, and a small green "LIVE" pulse on the right. Singular form
  ("RESPONDER VIEWING") for count of 1. No identity is shown — just the
  aggregate count.
- Voice message section on the Active SOS screen now supports playback +
  re-record. After recording, the sender sees a play/pause button with a
  scrub bar (seekable) inside the same 56px tile, plus a red
  "DELETE & RE-RECORD" affordance below with a confirm dialog. Idle and
  recording states unchanged.
- Added `prepareUrl`, `resumePlayback`, `pausePlayback`, and `seek` to
  `SosVoiceService` to support the new playback UI without coarse
  setUrl→play→stop hacks.

### Removed
- Removed the dead `_heartbeat` method and its now-unused
  `district_subscription_service` import from `MainNavigationScreen`.
  Online/offline status tracking is gone, so the heartbeat had no purpose.
- Removed an unused `location_provider` import from `ActiveSOSScreen`.

## [2.0.4+7]
### Fixed
- On SOS activation, the app was pushing a standalone ActiveSOSScreen on
  top of the navigation stack, hiding the bottom nav bar. Pressing back
  revealed a second copy of the screen rendered inline inside the home
  tab (with the nav bar). The push has been removed - activation now
  just flips sosStateProvider.isActive and the home tab's build() method
  renders ActiveSOSScreen inline, keeping the bottom nav visible the
  whole time.
- The "Emergency alert sent successfully!" green banner is now a proper
  transient toast: it appears on fresh activation, stays for 10 seconds,
  fades out, and removes itself from the layout. It's keyed on
  activatedAtMillis so a new alert restarts the timer cleanly, and it
  won't reappear if the user navigates away and comes back later.

## [2.0.3+6]
### Removed
- (Reverted in 2.0.4+7) Removed the inline green banner entirely - that
  was the wrong fix. The banner is correct, it just needed to auto-hide
  and the activation flow needed to stop pushing a duplicate screen.

## [2.0.2+5]
### Fixed
- Tapping a photo or voice note on the Alerts screen used to open the file
  in the system browser, which on Android downloaded the JPEG/M4A to
  /Download instead of showing it. Photos now open in a full-screen in-app
  viewer (pinch-to-zoom, swipe between photos, X to close) and voice notes
  play in an in-app bottom sheet (just_audio player with play/pause +
  scrubbable progress) - no browser, no downloads. Thumbnails now use
  CachedNetworkImage so they don't refetch on rebuild.

## [1.1.1+2]
### Fixed
- SOS send failed with backend error "Invalid sos_type". The home screen now
  posts `sos_type: 'sos_alert'` (matching the cloud function contract) instead
  of `'emergency'`, and includes the same userInfo payload as the reference
  implementation.
- STOP SOS only cleared local state and never notified the backend, leaving
  the alert active for other district volunteers. The active-SOS screen now
  fetches a fresh GPS fix and posts `sos_type: 'stop'` with the user's
  district + profile info, mirroring the working implementation.
- The Chats screen district strip is now tappable when subscribers exist,
  opening a "Responders in <District>" sheet that lists each subscriber by
  name (streamed live from `subscribed_users`).
- Onboarding profile screen (3 OF 3) header now shows the paw logo + green
  online dot alongside the back arrow + "3 OF 3" badge so it visually matches
  the post-onboarding home / chats / profile tabs. Edit-mode profile entry
  (from settings) keeps the simpler back-arrow header.
- Replaced every em dash and en dash across the project (Dart sources, MD,
  YAML) with a plain hyphen, including comments, code, and user-facing
  strings. Empty profile placeholders ('-') and notice copy ("... SOS - you'll
  be prompted next.") read with hyphens now.

## [1.1.0+1]
### Added 
- Compliance fixes

## [0.1.0] - 2026-02-01
### Added
- Initial app release.
