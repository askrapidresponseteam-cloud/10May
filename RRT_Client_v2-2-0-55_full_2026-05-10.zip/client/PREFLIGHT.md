# preflight.sh — release gate for RRT

Run before every release build:

```
./preflight.sh
```

Exits **0** if all green, **1** if any blocker, **2** if only warnings.

The script runs ~30 checks across six categories:

1. **Toolchain** — flutter, dart, cocoapods present
2. **Version** — pubspec version is set, and changed since last git tag
3. **Static analysis** — `flutter analyze` clean, `dart format` clean, tests pass
4. **iOS build readiness** — Podfile macros present for every Dart `Permission.*` you use; Podfile.lock contains the iOS pod for every plugin in pubspec; Info.plist has the matching usage description for every Dart permission
5. **Android build readiness** — AndroidManifest declares every permission Dart requests; signing config present
6. **Regression smells** — Firestore `.update()` calls (prefer `set(merge:true)`); single-line catch blocks that only `debugPrint`; stray `print()`; hardcoded secrets; TODO/FIXME markers

## Why this script exists

Each blocker check corresponds to a real bug that has shipped to users. The iOS-pod-missing check, in particular, would have prevented the v2.1.10.43 disaster where `Podfile.lock` was stale and camera/mic permission prompts never fired on iOS at all.

## Silencing false positives

A `.update()` call that you've reviewed and confirmed is safe (e.g. delete paths where the doc is known to exist) can be silenced by adding a comment on the same line:

```dart
.update({'voice_url': FieldValue.delete()}); // preflight: ok
```

Don't silence anything until you've actually verified the call is safe. The whole point is the friction.

## Suggested git hook

Drop this in `.git/hooks/pre-push` to catch problems before they leave your machine:

```sh
#!/bin/sh
exec ./preflight.sh
```

`chmod +x .git/hooks/pre-push` and you're done.

## CI integration

In `.github/workflows/ci.yaml` (or your equivalent):

```yaml
- name: Preflight
  run: ./preflight.sh
```

Configure the job to fail on exit codes 1 *and* 2 if you want strict mode (recommended for `main` and release branches), or only 1 for feature branches.
