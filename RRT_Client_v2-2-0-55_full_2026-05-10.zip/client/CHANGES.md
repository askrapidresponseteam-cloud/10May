# RRT Client v45 - patched

This is the v45 codebase with the following fixes applied. After unzipping,
run:

```bash
flutter clean
flutter pub get
```

The `pubspec.yaml` change requires a fresh `pub get` to pick up the new
`in_app_update` package (and remove the old `upgrader` package).

---

## ⚠️ Version reconciliation — READ BEFORE BUILDING

The codebase that produced this patch was at `2.1.10+45`. As of this
zip, the live production app on Play is `2.1.13+48`. That means three
builds (46, 47, 48) were shipped after the snapshot used here.

**`pubspec.yaml` in this zip has been bumped to `2.1.14+49`** to clear
Play's monotonicity check.

But that doesn't address the source code drift. Before you build:

1. Check git history for whatever was changed between `2.1.10+45` and
   `2.1.13+48`. If those three builds had real changes, building from
   this zip will silently revert them.
2. Three options:
   - Apply the 11 modified files in this zip on top of your current
     `2.1.13+48` source (safest, but more work).
   - Confirm 46/47/48 were cosmetic-only and build straight from here.
   - Build from here and accept the regression (risky).

If you don't know the answer, ask whoever shipped 46/47/48.

---

## Files changed (10 modified, 1 added)

### `pubspec.yaml`
- Removed `upgrader: ^11.3.0` (was failing 100% in production).
- Added `in_app_update: ^4.2.3` (Google's official Play Core wrapper).

### `lib/main.dart`
- AppInfoService primed at startup so SOS payloads carry the real build
  version, not the hardcoded `1.0.0`.
- Force-update first-check now runs after a 4-second delay rather than
  from `addPostFrameCallback`. The previous timing fired while the
  FutureBuilder loading-spinner was still up, and the dialog tried to
  attach to a context that got replaced when init resolved.
- Added observable `debugPrint` lines on every entry to
  `_checkForceUpdate` and at every step of the service. Future
  "is the check even running?" questions are now answerable from
  `flutter logs`.

### `lib/core/services/force_update_service.dart` (rewrite)
- Dropped the `upgrader` package entirely.
- iOS now hits Apple's iTunes Lookup endpoint directly via `http.get`,
  with `country=IN` hardcoded (the previous setup used the device's
  system locale, which for non-IN regions returned no results - a
  major contributor to the 100% failure rate).
- Android uses `InAppUpdate.checkForUpdate()` from the
  `in_app_update` package. The "Update Now" button on the dialog now
  calls `InAppUpdate.performImmediateUpdate()`, which triggers
  Google's native full-screen download+install flow in-app - no
  Play Store bounce.
- Added `canUpdateInApp` flag on the result so the dialog can pick
  the right path per platform.
- Separate `_iosBundleId` and `_androidPackage` constants. Previously
  both store paths used the same `_androidPackage` constant, which
  worked by coincidence (both IDs are `com.rrt.sos`) but would
  silently break iOS detection if they ever diverged.
- `debugPrint` at every step.

### `lib/core/services/app_info_service.dart` (new)
- Single source of truth for the running build's version. Lazily
  primed once at startup, returns `version+buildNumber` (matches
  pubspec format like `2.1.10+45`). Falls back to `'unknown'` on
  any failure. Replaces three hardcoded `'1.0.0'` literals.

### `lib/core/services/sos_service.dart`
- Reads `AppInfoService.versionString` instead of hardcoded `'1.0.0'`.

### `lib/core/services/sos_voice_service.dart`
- Local recording filenames are now unique per session
  (`sos_voice_${senderId}_${nowMs}.m4a`) rather than reusing a single
  path. Fixes a race where a record-cancel-record cycle could
  overwrite a file that was still being read by an in-flight upload.
- New `_isRecording` early-return prevents overlapping starts on the
  same service instance.
- Time-based stale-file sweep on every `startRecording` deletes any
  `sos_voice_*.m4a` older than 5 minutes. 5-min cushion is well past
  any legitimate upload (60s recording + slow upload), so the sweep
  never kills a file in use.

### `lib/core/providers/alerts_provider.dart`
- Removed the client-side stale-alert filter that used
  `DateTime.now() - timestamp > 60min`. Device clocks are
  user-mutable; a phone with a wrong-set clock would either hide
  live emergencies or display expired ones forever. The server's
  `active==true` flag is now the single source of truth - the
  60-min Cloud Task auto-expire and hourly fallback both flip it.

### `lib/screens/home_screen.dart`
- Reads `AppInfoService.versionString` instead of hardcoded `'1.0.0'`.

### `lib/screens/active_sos_screen.dart`
- Reads `AppInfoService.versionString` instead of hardcoded `'1.0.0'`.

### `lib/screens/help_screen.dart`
- Rewrote the "Share the app" message to match the website's voice:
  lowercase, hyphens (no em-dashes), and capacity-not-delivery
  framing. The previous copy ("volunteers get notified when someone
  nearby raises an SOS") read as a service promise; the website's
  own clarity section explicitly says "we aren't a guarantee."
- New copy: "rapid response is a peer network for people who already
  show up for animals - feeders, pet parents, fosterers, rescuers,
  vets. district by district. the more of us who're on it, the
  easier it gets to find each other when something comes up."
- Subject line widened from "Rapid Response Team" to
  "Rapid Response - animal emergency network".

### `lib/widgets/force_update_dialog.dart`
- "Update Now" button now branches on
  `ForceUpdateInfo.canUpdateInApp`. Android uses Google's native
  immediate-update flow (in-app, full-screen, downloads + installs,
  relaunches automatically). iOS continues to deep-link to the App
  Store as before (Apple has no equivalent native flow).

---

## Audit issues addressed

| # | Issue | Status |
|---|---|---|
|  1 | Photos/voice from prior SOS leaked into new SOS | ✅ in `index.js` |
|  2 | Media not deleted from Storage on SOS end | ✅ in `index.js` |
|  3 | Daily 00:00 IST cleanup sweep | ✅ in `index.js` |
|  4 | Hourly fallback running every 12h instead of 1h | ✅ in `index.js` |
|  5 | SOS trigger order race (FCM before Firestore) | ✅ in `index.js` |
|  6 | Photo attach TOCTOU race (3-photo cap bypassable) | ✅ in `index.js` |
|  7 | Detach blocked by attach rate-limiter | ✅ in `index.js` |
|  8 | Chat messages array unbounded | ✅ in `index.js` |
|  9 | mark-seen batch fails on missing doc | ✅ in `index.js` |
| 10 | Auto-expire / hourly fallback don't send "Resolved" FCM | ✅ in `index.js` |
| 11 | delete-user-data incomplete | ✅ in `index.js` |
| 12 | Client-clock stale-alert filter | ✅ in this zip |
| 13 | Voice recording temp filename collision | ✅ in this zip |
| 14 | Hardcoded `appVersion: '1.0.0'` | ✅ in this zip |
| 15 | Admin destructive endpoints not district-scoped | ✅ in `index.js` |
| 16 | admin/delete-user doesn't purge media | ✅ in `index.js` |
| 17 | Force-update mechanism failing 100% on both platforms | ✅ in this zip |
| 18 | Share message read like a service promise + em-dashes | ✅ in this zip |
| 19-27 | App Check / auth architecture cluster | deliberately deferred |

Plus the chat-media (photo/voice) feature was added on the backend
side. There is no client UI for it yet - that's a separate UX project.

The force-update fix in this zip is what lets future bumps to
`pubspec.yaml`'s `version:` field actually take effect on installed
devices going forward. Existing users on broken builds will only
pick up the new fix via Play Store / App Store auto-update.

---

## Test plan after install

1. `flutter clean && flutter pub get`
2. Build for both platforms.
3. **Android verification:**
   - Install via Play Internal Testing track.
   - Bump `version:` in pubspec.yaml, ship new build to internal
     testing, wait ~30 min for Play to index.
   - Open the old version → after 4 seconds, blocking dialog should
     appear. Tap "UPDATE NOW" → Google's native full-screen update
     flow takes over. App relaunches on new version.
   - In `flutter logs`, grep for `ForceUpdateService:` to see the
     full Android info dump (availability, immediate-allowed, etc).
4. **iOS verification:**
   - Install via TestFlight.
   - Bump version, ship new build, wait 6-24h for Apple's iTunes
     Lookup CDN to catch up.
   - Open old version → after 4 seconds, blocking dialog. Tap
     "UPDATE NOW" → bounces to App Store.
   - Xcode debug console: grep `ForceUpdateService:` for the
     iTunes lookup result.
5. **Negative test (both platforms):** install latest version →
   open → log should read `installed >= latest, no update`. No
   dialog should appear.

If anything misbehaves, the per-step logs make it possible to
identify which assumption broke without guessing.

---

## Chat-media UI - photo capture + voice record (2026-05-06)

Layered on top of the audit-fixes + group A (location pin, copy text,
download chat as text).

### New files

- `lib/core/services/chat_photo_service.dart` — capture-only photo
  service for chat. Camera (rear default), no gallery. Compresses to
  ~2MB target, falls back to original on compression failure. Uploads
  to `chat_photos/{convId}/`, calls `/chat/attach-photo`. Returns
  structured `ChatPhotoCaptureResult` so the screen can show a
  specific snackbar for cancel / atLimit / permissionDenied /
  uploadFailed / linkFailed.

- `lib/core/services/chat_voice_service.dart` — tap-to-record voice
  service for chat. m4a 64kbps mono, max 30s. Includes the
  unique-filename fix and 5-min stale-file sweep from the SOS-voice
  audit. Owned by ChatScreen for its lifetime; disposed on tear-down.

- `lib/widgets/full_screen_photo_viewer.dart` — black-bg viewer for
  photo bubbles. Top bar: × close, ⬇ save-to-gallery (gal package),
  🗑 delete (only shown to original sender). Bottom: avatar + sender
  name + timestamp.

### Edits

- `lib/screens/chat_screen.dart` — significant additions:
  - Standalone 📍 button replaced by a single 📎 paperclip
  - Paperclip opens bottom sheet with three rows: take photo / record
    voice / share location. Each row shows "X of N" counter (red when
    at-cap)
  - Recording strip replaces composer when recording (red dot, label,
    live counter, ✕ discard, ✓ confirm)
  - At-cap modal lists existing photos/voice with trash buttons; tap
    trash → confirm dialog → detach + reopen capture flow
  - `_MessageBubble` now branches on `kind`:
    - `'photo'` → 180×130 thumbnail, tap → FullScreenPhotoViewer
    - `'voice'` → play/pause + decorative waveform + duration
    - text/location/missing → preserved group-A behaviour
  - Single global active voice player; tapping a different bubble
    stops the previous

- `lib/core/config/api_config.dart` — 4 new endpoint URLs:
  `chatAttachPhotoEndpoint`, `chatDetachPhotoEndpoint`,
  `chatAttachVoiceEndpoint`, `chatDetachVoiceEndpoint`

- `pubspec.yaml` — `gal: ^2.3.1` for save-to-gallery in the photo
  viewer (cross-platform Android MediaStore + iOS PHPhotoLibrary)

### Build

```bash
flutter clean
flutter pub get
flutter build apk --release    # for sideload testing
flutter build appbundle --release   # for Play Store upload
```

### Test plan

1. Existing flows still work: text send, location pin (group A),
   long-press copy, ⋮ menu download chat as text
2. Photo bubble end-to-end: tap 📎 → take photo → confirm → bubble
   appears → tap → full-screen viewer opens → tap ⬇ → photo saved
   to gallery
3. Voice bubble end-to-end: tap 📎 → record voice → wait 8 seconds →
   tap ✓ → voice bubble appears → tap play → audio plays
4. At-cap photo: attach 3 photos → tap 📎 → "Take photo" row shows
   "3 of 3" red → tap row → at-cap modal → trash one → camera reopens
5. At-cap voice: same flow with 4 voice notes
6. Auto-stop at 30s: start recording, leave it; should auto-stop with
   strip still visible for confirm/cancel
7. Discard recording: ✕ → strip closes, no upload
8. Original SOS bug fix still holds: trigger SOS → photo + voice →
   stop → trigger again → SOS shows clean

### Backend dependency

This client requires the chat-media backend changes (caps lowered to
3/4, fallback text on attach, conv-doc message strip on SOS end). All
in this same deploy session. Deploy backend first, then ship the
client.

