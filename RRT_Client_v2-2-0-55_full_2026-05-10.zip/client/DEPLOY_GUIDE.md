# RRT v2.1.10+45 — Deploy guide

This release ships **paired backend + client** changes. The order matters.
Do not skip steps. Do not deploy client first.

---

## TL;DR

```
1. Backup current backend rules + indexes (so you can roll back)
2. Deploy backend:  firebase deploy --only firestore,storage,functions
3. Verify backend  (curl health checks below)
4. Build and submit iOS + Android client apps
5. Watch Crashlytics + logs for the first 24 hours
```

If you deploy the client first, photo and voice upload break for everyone
on the new build. The new client posts to `/sos/attach-photo` and
`/sos/attach-voice`, which don't exist on the old backend. Every upload
returns 404 and the user sees "Photo uploaded but could not attach to
alert."

---

## Step 0 — Pre-flight (5 min)

On a Mac with `firebase-tools` installed and logged in to the
`rrt-sos` project:

```sh
firebase use rrt-sos                          # confirm you're on the right project
firebase functions:list                       # see what's currently deployed
firebase firestore:rules:get > BACKUP-rules.txt  # backup current rules
firebase firestore:indexes -j > BACKUP-indexes.json  # backup current indexes
```

If `firestore:rules:get` doesn't exist on your CLI version, copy the
current rules text from the Firebase Console → Firestore → Rules tab into
`BACKUP-rules.txt` manually.

These backups are your rollback. Don't skip them.

---

## Step 1 — Unpack backend (1 min)

```sh
cd ~/some/work/dir
unzip rrt_backend_v45.zip
cd rrt-cloud-function-v45
```

Confirm structure:

```
.firebaserc
firebase.json                          ← updated to wire rules + storage + indexes
storage.rules                          ← NEW
functions/
  index.js                             ← updated (~345 new lines)
  firestore-security-rules.rules       ← NEW (replaces .txt)
  firestore.indexes.json               ← NEW
  package.json
  package-lock.json
```

Do NOT see `functions/firestore-security-rules.txt` — it's been removed.
If your existing checkout still has it, delete it; firebase CLI will get
confused.

---

## Step 2 — Install + dry-deploy backend (3 min)

```sh
cd functions
npm install
cd ..

# Dry run: shows what WILL change without actually deploying.
# Read this output carefully. Look for:
#   - rules diff (sos_alerts, sos_conversations, subscribed_users, sos_feedback)
#   - new indexes (sos_conversations, sos_alerts composite)
#   - storage rules being created
#   - new functions (api gains 4 attach/detach endpoints, wipeChatsAtMidnightIST scheduled)
firebase deploy --only firestore,storage,functions --dry-run
```

If anything in the dry-run output looks wrong, STOP and look. The next
command actually changes production.

---

## Step 3 — Deploy backend (5–10 min)

```sh
firebase deploy --only firestore,storage,functions
```

What gets deployed:
- **Firestore Security Rules** — instant
- **Firestore composite indexes** — index build time depends on collection
  size. `sos_alerts` index will likely complete in seconds (small
  collection); `sos_conversations` could take minutes if the collection
  is large. The CLI prints a console URL where you can watch the build.
- **Storage rules** — instant
- **Cloud Functions** — typically 2–5 min for v2 functions; first deploy
  of a new scheduled function provisions a Cloud Scheduler job too.

**Don't proceed until index builds show "READY"** in the Firebase Console
under Firestore → Indexes. The conversations list query will throw
`failed-precondition` until the index is ready.

---

## Step 4 — Verify backend (5 min)

Replace `<BASE>` with `https://us-central1-rrt-sos.cloudfunctions.net/api`.

```sh
# 1) Health check
curl -s <BASE>/health
# expect: {"ok":true,...}

# 2) Geocode (needs OLA_MAPS_API_KEY secret to be set)
curl -s "<BASE>/geocode/district?lat=13.34&lng=74.74"
# expect: {"district":"udupi"}  (or similar)

# 3) New attach endpoint exists (will 400 because we send no body, but proves
#    the route is registered — a 404 here means the deploy didn't pick up
#    the new endpoints).
curl -s -X POST <BASE>/sos/attach-photo -H 'Content-Type: application/json' -d '{}'
# expect: {"error":"Missing sender_id or url"}
# NOT expect: {"error":"Endpoint not found", availableEndpoints: [...]}

# 4) Same sanity check for voice
curl -s -X POST <BASE>/sos/attach-voice -H 'Content-Type: application/json' -d '{}'
# expect: {"error":"Missing sender_id or url"}

# 5) /delete-user-data should NO LONGER require auth (v45 dropped it)
curl -s -X POST <BASE>/delete-user-data -H 'Content-Type: application/json' -d '{}'
# expect: {"error":"Missing required field: fid"}
# NOT expect: {"error":"Unauthorized","message":"Missing or invalid authorization header"}
```

If any of these fail to match, STOP. Run the rollback in Step 9 and
investigate before deploying the client.

### Verify the scheduled chat-wipe is registered

In the Firebase Console → Functions tab, you should see two scheduled
functions:
- `expireOldAlertsScheduled` (existing)
- `wipeChatsAtMidnightIST` (new — schedule `0 0 * * *`, timezone `Asia/Kolkata`)

If the new one isn't there, the deploy missed it. Re-run `firebase deploy
--only functions:wipeChatsAtMidnightIST`.

### Verify storage rules

In the Firebase Console → Storage → Rules tab. The published rules should
include the `sos_photos/{senderId}/{filename}` and `sos_voice/{senderId}/{filename}`
allowlists. If you still see the old default rules, the storage entry in
`firebase.json` may be wrong — check that `storage.rules` is referenced
by the file.

---

## Step 5 — Test backend with a real device (10 min)

Before building the client app, test the new attach endpoint manually
using `curl` to confirm the validation logic actually fires.

```sh
# This should fail with "URL does not match sender storage path"
# because the URL doesn't begin with sos_photos/test-fid/
curl -s -X POST <BASE>/sos/attach-photo \
  -H 'Content-Type: application/json' \
  -d '{
    "sender_id": "test-fid",
    "url": "https://example.com/some-other-place/foo.jpg"
  }'
# expect: {"error":"URL does not match sender storage path"}

# This should fail with "Alert not found" (no doc at sos_alerts/test-fid)
curl -s -X POST <BASE>/sos/attach-photo \
  -H 'Content-Type: application/json' \
  -d '{
    "sender_id": "test-fid-no-such-alert",
    "url": "https://firebasestorage.googleapis.com/v0/b/rrt-sos.appspot.com/o/sos_photos%2Ftest-fid-no-such-alert%2Ffoo.jpg?alt=media"
  }'
# expect: {"error":"Alert not found for this sender_id"}
```

If both produce the expected errors, the validation logic works. The
happy path will be exercised in Step 7 with a real device.

---

## Step 6 — Build client (15–30 min)

```sh
cd /path/to/rrt_v45_client
flutter clean
flutter pub get

# iOS — must be done on a Mac
cd ios && pod deintegrate && pod install --repo-update && cd ..

# Build both
flutter build ios --release
flutter build apk --release            # for sideload testing
flutter build appbundle --release      # for Play Store
```

Run preflight before submitting:

```sh
./scripts/preflight.sh
```

It should report 0 fails. The 8 warnings are all benign (16 `getId()`
call sites flagged for the future centralization refactor; a single
`update()` call that's a Riverpod state update, not Firestore; benign
empty-catch comments).

---

## Step 7 — Smoke test (15 min, REQUIRED)

This is the only thing that catches "looked OK on paper but broken in
the wild." On a real Android device AND a real iPhone:

1. Fresh install. Onboard. Verify GPS picks up your district.
2. Send an SOS with description "test alert".
3. On the active SOS screen:
   - Add a photo. Watch network logs (Firebase console → Storage)
     to confirm the upload landed under `sos_photos/{your-fid}/`.
   - Watch Functions logs to confirm `attach-photo` succeeded for the
     same FID.
   - The photo appears in the strip with a thumbnail.
   - Add a voice clip. Same checks for `sos_voice/...` and
     `attach-voice`.
4. From a SECOND device in the same district (or a colleague's device):
   - Open the Alerts tab. Confirm your alert appears.
   - Tap your alert. Photos and voice should be visible.
   - Tap CHAT. Send a message.
5. Back on the first device:
   - Open the Chats tab. Confirm the conversation appears.
   - Reply.
6. STOP the SOS on the first device. Both alert visibility AND chat
   should flip to archived.
7. Tomorrow at 00:01 IST, confirm the conversation is gone (chat wipe).
   Or trigger the wipe manually for testing:
   ```
   firebase functions:shell
   wipeChatsAtMidnightIST({})
   ```
8. Profile tab → Delete my data → confirm. Reopen the app — should drop
   you back to onboarding (local data cleared) AND
   `sos_alerts/{your-fid}` and `subscribed_users/{your-fid}` should be
   gone in Firestore (server data deleted, which is the v45 fix).

If any step fails, do NOT submit to stores. Roll back (Step 9) and
re-investigate.

---

## Step 8 — Submit to stores (release-day flow)

```sh
# Android — Play Console
# Upload .aab from build/app/outputs/bundle/release/

# iOS — App Store Connect
# Submit via Xcode or fastlane
```

Phased rollout recommended for Play Store: 5% for 24h, then 20%, then
100%. Watch Crashlytics for spike in:
- `permission-denied` (rules deploy partial)
- `not-found` on attach (alert-create race — expected at low rate)
- `429` (rate-limit hit; investigate if persistent)

For iOS, no phased rollout option natively — submit and watch
Crashlytics closely for the first 24h.

---

## Step 9 — Rollback (if something is wrong)

### Backend rollback

Restore from your backups:

```sh
# Restore rules
cp BACKUP-rules.txt functions/firestore-security-rules.rules
firebase deploy --only firestore:rules

# Re-deploy old functions (you'd need the old git tag — make sure it's
# tagged before deploying v45):
git checkout <previous-tag>
cd functions && npm install && cd ..
firebase deploy --only functions
```

### Indexes rollback

Indexes are mostly additive — leaving the v45 indexes in place after a
rollback is safe and even helpful (the old client doesn't use them but
nothing breaks). Don't bother rolling them back unless you have a strong
reason.

### Storage rules rollback

There were no Storage rules before v45 — so a "rollback" is to either
leave the v45 rules in place (recommended; they're stricter than nothing)
OR restore whatever the Firebase Console default was. The v45 rules
shouldn't break the old client because the old client wrote to the same
storage paths with the same content types.

### Client rollback

Play Store: halt rollout in Play Console; users on the broken version
remain on it but no new users get it. Push a fast-follow that reverts.
App Store: requires a new submission with the old build.

---

## Known follow-ups (NOT in this release)

These were flagged in the audit but deliberately left for a future
release to keep v45 focused on "make the broken things work":

1. Centralize `senderId` — there are 16 places that independently call
   `FirebaseInstallations.instance.getId()`. Should fetch once on app
   start, cache in `sosStateProvider`, read from there everywhere. Risk
   pattern: if two `getId()` calls return different values within one
   logical operation, photos land on a different doc than the alert.
   Hasn't been observed in practice (Installation IDs are usually
   stable), but it's a latent bug.
2. Wire Firebase Crashlytics non-fatal errors at every `catch` in
   `lib/core/services/`. Without this, you have no telemetry on how
   often any of the v45 fixes is succeeding or failing in production.
3. Wire Firebase Analytics events at every service-boundary
   success/failure. Same reasoning.
4. Add Firebase App Check, then tighten the rate-limiter on attach
   endpoints to require a valid App Check token rather than just an
   FID claim.
5. Pagination on the responders list (`responders_screen.dart` reads
   `subscribed_users.where(district)` with no `.limit()`). Now that
   reads are unblocked by v45, large districts could OOM the app.

---

## Open questions (for product / ops)

- Chat wipe timezone is hardcoded to IST. If you have responders in
  other timezones, "midnight" lands at a different local time for them.
  Acceptable? If not, the schedule needs to be per-user instead of
  global.
- Storage retention beyond 60 min: photos and voice are deleted on
  alert auto-expire. There's no longer-term archive. If you need
  historical photos for case review, plumb in a copy-to-archive step
  before delete.
