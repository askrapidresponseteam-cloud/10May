# Release preflight

`./scripts/preflight.sh` — a static check that catches the classes of bugs
that have shipped from this repo before. Run it before every release.

## Usage

```sh
./scripts/preflight.sh             # run all checks
./scripts/preflight.sh --list      # show all checks
./scripts/preflight.sh ios_macros  # run a single check
NO_COLOR=1 ./scripts/preflight.sh  # for CI / log files
```

Exit codes: `0` ok, `1` failures (do not ship), `2` invocation error.

## What it checks

| Check                          | Catches                                             |
|--------------------------------|-----------------------------------------------------|
| `pubspec_lock_synced`          | pubspec.yaml newer than pubspec.lock                |
| `version_bumped`               | shipping the same version twice                     |
| `ios_deployment_target`        | iOS target below Firebase minimum (13.0)            |
| `ios_macros`                   | **the v2.1.10+43 camera/mic blocker**: missing PERMISSION_X=1 macros in Podfile |
| `ios_usage_strings`            | Info.plist missing NSCameraUsageDescription etc — App Store rejection + iOS crash |
| `ios_pods_complete`            | **the OTHER v2.1.10+43 blocker**: stale Podfile.lock missing native pods |
| `android_manifest_permissions` | runtime permission requests with no manifest entry — SecurityException |
| `installation_id_usage`        | multiple `FirebaseInstallations.getId()` callers (senderId drift risk) |
| `firestore_update_pattern`     | `.update()` calls that should be `.set(merge:true)` (the photo/voice "uploaded but not saved" bug) |
| `silent_catches`               | `catch (_) {}` blocks that swallow real failures    |
| `secrets`                      | hardcoded API keys (Google, Stripe, GitHub) in source |
| `todos`                        | unresolved TODO/FIXME/XXX/HACK in lib/              |
| `dart_format`                  | unformatted files                                   |
| `flutter_analyze`              | type errors, unused imports, dead code              |
| `flutter_test`                 | test failures                                       |

## What it CANNOT catch

A static script can't replace device testing. It will not catch:

- Whether the iOS camera prompt actually fires on a real iPhone
- UI regressions (overlapping widgets, wrong colors, broken layouts)
- Backend race conditions (alert doc not yet propagated when client writes)
- Firestore Security Rules rejecting client writes
- Network/offline behaviour
- Real user permission states (granted, denied, permanently denied)

You still need a manual smoke pass on at least one real Android device and
one real iPhone for every release. The script is the *gate* — it stops
known-bad builds from reaching that step. It is not a substitute for it.

## When a check fails

A `✗` line is a hard blocker. The line tells you what to fix. Examples:

- `✗ Camera is requested via permission_handler but PERMISSION_CAMERA=1 is missing from ios/Podfile`
  → Add the macro to ios/Podfile post_install block, then `cd ios && pod install`
- `✗ permission_handler is in pubspec.yaml but its iOS pod is NOT in Podfile.lock`
  → `cd ios && pod deintegrate && pod install --repo-update`
- `! 4 .update() call(s) in lib/`
  → Open each, decide if the doc is guaranteed to exist; if not, switch to `.set({...}, SetOptions(merge: true))`

## Adding new checks

Each check is a bash function named `check_<name>` that calls
`pass`/`fail`/`warn`/`info`. Add the function, then add `<name>` to the
`CHECKS` array. Rule of thumb:

- **fail**: code WILL break in production
- **warn**: suspicious, needs human review
- **info**: passive note (skip reason, etc)

Every time a real bug ships to production, write a check that would have
caught it and add it here. That's how this script grows — every regression
becomes a permanent gate.
