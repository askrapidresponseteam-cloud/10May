#!/usr/bin/env bash
# preflight.sh — release readiness checks for the RRT Flutter app.
#
# Run from the repo root:    ./scripts/preflight.sh
# Run a single check:        ./scripts/preflight.sh ios_macros
# List available checks:     ./scripts/preflight.sh --list
# CI mode (no colors):       NO_COLOR=1 ./scripts/preflight.sh
#
# Exit codes:
#   0 = all checks passed (or only warnings)
#   1 = one or more checks failed (DO NOT SHIP)
#   2 = script invoked incorrectly
#
# Each check is a function named  check_<name>  that prints PASS/FAIL/WARN
# lines and updates the global counters. Add new checks by defining a new
# function and listing its name in CHECKS.
#
# A FAIL means "this WILL break in production, do not ship". A WARN means
# "this is suspicious, look at it before shipping but it's not necessarily
# a blocker". The exit code is FAIL-driven only.

set -uo pipefail

# ---------- terminal output ----------
if [[ -t 1 && -z "${NO_COLOR:-}" ]]; then
  RED=$'\033[0;31m'; GREEN=$'\033[0;32m'; YELLOW=$'\033[0;33m'
  BLUE=$'\033[0;34m'; BOLD=$'\033[1m'; DIM=$'\033[2m'; RESET=$'\033[0m'
else
  RED=''; GREEN=''; YELLOW=''; BLUE=''; BOLD=''; DIM=''; RESET=''
fi

# ---------- counters ----------
PASSED=0; FAILED=0; WARNED=0
FAIL_LIST=()
WARN_LIST=()

pass() { printf '  %s✓%s %s\n' "$GREEN" "$RESET" "$1"; PASSED=$((PASSED+1)); }
fail() { printf '  %s✗%s %s\n' "$RED" "$RESET" "$1"; FAILED=$((FAILED+1)); FAIL_LIST+=("$1"); }
warn() { printf '  %s!%s %s\n' "$YELLOW" "$RESET" "$1"; WARNED=$((WARNED+1)); WARN_LIST+=("$1"); }
info() { printf '  %s·%s %s\n' "$DIM" "$RESET" "$1"; }
section() { printf '\n%s== %s ==%s\n' "$BOLD" "$1" "$RESET"; }

# ---------- repo root sanity ----------
if [[ ! -f pubspec.yaml ]]; then
  printf '%sERROR%s: run this from the repo root (no pubspec.yaml in CWD)\n' "$RED" "$RESET" >&2
  exit 2
fi

# ============================================================================
# CHECKS
# Each check is independent. Order in CHECKS determines run order.
# ============================================================================

# --- iOS: permission_handler macros are set in Podfile -----------------------
# This is the bug that broke camera/mic on iOS in v2.1.10+43.
check_ios_macros() {
  section "iOS: permission_handler macros"
  local podfile=ios/Podfile
  if [[ ! -f $podfile ]]; then
    fail "$podfile not found"
    return
  fi
  # If permission_handler isn't even a dependency, the macros don't apply.
  if ! grep -qE "^\s+permission_handler:" pubspec.yaml; then
    info "permission_handler not in pubspec.yaml — skipping (macros are this package's contract)"
    return
  fi

  # The macros only matter for permissions actually exercised through
  # permission_handler. We DON'T require macros for permissions that come
  # exclusively from native plugins (geolocator's location, image_picker's
  # photos) — those plugins request iOS permission natively via their own
  # code, not through permission_handler.
  check_macro() {
    local macro=$1 label=$2 dart_regex=$3
    if grep -rqE "$dart_regex" lib/ --include="*.dart"; then
      if grep -qE "['\"]${macro}=1['\"]" "$podfile"; then
        pass "$label: $macro=1"
      else
        fail "$label is requested via permission_handler but $macro=1 is missing from $podfile — iOS prompt will NEVER fire"
      fi
    else
      info "$label not requested via permission_handler — skipping"
    fi
  }
  check_macro "PERMISSION_CAMERA"             "Camera"     "Permission\.camera"
  check_macro "PERMISSION_MICROPHONE"         "Microphone" "Permission\.microphone"
  check_macro "PERMISSION_PHOTOS"             "Photos"     "Permission\.photos"
  check_macro "PERMISSION_LOCATION_WHENINUSE" "Location"   "Permission\.location"
}

# --- iOS: Podfile.lock has every native plugin pubspec.yaml declares ---------
# This is the OTHER bug that broke camera/mic on iOS — the lock was stale and
# half the pods weren't installed.
check_ios_pods_complete() {
  section "iOS: Podfile.lock has every Flutter plugin"
  local lock=ios/Podfile.lock
  if [[ ! -f $lock ]]; then
    warn "$lock missing — run 'cd ios && pod install' on a Mac before shipping"
    return
  fi

  # Plugins that need a corresponding iOS pod. Map Flutter package name to
  # the pod name(s) they ship — sometimes they differ (e.g. record →
  # record_darwin, image_picker → image_picker_ios).
  declare -A flutter_to_pod=(
    [permission_handler]="permission_handler_apple"
    [record]="record_darwin record_ios"
    [image_picker]="image_picker_ios"
    [flutter_image_compress]="flutter_image_compress_common flutter_image_compress_macos flutter_image_compress"
    [firebase_storage]="firebase_storage"
    [just_audio]="just_audio"
    [path_provider]="path_provider_foundation"
    [geolocator]="geolocator_apple"
    [shared_preferences]="shared_preferences_foundation"
    [url_launcher]="url_launcher_ios"
    [firebase_messaging]="firebase_messaging"
    [firebase_core]="firebase_core"
    [cloud_firestore]="cloud_firestore"
    [firebase_app_installations]="firebase_app_installations"
    [firebase_remote_config]="firebase_remote_config"
    [flutter_local_notifications]="flutter_local_notifications"
    [geocoding]="geocoding_ios"
  )

  for pkg in "${!flutter_to_pod[@]}"; do
    # Is the package actually used? We grep pubspec for the package name as
    # a top-level dep. The (\s|:) is to avoid matching e.g. `record_darwin`
    # when looking for `record`.
    if ! grep -qE "^\s+${pkg}:" pubspec.yaml; then
      continue
    fi
    local pods="${flutter_to_pod[$pkg]}"
    local found=0
    for pod in $pods; do
      if grep -q "^  - ${pod}" "$lock" || grep -q "^  ${pod}:" "$lock"; then
        found=1
        break
      fi
    done
    if [[ $found -eq 1 ]]; then
      pass "$pkg → pod present in Podfile.lock"
    else
      fail "$pkg is in pubspec.yaml but its iOS pod ($pods) is NOT in Podfile.lock — stale lock, run 'cd ios && pod install'"
    fi
  done
}

# --- iOS: Info.plist has usage strings for every Permission.X used -----------
# Note: usage strings are needed when EITHER the Dart code calls
# Permission.X via permission_handler, OR a plugin (image_picker,
# geolocator, record) requests the OS permission natively. We check
# both signals.
check_ios_usage_strings() {
  section "iOS: Info.plist usage descriptions"
  local plist=ios/Runner/Info.plist
  if [[ ! -f $plist ]]; then
    fail "$plist not found"
    return
  fi

  # check_string <plist_key> <label> <dart_signal_regex> <pubspec_pkg_alt...>
  # Passes if EITHER the dart regex matches in lib/, OR any of the
  # listed packages is in pubspec.yaml.
  check_string() {
    local plist_key=$1 label=$2 dart_regex=$3
    shift 3
    local needed=0
    if grep -rqE "$dart_regex" lib/ --include="*.dart"; then needed=1; fi
    for pkg in "$@"; do
      if grep -qE "^\s+${pkg}:" pubspec.yaml; then needed=1; fi
    done
    if [[ $needed -eq 0 ]]; then
      info "$label not used — skipping"
      return
    fi
    if grep -q "<key>${plist_key}</key>" "$plist"; then
      pass "$label: $plist_key present"
    else
      fail "$label is in use but $plist_key is missing from Info.plist — App Store rejection + iOS runtime crash"
    fi
  }
  check_string "NSCameraUsageDescription"     "Camera"     "Permission\.camera"     image_picker
  check_string "NSMicrophoneUsageDescription" "Microphone" "Permission\.microphone" record
  check_string "NSPhotoLibraryUsageDescription" "Photos"   "Permission\.photos"     image_picker
  check_string "NSLocationWhenInUseUsageDescription" "Location" "Permission\.location|LocationPermission\." geolocator
}

# --- Android: AndroidManifest declares every runtime-requested permission ----
# Same pattern as iOS — the permission may come from Dart via permission_handler
# OR from a plugin requesting natively (image_picker, geolocator, record).
check_android_manifest_permissions() {
  section "Android: manifest permissions match runtime requests"
  local manifest=android/app/src/main/AndroidManifest.xml
  if [[ ! -f $manifest ]]; then
    fail "$manifest not found"
    return
  fi

  check_perm() {
    local android_perm=$1 label=$2 dart_regex=$3
    shift 3
    local needed=0
    if grep -rqE "$dart_regex" lib/ --include="*.dart"; then needed=1; fi
    for pkg in "$@"; do
      if grep -qE "^\s+${pkg}:" pubspec.yaml; then needed=1; fi
    done
    if [[ $needed -eq 0 ]]; then
      info "$label not used — skipping"
      return
    fi
    if grep -q "android.permission.${android_perm}" "$manifest"; then
      pass "$label: ${android_perm} declared"
    else
      fail "$label is in use but ${android_perm} is missing from AndroidManifest.xml — runtime SecurityException"
    fi
  }
  check_perm "CAMERA"               "Camera"        "Permission\.camera"     image_picker
  check_perm "RECORD_AUDIO"         "Microphone"    "Permission\.microphone" record
  check_perm "ACCESS_FINE_LOCATION" "Location"      "Permission\.location|LocationPermission\." geolocator
  check_perm "POST_NOTIFICATIONS"   "Notifications" "Permission\.notification" firebase_messaging flutter_local_notifications
  check_perm "INTERNET"             "Internet"      "http\.|HttpClient|Uri\.parse" http firebase_core
}

# --- Firestore: .update() on documents that may not exist --------------------
# This was the Android "uploaded but never saved" bug: .update() throws
# not-found if the doc isn't materialised yet. Use .set(merge:true) for any
# write that may run before the doc is guaranteed to exist.
check_firestore_update_pattern() {
  section "Firestore: .update() vs .set(merge:true)"
  # Match patterns like:   .doc(senderId).update({   or   .doc(...).update(
  # We allow .update() but warn — many are legit (e.g. updating a doc that
  # the same client just created). The point is to make a human review each.
  local hits
  hits=$(grep -rn "\.update(" lib/ --include="*.dart" | grep -v "//.*\.update(" || true)
  if [[ -z "$hits" ]]; then
    pass "no .update() calls in lib/"
    return
  fi
  local count
  count=$(printf '%s\n' "$hits" | wc -l | tr -d ' ')
  warn "$count .update() call(s) in lib/ — verify each writes to a doc the client owns:"
  printf '%s\n' "$hits" | sed 's/^/      /'
  echo
  info "If any of these run before the doc is guaranteed to exist on the"
  info "client, switch to .set({...}, SetOptions(merge: true)) — update()"
  info "throws not-found and that error has bitten this app before."
}

# --- Silent error swallowing -------------------------------------------------
# catch (e) {} or catch (_) {} with no body — the exact pattern that hid
# the Firestore link-fail bug. We look for the common empty-body shapes:
#   } catch (e) {}
#   } catch (_) {}
#   } catch (...) {/* comment only */}
# Multi-line empty bodies (open brace on next line, close on the line after,
# nothing in between) are harder to catch reliably with grep — we match the
# most common single-line pattern and leave a note for the rest.
check_silent_catches() {
  section "Silent error swallowing"
  # Pattern: catch (anything) { optional whitespace, optional /* comment */, } on the same line.
  # Examples it matches:  catch (e) {}     catch (_) {/* ignore */}    catch (e) { }
  # Examples it skips:    catch (e) { debugPrint(...); }     catch (e) { return null; }
  local pattern='catch[[:space:]]*\([^)]*\)[[:space:]]*\{[[:space:]]*(/\*[^*]*\*/)?[[:space:]]*\}'
  local hits
  hits=$(grep -rEn "$pattern" lib/ --include="*.dart" || true)

  # Multi-line empty-body case: catch (...) { followed by a line that is just }
  # We detect this with a small awk that resets NR per file (FNR).
  local multi_hits
  multi_hits=$(find lib/ -name '*.dart' -print0 | xargs -0 awk '
    /catch[[:space:]]*\([^)]*\)[[:space:]]*\{[[:space:]]*$/ {
      open_line = FNR; open_text = $0; in_catch = 1; next
    }
    in_catch == 1 {
      # Strip whitespace and trailing comments
      line = $0
      sub(/\/\/.*$/, "", line)
      gsub(/[[:space:]]/, "", line)
      if (line == "}") {
        printf "%s:%d: %s\n", FILENAME, open_line, open_text
      }
      in_catch = 0
    }
  ' 2>/dev/null || true)

  local all_hits
  if [[ -n "$hits" && -n "$multi_hits" ]]; then
    all_hits=$(printf '%s\n%s\n' "$hits" "$multi_hits")
  else
    all_hits="${hits}${multi_hits}"
  fi

  if [[ -z "$all_hits" ]]; then
    pass "no obvious empty catch blocks in lib/"
  else
    local count
    count=$(printf '%s\n' "$all_hits" | wc -l | tr -d ' ')
    warn "$count empty catch block(s) — at minimum log via debugPrint, consider surfacing to user:"
    printf '%s\n' "$all_hits" | head -15 | sed 's/^/      /'
    [[ $count -gt 15 ]] && info "... and $((count-15)) more"
  fi
}

# --- Hardcoded secrets / keys ------------------------------------------------
check_secrets() {
  section "Hardcoded secrets"
  # Common patterns: AIza... (Google API keys), sk_live_, ghp_, etc.
  # We scan lib/ and android+ios config that ISN'T google-services.json /
  # GoogleService-Info.plist (those are expected to contain keys).
  local hits
  hits=$(grep -rEn "AIza[0-9A-Za-z_-]{35}|sk_live_[0-9a-zA-Z]{24,}|ghp_[0-9a-zA-Z]{36}" \
    lib/ android/app/src/main 2>/dev/null \
    | grep -v 'google-services.json' || true)
  if [[ -z "$hits" ]]; then
    pass "no obvious API keys/secrets in source"
  else
    fail "possible secrets in source — review and move to env/Remote Config:"
    printf '%s\n' "$hits" | sed 's/^/      /'
  fi
}

# --- TODO / FIXME / XXX in lib/ ----------------------------------------------
check_todos() {
  section "TODO / FIXME / XXX markers"
  local hits
  hits=$(grep -rEn "(TODO|FIXME|XXX|HACK)[: ]" lib/ --include="*.dart" || true)
  if [[ -z "$hits" ]]; then
    pass "no unresolved TODO/FIXME/XXX in lib/"
  else
    local count
    count=$(printf '%s\n' "$hits" | wc -l | tr -d ' ')
    warn "$count TODO/FIXME/XXX in lib/ — review before release:"
    printf '%s\n' "$hits" | head -10 | sed 's/^/      /'
    [[ $count -gt 10 ]] && info "... and $((count-10)) more"
  fi
}

# --- Version bump in pubspec.yaml --------------------------------------------
# Compares pubspec version against last git tag; if no bump, fail.
check_version_bumped() {
  section "pubspec version bumped vs last release"
  if ! command -v git >/dev/null 2>&1 || [[ ! -d .git ]]; then
    info "no git repo — skipping"
    return
  fi
  local current last
  current=$(grep -E '^version:' pubspec.yaml | awk '{print $2}')
  last=$(git tag --sort=-version:refname 2>/dev/null | head -1 | sed 's/^v//')
  if [[ -z "$last" ]]; then
    info "no git tags found — skipping (this is your first release?)"
    pass "current version: $current"
    return
  fi
  if [[ "$current" == "$last" ]]; then
    fail "pubspec version ($current) matches last tag ($last) — bump version before release"
  else
    pass "$last → $current"
  fi
}

# --- flutter analyze ---------------------------------------------------------
check_flutter_analyze() {
  section "flutter analyze"
  if ! command -v flutter >/dev/null 2>&1; then
    warn "flutter not on PATH — skipping (install Flutter to enable this check)"
    return
  fi
  local out
  if out=$(flutter analyze --no-pub 2>&1); then
    pass "no analyzer issues"
  else
    fail "flutter analyze reported issues:"
    printf '%s\n' "$out" | tail -30 | sed 's/^/      /'
  fi
}

# --- dart format -------------------------------------------------------------
check_dart_format() {
  section "dart format"
  if ! command -v dart >/dev/null 2>&1; then
    warn "dart not on PATH — skipping"
    return
  fi
  if dart format --output=none --set-exit-if-changed lib/ test/ >/dev/null 2>&1; then
    pass "all files formatted"
  else
    warn "some files are not formatted — run 'dart format lib/ test/'"
  fi
}

# --- flutter test ------------------------------------------------------------
check_flutter_test() {
  section "flutter test"
  if ! command -v flutter >/dev/null 2>&1; then
    warn "flutter not on PATH — skipping"
    return
  fi
  if [[ ! -d test ]] || [[ -z "$(find test -name '*_test.dart' 2>/dev/null)" ]]; then
    warn "no tests found in test/ — write some, especially for SosPhotoService and SosVoiceService"
    return
  fi
  local out
  if out=$(flutter test --no-pub 2>&1); then
    pass "all tests pass"
  else
    fail "flutter test failed:"
    printf '%s\n' "$out" | tail -40 | sed 's/^/      /'
  fi
}

# --- Sender ID consistency check ---------------------------------------------
# Risk pattern from this codebase: FirebaseInstallations.instance.getId() is
# fetched in two places independently. If it ever returns a different value
# between the alert send and the photo upload, the photo lands on a non-
# existent doc.
check_installation_id_usage() {
  section "FirebaseInstallations.getId() consistency"
  local hits
  hits=$(grep -rn "FirebaseInstallations\.instance\.getId" lib/ --include="*.dart" || true)
  if [[ -z "$hits" ]]; then
    pass "no direct getId() calls (good — should flow through state)"
    return
  fi
  local count
  count=$(printf '%s\n' "$hits" | wc -l | tr -d ' ')
  if [[ $count -le 1 ]]; then
    pass "getId() called from $count site"
  else
    warn "$count direct getId() calls — risk of inconsistent senderId between alert-create and media-upload paths:"
    printf '%s\n' "$hits" | sed 's/^/      /'
    info "Prefer fetching once and reading from sosStateProvider.senderId"
  fi
}

# --- pubspec.lock and pubspec.yaml in sync -----------------------------------
check_pubspec_lock_synced() {
  section "pubspec.lock sync"
  if [[ ! -f pubspec.lock ]]; then
    fail "pubspec.lock missing — run 'flutter pub get'"
    return
  fi
  if [[ pubspec.yaml -nt pubspec.lock ]]; then
    warn "pubspec.yaml is newer than pubspec.lock — run 'flutter pub get'"
  else
    pass "pubspec.lock up to date"
  fi
}

# --- iOS deployment target ---------------------------------------------------
check_ios_deployment_target() {
  section "iOS deployment target"
  local podfile=ios/Podfile
  if [[ ! -f $podfile ]]; then return; fi
  local target
  target=$(grep -E "^platform :ios" "$podfile" | grep -oE "[0-9]+\.[0-9]+" | head -1)
  if [[ -z "$target" ]]; then
    warn "could not determine iOS deployment target"
    return
  fi
  # Firebase iOS SDK requires iOS 13+. permission_handler 11+ requires 12+.
  local major=${target%%.*}
  if [[ $major -ge 13 ]]; then
    pass "iOS deployment target: $target"
  else
    fail "iOS deployment target is $target — Firebase requires 13.0+, will fail to build"
  fi
}

# ============================================================================
# RUNNER
# ============================================================================

# Order matters: cheap checks first so a fail-fast user gets feedback fast.
CHECKS=(
  pubspec_lock_synced
  version_bumped
  ios_deployment_target
  ios_macros
  ios_usage_strings
  ios_pods_complete
  android_manifest_permissions
  installation_id_usage
  firestore_update_pattern
  silent_catches
  secrets
  todos
  dart_format
  flutter_analyze
  flutter_test
)

usage() {
  cat <<EOF
preflight.sh — release-readiness checks

Usage:
  $(basename "$0")              run all checks
  $(basename "$0") <name>       run one check (e.g. ios_macros)
  $(basename "$0") --list       list all checks
  $(basename "$0") -h | --help  show this help

Exit codes: 0 ok, 1 failures, 2 usage error
Set NO_COLOR=1 to disable terminal colors.
EOF
}

case "${1:-}" in
  -h|--help) usage; exit 0 ;;
  --list)
    for c in "${CHECKS[@]}"; do printf '  %s\n' "$c"; done
    exit 0
    ;;
  '')
    for c in "${CHECKS[@]}"; do "check_${c}"; done
    ;;
  *)
    if ! declare -f "check_$1" >/dev/null 2>&1; then
      printf 'unknown check: %s\n' "$1" >&2
      printf 'run with --list to see available checks\n' >&2
      exit 2
    fi
    "check_$1"
    ;;
esac

# ---------- summary ----------
printf '\n%s── summary ──%s\n' "$BOLD" "$RESET"
printf '  %s%d passed%s   %s%d warned%s   %s%d failed%s\n' \
  "$GREEN" "$PASSED" "$RESET" \
  "$YELLOW" "$WARNED" "$RESET" \
  "$RED" "$FAILED" "$RESET"

if [[ $FAILED -gt 0 ]]; then
  printf '\n%sBLOCKERS — DO NOT SHIP:%s\n' "$RED" "$RESET"
  for f in "${FAIL_LIST[@]}"; do printf '  • %s\n' "$f"; done
  exit 1
fi

if [[ $WARNED -gt 0 ]]; then
  printf '\n%s%d warning(s) — review before shipping but not blocking%s\n' "$YELLOW" "$WARNED" "$RESET"
fi

printf '\n%s✓ ready to ship%s\n' "$GREEN" "$RESET"
exit 0
